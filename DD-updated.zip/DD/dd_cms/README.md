# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and [`typescript-eslint`](https://typescript-eslint.io) in your project.


VITE_API_BASE_URL_local=http://192.168.1.71:3010/api
VITE_WEBPATH=http://192.168.1.71:5173
 
Stage-cmo
VITE_API_BASE_URL=
VITE_API_BASE_URL_REPORT=
VITE_API_BASE_URL_local=
VITE_WEBPATH=
VITE_API_BASE_URL_PROD=
 
VITE_STATIC=http://localhost:3010