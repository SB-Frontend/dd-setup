// hooks/usePermission.js
import { useAuth } from '@/context/AuthContext';

export const usePermission = (permId) => {
  const { permissions } = useAuth();
  const parsed = Array.isArray(permissions)
    ? permissions
    : JSON.parse(permissions || '[]');

    // console.log(parsed)

  return parsed.find(p => p.perm_id === permId) || {};
};
