import { useEffect } from 'react';

const slugify = (text) =>
  text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '') // remove special chars
    .replace(/\s+/g, '-')         // spaces to dashes
    .replace(/-+/g, '-');         // collapse multiple dashes

const useAutoSlug = (watch, setValue, sourceField = 'title', targetField = 'slug') => {
  const sourceValue = watch(sourceField);

  useEffect(() => {
    if (sourceValue !== undefined) {
      const slug = slugify(sourceValue);
      setValue(targetField, slug, { shouldValidate: true });
    }
  }, [sourceValue, setValue, targetField]);
};

export default useAutoSlug;
