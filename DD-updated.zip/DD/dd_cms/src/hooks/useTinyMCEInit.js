import { useEffect } from 'react';

const useTinyMCEInit = ({ scriptsLoaded, editors = [], webPath }) => {
  useEffect(() => {
    if (!scriptsLoaded || !window.tinymce) return;

    // Cleanup any existing editor instances BEFORE initializing new ones
    editors.forEach(({ id }) => {
      const existingEditor = window.tinymce.get(id);
      if (existingEditor) existingEditor.remove();
    });

    // Now safely initialize
    editors.forEach(({ id, content }) => {
      window.tinymce.init({
        selector: `textarea#${id}`,
        mode: "exact",
        readonly: false,
        plugins: 'searchreplace ice icesearchreplace print preview paste importcss autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern noneditable help quickbars emoticons',
        toolbar1: 'undo redo | bold italic underline strikethrough | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | outdent indent | numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen preview save print | insertfile image media template link anchor codesample | ltr rtl',
        toolbar2: "ice_togglechanges | ice_toggleshowchanges | iceacceptall icerejectall | iceaccept icereject",
        extended_valid_elements: "p,span[*],delete[*],insert[*]",
        quickbars_selection_toolbar: 'bold italic | quicklink h2 h3 blockquote quickimage quicktable addComment',
        noneditable_noneditable_class: "mceNonEditable",
        toolbar_mode: 'sliding',
        contextmenu: "link image imagetools table",
        height: 500,
        image_caption: true,
        content_css: `${webPath}/assets/js/ice/demo.css`,
        setup: function (editor) {
          editor.on('init', () => {
            console.log(`✅ Initialized TinyMCE: ${id}`);
            const safeContent = typeof content === 'string' ? content : '';
            editor.setContent(safeContent);
          });

          editor.ui.registry.addButton('addComment', {
            text: 'Add Comment',
            onAction: function () {
              const selectedText = editor.selection.getContent();
              if (selectedText) {
                const comment = window.prompt('Add a comment for the selected text:');
                if (comment) {
                  editor.execCommand(
                    'mceInsertContent',
                    false,
                    `<insert class="ins comm ">${selectedText}</insert> <insert class="del viewComment cts-1"> - (Comment by John Cena - ${comment})</insert>`
                  );
                }
              } else {
                alert('Please select some text to add a comment.');
              }
            }
          });
        },
        ice: {
          user: {
            name: 'John Cena',
            id: '10000000'
          },
          preserveOnPaste: 'p,a[href],i,em,b,span',
          deleteTag: 'delete',
          insertTag: 'insert',
          commentTag: 'comment'
        }
      });
    });

    // Cleanup when component unmounts or dependency changes
    return () => {
      editors.forEach(({ id }) => {
        const editor = window.tinymce.get(id);
        if (editor) editor.remove();
      });
    };
  }, [scriptsLoaded, editors, webPath]);
};

export default useTinyMCEInit;
