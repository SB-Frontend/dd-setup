import { useEffect, useState } from 'react';

const useLoadScripts = (webPath) => {
  const [scriptsLoaded, setScriptsLoaded] = useState(false);

  useEffect(() => {
    const loadScripts = async () => {
      const loadScript = (src) => {
        return new Promise((resolve) => {
          const script = document.createElement('script');
          script.src = src;
          script.onload = resolve;
          document.head.appendChild(script);
        });
      };

      await loadScript(`${webPath}/assets/js/jquery-3.6.0.min.js`);
      await loadScript(`${webPath}/assets/js/jquery-migrate-1.0.0.js`);
      await loadScript(`${webPath}/assets/js/ice/ice-master.min.js`);
      await loadScript(`${webPath}/assets/js/ice/lib/tinymce/tinymce.js`);

      setScriptsLoaded(true);
    };

    loadScripts();
  }, [webPath]);

  return scriptsLoaded;
};

export default useLoadScripts;
