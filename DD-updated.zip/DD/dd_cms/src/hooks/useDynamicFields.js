import { useState } from 'react';

export const useDynamicFields = (initialState) => {
    const [fields, setFields] = useState(initialState);
    const addField = () => setFields([...fields, { ...initialState[0] }]);
    const removeField = (index) => setFields(fields.filter((_, i) => i !== index));
    const handleChange = (index, field, value) => {
      const updated = [...fields];
      updated[index][field] = value;
      setFields(updated);
    };
    return [fields, addField, removeField, handleChange];
  };
