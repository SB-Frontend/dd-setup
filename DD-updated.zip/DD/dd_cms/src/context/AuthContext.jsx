import { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const storedUser = localStorage.getItem("user");
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const [token, setToken] = useState(() => {
    return localStorage.getItem('token') || null;
  });

  // const [permissions, setPermissions] = useState(() => {
  //   const storedPermissions = localStorage.getItem('permissions');
  //   return storedPermissions ? JSON.parse(storedPermissions) : null;
  // });

  const login = (userData, token, perms) => {
    setUser(userData);
    setToken(token);
    // setPermissions(perms);
    localStorage.setItem('user', JSON.stringify(userData));
    localStorage.setItem('token', token);
    // localStorage.setItem('permissions', JSON.stringify(perms));
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    // setPermissions(null);
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    // localStorage.removeItem('permissions');
  };

  return (
    //  value={{ user, token, permissions, login, logout }}>
    <AuthContext.Provider value={{ user, token, login, logout }}>  
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
