import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const MySwal = withReactContent(Swal);

export const showTailwindAlert = async ({
  title = 'Success!',
  text = 'Form has been submitted.',
  // html = "Form has been submitted.",
  icon = '',
  confirmButtonText = 'OK',
  cancelButtonText = 'Cancel',
  showConfirmButton = true,
  showCancelButton = false,
  allowOutsideClick = false,
  confirmButtonClass = 'bg-blue-600 text-sm text-white px-4 py-2 rounded hover:bg-blue-700 focus:outline-none mx-2',
  cancelButtonClass = 'bg-gray-300 text-sm text-gray-800 px-4 py-2 rounded hover:bg-gray-400 focus:outline-none mx-2',
}) => {
  return await MySwal.fire({
    title,
    text,
    // html,
    icon,
    showCancelButton,
    confirmButtonText,
    cancelButtonText,
    showConfirmButton,
    allowOutsideClick,
    buttonsStyling: false,
    customClass: {
      icon: 'text-[10px] mt-4 p-0 ',
      popup: 'w-[380px] rounded-lg shadow-lg bg-white dark:bg-gray-800',
      title: 'text-lg font-semibold text-gray-800 dark:text-white m-0 p-0 ',
      htmlContainer: 'text-sm text-gray-600 dark:text-gray-300  m-1 p-1' ,
      actions: 'mt-1 mb-0', 
      confirmButton: confirmButtonClass,
      cancelButton: cancelButtonClass,
    },    
  });
};
