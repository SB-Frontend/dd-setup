import { apiGet } from './api'; 

export async function fetchSubcategoriesByCategory(catId) {
  if (!catId) return [];
  
  try {
    const subcategories = await apiGet(`/rsubcategory/cat/${catId}`);
    return subcategories || [];
  } catch (error) {
    console.error("Failed to fetch subcategories", error);
    return [];
  }
}