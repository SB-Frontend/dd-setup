export const generateRandomString = (length = 13) =>
  Array.from({ length }, () =>
    Math.random().toString(36).charAt(2)
  ).join('');
