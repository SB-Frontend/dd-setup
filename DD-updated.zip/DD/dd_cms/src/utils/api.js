// src/utils/api.js
import axios from "axios";
import { showTailwindAlert } from "@/utils/showTailwindAlert";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const api = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
  // headers: { // "Content-Type": "application/json", // },
});

// Automatically attach token to every request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error),
);

// Auto logout / permission handling
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const status = error.response?.status;
    const errorData = error.response?.data || {
      error: "Authentication Failed",
      message: "Something went wrong.",
    };

    if (status === 401) {
      const result = await showTailwindAlert({
        title: `${errorData?.error || "Unauthorized"}`,
        text: `${errorData?.message || "Please login again."}`,
        icon: "error",
        showCancelButton: false,
        confirmButtonText: "Login",
        allowOutsideClick: false,
      });

      if (result.isConfirmed) {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        window.location.href = "/";
      }
    }

    if (status === 403) {
      await showTailwindAlert({
        title: `${errorData?.error || "Access Denied"}`,
        text: `${errorData?.message || "You do not have permission to perform this action."}`,
        icon: "error",
        showCancelButton: false,
        confirmButtonText: "OK",
        allowOutsideClick: false,
      });
    }

    return Promise.reject(error);
  },
);

// Handle API response
const handleResponse = async (axiosPromise) => {
  try {
    const response = await axiosPromise;

    if (
      response.data instanceof Blob ||
      response.request?.responseType === "blob"
    ) {
      return response.data;
    }

    return response.data;
  } catch (error) {
    const customError = new Error(error.response?.data?.message || "API Error");

    customError.status = error.response?.status || 500;
    customError.data = error.response?.data || {};

    throw customError;
  }
};

// API methods
export const apiGet = (endpoint, params = {}) =>
  handleResponse(api.get(endpoint, { params }));

export const apiPost = (endpoint, data, config = {}) =>
  handleResponse(api.post(endpoint, data, config));

export const apiPut = (endpoint, data, config = {}) =>
  handleResponse(api.put(endpoint, data, config));

export const apiPatch = (endpoint, data, config = {}) =>
  handleResponse(api.patch(endpoint, data, config));

export const apiDelete = (endpoint, config = {}) =>
  handleResponse(api.delete(endpoint, config));

// Users
export async function getUsersList({ page, limit, search } = {}) {
  try {
    const params = {
      page,
      limit,
      search: search || "",
    };

    const res = await apiGet("/auth/users", params);

    console.log("getUsersList response:", res);
    return {
      aaData: res.users || [],
      iTotalRecords: res.pagination?.total || 0,
      iTotalDisplayRecords: res.pagination?.total || 0,
    };
  } catch (err) {
    return {
      aaData: [],
      iTotalRecords: 0,
      iTotalDisplayRecords: 0,
    };
  }
}

export default api;
