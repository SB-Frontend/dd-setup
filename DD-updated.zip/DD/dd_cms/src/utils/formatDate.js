export const formatDateTime = (dateString, options = { showTime: false }) => {
    if (!dateString) return '';
  
    const date = new Date(dateString);
  
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      ...(options.showTime && {
        hour: 'numeric',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }),
    });
  };
  