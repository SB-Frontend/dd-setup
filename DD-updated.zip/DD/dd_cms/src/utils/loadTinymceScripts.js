export const loadTinymceScripts = (src) => {
    return new Promise((resolve, reject) => {
      if (document.querySelector(`script[src="${src}"]`)) {
        resolve(); // script already loaded
        return;
      }
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
      document.head.appendChild(script);
    });
  };
  
  export const loadAllScripts = async (webPath) => {
    
    const scripts = [
      `${webPath}/assets/js/jquery-3.6.0.min.js`,
      `${webPath}/assets/js/jquery-migrate-1.0.0.js`,
      `${webPath}/assets/js/ice/ice-master.min.js`,
      `${webPath}/assets/js/ice/lib/tinymce/tinymce.js`
    ];
  
    
    for (const src of scripts) {
      await loadTinymceScripts(src);
    }
  };
  