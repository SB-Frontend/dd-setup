// utils/cleanComment.js
export function cleanCommentString(str = '') {
  if (!str) return '';

  return str
    .replace(/\r?\n|\r/g, '')   // remove \r\n line breaks
    .replace(/\s{2,}/g, ' ')    // collapse multiple spaces
    .trim();                    // remove leading/trailing spaces
}
