// auth.js (optional utility file)
import Cookies from 'js-cookie';

export const isLoggedIn = () => !!Cookies.get('authToken');
export const getToken = () => Cookies.get('authToken');
export const logout = () => Cookies.remove('authToken');
