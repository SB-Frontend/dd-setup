import { useEffect, useState } from "react";
import { apiGet } from "./api";

const webPath = import.meta.env.VITE_WEBPATH;
const staticPath = import.meta.env.VITE_STATIC;

const TitleMapping = ({ title }) => {
  return (
    <div className="py-4 font-semibold capitalize text-[1.2rem]">
      {title || "default"}
    </div>
  );
};

const InputField = ({
  label,
  name,
  type = "text",
  value,
  required = false,
  placeholder = "",
  onChange,
  mt = true,
  needLabel = true,
  error = "", // <- NEW
}) => {
  return (
    <div className={mt ? "mt-4" : ""}>
      {needLabel && (
        <label className="text-sm font-medium text-gray-700 dark:bg-gray-800 dark:text-white flex items-center gap-1">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}

      <input
        type={type}
        name={name}
        className={`mt-1 block text-black w-full text-sm px-3 py-2 font-normal rounded-md shadow-sm border-[1.5px] focus:outline-none focus:ring-1 dark:bg-gray-800 dark:text-white 
          ${
            error
              ? "border-red-600 ring-red-500 focus:ring-red-500"
              : "border-gray-300 dark:border-gray-500 focus:border-blue-700 focus:ring-blue-700"
          }`}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
      />

      {error && <p className="text-red-600 text-xs mt-1 ms-2">{error}</p>}
    </div>
  );
};

const DiscardConfirmationModal = ({ isOpen, onConfirm, onCancel, opacity }) => {
  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 z-[999]  bg-black ${
        opacity ? "bg-opacity-[0.1]" : "bg-opacity-50"
      } flex items-center justify-center`}
    >
      <div className="bg-white rounded-lg p-6 max-w-sm text-center z-[1000] dark:bg-gray-700 dark:text-white">
        <p className="mb-4 text-gray-700 dark:text-white text-base font-medium">
          Are you sure you want to discard changes?
        </p>
        <div className="flex justify-center gap-4">
          <button
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded"
            onClick={onCancel}
          >
            No
          </button>
          <button
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
            onClick={onConfirm}
          >
            Yes, Discard
          </button>
        </div>
      </div>
    </div>
  );
};

const EditRole = ({
  isOpen,
  toggleModal,
  onConfirm,
  role,
  setRole,
  subModal,
  setSubModal,
}) => {
  if (!isOpen) return null;

  const handleDiscard = () => setSubModal(true);
  const confirmDiscard = () => {
    setSubModal(false);
    toggleModal();
  };
  const cancelDiscard = () => setSubModal(false);

  const handleCheckboxChange = (index, permissionType) => {
    const updatedPermissions = [...role.permissions];
    updatedPermissions[index] = {
      ...updatedPermissions[index],
      [permissionType]: updatedPermissions[index][permissionType] === 1 ? 0 : 1,
    };
    setRole({ ...role, permissions: updatedPermissions });
  };

  return (
    <>
      {/* MAIN MODAL */}
      <div className="fixed inset-0 z-40 bg-black bg-opacity-[0.1] flex items-center justify-center">
        <div className="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-lg">
          {/* Header */}
          <div className="flex justify-between items-center p-5 border-b border-gray-200 dark:border-gray-600">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
              Update Role Permissions
            </h3>
            <button
              onClick={handleDiscard}
              className="text-gray-500 hover:text-gray-700 dark:hover:text-white"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                viewBox="0 0 14 14"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M1 1l6 6m0 0l6 6M7 7l6-6M7 7L1 13"
                />
              </svg>
              <span className="sr-only">Close modal</span>
            </button>
          </div>

          {/* Content */}
          <div className="px-6 py-4">
            <div className="capitalize text-xl font-semibold mb-4 text-gray-800 dark:text-white">
              {role?.rolename || "Unnamed Role"}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                onConfirm();
                toggleModal();
              }}
            >
              {/* Permissions Table */}
              <div className="overflow-y-auto max-h-[400px] border border-gray-200 dark:border-gray-700 rounded">
                <table className="w-full text-sm text-left text-gray-700 dark:text-gray-300">
                  <thead className="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
                    <tr>
                      <th className="px-4 py-2">Module</th>
                      <th className="px-4 py-2 text-center">Create</th>
                      <th className="px-4 py-2 text-center">Read</th>
                      <th className="px-4 py-2 text-center">Update</th>
                      <th className="px-4 py-2 text-center">Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    {role?.permissions?.map((perm, index) => (
                      <tr
                        key={index}
                        className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700"
                      >
                        <td className="px-4 py-2 font-medium">
                          {perm.permissionname}
                        </td>
                        {["p_create", "p_read", "p_update", "p_delete"].map(
                          (permKey) => (
                            <td key={permKey} className="px-4 py-2 text-center">
                              <input
                                type="checkbox"
                                checked={perm[permKey] === 1}
                                onChange={() =>
                                  handleCheckboxChange(index, permKey)
                                }
                                className="w-4 h-4 text-blue-600 bg-white border-gray-300 rounded focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600"
                              />
                            </td>
                          ),
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Buttons */}
              <div className="text-center mt-6">
                <button
                  type="button"
                  className="text-white bg-gray-500 hover:bg-gray-600 font-medium rounded-lg text-sm px-5 py-2.5 mr-2"
                  onClick={handleDiscard}
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="text-gray-900 dark:text-white bg-white dark:bg-blue-600 hover:bg-gray-100 dark:hover:bg-blue-700 border border-gray-300 dark:border-blue-500 font-medium rounded-lg text-sm px-5 py-2.5"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* SUBMODAL */}
      <DiscardConfirmationModal
        isOpen={subModal}
        onConfirm={confirmDiscard}
        onCancel={cancelDiscard}
        opacity={true}
      />
    </>
  );
};

const AddRole = ({
  isOpen,
  toggleModal,
  onConfirm,
  subModal,
  setSubModal,
  setRolename,
  setRoleslug,
  rolename,
  roleslug,
  errors,
  setErrors,
}) => {
  if (!isOpen) return null;

  const handleDiscard = () => {
    setSubModal(true);
  };

  const confirmDiscard = () => {
    setSubModal(false);
    toggleModal();
    setErrors({});
  };

  const cancelDiscard = () => {
    setSubModal(false);
    setErrors({});
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black bg-opacity-[0.1] flex items-center justify-center">
        <div className="relative w-full max-w-2xl bg-white rounded-lg">
          <div className="flex justify-between items-center p-5 border-b dark:bg-gray-800 dark:text-white">
            <h3 className="text-lg font-semibold text-gray-700 dark:text-white">
              Add a Role
            </h3>
            <button
              onClick={handleDiscard}
              className="text-gray-400 hover:text-gray-600"
            >
              <svg
                className="w-3 h-3"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 14 14"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                />
              </svg>
              <span className="sr-only">Close modal</span>
            </button>
          </div>

          <div className="px-6 py-4 dark:bg-gray-800 dark:text-white">
            <form
              onSubmit={(e) => {
                e.preventDefault();

                const newErrors = {};

                if (!rolename.trim())
                  newErrors.rolename = "Role Name is required.";
                if (!roleslug.trim())
                  newErrors.roleslug = "Role Slug is required.";

                setErrors(newErrors);

                console.log("errors", errors);

                if (Object.keys(newErrors).length === 0) {
                  onConfirm();
                  toggleModal();
                }
              }}
            >
              <div className="rolename">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                  Role Name <span className="text-red-500">*</span>
                </label>

                <input
                  type="text"
                  className={`mt-1 block w-full text-sm px-3 py-2 rounded-md shadow-sm border-[1.5px] focus:outline-none focus:ring-1 dark:bg-gray-800 dark:text-white ${
                    errors.rolename
                      ? "border-red-500 ring-red-500 focus:border-red-500 focus:ring-red-500"
                      : "border-gray-300 dark:border-gray-600 focus:border-blue-500 focus:ring-blue-500"
                  }`}
                  value={rolename}
                  onChange={(e) => setRolename(e.target.value)}
                  placeholder="Enter a Role Name"
                />
                {errors.rolename && (
                  <p className="text-red-600 text-xs mt-1 ms-2">
                    {errors.rolename}
                  </p>
                )}
              </div>
              <div className="roleslug mt-4">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                  Role Slug <span className="text-red-500">*</span>
                </label>

                <input
                  type="text"
                  className={`mt-1 block w-full text-sm px-3 py-2 rounded-md shadow-sm border-[1.5px] focus:outline-none focus:ring-1 dark:bg-gray-800 dark:text-white ${
                    errors.roleslug
                      ? "border-red-500 ring-red-500 focus:border-red-500 focus:ring-red-500"
                      : "border-gray-300 dark:border-gray-600 focus:border-blue-500 focus:ring-blue-500"
                  }`}
                  value={roleslug}
                  onChange={(e) => setRoleslug(e.target.value)}
                  placeholder="Enter a Role Slug"
                />
                {errors.roleslug && (
                  <p className="text-red-600 text-xs mt-1 ms-2">
                    {errors.roleslug}
                  </p>
                )}
              </div>

              <div className="text-center mt-6">
                <button
                  type="button"
                  className="text-white bg-gray-400 hover:bg-gray-500 font-medium rounded-lg text-sm px-5 py-2.5 mr-2"
                  onClick={handleDiscard}
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="text-gray-900 bg-white border border-gray-300 hover:bg-gray-100 font-medium rounded-lg text-sm px-5 py-2.5"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <DiscardConfirmationModal
        isOpen={subModal}
        onConfirm={confirmDiscard}
        onCancel={cancelDiscard}
        opacity={true}
      />
    </>
  );
};

const Edit_AddUserModal = ({
  isOpen,
  toggleModal,
  onConfirm,
  selectedEditUser,
  setSelectedEditUser,
  subModal,
  setSubModal,
  roles,
  action,
  errors,
  setErrors,
  scrollRef,
}) => {
  if (!isOpen) return null;

  const handleDiscard = () => setSubModal(true);
  const confirmDiscard = () => {
    setSubModal(false);
    toggleModal();
    setErrors({}); // Reset errors on confirm discard
  };
  const cancelDiscard = () => {
    setSubModal(false);
    setErrors({}); // Reset errors on confirm discard
  };

const handleInputChange = (e, roleid) => {
  const { name, type, checked, value } = e.target;

  if (type === "checkbox" && name === "is_author") {
    setSelectedEditUser((prev) => ({
      ...prev,
      is_author: checked,
    }));
    return;
  }

  let newValue = type === "checkbox" ? checked : value;

  // Auto-format username
  if (name === "user_name") {
    newValue = newValue
      .toLowerCase()
      .replace(/\s+/g, "-"); // spaces -> hyphens
  }

  if (name === "phone") {
    if (!/^\d*$/.test(newValue)) return;

    if (newValue.length > 10) {
      newValue = newValue.slice(0, 10);
    }
  }

  setSelectedEditUser((prev) => ({
    ...prev,
    [name]: newValue,
    role_id: roleid || prev.role_id,
  }));

  if (name === "phone") {
    setErrors((prev) => ({
      ...prev,
      phone:
        newValue.length === 10
          ? ""
          : "Phone number must be 10 digits",
    }));
  }
};

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black bg-opacity-50 flex items-center justify-center">
        <div className="relative w-full max-w-3xl bg-white rounded-lg">
          <div className="flex justify-between items-center p-5 border-b dark:bg-gray-800 dark:text-white">
            <h3 className="text-lg font-semibold text-gray-700  dark:text-white">
              {action === "add" ? "Add" : "Edit"} User
            </h3>
            <button
              onClick={handleDiscard}
              className="text-gray-400 hover:text-gray-600"
            >
              <svg
                className="w-3 h-3"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 14 14"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                />
              </svg>
              <span className="sr-only">Close modal</span>
            </button>
          </div>

          <div className="px-6 py-4 dark:bg-gray-800 dark:text-white">
            <form
              onSubmit={(e) => {
                e.preventDefault();

                const newErrors = {};
               if (!selectedEditUser.display_name)
                 newErrors.display_name = "Full name is required.";

               if (!selectedEditUser.user_name)
                 newErrors.user_name = "Username is required.";
                if (!selectedEditUser.user_email)
                  newErrors.user_email = "Email is required.";
                if (action === "add" && !selectedEditUser.user_password)
                  newErrors.user_password = "Password is required.";

                // if (!selectedEditUser.role_id)
                //   newErrors.role_id = "Role is required.";

                // only check if hes an author

                setErrors(newErrors);

                if (Object.keys(newErrors).length > 0) {
                  setErrors(newErrors);

                  scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });

                  return;
                }

                onConfirm();
                toggleModal();
              }}
            >
              <div
                className="overflow-y-auto thin-scrollbar px-2 max-h-[75vh]"
                ref={scrollRef}
              >
                <div className="grid grid-cols-12 gap-2">
                  <div className="col-span-6">
                    <div className="col-span-6">
                      <InputField
                        label="Display Name"
                        name="display_name"
                        required
                        value={selectedEditUser.display_name || ""}
                        onChange={handleInputChange}
                        placeholder="Display Name"
                        error={errors.display_name}
                      />
                    </div>

                    <div className="col-span-6">
                      <InputField
                        label="Username"
                        name="user_name"
                        required
                        value={selectedEditUser.user_name || ""}
                        onChange={handleInputChange}
                        placeholder="Username"
                        error={errors.user_name}
                      />
                    </div>

                    {/* <InputField
                      label="Designation"
                      name="designation"
                      required
                      value={selectedEditUser.designation || ""}
                      onChange={handleInputChange}
                      placeholder="Designation"
                      error={errors.designation}
                    /> */}
                  </div>

                  <div className="col-span-6">
                    <InputField
                      label="Email"
                      name="user_email"
                      type="email"
                      required
                      value={selectedEditUser.user_email || ""}
                      onChange={handleInputChange}
                      placeholder="Email"
                      error={errors.user_email}
                    />
                  </div>
                </div>
                <div className="w-full ">
                  {action === "add" && (
                    <InputField
                      label="Password"
                      name="user_password"
                      type="password"
                      required
                      value={selectedEditUser.user_password || ""}
                      onChange={handleInputChange}
                      placeholder="**********"
                      error={errors.user_password}
                    />
                  )}
                </div>

                {/* <div className="checkbox py-3 mt-4 flex items-center">
                  <label
                    htmlFor="checked-checkbox"
                    className="text-sm font-medium text-gray-900 dark:text-gray-300"
                  >
                    Is Author?
                  </label>
                  <input
                    id="checked-checkbox"
                    type="checkbox"
                    name="is_author"
                    checked={selectedEditUser.is_author || false}
                    onChange={handleInputChange}
                    className=" ms-2 w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm  dark:ring-offset-gray-800  dark:bg-gray-700 dark:border-gray-600"
                  />
                </div> */}

                {/* roles */}
                {/* <div className="py-3">
                  <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">
                    Role <span className="text-red-500">*</span>
                  </label>

                  <div className="grid grid-cols-12 gap-4">
                    <div className="col-span-12">
                      {roles.map((roles) => (
                        <div
                          className="flex items-center gap-3 mb-2"
                          key={roles.id}
                        >
                          <input
                            type="radio"
                            name="role"
                            value={roles.id}
                            checked={selectedEditUser.role == roles.id}
                            onChange={(e) => handleInputChange(e)}
                          />
                          <span className="text-gray-800 dark:text-white">
                            {roles.role}
                          </span>
                        </div>
                      ))}

                      {errors.role && (
                        <p className="text-red-600 text-xs">{errors.role}</p>
                      )}
                    </div>
                  </div>
                </div> */}
                {/* <div className="py-3 ">
                  <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">
                    Role <span className="text-red-500">*</span>
                  </label>

                  <div className="grid grid-cols-12 gap-4">
                    <div className="col-span-6">
                      {roles
                        .slice(0, Math.ceil(roles.length / 2))
                        .map((role) => (
                          <div
                            className="flex items-center gap-3 mb-2"
                            key={role.id}
                          >
                            <input
                              type="radio"
                              name="role_id"
                              value={role.id}
                              checked={selectedEditUser.role_id == role.id}
                              onChange={(e) => handleInputChange(e, role.id)}
                            />
                            <span className="text-gray-800 dark:text-white">
                              {role.role}
                            </span>
                          </div>
                        ))}
                    </div>

                    <div className="col-span-6">
                      {roles.slice(Math.ceil(roles.length / 2)).map((role) => (
                        <div
                          className="flex items-center gap-3 mb-2"
                          key={role.id}
                        >
                          <input
                            type="radio"
                            name="role_id"
                            value={role.id}
                            checked={selectedEditUser.role_id == role.id}
                            onChange={(e) => handleInputChange(e, role.id)}
                          />
                          <span className="text-gray-800 dark:text-white">
                            {role.role}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="col-span-6">
                      {errors.role_id && (
                        <p className="text-red-600 text-xs">{errors.role_id}</p>
                      )}
                    </div>
                  </div>
                </div> */}
              </div>

              <div className="text-center mt-6">
                <button
                  type="button"
                  className="text-white bg-gray-400 hover:bg-gray-500 font-medium rounded-lg text-sm px-5 py-2.5 mr-2"
                  onClick={handleDiscard}
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="text-gray-900 bg-white border border-gray-300 hover:bg-gray-100 font-medium rounded-lg text-sm px-5 py-2.5"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <DiscardConfirmationModal
        isOpen={subModal}
        onConfirm={confirmDiscard}
        onCancel={cancelDiscard}
      />
    </>
  );
};

const DeleteModal = ({ isOpen, toggleModal, onConfirm, title }) => {
  if (!isOpen) return null;

  const handleDiscard = () => toggleModal();
  const confirmDiscard = () => {
    onConfirm();
    toggleModal();
  };

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black bg-opacity-50 flex items-center justify-center">
        <div className="relative w-full max-w-2xl bg-white rounded-lg">
          <div className="flex justify-between items-center p-5 border-b">
            <h3 className="text-lg font-semibold text-gray-700">
              {title || "Are your sure you wish to perform this deletion?"}
            </h3>
            <button
              onClick={handleDiscard}
              className="text-gray-400 hover:text-gray-600"
            >
              <svg
                className="w-3 h-3"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 14 14"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                />
              </svg>
              <span className="sr-only">Close modal</span>
            </button>
          </div>

          <div className="px-6 py-4">
            <div className="text-center mt-6">
              <button
                type="button"
                className="text-white bg-gray-400 hover:bg-gray-500 font-medium rounded-lg text-sm px-5 py-2.5 mr-2"
                onClick={handleDiscard}
              >
                Discard
              </button>
              <button
                type="button"
                className="text-gray-900 bg-white border border-gray-300 hover:bg-gray-100 font-medium rounded-lg text-sm px-5 py-2.5"
                onClick={confirmDiscard}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export {
  TitleMapping,
  EditRole,
  AddRole,
  Edit_AddUserModal,
  InputField,
  DeleteModal,
};
