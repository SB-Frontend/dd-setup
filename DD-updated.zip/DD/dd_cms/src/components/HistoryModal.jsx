import { Dialog, DialogBackdrop, DialogPanel, DialogTitle } from '@headlessui/react';
import { useEffect, useState } from 'react';
import { Controller } from 'react-hook-form';
import { apiGet } from '@/utils/api'; // adjust as needed
import { formatDateTime } from '@/utils/formatDate'; // optional
import { loadAllScripts  } from '@/utils/loadTinymceScripts'; // <-- your loader utility
import TinyMCEEditor from '@/components/TinyMCEEditor';

const HistoryModal = ({
  open,
  onClose,
  id,
  control,
  fieldName,
  label = 'Version History',
  apiListEndpoint,
  apiDetailEndpoint,
  editorId,
  webPath = '',
  readOnly = true,
  height = 350,
}) => {
  const [historyList, setHistoryList] = useState([]);
  const [scriptsLoaded, setScriptsLoaded] = useState(false);

  useEffect(() => {
    if (!open) return;

    const fetchHistoryAndLoadScripts = async () => {
      try {
        // Load all necessary TinyMCE related scripts first
        await loadAllScripts();
        setScriptsLoaded(true);

        // Fetch version history list
        const data = await apiGet(`${apiListEndpoint}/${id}`, 'report');
        setHistoryList(data?.postDesc || []);
      } catch (err) {
        console.error('Error loading scripts or fetching history:', err);
      }
    };

    fetchHistoryAndLoadScripts();

    return () => {
      // Cleanup TinyMCE editor instance on modal close/unmount
      const editor = window.tinymce?.get(editorId);
      if (editor) editor.remove();
    };
  }, [open, id, apiListEndpoint, editorId]);

  useEffect(() => {
    if (!scriptsLoaded || !open) return;

    // Initialize TinyMCE editor for the modal textarea if not already initialized
    const existingEditor = window.tinymce?.get(editorId);
    if (!existingEditor) {
      window.tinymce.init({
        selector: `textarea#${editorId}`,
        readonly: readOnly,
        plugins: 'searchreplace ice icesearchreplace',
        toolbar: false,
        menubar: false,
        statusbar: false,
        content_css: `${webPath}/assets/js/ice/demo.css`,
        height,
        noneditable_noneditable_class: 'mceNonEditable',
        extended_valid_elements: 'p,span[*],delete[*],insert[*]',
      });
    }
  }, [scriptsLoaded, open, editorId, readOnly, height, webPath]);

  const handleChange = async (e, onChange) => {
    const selectedId = e.target.value;
    onChange(selectedId);

    if (selectedId && window.tinymce) {
      try {
        const res = await apiGet(`${apiDetailEndpoint}/${selectedId}`, 'report');
        const content = res?.postDesc?.[0]?.[fieldName] || '';
        const editor = window.tinymce.get(editorId);
        if (editor) {
          editor.setContent(content);
        } else {
          console.warn('TinyMCE editor not found when setting content');
        }
      } catch (err) {
        console.error('Failed to fetch version content:', err);
      }
    }
  };

  return (
    <Dialog open={open} onClose={onClose} className="relative z-30">
      <DialogBackdrop className="fixed inset-0 bg-gray-500/75" />
      <div className="fixed inset-0 z-31 w-screen overflow-y-auto">
        <div className="flex min-h-full items-center justify-center p-4">
          <DialogPanel className="relative transform rounded-lg bg-white shadow-xl transition-all sm:max-w-3xl w-full">
            <div className="bg-white p-6">
              <DialogTitle as="h3" className="text-base font-semibold text-gray-900">
                {label}
              </DialogTitle>
              <div className="mt-2">
                <Controller
                  name={fieldName}
                  control={control}
                  defaultValue=""
                  render={({ field }) => (
                    <>
                      <select
                        {...field}
                        onChange={(e) => handleChange(e, field.onChange)}
                        className="w-full px-3 py-2 mt-2 border rounded-md"
                      >
                        <option value="">-- Select Version --</option>
                        {historyList.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.name} - {formatDateTime(item.created_at, { showTime: true })}
                          </option>
                        ))}
                      </select>
                      <TinyMCEEditor
  id={editorId}
  initialContent={someContent}
  readOnly={readOnly}
  height={500}
  webPath={webPath}
  onChange={() => {}}
  user={{ name: 'John Cena', id: '10000000' }}
/>
                    </>
                  )}
                />
              </div>
            </div>
            <div className="bg-gray-50 px-4 py-3 text-right">
              <button
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border rounded-md hover:bg-gray-100"
              >
                Close
              </button>
            </div>
          </DialogPanel>
        </div>
      </div>
    </Dialog>
  );
};

export default HistoryModal;
