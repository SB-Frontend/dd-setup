import React from "react";

const StatCard = ({ title, value, color = "#7b54c6", Logo }) => {
  return (
    <div
      className="relative bg-white dark:bg-gray-800 rounded-md shadow-lg p-5 overflow-hidden min-h-[150px] cursor-pointer hover:shadow-2xl hover:scale-[1.02] transition-transform duration-300"
    >
      <div className="mb-10"> {/* Large gap below the title */}
        <h3
          className="font-poppins text-2xl mt-0 transition-colors mb-6"
          style={{ color: color }}
        >
          <span className="dark:text-white">{title}</span>
        </h3>
        {Logo && (
  <div className="
      flex justify-start
      opacity-15
      dark:opacity-25
    "
    style={{ fontSize: "3.5rem" }}
  >
    <Logo className="w-10 h-10 text-gray-700 dark:text-white" />
  </div>
)}
      </div>
      <span
        className="font-roboto"
        style={{
          color: color,
          position: "absolute",
          right: -6,
          bottom: 40,
          fontSize: "12rem",
          opacity: 0.7,
          letterSpacing: "-1rem",
          lineHeight: 0.2,
          zIndex: 2,
          userSelect: "none",
        }}
      >
        {value}
      </span>
    </div>
  );
};

export default StatCard;
