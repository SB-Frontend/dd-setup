// src/components/Routes.jsx
import React from "react";
import { Routes, Route } from "react-router-dom";
import Dashboard from "@/pages/dashboard/Dashboard";
import Login from "@/pages/auth/Login";
import ForgotPassword from "@/pages/auth/ForgotPassword";
import ResetPassword from "@/pages/auth/ResetPassword";
import Profile from "@/pages/auth/Profile";
import NoAccess from "@/components/NoAccess";
import PermissionRoute from "@/components/PermissionRoute";
import NotFound from '@/components/NotFound';
// import AdvertisementLeadList from "@/pages/podcasts/advertisementLeadList";
// import BlogList from "@/pages/posts/PostsList";
// import CreateBlog from "@/pages/posts/CreateBlog";
// import EditBlog from "@/pages/posts/EditBlog";
import LeadList from "@/pages/leads/leadList";
// import AdvertisementLeadList from "@/pages/leads/advertisementLeadList";
import BrandKitLeadList from "@/pages/leads/brandKitLead";
import SubscriberList from "@/pages/leads/subscriberList";
import CustomerList from "@/pages/user-management/customers/Customer";
import UserList from "@/pages/user-management/users/UserList";
import MediaManager from "@/pages/posts/MediaList";
import CategoryPage from "@/pages/category/Category";
import SubcategoryPage from "@/pages/subcategory/SubCategory";
import CreateAdvertisement from "@/pages/Advertisement/CreateAdvertisement";
import RoleList from "@/pages/user-management/roles/RoleListing";
import PostList from "@/pages/posts/PostsList";
import HandoverReceived from "@/pages/posts/HandoverReceived";
import HandoverSent from "@/pages/posts/HandoverSent";
import DraftPost from "@/pages/posts/DraftPost";
import CreatePost from "@/pages/posts/CreatePost";
import EditPost from "@/pages/posts/EditPost";
import UrlRedirect from "@/pages/posts/UrlRedirect";
import AuthorPage from "@/pages/user-management/author/AuthorPage";
// import MediaManager from "@/pages/posts/MediaList";

// import DataTable from '@/pages/report/DataTable';

const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Login />} />
    <Route path="/forgot-password" element={<ForgotPassword />} />
    <Route path="/reset-password" element={<ResetPassword />} />
    <Route path="/dashboard" element={<Dashboard />} />
    <Route path="/profile" element={<Profile />} />

    {/* {/ blogs /} */}
    {/* <Route path="/posts/list" element={<BlogList />} />
    <Route path="/posts/create" element={<CreateBlog />} />
    <Route path="/posts/edit/:id" element={<EditBlog />} />
    <Route path="/posts/media/list" element={<MediaManager />} /> */}

    <Route path="/leads/list" element={<LeadList />} />
    {/* <Route path="/advertisement-leads" element={<AdvertisementLeadList />} /> */}
    <Route path="/subscriber-leads" element={<SubscriberList />} />
    {/* <Route path="/brand-kit-leads" element={<BrandKitLeadList />} /> */}
    
    {/* {/ posts /} */}
    <Route path="/posts/list" element={<PostList />} />
    <Route path="/posts/create" element={<CreatePost />} />
    <Route path="/posts/edit/:id" element={<EditPost />} />
    <Route path="/posts/media/list" element={<MediaManager />} />
    {/* <Route path="/posts/handover-received" element={<HandoverReceived />} /> */}
    {/* <Route path="/posts/handover-sent" element={<HandoverSent />} /> */}
    {/* <Route path="/posts/drafts" element={<DraftPost />} /> */}
    {/* <Route path="/posts/url-redirect" element={<UrlRedirect />} /> */}
    {/* {/ Users  /} */}
    <Route path="/author" element={<AuthorPage />} />
    <Route path="/users" element={<UserList />} />
     {/* <Route path="/roles" element={<RoleList />} /> */}


    <Route path="/category" element={<CategoryPage />} />
    <Route path="/subcategory" element={<SubcategoryPage />} />

    {/* {/ Advertisement /} */}
    {/* <Route path="/advertisement/list" element={<CreateAdvertisement />} /> */}


    <Route path="*" element={<NotFound />} />

    {/* {/ Protected Routes /} */}
  </Routes>
);

export default AppRoutes;