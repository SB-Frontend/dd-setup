// src/components/PermissionRoute.jsx
import { useAuth } from '@/context/AuthContext';
import { Navigate } from 'react-router-dom';

const hasPermission = (permissions, permName, action = 'p_read') => {
  const perm = permissions.find(p => p.perm === permName);
  return perm && perm[action] === 1;
};

const PermissionRoute = ({ children, permName, action = 'p_read' }) => {
  const { permissions } = useAuth();
  
  return hasPermission(permissions, permName, action) ? children : <Navigate to="/no-access" />;
};

export default PermissionRoute;
