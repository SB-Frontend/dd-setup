import React, { useEffect, useState, useRef } from 'react';

const webPath = import.meta.env.VITE_WEBPATH; // Replace with your actual path or pass as prop

function loadScript(src) {
  return new Promise((resolve, reject) => {
    // Avoid loading script twice
    if (document.querySelector(`script[src="${src}"]`)) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

const TinyMCEEditor = ({ id, initialContent = '', onChange }) => {
  const [scriptsLoaded, setScriptsLoaded] = useState(false);
  const editorRef = useRef(null);

  // Load scripts only once (shared across all instances)
  useEffect(() => {
    const loadAllScripts = async () => {
      try {
        await loadScript(`${webPath}/assets/js/jquery-3.6.0.min.js`);
        await loadScript(`${webPath}/assets/js/jquery-migrate-1.0.0.js`);
        await loadScript(`${webPath}/assets/js/ice/ice-master.min.js`);
        await loadScript(`${webPath}/assets/js/ice/lib/tinymce/tinymce.js`);
        setScriptsLoaded(true);
      } catch (e) {
        console.error('Failed to load scripts', e);
      }
    };

    loadAllScripts();
  }, []);

  // Initialize TinyMCE when scripts are loaded
  useEffect(() => {
    if (!scriptsLoaded || !window.tinymce) return;

    // Cleanup previous editor if any
    if (editorRef.current) {
      window.tinymce.remove(editorRef.current);
      editorRef.current = null;
    }

    window.tinymce.init({
      selector: `textarea#${id}`,
      mode: 'exact',
      readonly: false,
      plugins: 'searchreplace ice icesearchreplace print preview paste importcss autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern noneditable help charmap quickbars emoticons',
      toolbar1: 'undo redo | bold italic underline strikethrough | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen preview save print | insertfile image media template link anchor codesample | ltr rtl',
      toolbar2: "ice_togglechanges | ice_toggleshowchanges | iceacceptall icerejectall | iceaccept icereject",
      extended_valid_elements: "p,span[*],delete[*],insert[*]",
      quickbars_selection_toolbar: 'bold italic | quicklink h2 h3 blockquote quickimage quicktable addComment',
      noneditable_noneditable_class: "mceNonEditable",
      toolbar_mode: 'sliding',
      contextmenu: "link image imagetools table",
      height: 500,
      image_caption: true,
      content_css: `${webPath}/assets/js/ice/demo.css`,
      setup: function (editor) {
        editorRef.current = editor;

        editor.on('init', () => {
          editor.setContent(initialContent || '');
        });

        editor.on('Change KeyUp', () => {
          const content = editor.getContent();
          onChange && onChange(content);
        });

        editor.ui.registry.addButton('addComment', {
          text: 'Add Comment',
          onAction: function () {
            var selectedText = editor.selection.getContent();
            if (selectedText) {
              var comment = window.prompt('Add a comment for the selected text:');
              if (comment) {
                editor.execCommand('mceInsertContent', false, `<insert class="ins comm ">${selectedText}</insert> <insert class="del viewComment cts-1"> - (Comment by John Cena - This date ${comment})</insert> `);
              }
            } else {
              alert('Please select some text to add a comment.');
            }
          }
        });
      },
      ice: {
        user: {
          name: 'John Cena',
          id: '10000000'
        },
        preserveOnPaste: 'p,a[href],i,em,b,span',
        deleteTag: 'delete',
        insertTag: 'insert',
        commentTag: 'comment'
      }
    });

    // Cleanup on unmount
    return () => {
      if (editorRef.current) {
        window.tinymce.remove(editorRef.current);
        editorRef.current = null;
      }
    };
  }, [scriptsLoaded, id, initialContent, onChange]);

  return (
    <textarea
      id={id}
      className="w-full text-sm px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:text-white"
    />
  );
};

export default TinyMCEEditor;
