"use client";

import React, { useState, useEffect, useMemo } from "react";
import {
  useReactTable,
  getCoreRowModel,
  getExpandedRowModel,
  flexRender,
} from "@tanstack/react-table";
import { ChevronDown, ChevronRight } from "lucide-react";

const GenericTable = ({
  columnsConfig,
  fetchDataFunction,
  enableExpansion = false,
  renderExpandedRow = () => null,
  title = "",
  initialSort = { key: "id", order: "desc" },
  addFlag = false,
  addToggle,
  tag,
  refresh = false,
}) => {
  const [data, setData] = useState([]);
  const [expanded, setExpanded] = useState({});
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [sortBy, setSortBy] = useState(initialSort.key);
  const [order, setOrder] = useState(initialSort.order);
  const [search, setSearch] = useState("");

  const [filteredCount, setFilteredCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const res = await fetchDataFunction({
          page,
          limit,
          sort: sortBy,
          order,
          search,
        });
        setData(res?.aaData || []);
        setFilteredCount(res?.iTotalDisplayRecords || 0);
        setTotalCount(res?.iTotalRecords || 0);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [page, limit, sortBy, order, search, fetchDataFunction, refresh]);


  const handleSort = (key) => {
    setOrder(sortBy === key && order === "asc" ? "desc" : "asc");
    setSortBy(key);
  };

  const columns = useMemo(() => {
    const expansionCol = enableExpansion
      ? [
          {
            id: "expander",
            header: "",
            cell: ({ row }) => (
              <button onClick={() => row.toggleExpanded()}>
                {row.getIsExpanded() ? (
                  <ChevronDown size={16} />
                ) : (
                  <ChevronRight size={16} />
                )}
              </button>
            ),
          },
        ]
      : [];

    const renderedCols = columnsConfig.map((col) => ({
      ...col,
      header: col.sortable
        ? () => (
            <div
              onClick={() => handleSort(col.accessorKey)}
              className="cursor-pointer text-blue-600 dark:text-white flex items-center gap-1"
            >
              {col.header}{" "}
              {sortBy === col.accessorKey && (order === "asc" ? "↑" : "↓")}
            </div>
          )
        : col.header,
    }));

    return [...expansionCol, ...renderedCols];
  }, [columnsConfig, sortBy, order]);

  const table = useReactTable({
    data,
    columns,
    state: { expanded },
    onExpandedChange: setExpanded,
    getCoreRowModel: getCoreRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    getRowCanExpand: () => enableExpansion,
  });

  const totalPages = Math.ceil(filteredCount / limit);
  const start = (page - 1) * limit + 1;
  const end = Math.min(page * limit, filteredCount);



  return (
    <div className="bg-white dark:bg-gray-800 shadow-lg rounded-md p-4">
      <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
        {title}
      </h2>
      <div className="flex flex-col md:flex-row justify-between mb-4 gap-4">
        <div className="flex items-center gap-2">
          <span className="text-sm">Rows per page:</span>
          <select
            value={limit}
            onChange={(e) => {
              setPage(1);
              setLimit(Number(e.target.value));
            }}
            className="px-2 py-1 text-sm border rounded-md bg-white dark:bg-gray-700 dark:text-white dark:border-gray-600"
          >
            {[10, 20, 50, 100].map((val) => (
              <option key={val} value={val}>
                {val}
              </option>
            ))}
          </select>
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Search..."
            value={search}
            onChange={(e) => {
              setPage(1);
              setSearch(e.target.value);
            }}
            className="px-3 py-2 w-64 text-sm border rounded-md bg-white dark:bg-gray-700 dark:text-white dark:border-gray-600"
          />{" "}
          {addFlag && (
            <button
              type="button"
              className="bg-blue-500 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded"
              onClick={() => {
                addToggle();
              }}
            >
              Add {tag || "User"}
            </button>
          )}
        </div>
      </div>

      <div className="overflow-auto border rounded-lg border-gray-300 dark:border-gray-700">
        <table className="min-w-full  text-sm text-gray-700 dark:text-gray-300">
          <thead className="bg-gray-100 dark:bg-gray-700 text-left text-xs font-semibold uppercase tracking-wider">
            {table.getHeaderGroups().map((group) => (
              <tr key={group.id}>
                {group.headers.map((header) => (
                  <th key={header.id} className="px-4 py-3">
                    {flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 10 }).map((_, i) => (
                <tr key={i} className="animate-pulse">
                  {columns.map((col, idx) => (
                    <td key={idx} className="px-4 py-2">
                      <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded"></div>
                    </td>
                  ))}
                </tr>
              ))
            ) : data.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length}
                  className="text-center py-6 text-gray-500 dark:text-gray-400"
                >
                  No records found.
                </td>
              </tr>
            ) : (
              table.getRowModel().rows.map((row) => (
                <React.Fragment key={row.id}>
                  <tr className="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="px-4 py-2">
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </td>
                    ))}
                  </tr>
                  {enableExpansion && row.getIsExpanded() && (
                    <tr className="bg-gray-50 dark:bg-gray-900 text-sm">
                      <td colSpan={columns.length + 1} className="px-6 py-3">
                        {renderExpandedRow(row.original)}
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex flex-col md:flex-row justify-between items-center mt-4 gap-4 flex-wrap">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
          <div>
            {`Showing ${start} to ${end} of ${filteredCount} records`}
            {search && ` (filtered from ${totalCount} total entries)`}
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
            disabled={page === 1}
            className="px-3 py-1 rounded-md border text-sm bg-gray-100 dark:bg-gray-700 dark:text-white hover:bg-gray-200 disabled:opacity-50"
          >
            &lt;
          </button>

          {page > 3 && (
            <>
              <button
                onClick={() => setPage(1)}
                className="px-3 py-1 rounded-md border text-sm bg-gray-100 dark:bg-gray-700 dark:text-white hover:bg-gray-200"
              >
                1
              </button>
              <span className="px-2">...</span>
            </>
          )}

          {Array.from({ length: 5 }, (_, i) => {
            const pg = page - 2 + i;
            if (pg < 1 || pg > totalPages) return null;
            return (
              <button
                key={pg}
                onClick={() => setPage(pg)}
                className={`px-3 py-1 rounded-md border text-sm ${
                  pg === page
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 dark:bg-gray-700 dark:text-white hover:bg-gray-200"
                }`}
              >
                {pg}
              </button>
            );
          })}

          {page < totalPages - 2 && (
            <>
              <span className="px-2">...</span>
              <button
                onClick={() => setPage(totalPages)}
                className="px-3 py-1 rounded-md border text-sm bg-gray-100 dark:bg-gray-700 dark:text-white hover:bg-gray-200"
              >
                {totalPages}
              </button>
            </>
          )}

          <button
            onClick={() => setPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={page === totalPages}
            className="px-3 py-1 rounded-md border text-sm bg-gray-100 dark:bg-gray-700 dark:text-white hover:bg-gray-200 disabled:opacity-50"
          >
            &gt;
          </button>
        </div>
      </div>
    </div>
  );
};

export default GenericTable;
