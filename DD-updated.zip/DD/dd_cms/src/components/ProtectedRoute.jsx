// src/components/ProtectedRoute.jsx
import React, { useEffect } from 'react';
import { Navigate, useLocation,useNavigate  } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

const ProtectedRoute = ({ children }) => {
  const { user, token, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  // Optional: Check token expiry (if using JWTs with exp)
  useEffect(() => {
    if (token) {
      try {
        const decoded = JSON.parse(atob(token.split('.')[1]));
        const isExpired = decoded.exp * 1000 < Date.now();
        if (isExpired) {
          logout();
          navigate('/');
        }
      } catch (err) {
        console.error('Invalid token',err);
        logout();
        navigate('/');
      }
    }
  }, [token, logout]);

  // Redirect if no token or no user
  if (!token || !user) {
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  return children;
};

export default ProtectedRoute;
