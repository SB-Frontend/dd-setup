import CountUp from "react-countup";

const SmallCard = ({ icon, title, value, color = "indigo" }) => {
  const COLOR_CLASSES = {
    indigo: {
      gradient: "from-white/10 to-indigo-500/10 dark:from-indigo-500/10 dark:to-indigo-500/5",
      iconBg: "bg-indigo-500/10 text-indigo-600 dark:text-indigo-300",
      value: "text-indigo-600 dark:text-indigo-300",
    },
    green: {
      gradient: "from-white/10 to-green-500/10 dark:from-green-500/10 dark:to-green-500/5",
      iconBg: "bg-green-500/10 text-green-600 dark:text-green-300",
      value: "text-green-600 dark:text-green-300",
    },
    blue: {
      gradient: "from-white/10 to-blue-500/10 dark:from-blue-500/10 dark:to-blue-500/5",
      iconBg: "bg-blue-500/10 text-blue-600 dark:text-blue-300",
      value: "text-blue-600 dark:text-blue-300",
    },
    yellow: {
      gradient: "from-white/10 to-yellow-500/10 dark:from-yellow-500/10 dark:to-yellow-500/5",
      iconBg: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-300",
      value: "text-yellow-600 dark:text-yellow-300",
    },
    purple: {
      gradient: "from-white/10 to-purple-500/10 dark:from-purple-500/10 dark:to-purple-500/5",
      iconBg: "bg-purple-500/10 text-purple-600 dark:text-purple-300",
      value: "text-purple-600 dark:text-purple-300",
    },
    red: {
      gradient: "from-white/10 to-red-500/10 dark:from-red-500/10 dark:to-red-500/5",
      iconBg: "bg-red-500/10 text-red-600 dark:text-red-300",
      value: "text-red-600 dark:text-red-300",
    },
  };

  const theme = COLOR_CLASSES[color] || COLOR_CLASSES.indigo;

  return (
    <div
      className={`
      group relative overflow-hidden
      rounded-2xl
      border border-gray-200/70 dark:border-gray-700/50
      bg-gradient-to-br ${theme.gradient}
      p-6
      shadow-sm hover:shadow-xl
      transition-all duration-300
      hover:-translate-y-1
      backdrop-blur-sm
    `}
    >
      {/* Glow */}
      <div
        className={`
        absolute -top-10 -right-10
        h-40 w-40 rounded-full
        blur-3xl opacity-20
        ${theme.iconBg}
      `}
      />

      {/* Watermark Icon */}
      <div
        className={`
        absolute right-10 bottom-10
        opacity-[0.05]
        scale-[7]
        pointer-events-none
        ${theme.value}
      `}
      >
        {icon}
      </div>

      {/* Top Section */}
      <div className="relative z-10 flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">
            {title}
          </p>
        </div>

        <div
          className={`
          flex items-center justify-center
          w-12 h-12 rounded-xl
          shadow-md
          transition-transform duration-300
          group-hover:scale-110 group-hover:rotate-3
          ${theme.iconBg}
        `}
        >
          {icon}
        </div>
      </div>

      {/* Metric */}
      <div className="relative z-10">
        <h3
          className={`
          text-5xl font-normal tracking-tight
          ${theme.value}
        `}
        >
          <CountUp end={value} duration={2} />
        </h3>

        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          Total {title.toLowerCase()}
        </p>
      </div>

      {/* Hover Shine */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
        <div className="absolute -left-10 top-0 h-full w-16 bg-white/10 rotate-12 blur-xl" />
      </div>
    </div>
  );
};

export default SmallCard;