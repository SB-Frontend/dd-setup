import React from "react";
import { UserRound, UserRoundPen ,CirclePlus} from "lucide-react";

const RoleCard = ({
  displayNameAndCount,
  permissions,
  setSelectedRole,
  toggleModal,
  toggleAddModal,
  index,
  icons,
}) => {
  const isAddRole = displayNameAndCount === "addRole";

  if (isAddRole) {
    return (
      <div
        key={index}
        className="col-span-6 sm:col-span-6 md:col-span-4 lg:col-span-3 
          bg-white dark:bg-gray-800 rounded-md shadow-lg  p-5 min-h-[100px] opacity-70
          flex items-center justify-center cursor-pointer 
          hover:shadow-2xl hover:scale-[1.02] transition-transform duration-300 mb-8  hover:opacity-100"
        onClick={toggleAddModal}
      >
        <h2 className="flex flex-col items-center text-lg font-semibold text-[#7b54c6]  cursor-pointer">
  <CirclePlus className="w-8 h-8 mb-1" />
  <span>Add New Role</span>
</h2>
      </div>
    );
  }

  const icon = icons[displayNameAndCount.rolename] || <UserRound size={40} />;

  return (
    <div className="relative group font-roboto col-span-6 sm:col-span-6 md:col-span-4 lg:col-span-3 bg-white dark:bg-gray-800 rounded-xl shadow-lg cursor-pointer hover:shadow-2xl hover:scale-[1.02] transition-transform duration-300 mb-8">
      <div className="relative  pl-6 pt-4 overflow-hidden  min-h-[130px]">
        <p className="text-xl  text-[#7b54c6] dark:text-white">
          {displayNameAndCount.rolename}
        </p>
        <p className="absolute font-extralight text-[9rem] opacity-50 text-[#7b54c6] -bottom-16  overflow-hidden -right-4  group-hover:opacity-80">
          {displayNameAndCount.TotalUsers || 0}
        </p>

        {/* <div className="text-gray-300 absolute  dark:text-gray-50 dark:opacity-5 bottom-14 left-4 ">
          {React.cloneElement(icon, { className: "w-8 h-8" })}
        </div> */}
        <button
        type="button"
        onClick={() => {
          setSelectedRole(permissions);
          toggleModal();
        }}
        className="absolute  bottom-2  h-8 left-6  text-gray-500  flex items-center justify-center  hover:text-indigo-700 transition-colors z-20"
      >
        <UserRoundPen size={28} className="text-gray-500 group-hover:text-[#7b54c6]" />
      </button>
      </div>

      
    </div>
  );
};

export default RoleCard;
