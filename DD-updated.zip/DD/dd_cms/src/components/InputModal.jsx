import React from "react";

const Modal = ({ isOpen, title, children, onCancel, onSave }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 dark:text-gray-300">
      <div className="bg-white p-6 rounded shadow-md dark:bg-gray-900 w-96 relative">
        <button
          className="absolute top-6 right-6 text-gray-500 hover:text-blue-600 text-3xl font-bold focus:outline-none"
          onClick={onCancel}
        >
          &times;
        </button>

        {title && <h2 className="text-lg font-semibold mb-4">{title}</h2>}
        <div className="mb-4">{children}</div>
        <div className="flex justify-end gap-2">
          <button
            className=" bg-gray-300 text-sm text-gray-800 px-4 py-2 rounded hover:bg-gray-400 focus:outline-none mx-2"
            onClick={onCancel}
          >
            Cancel
          </button>
          <button
            className="px-4 py-2 bg-blue-600 text-white rounded hover:ring-blue-400"
            onClick={onSave}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};


export default Modal;
