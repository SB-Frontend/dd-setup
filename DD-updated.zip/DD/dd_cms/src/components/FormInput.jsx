"use client";

import React from "react";

const FormInput = ({
  name,
  label,
  placeholder,
  value,
  onChange,
  required = false,
  type = "text",
  isSlug = false,
  className = "",
}) => {
  const handleChange = (e) => {
    let val = e.target.value;
    if (isSlug) {
      val = val.replace(/\s+/g, "-").toLowerCase();
    }
    onChange(name, val);
  };

  return (
    <div className={className}>
      {label && (
        <label
          htmlFor={name}
          className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1"
        >
          {label}
          {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <input
        type={type}
        name={name}
        id={name}
        placeholder={placeholder}
        required={required}
        value={value}
        onChange={handleChange}
        className="block w-full px-3 py-2 border rounded-md shadow-sm bg-white dark:bg-gray-800 dark:text-white dark:border-gray-600"
      />
    </div>
  );
};

export default FormInput;
