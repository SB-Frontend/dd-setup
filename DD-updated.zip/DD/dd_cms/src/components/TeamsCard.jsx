import React, { useEffect, useMemo, useState } from "react";
import { apiGet } from "@/utils/api";
import { Users2, Briefcase, X, UserCircle2 } from "lucide-react";

const DEPARTMENTS = {
  Research: ["Research Manager", "Research Executive", "Research Associate"],
  Content: ["Content Manager", "Content Executive", "Content Associate"],
  DM: ["DM Manager", "DM Executive", "DM Associate"],
  Sales: ["Sales"],
  Graphics: ["Graphic Manager"],
  Admin: ["Admin", "User"],
  Publish: ["Publish Manager"],
};

const FALLBACK_DEPT = "Others";

function mapRoleToDepartment(roleDisplayName) {
  for (const [dept, roleNames] of Object.entries(DEPARTMENTS)) {
    if (roleNames.includes(roleDisplayName)) return dept;
  }
  return FALLBACK_DEPT;
}

function Drawer({ open, onClose, title, children }) {
  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/40 transition-opacity ${open ? "opacity-15 dark:opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`}
        onClick={onClose}
      />
      {/* Panel */}
      <aside
        className={`fixed right-0  top-0 h-full  max-w-[400px] *:first-letter: sm:w-[520px] bg-white  border-gray-900 dark:bg-gray-800 shadow-xl transform transition-transform ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100">{title}</h3>
          <button
            onClick={onClose}
            className="p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-4 overflow-y-auto h-[calc(100%-96px)]">
          {children}
        </div>
      </aside>
    </>
  );
}

function DepartmentHeaderCard({ dept, deptTotal, onOpen }) {
  return (
    <section className="rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm">
      <button
        type="button"
        onClick={onOpen}
        className="w-full p-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700/40 transition"
      >
        <div className="flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <h3 className="text-left text-lg font-semibold text-gray-800 dark:text-gray-100">
            {dept}
          </h3>
        </div>
        <div className="flex items-center gap-1 text-sm text-gray-600 dark:text-gray-300">
          <Users2 className="w-4 h-4" />
          <span>{deptTotal} total</span>
        </div>
      </button>
    </section>
  );
}

function DepartmentsGridWithDrawer() {
  const [roles, setRoles] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [openDept, setOpenDept] = useState(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        const [rolesRes, usersRes] = await Promise.all([
          apiGet("/roles"), // resolves to http://localhost:3002/api/v1/roles
          apiGet("/auth"),  // resolves to http://localhost:3002/api/v1/auth
        ]);
        if (!mounted) return;
        setRoles(Array.isArray(rolesRes) ? rolesRes : []);
        setUsers(Array.isArray(usersRes) ? usersRes : []);
      } catch (e) {
        console.error("Failed to load roles/users", e);
        setError("Failed to load roles or users.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  // Map role display -> role meta from roles API (for totals)
  const roleDisplayMap = useMemo(() => {
    const byDisplay = new Map();
    roles.forEach((r) => {
      if (r?.rolename) byDisplay.set(r.rolename, r);
    });
    return byDisplay;
  }, [roles]);

  // Build departments data: { dept, roles: [{roleName, users[], totalFromAPI}], deptTotal }
  const departmentsData = useMemo(() => {
    const deptRoleUsers = new Map();

    users.forEach((u) => {
      const roleDisplay = u?.rolename || "Unknown";
      const dept = mapRoleToDepartment(roleDisplay);
      if (!deptRoleUsers.has(dept)) deptRoleUsers.set(dept, new Map());
      const roleMap = deptRoleUsers.get(dept);
      if (!roleMap.has(roleDisplay)) roleMap.set(roleDisplay, []);
      roleMap.get(roleDisplay).push(u);
    });

    const result = [];
    for (const [dept, roleMap] of deptRoleUsers.entries()) {
      const definedOrder = DEPARTMENTS[dept] || [];
      const rolesOrdered = [];

      // Roles in defined order
      definedOrder.forEach((roleName) => {
        if (roleMap.has(roleName)) {
          rolesOrdered.push({
            roleName,
            users: roleMap.get(roleName),
            totalFromAPI: Number(roleDisplayMap.get(roleName)?.TotalUsers ?? 0),
          });
        }
      });

      // Extra roles not in defined order
      roleMap.forEach((usersArr, roleName) => {
        if (!definedOrder.includes(roleName)) {
          rolesOrdered.push({
            roleName,
            users: usersArr,
            totalFromAPI: Number(roleDisplayMap.get(roleName)?.TotalUsers ?? 0),
          });
        }
      });

      const deptTotal = rolesOrdered.reduce((sum, r) => sum + r.totalFromAPI, 0);

      result.push({ dept, roles: rolesOrdered, deptTotal });
    }

    // Ensure departments without users still appear (using totals from roles API)
    Object.keys(DEPARTMENTS).forEach((dept) => {
      if (!result.find((d) => d.dept === dept)) {
        const roleNames = DEPARTMENTS[dept];
        const rolesOrdered = roleNames.map((roleName) => ({
          roleName,
          users: [],
          totalFromAPI: Number(roleDisplayMap.get(roleName)?.TotalUsers ?? 0),
        }));
        const deptTotal = rolesOrdered.reduce((sum, r) => sum + r.totalFromAPI, 0);
        result.push({ dept, roles: rolesOrdered, deptTotal });
      }
    });

    // Sort departments in configured order, put Others at end
    const deptOrder = Object.keys(DEPARTMENTS);
    result.sort((a, b) => {
      if (a.dept === FALLBACK_DEPT) return 1;
      if (b.dept === FALLBACK_DEPT) return -1;
      return deptOrder.indexOf(a.dept) - deptOrder.indexOf(b.dept);
    });

    return result;
  }, [users, roleDisplayMap]);

  const selected = departmentsData.find((d) => d.dept === openDept);

  if (loading) {
    return (
      <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
        <p className="text-gray-600 dark:text-gray-300">Loading team…</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 dark:bg-red-900/30 border border-red-300 dark:border-red-700 rounded-lg">
        <p className="text-red-700 dark:text-red-300">{error}</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
        {/* 3 departments per row on large screens */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {departmentsData.map(({ dept, roles, deptTotal }) => (
            <DepartmentHeaderCard
              key={dept}
              dept={dept}
              deptTotal={deptTotal}
              onOpen={() => setOpenDept(dept)}
            />
          ))}
        </div>
      </div>

      <Drawer
        open={Boolean(openDept)}
        onClose={() => setOpenDept(null)}
        title={openDept || ""}
      >
        {!selected ? (
          <p className="text-sm text-gray-500 dark:text-gray-400">No data.</p>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
              <Users2 className="w-4 h-4" />
              <span>{selected.deptTotal} total</span>
            </div>

            {selected.roles.length === 0 && (
              <p className="text-sm text-gray-500 dark:text-gray-400">
                No roles in this department.
              </p>
            )}

            {selected.roles.map((roleBlock) => (
              <div key={roleBlock.roleName}>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-200">
                    {roleBlock.roleName}
                  </h4>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {roleBlock.totalFromAPI} total
                  </span>
                </div>

                <div className="space-y-2">
                  {roleBlock.users.length === 0 ? (
                    <p className="text-xs text-gray-500 dark:text-gray-400">No users.</p>
                  ) : (
                    roleBlock.users.map((u) => (
                      <div key={u.id} className="flex items-center gap-3" title={u.email}>
                        {/* <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 flex items-center justify-center shrink-0">
                          <UserCircle2 className="w-5 h-5" /> || {u.author_details.author_img}
                        </div> */}

<div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 flex items-center justify-center shrink-0 overflow-hidden">
  <img
    src={`https://app.kingsresearch.com/nodekings/author/${u?.author_details?.author_img || ""}`}
    alt={u?.name || "Author"}
    className="w-full h-full object-cover"
    loading="lazy"
    onError={(e) => {
      // First fallback: switch to local per-user asset
      const img = e.currentTarget;
      if (!img.dataset.fallbackTried) {
        img.dataset.fallbackTried = "1";
        img.src = `/assets/profileImg/${u?.id}.webp`;
        return;
      }

      // Final fallback: hide image and render inline SVG icon
      img.onerror = null;
      img.style.display = "none";
      const parent = img.parentElement;
      if (parent && !parent.querySelector("svg")) {
        const span = document.createElement("span");
        span.innerHTML =
          "<svg xmlns='http://www.w3.org/2000/svg' class='w-5 h-5' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M18 20a6 6 0 0 0-12 0'/><circle cx='12' cy='10' r='4'/></svg>";
        parent.appendChild(span);
      }
    }
  }
  />
</div>
                        <div className="min-w-0 mb-1">
                            <div className="flex items-center gap-1">
                          <p className="text-sm font-medium text-gray-800 dark:text-gray-100 truncate">
                            {u.name} 
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                          - {u.designation}
                          </p>
                          </div>
                          <p className="text-xs text-blue-500 dark:text-gray-400 truncate">
                            {u.email}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Drawer>
    </>
  );
}

export default DepartmentsGridWithDrawer;