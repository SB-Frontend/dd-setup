import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  ResponsiveContainer,
} from "recharts";

const ReportUserMetrics = ({ totalStats }) => {
  // Define chart data with full opacity colors
  const chartData = [
    { name: "Blog", value: totalStats.blog, color: "#8b5cf6" },
    { name: "PR", value: totalStats.press_release, color: "#14b8a6" },
    { name: "Subs", value: totalStats.news_subscribe, color: "#9333ea" },
    { name: "Leads", value: totalStats.lead, color: "#0ea5e9" },
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-5 h-72">
      <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-4">
        Report & User Metrics
      </h3>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={chartData}
          margin={{ top: 20, right: 20, left: 0, bottom: 25 }}
          barSize={60}
        >
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip
            contentStyle={{
              backgroundColor: "#fff",
              borderRadius: "6px",
              border: "1px solid #ccc",
            }}
            itemStyle={{ color: "#1f2937", fontWeight: 500 }}
            labelStyle={{ color: "#1f2937", fontWeight: 600 }}
            cursor={{ fill: "rgba(0, 0, 0, 0.05)" }}
          />
          <Bar dataKey="value">
            {chartData.map(({ color }, index) => (
              <Cell key={`cell-${index}`} fill={color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ReportUserMetrics;


