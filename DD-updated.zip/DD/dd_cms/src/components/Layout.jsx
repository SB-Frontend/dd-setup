// src/components/Layout.jsx
import React from 'react';
import Navbar from '@/components/shared/Navbar';
import Sidebar from './Sidebar';
import Footer from '@/components/shared/Footer';

const Layout = ({ children, toggleDarkMode, isDarkMode, toggleSidebar, isSidebarOpen }) => {
  return (
    <div className="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-screen flex flex-col transition-all duration-300">
      <Navbar
        onToggleDarkMode={toggleDarkMode}
        isDarkMode={isDarkMode}
        toggleSidebar={toggleSidebar}
        isSidebarOpen={isSidebarOpen}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar isOpen={isSidebarOpen} toggle={toggleSidebar} />
        <main className="flex-1 p-4 mt-16 mb-8 overflow-y-auto md:ml-64">
          {children}
        </main>
      </div>

      <Footer />
    </div>
  );
};

export default Layout;
