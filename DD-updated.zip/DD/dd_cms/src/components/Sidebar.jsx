import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  FileText,
  Newspaper,
  CircleUserRound,
  Folder,
  UserCheck,
  ShieldCheck,
  ChevronRight,
  ChevronDown,
  Link as LinkIcon,
  SquarePlus,
  FolderTree,
  Megaphone,
  ListTree,
  Tags,
  Image,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";

// Route aliases to ensure correct highlighting
const routeAliases = {
  "/posts/create": "/posts/list",
  "/posts/edit": "/posts/list",
  // "/events/create": "/events/list",
  // "/events/edit": "/events/list",
  // "/tools/add": "/tools/list",
  // "/tools/edit": "/tools/list",
  // "/podcasts/create": "/podcasts/list",
  // "/podcasts/edit": "/podcasts/list",
  // "/questions/list": "/questions/list",
  // "/advertisement-leads": "/advertisement-leads",
  // "/questions/add-answers": "/questions/list",
  // "/questions/edit-answers/": "/questions/add-answers",
  // Add more aliases as needed
};

const resolveActivePath = (path) => {
  if (routeAliases[path]) return routeAliases[path];
  const matchedAlias = Object.keys(routeAliases).find((alias) =>
    path.startsWith(alias)
  );
  return matchedAlias ? routeAliases[matchedAlias] : path;
};

const menuItems = [
  {
    path: "/dashboard",
    label: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    path: "/User Management",
    label: "User Management",
    icon: Users,
    // perm_id: 3,
    children: [
      { path: "/users", label: "User List", icon: UserCheck },
      // { path: "/roles", label: "Roles", icon: ShieldCheck },
    ],
  },
  {
    path: "/author",
    label: "Author Management",
    icon: CircleUserRound,
    // perm_id: 8,
  },
  {
    path: "/posts",
    label: "Posts",
    icon: Newspaper,
    // perm_id: 2,
    children: [
      { path: "/posts/list", label: "Posts List", icon: FileText },
      { path: "/posts/media/list", label: "Media List", icon: Image },
    ],
  },
  {
    path: "/Category",
    label: "Category",
    icon: FolderTree,
    // perm_id: 5,
    children: [
      { path: "/category", label: "Category", icon: Tags },
      // { path: "/subcategory", label: "Subcategory", icon: ListTree },
    ],
  },
  {
    path: "/leads",
    label: "Leads",
    icon: Users,
    // perm_id: 4,
    children: [
      { path: "/leads/list", label: "Contact Leads", icon: Folder },
      { path: "/subscriber-leads", label: "Subscriber Leads", icon: Folder },
      // { path: "/brand-kit-leads", label: "Brand-Kit Leads", icon: Folder },
    ],
  },
  // {
  //   path: "/advertisement",
  //   label: "Advertisement",
  //   icon: Megaphone,
  //   perm_id: 7,
  //   children: [
  //     {
  //       path: "/advertisement/list",
  //       label: "Create Advertisement",
  //       icon: SquarePlus,
  //     },
  //   ],
  // },
];



function Sidebar({ isOpen, toggle, sidebarRef }) {
  const location = useLocation();
  const resolvedPath = resolveActivePath(location.pathname);
  const [openSubmenus, setOpenSubmenus] = useState([]);
  const [filteredMenu, setFilteredMenu] = useState([]);
  const submenuRefs = useRef({});
  const { permissions } = useAuth();

  const toggleSubmenu = useCallback((path) => {
    setOpenSubmenus((prev) =>
      prev.includes(path) ? [] : [path]
    );
  }, []);

  useEffect(() => {
    const parsedPerms = Array.isArray(permissions)
      ? permissions
      : JSON.parse(permissions || '[]');

    const permMap = new Map(parsedPerms.map((p) => [p.perm_id, p.read]));

    const filterMenu = (items) =>
      items
        .map((item) => {
          if (item.label === 'Dashboard') return item;
          if (item.perm_id && permMap.get(item.perm_id) !== 1) return null;
          if (item.children?.length) {
            const filteredChildren = filterMenu(item.children);
            return filteredChildren.length ? { ...item, children: filteredChildren } : null;
          }
          return item;
        })
        .filter(Boolean);

    setFilteredMenu(filterMenu(menuItems));
  }, [permissions]);

  useEffect(() => {
    const activeParent = filteredMenu.find((item) =>
      item.children?.some((child) => resolvedPath.startsWith(child.path))
    );
    if (activeParent) {
      setOpenSubmenus([activeParent.path]);
    } else {
      setOpenSubmenus([]);
    }
  }, [resolvedPath, filteredMenu]);

  useEffect(() => {
    Object.entries(submenuRefs.current).forEach(([path, ref]) => {
      if (ref) {
        ref.style.transition = 'max-height 0.3s ease';
        ref.style.overflow = 'hidden';
        ref.style.maxHeight = openSubmenus.includes(path)
          ? `${ref.scrollHeight}px`
          : '0px';
      }
    });
  }, [openSubmenus]);

  const renderMenuItem = (item) => {
    const hasChildren = item.children?.length > 0;
    const isSubmenuOpen = openSubmenus.includes(item.path);
    const isActive =
      resolvedPath === item.path ||
      (hasChildren &&
        item.children.some(
          (child) =>
            resolvedPath === child.path || resolvedPath.startsWith(child.path + '/')
        ));
    const Icon = item.icon;
    return (
      <li key={item.path} className="w-full">
        <div
          className={`nav_menu !p-0 ${isActive ? "nav_active" : ""}`}
          onClick={() => {
            if (hasChildren) {
              toggleSubmenu(item.path);
            } else {
              setOpenSubmenus([]);
            }
          }}
        >
          <Link
            to={item.path}
            className="flex w-full items-center gap-2"
            onClick={(e) => hasChildren && e.preventDefault()}
          >
            {Icon && <Icon className="ml-2 h-4 w-4 shrink-0" />}
            <span className="py-2 text-sm">{item.label}</span>
          </Link>

          {hasChildren &&
            (isSubmenuOpen ? (
              <ChevronDown className="mr-2 h-4 w-4 shrink-0" />
            ) : (
              <ChevronRight className="mr-2 h-4 w-4 shrink-0" />
            ))}
        </div>

        {hasChildren && (
          <ul
            ref={(el) => (submenuRefs.current[item.path] = el)}
            className="ml-4 space-y-1 pt-1 text-sm"
          >
            {item.children.map((child) => {
              const ChildIcon = child.icon;
              const isChildActive =
                resolvedPath === child.path ||
                resolvedPath.startsWith(child.path + "/");

              return (
                <li key={child.path}>
                  <Link
                    to={child.path}
                    className={`sub_menu !flex items-center gap-2 ${isChildActive ? "nav_active" : ""
                      }`}
                  >
                    {ChildIcon && <ChildIcon className="h-4 w-4 shrink-0" />}
                    <span className="text-sm">{child.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </li>
    );
  };

  return (
    <div
      ref={sidebarRef}
      className={`fixed left-0 top-16 z-30 h-[calc(100vh-4rem)] w-64 overflow-y-auto border-r border-[var(--border)] bg-[var(--background)] px-3 py-4 font-semibold text-[var(--foreground)] transition-transform duration-300 ease-in-out md:translate-x-0 ${isOpen ? "translate-x-0" : "-translate-x-full"}`}
    >
      <ul>{filteredMenu.map(renderMenuItem)}</ul>
    </div>
  );
}

export default Sidebar;
