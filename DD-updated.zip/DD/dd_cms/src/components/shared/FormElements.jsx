import React from 'react';

export const InputField = ({ label, icon: Icon, error, type = 'text', required = false, ...props }) => {
  const isReadOnly = props.readOnly;
  return (
    <div>
      {label && (
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
          {Icon && <Icon className="w-4 h-4" />}
          <span className="flex items-center gap-0.5">
            {label}
            {required && <span className="text-red-500">*</span>}
          </span>
        </label>
      )}
      <input
        type={type}
        {...props}
        className={`mt-1 block w-full text-sm px-3 py-2 border rounded-md shadow-sm focus:outline-none 
    focus:ring-1 focus:ring-blue-500 focus:border-blue-500 focus:bg-white dark:focus:bg-gray-800
    ${
      error
        ? "border-red-500 ring-red-500 focus:ring-red-500 focus:border-red-500 dark:border-red-500"
        : "border-gray-300 dark:border-gray-600"
    }
    ${
      isReadOnly
        ? "bg-gray-100 dark:bg-gray-700 cursor-not-allowed"
        : "bg-white dark:bg-gray-800"
    }`}
      />

      {error && <p className="text-red-600 text-xs mt-1  ms-2">{error}</p>}
    </div>
  );
};

export const Section = ({ icon: Icon, title, children }) => (
  <div className="bg-white dark:bg-gray-800 p-4 rounded-md mb-3">
    <div className="flex items-center mb-3">
      {Icon && <Icon className="w-5 h-5 mr-2" />}
      <h3 className="font-semibold">{title}</h3>
    </div>
    {children}
  </div>
);

export const SelectField = ({ label, icon: Icon, value, onChange, options = [], placeholder = '', className = '' }) => {
  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 block">
          {label}
        </label>
      )}
      <div className="relative">
        {Icon && <Icon className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />}
        <select
          value={value}
          onChange={onChange}
          className={`pl-10 pr-3 py-2 w-full text-sm border rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-white dark:border-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500`}
        >
          <option value="">{placeholder || `Select ${label}`}</option>
          {options.map((opt, index) => (
            <option key={index} value={opt.value || opt}>
              {opt.label || opt}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

export const FieldGroup = (items, handleChange, remove, placeholders) => (
  items.map((item, index) => (
    <div key={index} className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-2 mb-2">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {Object.keys(item).map((key, idx) => (
          <InputField
            key={idx}
            placeholder={placeholders[key] || key}
            value={item[key]}
            onChange={(e) => handleChange(index, key, e.target.value)}
          />
        ))}
      </div>
      <button
        type="button"
        onClick={() => remove(index)}
        className="mt-1 px-3 py-1 text-sm text-white bg-red-600 hover:bg-red-700 rounded-md"
      >
        Remove
      </button>
    </div>
  ))
);
