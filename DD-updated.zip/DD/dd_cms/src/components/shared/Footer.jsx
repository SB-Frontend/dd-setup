import React from "react";

const Footer = () => {
  return (
    <footer className="fixed inset-x-0 bottom-0 z-20 border border-[var(--border)] bg-[var(--background)] px-4 py-2 text-right text-[var(--muted-foreground)]">
      <p className="text-xs">
        &copy; {new Date().getFullYear()} Designed and Developed by KGV.
      </p>
    </footer>
  );
};

export default Footer;