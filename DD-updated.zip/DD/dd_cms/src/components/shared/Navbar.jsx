import React, { useState, useRef, useEffect } from "react";
import { Sun, Moon, Menu, X, User, LogOut, Bell } from 'lucide-react';

import { useAuth } from '@/context/AuthContext';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { usePermission } from '@/hooks/usePermission';

function Navbar({ onToggleDarkMode, isDarkMode, toggleSidebar, isSidebarOpen }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [isOpen, setIsOpen] = useState(false); // profile menu
  const [isNotifOpen, setIsNotifOpen] = useState(false); // notification menu
  const [totalNotificaions, setTotalNotificaions] = useState(0);
  const dropdownRef = useRef(null);
  const notifRef = useRef(null);

  // Example notification counts (can be fetched from API)
  const [notifications, setNotifications] = useState({
    reports_saved: 0,
    reports_assigned: 0,
    pr_saved: 0,
    pr_assigned: 0,
    leads_count: 0,

  });

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target)) {
        setIsNotifOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // useEffect(() => {
  //   async function fetchNotifications() {
  //     try {
  //       const res = await apiGet(`/dashboard/user_pending_task/${user.id}`);
  //       // console.log("res in navbar ", res[0]);

  //       setNotifications({
  //         reports_saved: res[0].reports_saved || 0,
  //         reports_assigned: res[0].reports_assigned || 0,
  //         pr_saved: res[0].pr_saved || 0,
  //         pr_assigned: res[0].pr_assigned || 0,
  //         leads_count: res[0].leads_count || 0,
  //       });

  //       setTotalNotificaions(
  //         Number(res[0].reports_saved || 0) +
  //           Number(res[0].reports_assigned || 0) +
  //           Number(res[0].pr_saved || 0) +
  //           Number(res[0].pr_assigned || 0) +
  //           Number(res[0].leads_count || 0)
  //       );
  //     } catch (err) {
  //       console.error('Error fetching notifications:', err);
  //     }
  //   }

  //   fetchNotifications();
  // }, [location.pathname, user.id]); // <-- will run whenever the page changes

  // const reportsPerm = usePermission(5);
  // const prPerm = usePermission(7);
  // const leadsPerm = usePermission(6);
  // const canReportNotification = reportsPerm.p_read === 1 || reportsPerm.p_create === 1 || reportsPerm.p_update === 1;
  // const canPrNotification = prPerm.p_read === 1 || prPerm.p_create === 1 || prPerm.p_update === 1;
  // const canLeadsNotification = leadsPerm.p_read === 1 || leadsPerm.p_create === 1 || leadsPerm.p_update === 1;

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <nav className="fixed inset-x-0 top-0 z-40 flex h-16 items-center justify-between border-b border-[var(--border)] bg-[var(--background)] px-4 text-[var(--foreground)] shadow-sm">
      {/* Left Section */}
      <div className="flex items-center gap-2 md:gap-4">
        {/* Mobile Menu Button */}
        <button
          type="button"
          onClick={toggleSidebar}
          className="flex h-9 w-9 items-center justify-center rounded-md text-[var(--muted-foreground)] transition hover:bg-[var(--muted)] hover:text-[var(--primary)] focus:outline-none focus:ring-2 focus:ring-[var(--ring)]/20 md:hidden"
          aria-label="Toggle Mobile Menu"
        >
          {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>

        {/* Logo */}
        <Link
          to="/"
          className="flex h-12 items-center"
          aria-label="DataDemand Dashboard"
        >
          <img
            src="/assets/logo/data-demand-logo.png"
            alt="DataDemand Logo"
            className="block h-8 w-auto object-contain dark:hidden md:h-10"
          />
          <img
            src="/assets/logo/datademand-logo.webp"
            alt="DataDemand Logo"
            className="hidden h-8 w-auto object-contain dark:block md:h-10"
          />
        </Link>
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-1 md:gap-3">
        {/* Dark Mode Toggle */}
        <button
          type="button"
          onClick={onToggleDarkMode}
          className="flex h-9 w-9 items-center justify-center rounded-md text-[var(--muted-foreground)] transition hover:bg-[var(--muted)] hover:text-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--ring)]/20"
          aria-label="Toggle Dark Mode"
        >
          {isDarkMode ? <Moon size={19} /> : <Sun size={19} />}
        </button>

        {/* User Menu */}
        <div className="relative text-left" ref={dropdownRef}>
          <button
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center rounded-md px-2 py-1.5 transition hover:bg-[var(--muted)] focus:outline-none focus:ring-2 focus:ring-[var(--ring)]/20"
            aria-expanded={isOpen}
            aria-haspopup="menu"
          >
            {/* Avatar */}
            <img
              src="/assets/user-icon.svg"
              alt=""
              className="h-8 w-8 rounded-full object-cover"
            />

            {/* User Details */}
            <div className="ml-2 hidden text-left sm:block">
              <p className="text-sm font-medium leading-5 text-[var(--foreground)]">
                {user.name}
              </p>
              <p className="text-[11px] font-normal leading-4 text-[var(--muted-foreground)]">
                {user.rolename}
              </p>
            </div>
          </button>

          {/* Dropdown */}
          {isOpen && (
            <div
              className="absolute right-0 top-full z-50 mt-2 w-44 overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--card)] shadow-lg ring-1 ring-black/5"
              role="menu"
            >
              {/* Profile */}
              <Link
                to="/profile"
                onClick={() => setIsOpen(false)}
                className="flex w-full items-center gap-2 px-3 py-2.5 text-sm text-[var(--foreground)] transition hover:bg-[var(--muted)] hover:text-[var(--primary)]"
                role="menuitem"
              >
                <User className="h-4 w-4" />
                <span>My Profile</span>
              </Link>

              {/* Divider */}
              <div className="border-t border-[var(--border)]" />

              {/* Logout */}
              <button
                type="button"
                onClick={handleLogout}
                className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm text-[var(--foreground)] transition hover:bg-[var(--error-light)] hover:text-[var(--error)]"
                role="menuitem"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
