"use client";
import React, { useEffect, useState } from "react";
import GenericTable from "@/components/TableStructure";
import ConfirmationModal from "@/components/ConfirmationModal";
import { apiGet, apiPost, apiPut, apiDelete } from "@/utils/api";
import { Pencil, Trash2 } from "lucide-react";
import FormInput from "@/components/FormInput";
import toast from "react-hot-toast";
import { usePermission } from "@/hooks/usePermission";
import NoAccess from "@/components/NoAccess";

const SubcategoryPage = () => {
    const [allData, setAllData] = useState([]);
    const [categoryData, setCategoryData] = useState([]);
    const [formData, setFormData] = useState({
        p_cat: "",
        subcat_name: "",
        subcat_slug: "",
        meta_title: "",
        meta_desc: "",
        meta_keywords: "",
    });
    const [editId, setEditId] = useState(null);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [deleteId, setDeleteId] = useState(null);
    const [isEditing, setIsEditing] = useState(false);

    const rcatPerm = usePermission(5) || {};
    const canRead = rcatPerm.read === 1;
    const canCreate = rcatPerm.create === 1;
    const canEdit = rcatPerm.update === 1;
    const canDelete = rcatPerm.delete === 1;

    // const handleInputChange = (name, value) => {
    //   setFormData((prev) => ({
    //     ...prev,
    //     [name]: value,
    //   }));
    // };

    const handleInputChange = (name, value) => {
        setFormData((prev) => {
            const updated = {
                ...prev,
                [name]: value,
            };

            if (name === "subcat_name") {
                updated.subcat_slug = value
                    .trim()
                    .toLowerCase()
                    .replace(/\s+/g, "-")
                    .replace(/[^a-z0-9-]/g, "");
            }

            return updated;
        });
    };

    const handleCancel = () => {
        setFormData({
            p_cat: "",
            subcat_name: "",
            subcat_slug: "",
            meta_title: "",
            meta_desc: "",
            meta_keywords: "",
        });
        setIsEditing(false);
        setEditId(null);
        setEditId(null);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!formData.subcat_name || !formData.subcat_slug) {
            toast.error("SubCategory Title and Slug are required!");
            return;
        }
        try {
            if (editId) {
                await apiPut(`/subcategory/${editId}`, formData);
                toast.success("SubCategory updated successfully!");
            } else {
                await apiPost("/subcategory", formData);
                toast.success("Subcategory added successfully!");
            }
            const updatedData = await apiGet("/subcategory/get_all_subcategories");
            setAllData(updatedData.data || []);
            handleCancel();
        } catch (err) {
            toast.error("Operation failed");
            console.error(err);
        }
    };

    const handleEdit = (id) => {
        const selected = allData.find((item) => item.subcat_id === id);
        if (selected) {
            setFormData({
                p_cat: selected.p_cat || "",
                subcat_name: selected.subcat_name || "",
                subcat_slug: selected.subcat_slug || "",
                meta_title: selected.meta_title || "",
                meta_desc: selected.meta_desc || "",
                meta_keywords: selected.meta_keywords || "",
            });
            setIsEditing(true);
            setEditId(id);
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
    };

    const handleDelete = (id) => {
        setDeleteId(id);
        setIsDeleteModalOpen(true);
    };

    const confirmDelete = async () => {
        if (!deleteId) return;
        try {
            await apiDelete(`/subcategory/${deleteId}`);
            toast.success("Subcategory deleted successfully!");
            const updatedData = await apiGet("/subcategory/get_all_subcategories");
            setAllData(updatedData.data || []);
        } catch (err) {
            toast.error("Failed to delete category.");
        }
        setDeleteId(null);
        setIsDeleteModalOpen(false);
    };

    const columns = [
        { accessorKey: "subcat_id", header: "ID" },
        { accessorKey: "subcat_name", header: "SubCategory Title" },
        { accessorKey: "subcat_slug", header: "SubCategory Slug" },
    ];

    if (canEdit || canDelete) {
        columns.push({
            accessorKey: "actions",
            header: "Action",
            cell: ({ row }) => {
                const id = row.original.subcat_id;
                return (
                    <div className="flex gap-2 justify-center items-center">
                        {canEdit && canCreate && (
                            <button
                                onClick={() => handleEdit(id)}
                                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition"
                                title="Edit"
                                aria-label="Edit"
                            >
                                <Pencil size={20} />
                            </button>
                        )}
                        {canDelete && (
                            <button
                                onClick={() => handleDelete(id)}
                                className="p-1 text-red-600 hover:bg-red-100 dark:hover:bg-red-700 dark:hover:text-white rounded transition"
                                title="Delete"
                                aria-label="Delete"
                            >
                                <Trash2 size={20} />
                            </button>
                        )}
                    </div>
                );
            },
        });
    }

    useEffect(() => {
        const fetchCategoryData = async () => {
            const result = await apiGet("/category/get_all_categories");
            setCategoryData(result.data || []);
        };
        fetchCategoryData();
    }, []);


    useEffect(() => {
        const fetchData = async () => {
            const result = await apiGet("/subcategory/get_all_subcategories");
            setAllData(result.data || []);
        };
        fetchData();
    }, []);

    const fetchDataFunction = async ({ page, limit, search }) => {
        let filtered = [...allData];
        if (search) {
            filtered = filtered.filter((item) =>
                item.subcat_name.toLowerCase().includes(search.toLowerCase())
            );
        }
        const start = (page - 1) * limit;
        const paginated = filtered.slice(start, start + limit);
        return {
            aaData: paginated,
            iTotalRecords: allData.length,
            iTotalDisplayRecords: filtered.length,
        };
    };


    if (!canRead) {
        return <NoAccess />;
    }
    return (
        <>
            <div className="container mx-auto dark:bg-gray-900 rounded-lg ">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Sub Category</h2>


                </div>
                <div className="space-y-8">
                    {canCreate && (
                        <div className="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6">
                            <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
                                {editId ? "Edit Sub Category" : "Add Sub Category"} Information
                            </h2>
                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium mb-1">
                                        Category <span className="text-red-500">*</span>
                                    </label>

                                    <select
                                        name="p_cat"
                                        value={formData.p_cat}
                                        onChange={(e) =>
                                            handleInputChange("p_cat", e.target.value)
                                        }
                                        className="block w-full px-3 py-2 border rounded-md shadow-sm"
                                        required
                                    >
                                        <option value="">Select Category</option>

                                        {categoryData.map((cat) => (
                                            <option key={cat.cat_id} value={cat.cat_id}>
                                                {cat.cat_name}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">


                                    <FormInput
                                        name="subcat_name"
                                        label="Sub Category Title"
                                        placeholder="Sub Category"
                                        value={formData.subcat_name}
                                        onChange={handleInputChange}
                                        required
                                    />
                                    <FormInput
                                        name="subcat_slug"
                                        label="Sub Category Slug"
                                        placeholder="Sub Category Slug"
                                        value={formData.subcat_slug}
                                        onChange={handleInputChange}
                                        required
                                    />
                                    <FormInput
                                        name="meta_title"
                                        label="Meta Title"
                                        placeholder="Meta Title"
                                        value={formData.meta_title}
                                        onChange={handleInputChange}
                                        required
                                    />
                                    <FormInput
                                        name="meta_desc"
                                        label="Meta Desc"
                                        placeholder="Meta Description"
                                        value={formData.meta_desc}
                                        onChange={handleInputChange}
                                        required
                                    />
                                    <FormInput
                                        name="meta_keywords"
                                        label="Meta Keywords"
                                        placeholder="Meta Keywords"
                                        value={formData.meta_keywords}
                                        onChange={handleInputChange}
                                        className="md:col-span-2"
                                    />
                                </div>
                                <div className="flex justify-end gap-4">
                                    <button
                                        type="button"
                                        onClick={handleCancel}
                                        className="px-4 py-2 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-white rounded-md"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md"
                                    >
                                        {editId ? "Update Sub Category" : "Add Sub Category"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    )}

                    {/* Table Section */}
                    <GenericTable
                        columnsConfig={columns}
                        fetchDataFunction={fetchDataFunction}
                        title="Sub Category List"
                    />

                    {/* Confirmation Modal */}
                    <ConfirmationModal
                        isOpen={isDeleteModalOpen}
                        onClose={() => setIsDeleteModalOpen(false)}
                        onConfirm={confirmDelete}
                        title="Delete Sub Category?"
                        message="This action will permanently delete the Sub category."
                        confirmText="Delete"
                        cancelText="Cancel"
                    />
                </div>
            </div>
        </>
    );
};

export default SubcategoryPage;
