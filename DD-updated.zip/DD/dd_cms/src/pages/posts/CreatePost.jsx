import React, { useState, useEffect } from "react";
import {
  CalendarCheck,
  FolderOpen,
  User,
  NotepadText,
  BookText,
  Tags,
  FileSearch2,
  ImagePlus,
} from "lucide-react";
import { InputField, Section } from "@/components/shared/FormElements";
import { useForm, Controller } from "react-hook-form";
const webPath = import.meta.env.VITE_WEBPATH;
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useAuth } from "@/context/AuthContext"; // Adjust the import path as necessary
import { showTailwindAlert } from "@/utils/showTailwindAlert";
import { useNavigate } from "react-router-dom";
import { apiGet, apiPost } from "@/utils/api";
import useAutoSlug from "@/hooks/useAutoSlug";
import { getDateTime } from "@/hooks/getDateTime";
import MediaModal from "./MediaModal";

const CreateBlog = () => {
  const navigate = useNavigate();
  const [previewImage, setPreviewImage] = useState(null);
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [authors, setAuthors] = useState([]);
  const [scriptsLoaded, setScriptsLoaded] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  // const [users, setUsers] = useState([]);
  const [showMediaModal, setShowMediaModal] = useState(false);
  const { user } = useAuth();
  const sessionUser = user?.id || "";

  const {
    register,
    control,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors, touchedFields },
  } = useForm();
  const fetchData = async () => {
    try {
      const [categoryRes, authorRes] = await Promise.all([
        apiGet("/category/get_all_categories"),
        apiGet("/auth/author-list"),
      ]);
      setCategories(categoryRes.data || []);
      setAuthors(authorRes.data || []);
      
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);


  // auto generate slug from title
  useAutoSlug(watch, setValue, "post_title", "post_slug");

  // Initial load


  //   const handleCategoryChange = async (catId) => {
  //     const subcats = await fetchSubcategoriesByCategory(catId);
  //     setSubcategories(subcats);
  //   };

  //  handle form submission
  // console.log("selectedUser",users)
  const formatMySQLDateTime = (date) => {
    if (!date) return "";

    const pad = (value) => String(value).padStart(2, "0");

    return `${date.getFullYear()}-${pad(
      date.getMonth() + 1,
    )}-${pad(date.getDate())} ${pad(
      date.getHours(),
    )}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

 const onSubmit = async (data) => {
  if (isSubmitting) return;

  setIsSubmitting(true);

  const formattedComment = `
    <b>By ${user?.name} [${getDateTime()}]:</b>
    ${data.comment}
  `;

  try {
    const formData = new FormData();

    const postEditor = window.tinymce?.get("post_content");

    formData.append("post_title", data.post_title);
    formData.append("post_slug", data.post_slug);

    formData.append(
      "post_content",
      postEditor ? postEditor.getContent() : "",
    );

    formData.append("post_author", data.post_author);
    formData.append("post_status", data.post_status || "draft");

    formData.append("banner_show", data.banner_show ? 1 : 0);

    formData.append(
      "post_date",
      formatMySQLDateTime(data.post_date || new Date()),
    );

    formData.append("cat_id", data.cat_id);

    formData.append("meta_title", data.meta_title);
    formData.append("meta_description", data.meta_description);
    formData.append("meta_keywords", data.meta_keywords);

    formData.append("session_user", sessionUser);

    formData.append("auto_publish", data.auto_publish ? 1 : 0);
    formData.append("comments", formattedComment);
    formData.append("comment_by", sessionUser);

    if (data.banner_img && data.banner_img.length > 0) {
      formData.append("banner_img", data.banner_img[0]);
    }

    const response = await apiPost("/posts/create", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    if (response.success) {
      await showTailwindAlert({
        title: "Success!",
        text: "Post Created Successfully",
        icon: "success",
      });

      navigate("/posts/list");
    }
  } catch (error) {
    console.error("Create post error:", error);

    const message =
      error?.response?.data?.message ||
      error?.message ||
      "Failed to create post";

    await showTailwindAlert({
      title: "Error",
      text: message,
      icon: "error",
    });
  } finally {
    setIsSubmitting(false);
  }
};

  // handle cancle button action
  const handleCancel = () => {
    reset({
      post_title: "",
      post_slug: "",
      meta_title: "",
      meta_description: "",
      meta_keywords: "",
      post_date: null,
      cat_id: "",
      post_author: "",
      post_content: "",
      banner_img: "",
      post_status: "draft",
      post_priority: "",
      banner_show: 1,
      auto_publish: 0,
      comments: "",
    });

    setPreviewImage(null);

    // Clear TinyMCE content if initialized
    if (window.tinymce?.get("post_content")) {
      window.tinymce.get("post_content").setContent("");
    }
  };

  useEffect(() => {
    const loadScripts = async () => {
      const loadScript = (src) => {
        return new Promise((resolve) => {
          const script = document.createElement("script");
          script.src = src;
          script.onload = resolve;
          document.head.appendChild(script);
        });
      };

      await loadScript(`${webPath}/assets/js/jquery-3.6.0.min.js`);
      await loadScript(`${webPath}/assets/js/jquery-migrate-1.0.0.js`);
      await loadScript(`${webPath}/assets/js/ice/ice-master.min.js`);
      await loadScript(`${webPath}/assets/js/ice/lib/tinymce/tinymce.js`);

      setScriptsLoaded(true);
    };

    loadScripts();
  }, []);

  useEffect(() => {
    if (!scriptsLoaded || !window.tinymce) return;

    // Remove any existing editors
    window.tinymce.remove();

    const commonConfig = {
      plugins:
        "searchreplace print preview paste importcss autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern noneditable help quickbars emoticons",

      toolbar1:
        "undo redo | bold italic underline strikethrough | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | outdent indent | numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen preview save print | insertfile image media template link anchor codesample | ltr rtl",

      extended_valid_elements: "p,span[*],delete[*],insert[*]",

      quickbars_selection_toolbar:
        "bold italic | quicklink h2 h3 blockquote quickimage quicktable addComment",

      noneditable_noneditable_class: "mceNonEditable",

      toolbar_mode: "sliding",

      contextmenu: "link image imagetools table",

      image_caption: true,

      relative_urls: false,

      content_css: `${webPath}/assets/js/ice/demo.css`,

      image_class_list: [
        {
          title: "None",
          value: "",
        },
        {
          title: "Some class",
          value: "class-name",
        },
      ],
    };

    // Main Post Editor
    window.tinymce.init({
      selector: "#post_content",
      height: 500,
      ...commonConfig,
    });


    return () => {
      window.tinymce.remove();
    };
  }, [scriptsLoaded]);

  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">
      <div className="flex items-center justify-between mb-1">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          Add New Post
        </h2>
      </div>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* <input type="hidden" value={start_time} /> */}
        <input type="hidden" value={sessionUser} />
        <Section icon={NotepadText} title="Post Information">
          <div className="mb-4">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Post Title <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              className={`mt-1 w-full text-sm px-3 py-2 border rounded-md shadow-sm focus:outline-none 
              focus:ring-1 focus:ring-blue-500 focus:border-blue-500 dark:focus:ring-blue-500 dark:focus:border-blue-500
              ${
                errors.post_title
                  ? "border-red-500 ring-red-500 focus:ring-red-500 focus:border-red-500 dark:border-red-500 dark:ring-red-500 dark:focus:border-red-500"
                  : "border-gray-300 dark:border-gray-600"
              } 
              dark:bg-gray-800 dark:text-white`}
              {...register("post_title", {
                required: "Post Title is required",
              })}
            />
          </div>

          <div className="mb-4">
            <InputField
              label="Slug URL"
              required
              placeholder="slug-url (auto-generated from title)"
              error={errors.post_slug?.message}
              {...register("post_slug", { required: "Slug URL is required" })}
              // readOnly
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* LEFT COLUMN */}
            <div className="space-y-4">
              {/* Category */}
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-2">
                  <FolderOpen className="icons" />
                  Category <span className="text-red-500">*</span>
                </label>

                <Controller
                  name="cat_id"
                  control={control}
                  rules={{ required: "Category is required" }}
                  render={({ field }) => (
                    <select
                      {...field}
                      className="block w-full px-2 py-2 mt-1 text-sm border border-gray-300 rounded-md dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                    >
                      <option value="">Select Category</option>

                      {categories.map((category) => (
                        <option key={category.cat_id} value={category.cat_id}>
                          {category.cat_name}
                        </option>
                      ))}
                    </select>
                  )}
                />
              </div>

              {/* Podcast Link */}
              {String(watch("cat_id")) === "30347" && (
                <InputField
                  label="Podcast Link"
                  placeholder="https://youtube.com/watch?v=..."
                  {...register("podcast_link", {
                    required: "Podcast Link is required",
                  })}
                  error={errors.podcast_link?.message}
                />
              )}

              {/* Author */}
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                  <User className="icons" />
                  Author <span className="text-red-500">*</span>
                </label>

                <Controller
                  name="post_author"
                  control={control}
                  rules={{ required: "Author is required" }}
                  render={({ field }) => (
                    <select
                      {...field}
                      className="block w-full px-2 py-2 mt-1 text-sm border border-gray-300 rounded-md dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                    >
                      <option value="">Select Author</option>

                      {authors.map((author) => (
                        <option key={author.user_id} value={author.user_id}>
                          {author.display_name}
                        </option>
                      ))}
                    </select>
                  )}
                />

                {errors.post_author && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.post_author.message}
                  </p>
                )}
              </div>

              {/* Publish Date */}
              <div className="flex items-start gap-4">
                {/* Publish Date */}
                <div className="flex-1">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                    <CalendarCheck className="icons" />
                    Publish Date <span className="text-red-500">*</span>
                  </label>

                  <div
                    className={`mt-1 rounded-md shadow-sm border ${
                      errors.post_date
                        ? "border-red-500"
                        : "border-gray-300 dark:border-gray-600"
                    }`}
                  >
                    <Controller
                      control={control}
                      name="post_date"
                      rules={{
                        required: "Publish Date is required",
                      }}
                      render={({ field }) => (
                        <DatePicker
                          selected={field.value}
                          onChange={field.onChange}
                          placeholderText="Select date and time"
                          showTimeSelect
                          timeFormat="hh:mm aa"
                          timeIntervals={5}
                          dateFormat="yyyy-MM-dd hh:mm aa"
                          className="w-full px-3 py-2 text-sm rounded-md border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                        />
                      )}
                    />
                  </div>

                  {errors.post_date && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.post_date.message}
                    </p>
                  )}
                </div>

                {/* Auto Publish */}
                <div className="pt-7">
                  <label
                    htmlFor="auto_publish"
                    className="flex items-center gap-2 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 cursor-pointer whitespace-nowrap"
                  >
                    <input
                      id="auto_publish"
                      type="checkbox"
                      {...register("auto_publish")}
                      className="w-4 h-4 cursor-pointer accent-blue-600"
                    />

                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Auto Publish
                    </span>
                  </label>
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN */}
            <div className="space-y-4">
              {/* Banner Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Banner Image
                </label>

                <div
                  className={`flex items-center px-3 py-1 border rounded-md
      ${
        errors.banner_img
          ? "border-red-500"
          : "border-gray-300 dark:border-gray-600"
      }
      bg-white dark:bg-gray-800`}
                >
                  <Controller
                    name="banner_img"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="file"
                        accept="image/*"
                        className="w-full cursor-pointer file:mr-4 file:py-1 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-500"
                        onChange={(e) => {
                          field.onChange(e.target.files);

                          const file = e.target.files?.[0];
                          setPreviewImage(
                            file ? URL.createObjectURL(file) : null,
                          );
                        }}
                      />
                    )}
                  />
                </div>

                {errors.banner_img && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.banner_img.message}
                  </p>
                )}
              </div>

              {/* Preview */}
              <div className="flex flex-col items-center">
                <h3 className="mb-2 font-medium text-gray-800 dark:text-gray-100">
                  Post Banner Preview
                </h3>

                <div className="w-full max-w-[500px] h-[270px] border border-dashed border-gray-300 dark:border-gray-600 rounded-md overflow-hidden flex items-center justify-center">
                  <img
                    src={
                      previewImage
                        ? previewImage
                        : `${webPath}/assets/blank-image.svg`
                    }
                    alt="Banner Preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </Section>
        <Section icon={FileSearch2} title="SEO Information">
          <div>
            {" "}
            <div className="mb-4">
              <InputField
                label="Meta Title"
                placeholder="Meta Title"
                required
                error={errors.meta_title?.message}
                {...register("meta_title", {
                  required: "Meta title is required",
                  validate: (value) =>
                    value.length <= 60 ||
                    "Meta title cannot exceed 60 characters",
                })}
              />

              <p
                className={`mt-1 text-xs ${
                  (watch("meta_title") || "").length > 60
                    ? "text-red-500"
                    : "text-gray-500"
                }`}
              >
                {(watch("meta_title") || "").length}/60 characters
              </p>
            </div>
            <div className="mb-4">
              <InputField
                label="Meta Description"
                placeholder="Meta Description"
                required
                error={errors.meta_description?.message}
                {...register("meta_description", {
                  required: "Meta description is required",
                  validate: (value) =>
                    value.length <= 160 ||
                    "Meta description cannot exceed 160 characters",
                })}
              />

              <p
                className={`mt-1 text-xs ${
                  (watch("meta_description") || "").length > 160
                    ? "text-red-500"
                    : "text-gray-500"
                }`}
              >
                {(watch("meta_description") || "").length}/160 characters
              </p>
            </div>
            <div className="mb-4">
              <InputField
                label="Meta Keywords"
                placeholder="Meta Keywords"
                required
                error={errors.meta_keywords?.message}
                {...register("meta_keywords", {
                  required: "Meta keywords are required",
                })}
              />
            </div>
          </div>
        </Section>

        <Section icon={BookText} title="Description">
          <div className="flex justify-end mb-3">
            <button
              type="button"
              onClick={() => setShowMediaModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium transition"
            >
              <ImagePlus size={17} />
              Add Media
            </button>
          </div>

          <textarea
            rows={3}
            id="post_content"
            className="w-full text-sm px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:text-white"
          />
        </Section>

        <Section icon={NotepadText} title="Comments">
          <div className="space-y-4">
            {/* Comment */}
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 block">
                Add Comment <span className="text-red-500">*</span>
              </label>

              <textarea
                rows={2}
                placeholder="Enter comment"
                className={`w-full rounded-md px-3 py-2 text-sm dark:bg-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.comment
                    ? "border border-red-500"
                    : "border border-gray-300 dark:border-gray-600"
                }`}
                {...register("comment", {
                  required: "Comment is required",
                })}
              />

              {errors.comment && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.comment.message}
                </p>
              )}
            </div>
          </div>
        </Section>
        <div className="text-end p-4 rounded-md space-x-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className={`inline-flex items-center justify-center px-6 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 transition-all ${
              isSubmitting
                ? "bg-blue-400 cursor-not-allowed opacity-70"
                : "bg-blue-600 hover:bg-blue-700"
            } text-white`}
          >
            {isSubmitting ? (
              <>
                <svg
                  className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                  />
                </svg>
                Creating...
              </>
            ) : (
              "Add Post"
            )}
          </button>
          <button
            type="cancle"
            onClick={handleCancel}
            className="inline-flex items-center  bg-gray-300 text-sm text-gray-800 px-4 py-2 rounded hover:bg-gray-400 focus:outline-none mx-2"
          >
            Cancel
          </button>
        </div>
        <MediaModal
          isOpen={showMediaModal}
          onClose={() => setShowMediaModal(false)}
        />
      </form>
    </div>
  );
};

export default CreateBlog;
