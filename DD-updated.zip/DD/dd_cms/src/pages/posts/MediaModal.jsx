import React, {
  useEffect,
  useState,
  useRef,
} from "react";

import { apiPost } from "@/utils/api";
import toast from "react-hot-toast";

import {
  X,
  Copy,
  Search,
  Loader2,
} from "lucide-react";

const MediaModal = ({
  isOpen,
  onClose,
}) => {
  const [media, setMedia] = useState([]);
  const [loading, setLoading] =
    useState(false);

  const [loadingMore, setLoadingMore] =
    useState(false);

  const [search, setSearch] =
    useState("");

  const [page, setPage] =
    useState(1);

  const [hasMore, setHasMore] =
    useState(true);

  const searchTimeout = useRef(null);

  const LIMIT = 12;
  const imgPath = import.meta.env.VITE_API_IMAGE_PATH;

  // ============================
  // FETCH MEDIA
  // ============================

const fetchMedia = async (
  pageNumber = 1,
  searchValue = "",
  append = false
) => {
  try {
    if (append) {
      setLoadingMore(true);
    } else {
      setLoading(true);
    }

    const res = await apiPost(
      "/media/getlist",
      {
        page: pageNumber,
        limit: LIMIT,
        search: searchValue,
        sort: "media_id",
        order: "DESC",
      }
    );

    const newMedia = res?.aaData || [];

    // IMPORTANT:
    // API returns iTotalDisplayRecords directly
    const totalRecords =
      res?.iTotalDisplayRecords || 0;

    setMedia((prev) => {
      const updatedMedia = append
        ? [...prev, ...newMedia]
        : newMedia;

      // Check if more records are available
      setHasMore(
        updatedMedia.length < totalRecords
      );

      return updatedMedia;
    });

    setPage(pageNumber);

  } catch (error) {
    console.error(
      "Fetch media error:",
      error
    );

    toast.error(
      "Failed to load media"
    );
  } finally {
    setLoading(false);
    setLoadingMore(false);
  }
};
  // ============================
  // INITIAL LOAD
  // ============================

  useEffect(() => {
    if (isOpen) {
      setMedia([]);
      setSearch("");
      setPage(1);
      setHasMore(true);

      fetchMedia(1, "", false);
    }
  }, [isOpen]);

  // ============================
  // SEARCH WITH DEBOUNCE
  // ============================

  const handleSearch = (e) => {
    const value = e.target.value;

    setSearch(value);

    if (searchTimeout.current) {
      clearTimeout(
        searchTimeout.current
      );
    }

    searchTimeout.current =
      setTimeout(() => {
        setPage(1);
        setHasMore(true);

        fetchMedia(
          1,
          value,
          false
        );
      }, 500);
  };

  // ============================
  // LOAD MORE
  // ============================

  const handleLoadMore = () => {
    if (
      loading ||
      loadingMore ||
      !hasMore
    ) {
      return;
    }

    fetchMedia(
      page + 1,
      search,
      true
    );
  };


const handleCopy = async (mediaPath) => {
  const fullUrl = `${imgPath}/posts/${mediaPath}`;
  console.log("Copying URL:", fullUrl);

  try {
    if (
      navigator.clipboard &&
      window.isSecureContext
    ) {
      await navigator.clipboard.writeText(fullUrl);
    } else {
      const textarea =
        document.createElement("textarea");

      textarea.value = fullUrl;
      textarea.style.position = "fixed";
      textarea.style.left = "-9999px";

      document.body.appendChild(textarea);

      textarea.focus();
      textarea.select();

      document.execCommand("copy");

      document.body.removeChild(textarea);
    }

    toast.success("Media URL copied!");
  } catch (err) {
    console.error(
      "Clipboard error:",
      err
    );

    toast.error("Failed to copy");
  }
};

  // ============================
  // MODAL SCROLL
  // ============================

  const handleScroll = (e) => {
    const element =
      e.currentTarget;

    const nearBottom =
      element.scrollHeight -
        element.scrollTop -
        element.clientHeight <
      150;

    if (nearBottom) {
      handleLoadMore();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl w-full max-w-6xl max-h-[90vh] flex flex-col">
        {/* ============================
            HEADER
        ============================ */}

 <div className="flex items-center justify-between gap-6 px-6 py-4">
  
  {/* Header */}
  <div className="min-w-0">
    <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
      Media Library
    </h2>

    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
      Copy an image URL to use it in your content.
    </p>
  </div>

  {/* Search */}
  <div className="relative w-full max-w-sm">
    <Search
      size={18}
      className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
    />

    <input
      type="text"
      value={search}
      onChange={handleSearch}
      placeholder="Search image..."
      className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
  </div>

</div>
        {/* ============================
            MEDIA LIST
        ============================ */}

        <div className="flex-1 overflow-y-auto p-6" onScroll={handleScroll}>
          {loading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 size={30} className="animate-spin text-blue-600" />
            </div>
          ) : media.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-gray-500 dark:text-gray-400">
                No media found.
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
                {media.map((item) => {
                  const fullUrl = `${imgPath}/posts/${item.media_path}`;

                  return (
                  <div
  key={item.media_id}
  className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden bg-white dark:bg-gray-900 shadow-sm hover:shadow-md transition"
>
  <div className="group relative aspect-video bg-gray-100 dark:bg-gray-800 overflow-hidden">
    <img
      src={fullUrl}
      alt={item.media_title || "Media"}
      loading="lazy"
      className="w-full h-full object-cover"
    />

    {/* Copy Button */}
    <button
      type="button"
      onClick={() => handleCopy(item.media_path)}
      title="Copy image URL"
      className="
        absolute
        top-3
        right-3
        z-10
        w-9
        h-9
        rounded-full
        bg-teal-600
        text-white
        flex
        items-center
        justify-center
        shadow-md
        opacity-0
        group-hover:opacity-100
        transition-opacity
        duration-200
        hover:bg-teal-700
      "
    >
      <Copy size={16} />
    </button>
  </div>

  <div className="p-3">
    <p
      title={item.media_title}
      className="text-sm font-medium text-gray-800 dark:text-white truncate"
    >
      {item.media_title}
    </p>
  </div>
</div>
                  );
                })}
              </div>

              {/* LOAD MORE LOADER */}

              {loadingMore && (
                <div className="flex justify-center py-6">
                  <Loader2 size={24} className="animate-spin text-blue-600" />
                </div>
              )}

              {/* END MESSAGE */}

              {!hasMore && media.length > 0 && (
                <p className="text-center text-sm text-gray-400 py-6">
                  No more media
                </p>
              )}
            </>
          )}
        </div>

        {/* ============================
            FOOTER
        ============================ */}

        <div className="flex justify-end px-6 py-4 border-t border-gray-200 dark:border-gray-700">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-md bg-gray-300 hover:bg-gray-400 text-gray-800 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default MediaModal;