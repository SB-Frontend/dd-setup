import React, { useState } from "react";
import GenericTable from "@/components/TableStructure";
import { Pencil } from "lucide-react";
import { Link } from "react-router-dom";
import { apiPatch, apiPost } from "@/utils/api";
import { useAuth } from "@/context/AuthContext";
import { showTailwindAlert } from "@/utils/showTailwindAlert";

const HandoverSentPosts = () => {
  const { user } = useAuth();

  const [refreshFlag, setRefreshFlag] = useState(false);
  const triggerTableReload = () => {
    setRefreshFlag((prev) => !prev);
  };
  const getHandedOverPosts = async ({
  page = 1,
  limit = 10,
  search = "",
  sort = "post_created",
  order = "desc",
}) => {
  const response = await apiPost(
    `/posts/handover_sent/${user?.id}`,
    {
      page,
      limit,
      search,
      sort,
      order,
    }
  );

  return {
    aaData: response?.aaData || [],
    iTotalRecords:
      response?.iTotalRecords || 0,
    iTotalDisplayRecords:
      response?.iTotalDisplayRecords || 0,
  };
};

  const handleStatusToggle = async (postId, currentStatus) => {
    const newStatus = currentStatus === "publish" ? "draft" : "publish";

    const result = await showTailwindAlert({
      title: newStatus === "publish" ? "Publish Post?" : "Move To Draft?",
      text:
        newStatus === "publish"
          ? "This post will be published."
          : "This post will be moved to draft.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    try {
      await apiPatch(`/posts/status/${postId}`, {
        post_status: newStatus,
      });

      // await showTailwindAlert({
      //   title: "Success",
      //   text: "Status updated successfully",
      //   icon: "success",
      // });

      triggerTableReload();
    } catch (error) {
      console.error(error);

      await showTailwindAlert({
        title: "Error",
        text: "Failed to update status",
        icon: "error",
      });
    }
  };

  const columnsConfig = [
    {
      accessorKey: "id",
      header: "ID",
      sortable: true,
    },

    {
      accessorKey: "post_title",
      header: "Post Title",
    },

    {
      accessorKey: "handover_to_name",
      header: "Handed Over To",
      cell: ({ row }) => (
        <span className="font-medium text-blue-700 dark:text-blue-300">
          {row.original.handover_to_name || "-"}
        </span>
      ),
    },

    {
      accessorKey: "post_date",
      header: "Post Date",
      cell: ({ row }) =>
        row.original.post_date
          ? new Date(row.original.post_date).toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            })
          : "-",
    },
{
  accessorKey: "post_status",
  header: "Status",
  cell: ({ row }) => {
    const status = row.original.post_status;

    return (
      <span
        className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
          status === "publish"
            ? "text-green-700 bg-green-100 dark:bg-green-700 dark:text-white"
            : "text-red-700 bg-red-100 dark:bg-red-700 dark:text-white"
        }`}
      >
        {status === "publish"
          ? "Published"
          : "Unpublished"}
      </span>
    );
  },
}

    // {
    //   accessorKey: "post_status",
    //   header: "Status",
    //   cell: ({ row }) => {
    //     const status = row.original.post_status;

    //     return (
    //       <button
    //         onClick={() => handleStatusToggle(row.original.id, status)}
    //         className={`px-2 py-1 rounded-full text-xs font-medium  ${
    //           status === "publish"
    //             ? "text-green-700 bg-green-100 dark:bg-green-700 dark:text-white"
    //             : "text-red-700 bg-red-100 dark:bg-red-700 dark:text-white"
    //         }`}
    //       >
    //         {status === "publish" ? "Published" : "Unpublish"}
    //       </button>
    //     );
    //   },
    // },

    // {
    //   accessorKey: "actions",
    //   header: "Action",
    //   cell: ({ row }) => (
    //     <div className="flex items-center gap-2">
    //       <Link
    //         to={`/posts/edit/${row.original.id}`}
    //         className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded"
    //       >
    //         <Pencil size={16} />
    //       </Link>
    //     </div>
    //   ),
    // },
    // {
    //   accessorKey: "actions",
    //   header: "Action",
    //   cell: ({ row }) => (
    //     <div className="flex items-center gap-2">
    //       <Link
    //         to={`/posts/edit/${row.original.id}`}
    //         className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded"
    //       >
    //         <Pencil size={16} />
    //       </Link>
    //     </div>
    //   ),
    // },
  ];

  const renderExpandedRow = (row) => {
    return (
      <div className="bg-gray-50 dark:bg-gray-800 p-4">
        <div className="font-semibold text-blue-600 mb-2">Comments</div>

        {row.comments ? (
          <div
            className="text-sm text-gray-800 dark:text-gray-200 leading-7"
            dangerouslySetInnerHTML={{
              __html: row.comments,
            }}
          />
        ) : (
          <div className="text-sm text-gray-500 italic">
            No comments available
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          Handed Over Posts
        </h2>
      </div>

      <GenericTable
        title=""
        fetchDataFunction={getHandedOverPosts}
        columnsConfig={columnsConfig}
        enableExpansion={true}
        renderExpandedRow={renderExpandedRow}
        refresh={refreshFlag}
      />
    </div>
  );
};

export default HandoverSentPosts;
