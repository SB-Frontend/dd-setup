import React, { useState, useEffect } from "react";
import {
  CalendarCheck,
  Files,
  FolderOpen,
  Layers,
  User,
  NotepadText,
  BookText,
  Tags,
  FileSearch2,
  ImagePlus,
} from "lucide-react";

import { InputField, Section } from "@/components/shared/FormElements";
import { useForm, Controller } from "react-hook-form";
import { getDateTime } from "@/hooks/getDateTime";
const webPath = import.meta.env.VITE_WEBPATH;
const staticPath = import.meta.env.VITE_STATIC; // for local test
const imgPath = import.meta.env.VITE_API_IMAGE_PATH;
import { fetchSubcategoriesByCategory } from "@/utils/categoryUtils";
import DatePicker from "react-datepicker";
import { apiGet, apiPut } from "@/utils/api";
import { useAuth } from "@/context/AuthContext";
import toast from "react-hot-toast";
import { useParams } from "react-router-dom"; // <-- For route params
import Select from "react-select";
import { showTailwindAlert } from "@/utils/showTailwindAlert";
import { useNavigate } from "react-router-dom";
import useAutoSlug from "@/hooks/useAutoSlug";
import MediaModal from "./MediaModal";

const EditBlog = () => {
  const navigate = useNavigate();
  const [previewImage, setPreviewImage] = useState(null);
  // console.log("check image", previewImage);
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [authors, setAuthors] = useState([]);
  const [scriptsLoaded, setScriptsLoaded] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showMediaModal, setShowMediaModal] = useState(false);
  const { user } = useAuth();
  const sessionUser = user?.id || "";
  const { id } = useParams();
  // console.log("Editing blog with ID:", id);
  const {
    register,
    control,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm();

  // auto generate slug from title
  useAutoSlug(watch, setValue, "post_title", "post_slug");

  // fetch categories, subcategories, tags, and authors
  const fetchData = async (searchText) => {
    try {
      const [categoryRes, authorRes] = await Promise.all([
        apiGet("/category/get_all_categories"),
        apiGet("/auth/author-list"),
    
      ]);
      // console.log("authorRes:", authorRes);
      // setCategories(categoriesData.data);
      // setAuthors(authorsData.data || []);
      setCategories(categoryRes.data || []);
      setAuthors(authorRes.data || []);
      setUsers(usersRes.data || []);
    } catch (error) {
      console.error("Failed to fetch dropdown data", error);
    }
  };
  // Initial load
  useEffect(() => {
    fetchData();
  }, []);

  //   const handleCategoryChange = async (catId) => {
  //     const subcats = await fetchSubcategoriesByCategory(catId);
  //     setSubcategories(subcats);
  //   };

  useEffect(() => {
    if (!authors.length) return;

    const fetchPostDetails = async () => {
      if (!id) return;

      try {
        const response = await apiGet(`/posts/get_post_by_id/${id}`);

        const post = response.main_post;

        if (post.banner_img) {
          setPreviewImage(`${imgPath}/posts/${post.banner_img}`);
        }

        reset({
          post_title: post.post_title || "",

          post_slug: post.post_slug || "",

          meta_title: post.meta_title || "",

          meta_description: post.meta_description || "",

          meta_keywords: post.meta_keywords || "",

          post_date: post.post_date ? new Date(post.post_date) : null,

          cat_id: String(post.cat_id || ""),
          subcat_id: String(post.subcat_id || ""),

          // IMPORTANT
          post_author: String(post.post_author || ""),

          post_content: post.post_content || "",

          podcast_link: post.podcast_link || "",


          img_title: post.img_title || "",

          banner_img: "",

          auto_publish: Number(post.auto_publish) === 1,

          guest_name: voice?.guest_name || "",

          guest_company: voice?.guest_company || "",
        });

        setTimeout(() => {
          if (!window.tinymce) return;

          window.tinymce
            .get("post_content")
            ?.setContent(post.post_content || "");

          if (voice) {
            window.tinymce
              .get("guest_description")
              ?.setContent(voice.guest_description || "");

            window.tinymce
              .get("company_description")
              ?.setContent(voice.company_description || "");
          }
        }, 500);
      } catch (error) {
        console.error("Error fetching post details:", error);
      }
    };

    fetchPostDetails();
  }, [id, reset, scriptsLoaded, authors]);

  const formatMySQLDateTime = (date) => {
    if (!date) return "";

    const pad = (value) => String(value).padStart(2, "0");

    return `${date.getFullYear()}-${pad(
      date.getMonth() + 1,
    )}-${pad(date.getDate())} ${pad(
      date.getHours(),
    )}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

  // Handle form submission
  const onSubmit = async (data) => {
    if (isSubmitting) return;

    setIsSubmitting(true);
    try {
      const formData = new FormData();

      // =====================================
      // COMMENT FORMAT
      // =====================================

      const selectedUser = users.find(
        (u) => String(u.user_id) === String(data.handover_to),
      );

      const handoverName =
        selectedUser?.display_name || selectedUser?.user_name || "";

      const handoverMsg =
        Number(data.handover_to) > 0
          ? ` | <b>Handover To - ${handoverName}</b>`
          : "";

      let formattedComment = "";

      if (data.comment?.trim()) {
        formattedComment = `
        <b>By ${user?.name || "Admin"} [${getDateTime()}]:</b>
        ${data.comment}
        ${handoverMsg}
      `;
      }

      // =====================================
      // BASIC FIELDS
      // =====================================

      formData.append("post_title", data.post_title);
      formData.append("post_slug", data.post_slug);
      formData.append("meta_title", data.meta_title);
      formData.append("meta_description", data.meta_description);
      formData.append("meta_keywords", data.meta_keywords);
      formData.append(
        "post_date",
        data.post_date
          ? formatMySQLDateTime(data.post_date)
          : formatMySQLDateTime(new Date()),
      );
      formData.append("cat_id", data.cat_id);
      formData.append("subcat_id", data.subcat_id);
      formData.append("post_author", data.post_author);
      formData.append("podcast_link", data.podcast_link || "");
      formData.append("auto_publish", data.auto_publish ? 1 : 0);

      const editor = window.tinymce?.get("post_content");

      formData.append("post_content", editor ? editor.getContent() : "");


      // =====================================
      // HANDOVER LOGIC
      // =====================================

      // const isHandover = Number(data.handover_to) > 0;

      // formData.append("handover_to", data.handover_to || 0);

      // Draft = 1
      // Handed Over = 0
      formData.append("draft_status", isHandover ? 0 : 1);

      formData.append("comment_by", sessionUser);

      // formData.append(
      //   "handover_time",
      //   isHandover
      //     ? new Date().toISOString()
      //     : ""
      // );
      // if (isHandover) {
      //   formData.append("handover_time", new Date().toISOString());
      // }

      formData.append("comments", formattedComment);

      formData.append("session_user", sessionUser);

      // =====================================
      // IMAGE
      // =====================================

      if (data.banner_img && data.banner_img.length > 0) {
        formData.append("banner_img", data.banner_img[0]);
      }

      const response = await apiPut(`/posts/${id}`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (response) {
        const successResult = await showTailwindAlert({
          title: "Success!",
          text: "Post Details Updated.",
          icon: "success",
          showCancelButton: false,
          confirmButtonText: "OK",
          allowOutsideClick: false,
        });

        if (successResult.isConfirmed) {
          navigate("/posts/list", {
            replace: true,
          });
        }
      }
    } catch (error) {
      console.error("❌ Error updating post:", error);

      await showTailwindAlert({
        title: "Post Error!",
        text: error?.message || "An error occurred while updating the post.",
        icon: "error",
        showCancelButton: false,
        confirmButtonText: "OK",
        allowOutsideClick: false,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle cancel button
  const handleCancel = () => {
    reset({
      post_title: "",

      post_slug: "",

      meta_title: "",

      meta_description: "",

      meta_keywords: "",

      post_date: null,

      cat_id: "",

      subcat_id: "",

      post_author: "",

      post_content: "",

      banner_img: "",
      auto_publish: false,
    });

    setPreviewImage(null);

    if (window.tinymce) {
      window.tinymce.get("post_content")?.setContent("");
    }
  };

  // Load scripts for TinyMCE
  useEffect(() => {
    const loadScripts = async () => {
      const loadScript = (src) => {
        return new Promise((resolve) => {
          const script = document.createElement("script");

          script.src = src;

          script.onload = resolve;

          document.head.appendChild(script);
        });
      };

      await loadScript(`${webPath}/assets/js/jquery-3.6.0.min.js`);

      await loadScript(`${webPath}/assets/js/jquery-migrate-1.0.0.js`);

      await loadScript(`${webPath}/assets/js/ice/ice-master.min.js`);

      await loadScript(`${webPath}/assets/js/ice/lib/tinymce/tinymce.js`);

      setScriptsLoaded(true);
    };

    loadScripts();
  }, []);

  useEffect(() => {
    if (!scriptsLoaded || !window.tinymce) return;

    // Remove existing editors before creating new ones
    window.tinymce.remove();

    const editors = ["#post_content"];


    window.tinymce.init({
      selector: editors.join(","),

      mode: "exact",

      elements: "tinymce",

      readonly: false,

      plugins:
        "searchreplace print preview paste importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern noneditable help charmap quickbars emoticons",

      toolbar1:
        "undo redo | bold italic underline strikethrough | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | outdent indent | numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen preview save print | insertfile image media template link anchor codesample | ltr rtl",

      extended_valid_elements: "p,span[*],delete[*],insert[*]",

      quickbars_selection_toolbar:
        "bold italic | quicklink h2 h3 blockquote quickimage quicktable addComment",

      noneditable_noneditable_class: "mceNonEditable",

      toolbar_mode: "sliding",

      contextmenu: "link image imagetools table",

      setup: (editor) => {
        editor.on("init", () => {
          if (
            editor.id === "guest_description" ||
            editor.id === "company_description"
          ) {
            editor.theme.resizeTo(null, 250);
          }
        });
      },

      height: 500,

      image_caption: true,
      relative_urls: false,

      content_css: `${webPath}/assets/js/ice/demo.css`,

      image_class_list: [
        {
          title: "None",
          value: "",
        },
        {
          title: "Some class",
          value: "class-name",
        },
      ],
    });

    return () => {
      window.tinymce.remove();
    };
  }, [scriptsLoaded]);

  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">
      <div className="flex items-center justify-between mb-1">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          Edit Post
        </h2>
      </div>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* <input type="hidden" value={start_time} /> */}
        <input type="hidden" value={sessionUser} />
        <Section icon={NotepadText} title="Post Information">
          <div className="mb-4">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Post Title <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              className={`mt-1 w-full text-sm px-3 py-2 border rounded-md shadow-sm focus:outline-none 
                focus:ring-1 focus:ring-blue-500 focus:border-blue-500 dark:focus:ring-blue-500 dark:focus:border-blue-500
                ${
                  errors.post_title
                    ? "border-red-500 ring-red-500 focus:ring-red-500 focus:border-red-500 dark:border-red-500 dark:ring-red-500 dark:focus:border-red-500"
                    : "border-gray-300 dark:border-gray-600"
                } 
                dark:bg-gray-800 dark:text-white`}
              {...register("post_title", {
                required: "Post Title is required",
              })}
            />
          </div>

          <div className="mb-4">
            <InputField
              label="Slug URL"
              required
              placeholder="slug-url (auto-generated from title)"
              error={errors.post_slug?.message}
              {...register("post_slug", { required: "Slug URL is required" })}
              // readOnly
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-6">
            {/* LEFT COLUMN */}
            <div className="space-y-4">
              {/* Publish Date */}
              <div className="flex items-start gap-4">
                {/* Publish Date */}
                <div className="flex-1">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                    <CalendarCheck className="icons" />
                    Publish Date <span className="text-red-500">*</span>
                  </label>

                  <div
                    className={`mt-1 rounded-md shadow-sm border ${
                      errors.post_date
                        ? "border-red-500"
                        : "border-gray-300 dark:border-gray-600"
                    }`}
                  >
                    <Controller
                      control={control}
                      name="post_date"
                      rules={{
                        required: "Publish Date is required",
                      }}
                      render={({ field }) => (
                        <DatePicker
                          selected={field.value}
                          onChange={field.onChange}
                          placeholderText="Select date and time"
                          showTimeSelect
                          timeFormat="hh:mm aa"
                          timeIntervals={5}
                          dateFormat="yyyy-MM-dd hh:mm aa"
                          className="w-full px-3 py-2 text-sm rounded-md border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                        />
                      )}
                    />
                  </div>

                  {errors.post_date && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.post_date.message}
                    </p>
                  )}
                </div>

                {/* Auto Publish */}
                <div className="pt-7">
                  <label
                    htmlFor="auto_publish"
                    className="flex items-center gap-2 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 cursor-pointer whitespace-nowrap"
                  >
                    <input
                      id="auto_publish"
                      type="checkbox"
                      {...register("auto_publish")}
                      className="w-4 h-4 cursor-pointer accent-blue-600"
                    />

                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Auto Publish
                    </span>
                  </label>
                </div>
              </div>

              {/* Author */}
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1">
                  <User className="icons" />
                  Author <span className="text-red-500">*</span>
                </label>

                <Controller
                  name="post_author"
                  control={control}
                  rules={{ required: "Author is required" }}
                  render={({ field }) => (
                    <select
                      {...field}
                      className="block w-full px-2 py-2 mt-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:border-gray-600 dark:bg-gray-800 dark:text-white"
                    >
                      <option value="">Select Author</option>

                      {authors.map((author) => (
                        <option
                          key={author.user_id}
                          value={String(author.user_id)}
                        >
                          {author.author_display_name}
                        </option>
                      ))}
                    </select>
                  )}
                />

                {errors.post_author && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.post_author.message}
                  </p>
                )}
              </div>

              {/* Category */}
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-2">
                  <FolderOpen className="icons" />
                  Category <span className="text-red-500">*</span>
                </label>

                <Controller
                  name="cat_id"
                  control={control}
                  rules={{ required: "Category is required" }}
                  render={({ field }) => (
                    <select
                      {...field}
                      className="block w-full px-2 py-2 mt-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm dark:bg-gray-800 dark:text-white"
                    >
                      <option value="">Select Category</option>

                      {categories.map((category) => (
                        <option key={category.cat_id} value={category.cat_id}>
                          {category.cat_name}
                        </option>
                      ))}
                    </select>
                  )}
                />

                {errors.cat_id && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.cat_id.message}
                  </p>
                )}
              </div>

              {/* Podcast Link */}
              {String(watch("cat_id")) === "30347" && (
                <InputField
                  label="Podcast Link"
                  placeholder="https://spotify.com/..."
                  {...register("podcast_link")}
                />
              )}
            </div>

            {/* RIGHT COLUMN */}
            <div className="space-y-4">
              {/* Banner Image */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Banner Image
                </label>

                <div
                  className={`flex items-center px-3 py-1 border rounded-md cursor-pointer
        ${
          errors.banner_img
            ? "border-red-500 dark:border-red-500"
            : "border-gray-300 dark:border-gray-600"
        }
        bg-white dark:bg-gray-800`}
                >
                  <Controller
                    name="banner_img"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="file"
                        accept="image/*"
                        className="w-full cursor-pointer file:mr-4 file:py-1 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-500 hover:file:bg-blue-100 bg-transparent"
                        onChange={(e) => {
                          field.onChange(e.target.files);
                          const file = e.target.files?.[0];

                          setPreviewImage(
                            file ? URL.createObjectURL(file) : null,
                          );
                        }}
                      />
                    )}
                  />
                </div>

                {errors.banner_img && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.banner_img.message}
                  </p>
                )}
              </div>

              {/* Preview */}
              <div className="flex flex-col items-center">
                <h3 className="mb-2 font-medium text-gray-800 dark:text-gray-100">
                  Post Banner Preview
                </h3>

                <div className="w-full max-w-[500px] h-[270px] border border-dashed border-gray-300 dark:border-gray-600 rounded-md overflow-hidden flex items-center justify-center">
                  <img
                    src={
                      previewImage
                        ? previewImage
                        : `${webPath}/assets/blank-image.svg`
                    }
                    alt="Banner Preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </Section>
        <Section icon={FileSearch2} title="SEO Information">
          <div>
            {" "}
            <div className="mb-4">
              <InputField
                label="Meta Title"
                placeholder="Meta Title"
                required
                error={errors.meta_title?.message}
                {...register("meta_title", {
                  required: "Meta title is required",
                  validate: (value) =>
                    value.length <= 60 ||
                    "Meta title cannot exceed 60 characters",
                })}
              />

              <p
                className={`mt-1 text-xs ${
                  (watch("meta_title") || "").length > 60
                    ? "text-red-500"
                    : "text-gray-500"
                }`}
              >
                {(watch("meta_title") || "").length}/60 characters
              </p>
            </div>
            <div className="mb-4">
              <InputField
                label="Meta Description"
                placeholder="Meta Description"
                required
                error={errors.meta_description?.message}
                {...register("meta_description", {
                  required: "Meta description is required",
                  validate: (value) =>
                    value.length <= 160 ||
                    "Meta description cannot exceed 160 characters",
                })}
              />

              <p
                className={`mt-1 text-xs ${
                  (watch("meta_description") || "").length > 160
                    ? "text-red-500"
                    : "text-gray-500"
                }`}
              >
                {(watch("meta_description") || "").length}/160 characters
              </p>
            </div>
            <div className="mb-4">
              <InputField
                label="Meta Keywords"
                placeholder="Meta Keywords"
                required
                error={errors.meta_keywords?.message}
                {...register("meta_keywords", {
                  required: "Meta keywords are required",
                })}
              />
            </div>
          </div>
        </Section>

        <Section icon={BookText} title="Description">
          <div className="flex justify-end mb-3">
            <button
              type="button"
              onClick={() => setShowMediaModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium transition"
            >
              <ImagePlus size={17} />
              Add Media
            </button>
          </div>

          <textarea
            rows={3}
            id="post_content"
            className="w-full text-sm px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:text-white"
          />
        </Section>

        <Section icon={NotepadText} title="Handover & Comments">
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 block">
                Add Comment <span className="text-red-500">*</span>
              </label>

              <textarea
                rows={2}
                placeholder="Enter comment"
                className={`w-full rounded-md px-3 py-2 text-sm dark:bg-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.comment
                    ? "border border-red-500"
                    : "border border-gray-300 dark:border-gray-600"
                }`}
                {...register("comment", {
                  required: "Comment is required",
                })}
              />

              {errors.comment && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.comment.message}
                </p>
              )}
            </div>
          </div>
        </Section>
        <div className="text-end p-4 rounded-md space-x-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className={`inline-flex items-center justify-center px-6 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 transition-all ${
              isSubmitting
                ? "bg-blue-400 cursor-not-allowed opacity-70"
                : "bg-blue-600 hover:bg-blue-700"
            } text-white`}
          >
            {isSubmitting ? (
              <>
                <svg
                  className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                  />
                </svg>
                Creating...
              </>
            ) : (
              "Add Post"
            )}
          </button>
          <button
            type="cancle"
            onClick={handleCancel}
            className="inline-flex items-center  bg-gray-300 text-sm text-gray-800 px-4 py-2 rounded hover:bg-gray-400 focus:outline-none mx-2"
          >
            Cancel
          </button>
        </div>
        <MediaModal
          isOpen={showMediaModal}
          onClose={() => setShowMediaModal(false)}
        />
      </form>
    </div>
  );
};

export default EditBlog;
