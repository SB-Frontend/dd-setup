import React, { useState, useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import GenericTable from "@/components/TableStructure";
import { Pencil, Trash2 } from "lucide-react";
import { showTailwindAlert } from "@/utils/showTailwindAlert";
import { apiGet, apiPost, apiDelete, apiPatch } from "@/utils/api";

const PostList = () => {
  const [refreshFlag, setRefreshFlag] = useState(false);
  const [categories, setCategories] = useState([]);
  const [subCategories, setSubCategories] = useState([]);
  const [authors, setAuthors] = useState([]);

  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSubCategory, setSelectedSubCategory] = useState("");
  const [selectedAuthor, setSelectedAuthor] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const location = useLocation();

  const triggerTableReload = () => {
    setRefreshFlag((prev) => !prev);
  };

  const handleResetFilters = () => {
    setSelectedCategory("");
    setSelectedSubCategory("");
    setSelectedAuthor("");
    setSelectedStatus("");
    setFromDate("");
    setToDate("");

    setSubCategories([]);

    triggerTableReload();
  };

  // ===================================
  // LOAD FILTERS
  // ===================================

  useEffect(() => {
    const loadFilters = async () => {
      try {
        const [catRes, authorRes] = await Promise.all([
          apiGet("/category/get_all_categories"),
          apiGet("/auth/author-list"),
        ]);

        setCategories(catRes?.data || []);
        setAuthors(authorRes?.data || []);
      } catch (err) {
        console.error(err);
      }
    };

    loadFilters();
  }, []);

  // ===================================
  // INITIALIZE CATEGORY
  // ===================================

  useEffect(() => {
    const initializeCategory = async () => {
      if (!location.state?.categorySlug || !categories.length) {
        return;
      }

      const matchedCategory = categories.find(
        (cat) => cat.cat_slug === location.state.categorySlug
      );

      if (!matchedCategory) return;

      setSelectedCategory(matchedCategory.cat_id);

      try {
        const response = await apiGet(
          `/subcategory/by-category/${matchedCategory.cat_id}`
        );

        setSubCategories(response?.data || []);
      } catch (err) {
        console.error(err);
      }

      triggerTableReload();
    };

    initializeCategory();
  }, [categories, location.state]);

  // ===================================
  // CATEGORY CHANGE
  // ===================================

  const handleCategoryChange = async (catId) => {
    setSelectedCategory(catId);

    setSelectedSubCategory("");

    try {
      const response = await apiGet(
        `/subcategory/by-category/${catId}`
      );

      setSubCategories(response?.data || []);
    } catch (error) {
      console.error(error);
      setSubCategories([]);
    }
  };

  // ===================================
  // FETCH POSTS
  // ===================================

  const getPostList = async ({
    page = 1,
    limit = 10,
    search = "",
    sort = "post_created",
    order = "desc",
  }) => {
    const payload = {
      page,
      limit,
      search,
      sort,
      order,
    };

    if (selectedCategory) {
      payload.cat_id = selectedCategory;
    }

    if (selectedSubCategory) {
      payload.subcat_id = selectedSubCategory;
    }

    if (selectedAuthor) {
      payload.post_author = selectedAuthor;
    }

    if (selectedStatus) {
      payload.post_status = selectedStatus;
    }

    if (fromDate) {
      payload.from_date = fromDate;
    }

    if (toDate) {
      payload.to_date = toDate;
    }

    const response = await apiPost(
      "/posts/get_all_posts",
      payload
    );

    return response;
  };

  // ===================================
  // DELETE POST
  // ===================================

  const handleDelete = async (id) => {
    try {
      const result = await showTailwindAlert({
        title: "Delete Post?",
        text: "This post will be permanently deleted.",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Delete",
      });

      if (!result.isConfirmed) return;

      await apiDelete(`/posts/${id}`);

      await showTailwindAlert({
        title: "Success",
        text: "Post deleted successfully.",
        icon: "success",
      });

      triggerTableReload();
    } catch (error) {
      console.error(error);

      showTailwindAlert({
        title: "Error",
        text: error.message,
        icon: "error",
      });
    }
  };

  // ===================================
  // STATUS TOGGLE
  // ===================================

  const handleStatusToggle = async (postId, currentStatus) => {
    const newStatus =
      currentStatus === "publish"
        ? "draft"
        : "publish";

    const result = await showTailwindAlert({
      title:
        newStatus === "publish"
          ? "Publish Post?"
          : "Move To Draft?",
      text:
        newStatus === "publish"
          ? "This post will be published."
          : "This post will be moved to draft.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    try {
      await apiPatch(
        `/posts/status/${postId}`,
        {
          post_status: newStatus,
        }
      );

      triggerTableReload();
    } catch (error) {
      console.error(error);

      await showTailwindAlert({
        title: "Error",
        text: "Failed to update status",
        icon: "error",
      });
    }
  };

  // ===================================
  // TABLE COLUMNS
  // ===================================

  const columnsConfig = [
    {
      accessorKey: "id",
      header: "ID",
      sortable: true,
    },

    {
      accessorKey: "post_title",
      header: "Post Title",
    },

    {
      accessorKey: "post_date",
      header: "Publish Date",
      sortable: true,
      cell: ({ getValue }) =>
        getValue()
          ? new Date(getValue()).toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            })
          : "-",
    },

    {
      accessorKey: "cat_name",
      header: "Category",
      cell: ({ getValue }) => getValue() || "-",
    },

    {
      accessorKey: "post_status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.original.post_status;

        return (
          <button
            onClick={() =>
              handleStatusToggle(
                row.original.id,
                status
              )
            }
            className={`px-2 py-1 rounded-full text-xs font-medium cursor-pointer ${
              status === "publish"
                ? "text-green-700 bg-green-100 dark:bg-green-700 dark:text-white"
                : "text-red-700 bg-red-100 dark:bg-red-700 dark:text-white"
            }`}
          >
            {status === "publish"
              ? "Published"
              : "Unpublished"}
          </button>
        );
      },
    },

    {
      accessorKey: "actions",
      header: "Action",
      cell: ({ row }) => {
        return (
          <div className="flex gap-2">
            <Link
              to={`/posts/edit/${row.original.id}`}
              className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded"
            >
              <Pencil size={16} />
            </Link>

            <button
              onClick={() =>
                handleDelete(row.original.id)
              }
              className="p-1 text-red-600 hover:bg-red-100 dark:hover:bg-red-700 dark:hover:text-white rounded transition"
            >
              <Trash2 size={20} />
            </button>
          </div>
        );
      },
    },
  ];

  // ===================================
  // EXPANDABLE ROW CONTENT
  // ===================================

  const renderExpandedRow = (row) => {
    return (
      <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-md space-y-3">

        <div>
          <strong>Sub Category:</strong>{" "}
          {row.subcat_name || "-"}
        </div>

        <div>
          <strong>Author:</strong>{" "}
          {row.author_display_name || "-"}
        </div>

        <div>
          <strong>Comments:</strong>

          <div
            className="mt-2 text-sm text-gray-700 dark:text-gray-300"
            dangerouslySetInnerHTML={{
              __html:
                row.comments ||
                "No comments available",
            }}
          />
        </div>

      </div>
    );
  };

  // ===================================
  // RENDER
  // ===================================

  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">

      {/* Header */}

      <div className="flex justify-between items-center mb-4">

        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          Post List
        </h2>

        <div className="flex items-center gap-2">

          <Link
            to="/posts/create"
            className="px-4 py-2 text-sm text-white bg-blue-600 hover:bg-blue-700 rounded-md"
          >
            New Post
          </Link>

        </div>

      </div>

      {/* Filters */}

      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm mb-4">

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3">

          {/* Category */}

          <select
            value={selectedCategory}
            onChange={(e) => {
              handleCategoryChange(e.target.value);
              triggerTableReload();
            }}
            className="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-3 py-2"
          >
            <option value="">
              All Categories
            </option>

            {categories.map((cat) => (
              <option
                key={cat.cat_id}
                value={cat.cat_id}
              >
                {cat.cat_name}
              </option>
            ))}
          </select>

          {/* Sub Category */}

          <select
            value={selectedSubCategory}
            onChange={(e) => {
              setSelectedSubCategory(e.target.value);
              triggerTableReload();
            }}
            className="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-3 py-2"
          >
            <option value="">
              All Sub Categories
            </option>

            {subCategories.map((sub) => (
              <option
                key={sub.subcat_id}
                value={sub.subcat_id}
              >
                {sub.subcat_name}
              </option>
            ))}
          </select>

          {/* Author */}

          <select
            value={selectedAuthor}
            onChange={(e) => {
              setSelectedAuthor(e.target.value);
              triggerTableReload();
            }}
            className="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-3 py-2"
          >
            <option value="">
              All Authors
            </option>

            {authors.map((author) => (
              <option
                key={author.user_id}
                value={author.user_id}
              >
                {author.display_name}
              </option>
            ))}
          </select>

          {/* Status */}

          <select
            value={selectedStatus}
            onChange={(e) => {
              setSelectedStatus(e.target.value);
              triggerTableReload();
            }}
            className="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-3 py-2"
          >
            <option value="">
              All Status
            </option>

            <option value="publish">
              Published
            </option>

            <option value="draft">
              Draft
            </option>
          </select>

          {/* From Date */}

          <input
            type="date"
            value={fromDate}
            onChange={(e) => {
              setFromDate(e.target.value);
              triggerTableReload();
            }}
            className="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-3 py-2"
          />

          {/* To Date */}

          <input
            type="date"
            value={toDate}
            onChange={(e) => {
              setToDate(e.target.value);
              triggerTableReload();
            }}
            className="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-3 py-2"
          />

        </div>

        <div className="flex justify-end mt-3">

          <button
            onClick={handleResetFilters}
            className="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-md"
          >
            Reset Filters
          </button>

        </div>

      </div>

      {/* Table */}

      <GenericTable
        title=""
        fetchDataFunction={getPostList}
        columnsConfig={columnsConfig}
        enableExpansion={true}
        renderExpandedRow={renderExpandedRow}
        refresh={refreshFlag}
      />

    </div>
  );
};

export default PostList;

