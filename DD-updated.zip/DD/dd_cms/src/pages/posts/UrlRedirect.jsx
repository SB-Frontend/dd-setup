"use client";

import React, { useRef, useState } from "react";

import GenericTable from "@/components/TableStructure";
import ConfirmationModal from "@/components/ConfirmationModal";

import { apiPost, apiPut, apiDelete } from "@/utils/api";

import {
  Plus,
  Upload,
  Pencil,
  Trash2,
  ChevronDown,
  ChevronUp,
  Download,
  X,
} from "lucide-react";

import toast from "react-hot-toast";
import * as XLSX from "xlsx";

import { useAuth } from "@/context/AuthContext";
import { usePermission } from "@/hooks/usePermission";
import NoAccess from "@/components/NoAccess";

const UrlRedirect = () => {
  const { user } = useAuth();

  // ==========================================
  // PERMISSIONS
  // ==========================================

  const redirectPerm = usePermission(2) || {};

  const canRead = redirectPerm.read === 1;
  const canCreate = redirectPerm.create === 1;
  const canEdit = redirectPerm.update === 1;
  const canDelete = redirectPerm.delete === 1;

  // ==========================================
  // TABLE
  // ==========================================

  const [refreshTable, setRefreshTable] = useState(false);

  const triggerTableReload = () => {
    setRefreshTable((prev) => !prev);
  };

  // ==========================================
  // MODALS
  // ==========================================

  const [singleModalOpen, setSingleModalOpen] = useState(false);

  const [bulkModalOpen, setBulkModalOpen] = useState(false);

  // ==========================================
  // USER DETAILS
  // ==========================================

  const userId = user?.id;

  const userName = user?.name || user?.user_name || "";

  // ==========================================
  // SINGLE REDIRECT
  // ==========================================

  const [currentUrl, setCurrentUrl] = useState("");

  const [redirectUrl, setRedirectUrl] = useState("");

  const [isSubmitting, setIsSubmitting] = useState(false);

  // ==========================================
  // EDIT
  // ==========================================

  const [editModalOpen, setEditModalOpen] = useState(false);

  const [selectedRedirect, setSelectedRedirect] = useState(null);

  const [editCurrentUrl, setEditCurrentUrl] = useState("");

  const [editRedirectUrl, setEditRedirectUrl] = useState("");

  const [isUpdating, setIsUpdating] = useState(false);

  // ==========================================
  // DELETE
  // ==========================================

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  const [redirectToDelete, setRedirectToDelete] = useState(null);

  const [isDeleting, setIsDeleting] = useState(false);

  // ==========================================
  // BULK UPLOAD
  // ==========================================

  const fileInputRef = useRef(null);

  const [selectedExcelFile, setSelectedExcelFile] = useState(null);

  const [excelRows, setExcelRows] = useState([]);

  const [isExcelValid, setIsExcelValid] = useState(false);

  const [isBulkUploading, setIsBulkUploading] = useState(false);

  const [uploadResult, setUploadResult] = useState(null);

  const [showDuplicates, setShowDuplicates] = useState(false);

  // ==========================================
  // ADD SINGLE REDIRECT
  // ==========================================

  const handleAddRedirect = async (e) => {
    e.preventDefault();

    const cleanCurrentUrl = currentUrl.trim();

    const cleanRedirectUrl = redirectUrl.trim();

    if (!cleanCurrentUrl) {
      toast.error("Current URL is required");
      return;
    }

    if (!cleanRedirectUrl) {
      toast.error("Redirect URL is required");
      return;
    }

    if (cleanCurrentUrl === cleanRedirectUrl) {
      toast.error("Current URL and Redirect URL cannot be the same");

      return;
    }

    if (!userId) {
      toast.error("User information not found");

      return;
    }

    setIsSubmitting(true);

    try {
      const response = await apiPost("/redirect", {
        current_url: cleanCurrentUrl,

        redirect_url: cleanRedirectUrl,

        user_id: userId,

        user_name: userName,
      });

      if (response?.success) {
        toast.success("Redirect added successfully");

        setCurrentUrl("");
        setRedirectUrl("");

        setSingleModalOpen(false);

        triggerTableReload();
      }
    } catch (error) {
      console.error("Add redirect error:", error);

      const message =
        error?.response?.data?.message ||
        error?.data?.message ||
        error?.message ||
        "Failed to add redirect";

      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // ==========================================
  // RESET SINGLE FORM
  // ==========================================

  const handleSingleReset = () => {
    setCurrentUrl("");
    setRedirectUrl("");
  };

  // ==========================================
  // EXCEL FILE SELECTION
  // ==========================================

  const handleExcelUpload = (event) => {
    const file = event.target.files?.[0];

    if (!file) return;

    setUploadResult(null);
    setShowDuplicates(false);
    setExcelRows([]);
    setIsExcelValid(false);

    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);

        const workbook = XLSX.read(data, {
          type: "array",
        });

        const sheetName = workbook.SheetNames[0];

        const worksheet = workbook.Sheets[sheetName];

        const rows = XLSX.utils.sheet_to_json(worksheet, {
          defval: "",
        });

        if (!rows.length) {
          toast.error("Excel file is empty.");

          return;
        }

        const firstRow = rows[0];

        if (
          !Object.prototype.hasOwnProperty.call(firstRow, "current_url") ||
          !Object.prototype.hasOwnProperty.call(firstRow, "redirect_url")
        ) {
          toast.error(
            "Excel must contain current_url and redirect_url columns.",
          );

          return;
        }

        const formattedRows = rows.map((row, index) => ({
          current_url: String(row.current_url || "").trim(),

          redirect_url: String(row.redirect_url || "").trim(),

          row_number: index + 2,
        }));

        setSelectedExcelFile(file);

        setExcelRows(formattedRows);

        setIsExcelValid(true);

        toast.success(`${formattedRows.length} rows ready to upload.`);
      } catch (error) {
        console.error("Excel parsing error:", error);

        toast.error("Failed to read Excel file.");
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // ==========================================
  // BULK SUBMIT
  // ==========================================

  const handleBulkSubmit = async () => {
    if (!isExcelValid || excelRows.length === 0) {
      toast.error("Please select a valid Excel file.");

      return;
    }

    if (!userId) {
      toast.error("User information not found");

      return;
    }

    setIsBulkUploading(true);

    setUploadResult(null);

    setShowDuplicates(false);

    try {
      const response = await apiPost("/redirect/bulk", {
        redirects: excelRows,

        user_id: userId,

        user_name: userName,
      });

      setUploadResult(response);

      if (response?.success) {
        toast.success(`${response.inserted || 0} URLs uploaded successfully.`);

        triggerTableReload();

        setSelectedExcelFile(null);

        setExcelRows([]);

        setIsExcelValid(false);

        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      }
    } catch (error) {
      console.error("Bulk redirect upload error:", error);

      toast.error(error?.response?.data?.message || "Bulk upload failed.");
    } finally {
      setIsBulkUploading(false);
    }
  };

  // ==========================================
  // BULK RESET
  // ==========================================

  const handleBulkReset = () => {
    setSelectedExcelFile(null);

    setExcelRows([]);

    setIsExcelValid(false);

    setUploadResult(null);

    setShowDuplicates(false);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // ==========================================
  // DOWNLOAD SAMPLE EXCEL
  // ==========================================


const downloadSampleExcel = () => {
  const sampleData = [
    {
      current_url:
        "https://martech360.com/digitaltech/top-5-must-have-productivity-tools-for-businesses/",
      redirect_url:
        "https://www.martech360.com/insights/staff-writers/top-5-must-have-productivity-tools-for-businesses",
    },
    {
      current_url:
        "https://martech360.com/social-media-technology/new-engen-and-acorn-influence-join-forces-to-create-expanded-digital-marketing-offering/",
      redirect_url:
        "https://www.martech360.com/news/stack-platforms/new-engen-and-acorn-influence-join-forces-to-create-expanded-digital-marketing-offering",
    },
    {
      current_url:
        "https://martech360.com/tech-analytics/snappy-kraken-recognizes-best-industry-marketing-work-with-jolt-awards/",
      redirect_url:
        "https://www.martech360.com/insights/martech-predictions/snappy-kraken-recognizes-best-industry-marketing-work-with-jolt-awards",
    },
    {
      current_url:
        "https://www.martech360.com/old-url-1",
      redirect_url:
        "https://www.martech360.com/new-url-1",
    },
    {
      current_url:
        "https://www.martech360.com/old-url-2",
      redirect_url:
        "https://www.martech360.com/new-url-2",
    },
    {
      current_url:
        "https://www.martech360.com/old-url-3",
      redirect_url:
        "https://www.martech360.com/new-url-3",
    },
  ];

  const worksheet =
    XLSX.utils.json_to_sheet(sampleData);

  // ==========================================
  // COLUMN WIDTHS
  // ==========================================

  worksheet["!cols"] = [
    {
      wch: 70, // current_url
    },
    {
      wch: 70, // redirect_url
    },
  ];

  // ==========================================
  // WRAP TEXT
  // ==========================================

  const range =
    XLSX.utils.decode_range(
      worksheet["!ref"]
    );

  for (
    let row = range.s.r;
    row <= range.e.r;
    row++
  ) {
    for (
      let col = range.s.c;
      col <= range.e.c;
      col++
    ) {
      const cellAddress =
        XLSX.utils.encode_cell({
          r: row,
          c: col,
        });

      const cell =
        worksheet[cellAddress];

      if (cell) {
        cell.s = {
          alignment: {
            wrapText: true,
            vertical: "top",
          },
        };
      }
    }
  }

  const workbook =
    XLSX.utils.book_new();

  XLSX.utils.book_append_sheet(
    workbook,
    worksheet,
    "Redirects"
  );

  XLSX.writeFile(
    workbook,
    "redirect_sample.xlsx"
  );
};



  // ==========================================
  // GET REDIRECT LIST
  // ==========================================

  const getRedirectList = async ({
    page = 1,
    pageSize = 10,
    search = "",
    sort = "id",
    order = "desc",
  }) => {
    try {
      const response = await apiPost("/redirect/getlist", {
        page,
        limit: pageSize,
        search,
        sort,
        order,
      });

      return {
        aaData: response?.aaData || [],

        iTotalRecords: response?.iTotalRecords || 0,

        iTotalDisplayRecords: response?.iTotalDisplayRecords || 0,
      };
    } catch (error) {
      console.error("Get redirect list error:", error);

      return {
        aaData: [],
        iTotalRecords: 0,
        iTotalDisplayRecords: 0,
      };
    }
  };

  // ==========================================
  // OPEN EDIT
  // ==========================================

  const handleEdit = (row) => {
    setSelectedRedirect(row);

    setEditCurrentUrl(row.current_url || "");

    setEditRedirectUrl(row.redirect_url || "");

    setEditModalOpen(true);
  };

  // ==========================================
  // UPDATE
  // ==========================================

  const handleUpdateRedirect = async () => {
    const cleanCurrentUrl = editCurrentUrl.trim();

    const cleanRedirectUrl = editRedirectUrl.trim();

    if (!cleanCurrentUrl) {
      toast.error("Current URL is required");

      return;
    }

    if (!cleanRedirectUrl) {
      toast.error("Redirect URL is required");

      return;
    }

    if (cleanCurrentUrl === cleanRedirectUrl) {
      toast.error("Current URL and Redirect URL cannot be the same");

      return;
    }

    if (!selectedRedirect) {
      return;
    }

    setIsUpdating(true);

    try {
      const response = await apiPut(`/redirect/${selectedRedirect.id}`, {
        current_url: cleanCurrentUrl,

        redirect_url: cleanRedirectUrl,

        user_id: userId,

        user_name: userName,
      });

      if (response?.success) {
        toast.success("Redirect updated successfully");

        setEditModalOpen(false);

        setSelectedRedirect(null);

        triggerTableReload();
      }
    } catch (error) {
      console.error("Update redirect error:", error);

      const message =
        error?.response?.data?.message ||
        error?.data?.message ||
        error?.message ||
        "Failed to update redirect";

      toast.error(message);
    } finally {
      setIsUpdating(false);
    }
  };

  // ==========================================
  // DELETE
  // ==========================================

  const handleDelete = (row) => {
    setRedirectToDelete(row);

    setDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!redirectToDelete) {
      return;
    }

    setIsDeleting(true);

    try {
      const response = await apiDelete(`/redirect/${redirectToDelete.id}`);

      if (response?.success) {
        toast.success("Redirect deleted successfully");

        setDeleteModalOpen(false);

        setRedirectToDelete(null);

        triggerTableReload();
      }
    } catch (error) {
      console.error("Delete redirect error:", error);

      const message =
        error?.response?.data?.message ||
        error?.data?.message ||
        error?.message ||
        "Failed to delete redirect";

      toast.error(message);
    } finally {
      setIsDeleting(false);
    }
  };

  // ==========================================
  // TABLE COLUMNS
  // ==========================================

  const columnsConfig = [
    {
      accessorKey: "id",
      header: "ID",
      sortable: true,

      cell: ({ getValue }) => (
        <div className="text-gray-700 dark:text-gray-200">{getValue()}</div>
      ),
    },

    {
      accessorKey: "current_url",

      header: "Current URL",

      sortable: true,

      cell: ({ getValue }) => (
        <div className="max-w-[450px] break-all">{getValue()}</div>
      ),
    },

    {
      accessorKey: "redirect_url",

      header: "Redirect URL",

      sortable: true,

      cell: ({ getValue }) => (
        <div className="max-w-[450px] break-all">{getValue()}</div>
      ),
    },

    {
      accessorKey: "actions",

      header: "Action",

      cell: ({ row }) => {
        const redirect = row.original;

        return (
          <div className="flex gap-2">
            {canEdit && (
              <button
                type="button"
                onClick={() => handleEdit(redirect)}
                className="p-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 flex items-center gap-1"
              >
                <Pencil size={16} />
                Edit
              </button>
            )}

            {canDelete && (
              <button
                type="button"
                onClick={() => handleDelete(redirect)}
                className="p-2 bg-red-100 text-red-700 rounded hover:bg-red-200 flex items-center gap-1"
              >
                <Trash2 size={16} />
                Delete
              </button>
            )}
          </div>
        );
      },
    },
  ];

  // ==========================================
  // ACCESS
  // ==========================================

  if (!canRead) {
    return <NoAccess />;
  }

  // ==========================================
  // UI
  // ==========================================

  return (
    <>
      <div className="container mx-auto dark:bg-gray-900 rounded-lg">
        {/* HEADER */}

        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
            URL Redirect Manager
          </h2>

          <div className="flex gap-3">
            {canCreate && (
              <>
                <button
                  type="button"
                  onClick={() => setSingleModalOpen(true)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md flex items-center gap-2"
                >
                  <Plus size={17} />
                  Add Redirect
                </button>

                <button
                  type="button"
                  onClick={() => setBulkModalOpen(true)}
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md flex items-center gap-2"
                >
                  <Upload size={17} />
                  Bulk Upload
                </button>
              </>
            )}
          </div>
        </div>

        {/* ==================================
            TABLE
        ================================== */}

        <GenericTable
          title="Redirect List"
          columnsConfig={columnsConfig}
          fetchDataFunction={getRedirectList}
          refresh={refreshTable}
        />
      </div>

      {/* ==========================================
          ADD SINGLE REDIRECT MODAL
      ========================================== */}

      {singleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-xl bg-white dark:bg-gray-800 rounded-xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-800 dark:text-white">
                Add URL Redirect
              </h3>

              <button
                type="button"
                onClick={() => setSingleModalOpen(false)}
                className="text-gray-500 hover:text-gray-800 dark:hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleAddRedirect} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-white mb-1">
                  Current URL
                </label>

                <input
                  type="text"
                  value={currentUrl}
                  onChange={(e) => setCurrentUrl(e.target.value)}
                  placeholder="https://www.martech360.com/old-url"
                  disabled={isSubmitting}
                  className="w-full border border-gray-300 dark:border-gray-700 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-white mb-1">
                  Redirect URL
                </label>

                <input
                  type="text"
                  value={redirectUrl}
                  onChange={(e) => setRedirectUrl(e.target.value)}
                  placeholder="https://www.martech360.com/new-url"
                  disabled={isSubmitting}
                  className="w-full border border-gray-300 dark:border-gray-700 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => {
                    handleSingleReset();
                    setSingleModalOpen(false);
                  }}
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-gray-300 dark:bg-gray-700 text-gray-800 dark:text-white rounded-md"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md disabled:opacity-50"
                >
                  {isSubmitting ? "Adding..." : "Add Redirect"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          BULK UPLOAD MODAL
      ========================================== */}

      {bulkModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-gray-800 rounded-xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-xl font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                <Upload size={20} className="text-green-600" />
                Bulk Upload Redirects
              </h3>

              <button
                type="button"
                onClick={() => setBulkModalOpen(false)}
                disabled={isBulkUploading}
                className="text-gray-500 hover:text-gray-800 dark:hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            {/* DESCRIPTION */}

            <p className="text-sm text-gray-500 dark:text-gray-400 mb-5">
              Upload an Excel file containing
              <strong> current_url</strong> and
              <strong> redirect_url</strong> columns.
            </p>

            {/* SAMPLE FILE */}

            <div className="mb-5 flex items-center justify-between gap-4 p-4 rounded-lg border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-900/20">
              <div>
                <p className="text-sm font-medium text-blue-800 dark:text-blue-300">
                  Need help with the Excel format?
                </p>

                <p className="text-xs text-blue-700 dark:text-blue-400 mt-1">
                  Download the sample file and use it as a template.
                </p>
              </div>

              <button
                type="button"
                onClick={downloadSampleExcel}
                className="shrink-0 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md flex items-center gap-2 text-sm"
              >
                <Download size={16} />
                Sample Excel
              </button>
            </div>

            {/* FILE */}

            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleExcelUpload}
              disabled={isBulkUploading}
              className="block w-full cursor-pointer file:cursor-pointer file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-600 hover:file:bg-green-100 text-sm px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
            />

            {/* SELECTED FILE */}

            {selectedExcelFile && (
              <div className="mt-3 p-3 rounded-md bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  Selected file:
                  <span className="font-medium ml-1">
                    {selectedExcelFile.name}
                  </span>
                </p>

                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {excelRows.length} rows detected
                </p>
              </div>
            )}

            {/* VALID FILE */}

            {isExcelValid && excelRows.length > 0 && (
              <div className="mt-4 p-3 rounded-md bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700">
                <p className="text-sm text-green-700 dark:text-green-400 font-medium">
                  ✓ File ready for upload
                </p>

                <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                  {excelRows.length} redirect rows detected.
                </p>
              </div>
            )}

            {/* UPLOAD RESULT */}

            {uploadResult && (
              <div className="mt-5 space-y-4">
                {uploadResult.inserted > 0 && (
                  <div className="text-green-700 dark:text-green-400 text-sm font-medium">
                    ✓ {uploadResult.inserted} URLs added successfully
                  </div>
                )}

                {/* DUPLICATES */}

                {uploadResult.skipped > 0 && (
                  <div>
                    <button
                      type="button"
                      onClick={() => setShowDuplicates((prev) => !prev)}
                      className="flex items-center gap-2 text-yellow-700 dark:text-yellow-400 text-sm font-medium hover:underline"
                    >
                      ⚠ {uploadResult.skipped} duplicate URLs skipped
                      {showDuplicates ? (
                        <ChevronUp size={16} />
                      ) : (
                        <ChevronDown size={16} />
                      )}
                      <span>{showDuplicates ? "Hide" : "Show"}</span>
                    </button>

                    {showDuplicates && (
                      <div className="mt-3 border border-yellow-200 dark:border-yellow-700 rounded-md bg-yellow-50 dark:bg-yellow-900/20 p-4 space-y-2 max-h-64 overflow-y-auto">
                        {uploadResult.duplicates?.map((duplicate, index) => (
                          <div
                            key={`${duplicate.row_number}-${index}`}
                            className="text-sm text-gray-700 dark:text-gray-200"
                          >
                            <span className="font-medium mr-2">
                              Row {duplicate.row_number}
                            </span>

                            <span className="break-all">
                              {duplicate.current_url}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* INVALID */}

                {uploadResult.invalid?.length > 0 && (
                  <div>
                    <div className="text-red-600 dark:text-red-400 text-sm font-medium">
                      ✕ {uploadResult.invalid.length} invalid rows
                    </div>

                    <div className="mt-2 border border-red-200 dark:border-red-700 rounded-md bg-red-50 dark:bg-red-900/20 p-4 space-y-2 max-h-64 overflow-y-auto">
                      {uploadResult.invalid.map((invalid, index) => (
                        <div
                          key={`${invalid.row_number}-${index}`}
                          className="text-sm text-gray-700 dark:text-gray-200"
                        >
                          <div>
                            <strong>Row {invalid.row_number}</strong>
                          </div>

                          <div className="text-red-600 dark:text-red-400">
                            {invalid.reason}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* BUTTONS */}

            <div className="flex justify-end gap-3 mt-7">
              <button
                type="button"
                onClick={() => {
                  handleBulkReset();

                  setBulkModalOpen(false);
                }}
                disabled={isBulkUploading}
                className="px-5 py-2 bg-gray-300 dark:bg-gray-700 text-gray-800 dark:text-white rounded-md"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleBulkSubmit}
                disabled={
                  isBulkUploading || !isExcelValid || excelRows.length === 0
                }
                className="px-5 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isBulkUploading ? "Uploading..." : "Upload Redirects"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          EDIT MODAL
      ========================================== */}

      {editModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-xl bg-white dark:bg-gray-800 rounded-xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-800 dark:text-white">
                Edit Redirect
              </h3>

              <button
                type="button"
                onClick={() => setEditModalOpen(false)}
                className="text-gray-500 hover:text-gray-800 dark:hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-white mb-1">
                  Current URL
                </label>

                <input
                  type="text"
                  value={editCurrentUrl}
                  onChange={(e) => setEditCurrentUrl(e.target.value)}
                  disabled={isUpdating}
                  className="w-full border border-gray-300 dark:border-gray-700 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-white mb-1">
                  Redirect URL
                </label>

                <input
                  type="text"
                  value={editRedirectUrl}
                  onChange={(e) => setEditRedirectUrl(e.target.value)}
                  disabled={isUpdating}
                  className="w-full border border-gray-300 dark:border-gray-700 rounded-md px-3 py-2 text-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-7">
              <button
                type="button"
                onClick={() => setEditModalOpen(false)}
                disabled={isUpdating}
                className="px-5 py-2 bg-gray-300 dark:bg-gray-700 text-gray-800 dark:text-white rounded-md"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleUpdateRedirect}
                disabled={isUpdating}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md disabled:opacity-50"
              >
                {isUpdating ? "Updating..." : "Update"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          DELETE MODAL
      ========================================== */}

      <ConfirmationModal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={confirmDelete}
        title="Delete Redirect?"
        message={
          redirectToDelete
            ? `Are you sure you want to delete "${redirectToDelete.current_url}"?`
            : ""
        }
        confirmText="Yes, Delete"
        cancelText="Cancel"
      />
    </>
  );
};

export default UrlRedirect;
