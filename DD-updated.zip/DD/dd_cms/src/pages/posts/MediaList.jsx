
"use client";

import React, {
  useState,
  useEffect,
} from "react";

import GenericTable from "@/components/TableStructure";

import ConfirmationModal from "@/components/ConfirmationModal";

import {
  apiPost,
  apiDelete,
} from "@/utils/api";

import {
  Copy,
  Trash2,
  Upload,
} from "lucide-react";

import toast from "react-hot-toast";

import { useForm } from "react-hook-form";
import { usePermission } from "@/hooks/usePermission";
import NoAccess from "@/components/NoAccess";
import { useAuth } from "@/context/AuthContext";

const webPath = import.meta.env.VITE_WEBPATH;
const staticPath = import.meta.env.VITE_STATIC;
const imgPath = import.meta.env.VITE_API_IMAGE_PATH;
const apiBaseUrl =
  import.meta.env.VITE_API_BASE_URL;

const MediaManager = () => {

    const { user } = useAuth();

  const BLANK_IMAGE = `${webPath}/assets/blank-image.svg`;

  const [previewUrl, setPreviewUrl] =
    useState(BLANK_IMAGE);

  const [refreshTable, setRefreshTable] =
    useState(false);

  const [modalOpen, setModalOpen] =
    useState(false);

  const [mediaToDelete, setMediaToDelete] =
    useState(null);

  const [isUploading, setIsUploading] =
    useState(false);

  const [uploadStatus, setUploadStatus] =
    useState("");

  const mediaPerm = usePermission(2) || {};
  const canRead = mediaPerm.read === 1;
  const canCreate = mediaPerm.create === 1;
  const canEdit = mediaPerm.update === 1;
  const canDelete = mediaPerm.delete === 1;

  // =====================================
  // REACT HOOK FORM
  // =====================================

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
    watch,
  } = useForm({
    defaultValues: {
      mediaTitle: "",
      mediaFile: null,
    },
  });

  // =====================================
  // IMAGE PREVIEW
  // =====================================

  const mediaFile = watch("mediaFile");

  useEffect(() => {
    if (
      mediaFile &&
      mediaFile.length > 0
    ) {
      const url = URL.createObjectURL(
        mediaFile[0]
      );

      setPreviewUrl(url);

      return () =>
        URL.revokeObjectURL(url);
    } else {
      setPreviewUrl(BLANK_IMAGE);
    }
  }, [mediaFile]);

  // =====================================
  // CREATE MEDIA
  // =====================================

  const onSubmit = async (data) => {
    if (
      !data.mediaTitle ||
      !data.mediaFile ||
      data.mediaFile.length === 0
    ) {
      toast.error(
        "Please provide both image and title"
      );

      return;
    }

    setIsUploading(true);

    setUploadStatus("");

    try {
      const userStr =
        localStorage.getItem("user");

      const user = userStr
        ? JSON.parse(userStr)
        : null;

      const userId = user?.id;

      const formData = new FormData();

      formData.append(
        "media_title",
        data.mediaTitle
      );

      formData.append(
        "media_path",
        data.mediaFile[0]
      );

      if (userId) {
        formData.append("user", userId);
      }

      await apiPost("/media", formData, {
        headers: {
          "Content-Type":
            "multipart/form-data",
        },
      });

      toast.success(
        "Media uploaded successfully!"
      );

      setUploadStatus("Upload complete");

      setRefreshTable((prev) => !prev);

      reset();

      setPreviewUrl(BLANK_IMAGE);

      const input =
        document.getElementById(
          "media_file"
        );

      if (input) {
        input.value = "";
      }
    } catch (err) {
      toast.error("Upload failed");

      console.error(
        "Error uploading media:",
        err
      );
    } finally {
      setIsUploading(false);

      setTimeout(
        () => setUploadStatus(""),
        4000
      );
    }
  };

  // =====================================
  // RESET FORM
  // =====================================

  const handleReset = () => {
    reset();

    setPreviewUrl(BLANK_IMAGE);

    const input =
      document.getElementById(
        "media_file"
      );

    if (input) {
      input.value = "";
    }

    setUploadStatus("");
  };

  // =====================================
  // DELETE MEDIA
  // =====================================

  const handleDeleteClick = (row) => {
    setMediaToDelete(row);

    setModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!mediaToDelete) return;

    try {
      await apiDelete(
        `/media/${mediaToDelete.media_id}`
      );

      toast.success(
        "Deleted successfully!"
      );

      setRefreshTable((prev) => !prev);

      setModalOpen(false);

      setMediaToDelete(null);
    } catch (err) {
      toast.error("Delete failed");

      console.error(
        "Delete Media Error:",
        err
      );
    }
  };

  // =====================================
  // FETCH MEDIA LIST
  // =====================================

  const getMediaList = async ({
    page = 1,
    pageSize = 10,
    search = "",
  }) => {
    const response = await apiPost(
      "/media/getlist",
      {
        page,
        limit: pageSize,
        search,
      }
    );

    console.log("MEDIA RESPONSE", response);

    return {
      aaData: response?.aaData || [],

      iTotalRecords:
        response?.iTotalRecords || 0,

      iTotalDisplayRecords:
        response?.iTotalDisplayRecords || 0,
    };
  };

  // =====================================
  // TABLE COLUMNS
  // =====================================

  const columnsConfig = [
    {
      accessorKey: "media_id",
      header: "ID",
      sortable: true,
    },

    {
      accessorKey: "media_title",
      header: "Title",
    },

    {
      accessorKey: "media_path",
      header: "Preview",

      cell: ({ row }) => {
        const file =
          row.original.media_path;

        const src = `${imgPath}/posts/${file}`;

        return (
          <img
            src={src}
            alt="media"
            className="w-36 h-24 object-contain shadow rounded-md bg-gray-50"
          />
        );
      },
    },

    {
      accessorKey: "actions",
      header: "Action",

      cell: ({ row }) => {
        const mediaPath =
          row.original.media_path;

        const fullUrl = `${imgPath}/posts/${mediaPath}`;

        const handleCopy =
          async () => {
            try {
              if (
                navigator.clipboard &&
                window.isSecureContext
              ) {
                await navigator.clipboard.writeText(
                  fullUrl
                );
              } else {
                const textarea =
                  document.createElement(
                    "textarea"
                  );

                textarea.value = fullUrl;

                textarea.style.position =
                  "fixed";

                textarea.style.left =
                  "-9999px";

                document.body.appendChild(
                  textarea
                );

                textarea.focus();

                textarea.select();

                document.execCommand(
                  "copy"
                );

                document.body.removeChild(
                  textarea
                );
              }

              toast.success(
                "Media URL copied!"
              );
            } catch (err) {
              console.error(
                "Clipboard error:",
                err
              );

              toast.error(
                "Failed to copy"
              );
            }
          };

        return (
          <div className="flex gap-3">

            <button
              onClick={handleCopy}
              className="p-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 flex items-center gap-1"
            >
              <Copy size={16} />
              Copy
            </button>
            {canDelete && (
              <button
                onClick={() =>
                  handleDeleteClick(
                    row.original
                  )
                }
                className="p-2 bg-red-100 text-red-700 rounded hover:bg-red-200 flex items-center gap-1"
              >
                <Trash2 size={16} />
                Delete
              </button>
            )}
          </div>
        );
      },
    },
  ];

  if (!canRead) {
    return <NoAccess />;
  }

  return (
    <>
      <div className="container mx-auto dark:bg-gray-900 rounded-lg">

        {/* HEADER */}

        <div className="flex items-center justify-between mb-4">

          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
            Media Manager
          </h2>

        </div>

        <div className="space-y-10 mx-auto">

          {/* UPLOAD CARD */}
          {canCreate  && (
            <div className="bg-white dark:bg-gray-800 shadow-md rounded-xl p-8 flex flex-col lg:flex-row gap-10 w-full">

              {/* FORM */}

              <form
                onSubmit={handleSubmit(
                  onSubmit
                )}
                className="flex-1 flex flex-col gap-6 justify-between"
              >

                <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">

                  <Upload
                    size={20}
                    className="inline mb-1 mr-2 text-blue-600"
                  />

                  Add New Media

                </h2>

                {/* TITLE */}

                <div>

                  <label className="block text-sm font-medium text-gray-700 dark:text-white mb-1">
                    Image Title
                  </label>

                  <input
                    type="text"
                    placeholder="Enter image title"
                    {...register(
                      "mediaTitle",
                      {
                        required:
                          "Image title is required",
                      }
                    )}
                    disabled={isUploading}
                    className={`w-full border text-sm rounded px-3 py-2 bg-white dark:bg-gray-900 text-gray-900 dark:text-white ${errors.mediaTitle
                      ? "border-red-500"
                      : "border-gray-300 dark:border-gray-700"
                      }`}
                  />

                  {errors.mediaTitle && (
                    <p className="text-red-600 text-xs mt-1">
                      {
                        errors.mediaTitle
                          .message
                      }
                    </p>
                  )}

                </div>

                {/* FILE */}

                <div>

                  <label className="block text-sm font-medium text-gray-700 dark:text-white mb-1">
                    Upload Image
                  </label>

                  <input
                    id="media_file"
                    type="file"
                    accept="image/*"
                    {...register(
                      "mediaFile",
                      {
                        required:
                          "Image file is required",
                      }
                    )}
                    disabled={isUploading}
                    className={`block w-full cursor-pointer file:cursor-pointer mt-1 file:m-0 file:mr-4 file:py-1 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-500 hover:file:bg-blue-100 text-sm px-3 py-1 border rounded bg-white dark:bg-gray-900 text-gray-900 dark:text-white ${errors.mediaFile
                      ? "border-red-500"
                      : "border-gray-300 dark:border-gray-700"
                      }`}
                  />

                  {errors.mediaFile && (
                    <p className="text-red-600 text-xs mt-1">
                      {
                        errors.mediaFile
                          .message
                      }
                    </p>
                  )}

                </div>

                {/* BUTTONS */}


                <div className="flex gap-4 mt-4">

                  <button
                    type="button"
                    onClick={handleReset}
                    disabled={isUploading}
                    className="px-4 py-2 bg-gray-300 dark:bg-gray-700 text-gray-800 dark:text-white rounded-md"
                  >
                    Reset
                  </button>

                  <button
                    type="submit"
                    disabled={isUploading}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md disabled:opacity-50"
                  >
                    {isUploading
                      ? "Uploading..."
                      : "Add Media"}
                  </button>

                </div>

                {uploadStatus && (
                  <div className="text-blue-700 dark:text-blue-300 mt-2">
                    {uploadStatus}
                  </div>
                )}

              </form>

              {/* PREVIEW */}

              <div className="w-full lg:w-2/5 flex flex-col items-center">

                <label className="text-lg font-medium text-blue-700 dark:text-white mb-4">
                  Image Preview
                </label>

                <div className="w-[530px] h-[250px] bg-white dark:bg-gray-800 rounded-lg flex items-center justify-center overflow-hidden">

                  <img
                    src={
                      previewUrl ||
                      BLANK_IMAGE
                    }
                    alt="Preview"
                    className="object-contain w-full h-full"
                    draggable={false}
                  />

                </div>

              </div>

            </div>
          )}
          {/* TABLE */}

          <div>

            <GenericTable
              title="Media List"
              columnsConfig={
                columnsConfig
              }
              fetchDataFunction={
                getMediaList
              }
              refresh={refreshTable}
            />

            {/* DELETE MODAL */}

            <ConfirmationModal
              isOpen={modalOpen}
              onClose={() =>
                setModalOpen(false)
              }
              onConfirm={confirmDelete}
              title="Delete Media?"
              message={
                mediaToDelete
                  ? `Are you sure you want to delete "${mediaToDelete.media_title}"?`
                  : ""
              }
              confirmText="Yes, Delete"
              cancelText="Cancel"
            />

          </div>
        </div>
      </div>
    </>
  );
};

export default MediaManager;
