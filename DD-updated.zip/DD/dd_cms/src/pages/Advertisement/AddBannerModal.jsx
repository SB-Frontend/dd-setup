"use client";

import { useState, useEffect } from "react";
import { ImageIcon, X } from "lucide-react";
import { apiPost, apiPut } from "@/utils/api";

export default function AddBannerModal({ open, onClose, onSubmit, banner }) {
    const isEdit = !!banner;

    const [formData, setFormData] = useState({
        banner_type: "",
        banner_name: "",
        dest_url: "",
        banner_img: null,
    });

    const getBannerImage = (img) => img ? `${import.meta.env.VITE_API_IMAGE_PATH}/banner/${img}` : null;

    useEffect(() => {
        if (banner) {
            setFormData({
                banner_type: banner.banner_type || "",
                banner_name: banner.banner_name || "",
                dest_url: banner.dest_url || "",
                banner_img: null,
            });

            setPreview(getBannerImage(banner.banner_img));

        } else {
            setFormData({
                banner_type: "",
                banner_name: "",
                dest_url: "",
                banner_img: null,
            });

            setPreview(null);
        }
    }, [banner, open]);

    const [preview, setPreview] = useState(null);
    const [loading, setLoading] = useState(false);

    if (!open) return null;

    const handleChange = (e) => {
        setFormData((prev) => ({
            ...prev,
            [e.target.name]: e.target.value,
        }));
    };

    const handleImageChange = (e) => {
        const file = e.target.files?.[0];

        if (file) {
            setFormData((prev) => ({
                ...prev,
                banner_img: file,
            }));

            setPreview(URL.createObjectURL(file));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            setLoading(true);

            const payload = new FormData();

            payload.append("banner_type", formData.banner_type);
            payload.append("banner_name", formData.banner_name);
            payload.append("dest_url", formData.dest_url);

            if (formData.banner_img) {
                payload.append("banner_img", formData.banner_img);
            }

            let response;

            if (isEdit) {
                response = await apiPut(
                    `/ad_banner/${banner.banner_id}`,
                    payload
                );
            } else {
                response = await apiPost(
                    "/ad_banner",
                    payload
                );
            }

            if (response.success) {
                onSubmit();
                onClose();
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };
    return (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-gray-800 w-full max-w-6xl rounded-xl shadow-xl">
                {/* Header */}
                <div className="flex items-center justify-between p-5 border-b">
                    <h2 className="text-xl font-semibold">
                        {isEdit
                            ? "Edit Advertisement Banner"
                            : "Add Advertisement Banner"}
                    </h2>

                    <button onClick={onClose}>
                        <X size={20} />
                    </button>
                </div>

                {/* Body */}
                <form onSubmit={handleSubmit} className="p-6">
                    <div className="grid lg:grid-cols-12 gap-6">
                        {/* Preview */}
                        <div className="lg:col-span-8">
                            <div className="border bg-gray-50 h-[400px] rounded-lg flex items-center justify-center overflow-hidden">
                                {preview ? (
                                    <img
                                        src={preview}
                                        alt="preview"
                                        className="w-full h-full object-contain"
                                    />
                                ) : (
                                    <div className="text-gray-300 flex flex-col items-center">
                                        <ImageIcon size={220} strokeWidth={1} />
                                        <p>Banner Preview</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Form */}
                        <div className="lg:col-span-4 space-y-4">
                            <div>
                                <label className="block mb-1">
                                    Banner Type <span className="text-red-500">*</span>
                                </label>

                                <select
                                    name="banner_type"
                                    value={formData.banner_type}
                                    onChange={handleChange}
                                    className="w-full border rounded-md p-2"
                                >
                                    <option value="">Select Type</option>
                                    <option value="home-1">Home Banner Top</option>
                                    <option value="home-2">Home Banner Middle</option>
                                    <option value="home-3">Home Banner Bottom</option>
                                    <option value="post-1">Post Banner Top</option>
                                    <option value="post-2">Post Banner Bottom</option>
                                    <option value="post-3">Post Banner Sidebar</option>
                                </select>
                            </div>

                            <div>
                                <label className="block mb-1">
                                    Banner Name <span className="text-red-500">*</span>
                                </label>

                                <input
                                    type="text"
                                    name="banner_name"
                                    value={formData.banner_name}
                                    onChange={handleChange}
                                    className="w-full border rounded-md p-2"
                                />
                            </div>

                            <div>
                                <label className="block mb-1">
                                    Destination URL <span className="text-red-500">*</span>
                                </label>

                                <input
                                    type="url"
                                    name="dest_url"
                                    value={formData.dest_url}
                                    onChange={handleChange}
                                    className="w-full border rounded-md p-2"
                                />
                            </div>

                            <div>
                                <label className="block mb-1">
                                    Banner Image <span className="text-red-500">*</span>
                                </label>

                                <input
                                    type="file"
                                    accept="image/*"
                                    onChange={handleImageChange}
                                    className="w-full border rounded-md p-2"
                                />
                            </div>

                            <div className="flex justify-end gap-2 pt-3">
                                <button
                                    type="button"
                                    onClick={onClose}
                                    className="px-5 py-2 border rounded-md"
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    disabled={loading}
                                    className="px-5 py-2 bg-blue-600 text-white rounded-md disabled:opacity-50"
                                >
                                    {loading
                                        ? "Saving..."
                                        : isEdit
                                            ? "Update Banner"
                                            : "Add Banner"}
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
}