
import { useEffect, useState } from "react";
import AddBannerModal from "./AddBannerModal";
import GenericTable from "@/components/TableStructure";
import ConfirmationModal from "@/components/ConfirmationModal";
import { apiDelete, apiGet, apiPatch } from "@/utils/api";
import { Pencil, Trash2 } from "lucide-react";
import ActiveBanner from "./ActiveBanner";
import { usePermission } from "@/hooks/usePermission";

export default function CreateAdvertisement() {
    const [showModal, setShowModal] = useState(false);
    const [selectedBanner, setSelectedBanner] = useState(null);
    const [refreshKey, setRefreshKey] = useState(0);

    const [deleteId, setDeleteId] = useState(null);
    const [showDeleteModal, setShowDeleteModal] = useState(false);

    const adsPerm = usePermission(7) || {};
    const canRead = adsPerm.read === 1;
    const canCreate = adsPerm.create === 1;
    const canEdit = adsPerm.update === 1;
    const canDelete = adsPerm.delete === 1;

    const handleAddClick = () => {
        setSelectedBanner(null);
        setShowModal(true);
    };

    const handleEdit = (banner) => {
        setSelectedBanner(banner);
        setShowModal(true);
    };

    const handleSaveSuccess = () => {
        setRefreshKey((prev) => prev + 1);
    };

    const handleDelete = (id) => {
        setDeleteId(id);
        setShowDeleteModal(true);
    };

    const handleToggleStatus = async (id) => {
        try {
            const res = await apiPatch(`/ad_banner/${id}/status`);

            if (res.success) {
                setRefreshKey((prev) => prev + 1);
            }
        } catch (error) {
            console.error("Status update failed:", error);
        }
    };



    const columns = [
        { accessorKey: "banner_id", header: "ID" },
        { accessorKey: "banner_name", header: "Banner Title" },
        { accessorKey: "banner_type", header: "Banner Type" },
        { accessorKey: "banner_img", header: "Banner Image" },

    ];

    if (canEdit || canDelete) {
        columns.push({
            accessorKey: "banner_status",
            header: "Status",
            // sortable: true,
            cell: ({ row, getValue }) => {
                const id = row.original.banner_id;
                const status = getValue();

                return (
                    <>
                        {canEdit && canCreate && (
                            <button
                                onClick={() => handleToggleStatus(id)}
                                className={`px-3 py-1 rounded-full text-xs font-medium transition
                    ${status === 1
                                        ? "bg-green-100 text-green-700 hover:bg-green-200"
                                        : "bg-yellow-100 text-yellow-700 hover:bg-yellow-200"
                                    }`}
                            >
                                {status === 1 ? "Active" : "Inactive"}
                            </button>
                        )}
                    </>

                );
            },
        })
    }

    if (canEdit || canDelete) {
        columns.push({
            accessorKey: "actions",
            header: "Action",
            cell: ({ row }) => {
                const id = row.original.banner_id;
                return (
                    <div className="flex gap-2 justify-center items-center">
                        {canEdit && canCreate && (
                            <button
                                onClick={() => handleEdit(row.original)}
                                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition"
                                title="Edit"
                                aria-label="Edit"
                            >
                                <Pencil size={20} />
                            </button>
                        )}
                        {canDelete && (
                            <button
                                onClick={() => handleDelete(id)}
                                className="p-1 text-red-600 hover:bg-red-100 dark:hover:bg-red-700 dark:hover:text-white rounded transition"
                                title="Delete"
                                aria-label="Delete"
                            >
                                <Trash2 size={20} />
                            </button>
                        )}
                    </div>
                );
            },
        });
    }

    const confirmDelete = async () => {
        try {
            const res = await apiDelete(`/ad_banner/${deleteId}`);

            if (res.success) {
                setRefreshKey((prev) => prev + 1);
            }
        } catch (error) {
            console.error("Delete failed:", error);
        } finally {
            setShowDeleteModal(false);
            setDeleteId(null);
        }
    };

    const fetchDataFunction = async ({ page, limit, search }) => {
        const result = await apiGet(
            `/ad_banner/get-all-ad-banner?page=${page}&limit=${limit}&search=${search || ""}`
        );

        return {
            aaData: result.banners || [],
            iTotalRecords: result.total,
            iTotalDisplayRecords: result.total,
        };
    };

    return (
        <div className="container mx-auto">
            <div className="flex justify-between items-center mb-5">
                <h2 className="text-xl font-semibold">
                    Advertisement Banners
                </h2>
                {canCreate && (
                    <button
                        onClick={handleAddClick}
                        className="bg-blue-500 text-white px-4 py-2 rounded-lg"
                    >
                        Add Advertisement Banner
                    </button>
                )}
            </div>

            <ActiveBanner  refreshKey={refreshKey}/>

            {/* Your Banner Table Here */}
            {/* Table Section */}
            <GenericTable
                key={refreshKey}
                title="Banner List"
                columnsConfig={columns}
                fetchDataFunction={fetchDataFunction}
            />

            {/* Confirmation Modal */}
            <ConfirmationModal
                isOpen={showDeleteModal}
                onClose={() => setShowDeleteModal(false)}
                onConfirm={confirmDelete}
                title="Delete Banner?"
                message="This action will permanently delete this banner."
                confirmText="Delete"
                cancelText="Cancel"
            />

            <AddBannerModal
                open={showModal}
                onClose={() => {
                    setShowModal(false);
                    setSelectedBanner(null);
                }}
                onSubmit={handleSaveSuccess}
                banner={selectedBanner}
            />
        </div>
    );
}