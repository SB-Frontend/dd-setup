import React, { useEffect, useState } from "react";
import axios from "axios";
import { apiGet } from "@/utils/api";

function ActiveBanner({ refreshKey }) {
    const [banners, setBanners] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchBanners();
    }, [refreshKey]);

    const fetchBanners = async () => {
        try {
            const res = await apiGet(`/ad_banner`);
            console.log(res)
            // assuming API returns array
            setBanners(res);
        } catch (error) {
            console.error("Error fetching banners", error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="container mx-auto py-6">
                <p className="text-gray-500">Loading banners...</p>
            </div>
        );
    }

    return (
        <div className="container mx-auto py-6 bg-white px-6 rounded-lg mb-4">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Active Banners</h2>

                <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                    {banners.length} Active
                </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {banners.length === 0 ? (
                    <div className="col-span-full text-center py-12">
                        <p className="text-gray-500">No active banners found.</p>
                    </div>
                ) : (
                    banners.map((banner) => (
                        <div
                            key={banner.banner_id}
                            className="bg-white rounded-xl shadow-md overflow-hidden border hover:shadow-lg transition "
                        >
                            {/* Banner Image */}
                            <img
                                src={`${import.meta.env.VITE_API_IMAGE_PATH}/banner/${banner.banner_img}`}
                                alt={banner.banner_name}
                                className="w-full h-52 object-contain bg-gray-50"
                            />

                            <div className="p-4">
                                <div className="flex justify-between items-start">
                                    <p className="text-sm text-gray-500 mb-2">
                                        Type: {banner.banner_type}
                                    </p>

                                    <span className="px-3 py-1 text-xs rounded-full bg-green-100 text-green-700 font-medium">
                                        Active
                                    </span>
                                </div>



                                {/* <a
                href={banner.dest_url}
                target="_blank"
                rel="noreferrer"
                className="text-blue-600 text-sm hover:underline break-all"
              >
                Visit Link
              </a> */}
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}

export default ActiveBanner;