import React, { useEffect, useState } from "react";
import { ImageIcon } from "lucide-react";

const initialForm = {
    author_name: "",
    author_display_name: "",
    author_designation: "",
    author_photo: null,
    author_photo_preview: "",
    author_description: "",
    author_email_id: "",
    author_website_link: "",
    author_linkdin_link: "",
};

export default function AuthorModal({
    isOpen,
    onClose,
    action,
    initialData,
    onSubmit,
}) {
    const [formData, setFormData] = useState(initialForm);
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});

    useEffect(() => {
        if (action === "edit" && initialData) {
            setFormData({
                author_name: initialData.author_name || "",
                author_display_name:
                    initialData.author_display_name || "",
                author_designation:
                    initialData.author_designation || "",
                author_photo:
                    initialData.author_photo || null,
                author_photo_preview: "",
                author_description:
                    initialData.author_description || "",
                author_email_id:
                    initialData.author_email_id || "",
                author_website_link:
                    initialData.author_website_link || "",
                author_linkdin_link:
                    initialData.author_linkdin_link || "",
            });
        } else {
            setFormData(initialForm);
        }
    }, [action, initialData]);

    const AUTHOR_IMAGE_URL = import.meta.env.VITE_API_IMAGE_PATH + "/author/";

    const handleChange = (e) => {
        const { name, value, type } = e.target;

        if (type === "file") {
            const file = e.target.files?.[0];

            if (file) {
                const reader = new FileReader();

                reader.onloadend = () => {
                    setFormData((prev) => ({
                        ...prev,
                        author_photo: file,
                        author_photo_preview: reader.result,
                    }));
                };

                reader.readAsDataURL(file);
            }

            return;
        }

        setFormData((prev) => {
            const updated = {
                ...prev,
                [name]: value,
            };

            // Auto-generate slug from Display Name
            if (name === "author_display_name") {
                updated.author_name = value
                    .toLowerCase()
                    .trim()
                    .replace(/[^\w\s-]/g, "") // remove special chars
                    .replace(/\s+/g, "-") // spaces to hyphen
                    .replace(/-+/g, "-"); // remove duplicate hyphens
            }

            return updated;
        });
    };

    const validateForm = () => {
        const newErrors = {};

        if (!formData.author_name?.trim()) {
            newErrors.author_name = "Author name is required";
        }

        if (!formData.author_display_name?.trim()) {
            newErrors.author_display_name =
                "Display name is required";
        }

        if (!formData.author_designation?.trim()) {
            newErrors.author_designation =
                "Designation is required";
        }

        if (!formData.author_email_id?.trim()) {
            newErrors.author_email_id =
                "Email is required";
        }

        if (!formData.author_description?.trim()) {
            newErrors.author_description =
                "Description is required";
        }

        if (
            action === "add" &&
            !formData.author_photo
        ) {
            newErrors.author_photo =
                "Author image is required";
        }

        setErrors(newErrors);

        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) return;

        try {
            setLoading(true);

            await onSubmit(formData);
            resetForm();
            onClose();
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (!isOpen) {
            setFormData(initialForm);
            setErrors({});
        }
    }, [isOpen]);

    const resetForm = () => {
        setFormData(initialForm);
        setErrors({});
    };

    const handleClose = () => {
        resetForm();
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
            <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-3xl p-6">
                <div className="flex justify-between items-center mb-5">
                    <h2 className="text-xl font-semibold">
                        {action === "add"
                            ? "Add Author"
                            : "Edit Author"}
                    </h2>

                    <button onClick={handleClose}>
                        ✕
                    </button>
                </div>

                <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-12 gap-4 max-h-[70vh] overflow-y-auto pr-2">

                        <div className="col-span-6">
                            <label className="text-sm font-medium">
                                Display Name *
                            </label>

                            <input
                                name="author_display_name"
                                value={formData.author_display_name}
                                onChange={handleChange}
                                className="w-full border rounded p-2 mt-1"
                            />

                            {errors.author_display_name && (
                                <p className="text-red-500 text-xs mt-1">
                                    {errors.author_display_name}
                                </p>
                            )}
                        </div>

                        <div className="col-span-6">
                            <label className="text-sm font-medium">
                                Author Name *
                            </label>

                            <input
                                name="author_name"
                                value={formData.author_name}
                                onChange={handleChange}
                                className="w-full border rounded p-2 mt-1"
                            />

                            {errors.author_name && (
                                <p className="text-red-500 text-xs mt-1">
                                    {errors.author_name}
                                </p>
                            )}
                        </div>



                        <div className="col-span-6">
                            <label className="text-sm font-medium">
                                Designation *
                            </label>

                            <input
                                name="author_designation"
                                value={formData.author_designation}
                                onChange={handleChange}
                                className="w-full border rounded p-2 mt-1"
                            />

                            {errors.author_designation && (
                                <p className="text-red-500 text-xs mt-1">
                                    {errors.author_designation}
                                </p>
                            )}
                        </div>

                        <div className="col-span-6">
                            <label className="text-sm font-medium">
                                Email *
                            </label>

                            <input
                                type="email"
                                name="author_email_id"
                                value={formData.author_email_id}
                                onChange={handleChange}
                                className="w-full border rounded p-2 mt-1"
                            />

                            {errors.author_email_id && (
                                <p className="text-red-500 text-xs mt-1">
                                    {errors.author_email_id}
                                </p>
                            )}
                        </div>

                        <div className="col-span-6">
                            <label className="text-sm font-medium">
                                Website URL
                            </label>

                            <input
                                name="author_website_link"
                                value={formData.author_website_link}
                                onChange={handleChange}
                                className="w-full border rounded p-2 mt-1"
                            />
                        </div>

                        <div className="col-span-6">
                            <label className="text-sm font-medium">
                                LinkedIn URL
                            </label>

                            <input
                                name="author_linkdin_link"
                                value={formData.author_linkdin_link}
                                onChange={handleChange}
                                className="w-full border rounded p-2 mt-1"
                            />
                        </div>

                        <div className="col-span-12 ">
                            <label className="text-sm font-medium block mb-2">
                                Author Photo *
                            </label>

                            <div className="flex items-center gap-4 border px-2 py-4 rounded-xl ">
                                {/* Preview */}
                                <div className="h-32 w-32 rounded-full border overflow-hidden flex items-center justify-center bg-gray-100">
                                    {formData.author_photo_preview ||
                                        formData.author_photo ? (
                                        <img
                                            src={
                                                formData.author_photo_preview ||
                                                `${AUTHOR_IMAGE_URL}${formData.author_photo}`
                                            }
                                            alt="Author"
                                            className="h-full w-full object-cover"
                                        />
                                    ) : (
                                        <ImageIcon
                                            size={50}
                                            className="text-gray-400"
                                        />
                                    )}
                                </div>

                                {/* Upload */}
                                <div className="flex-1">
                                    <input
                                        type="file"
                                        name="author_photo"
                                        accept="image/*"
                                        onChange={handleChange}
                                        className="w-full border rounded p-2 bg-white"
                                    />

                                    <p className="text-xs text-gray-500 mt-2">
                                        JPG, PNG, WEBP
                                    </p>

                                    {errors.author_photo && (
                                        <p className="text-red-500 text-xs mt-1">
                                            {errors.author_photo}
                                        </p>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="col-span-12">
                            <label className="text-sm font-medium">
                                Description *
                            </label>

                            <textarea
                                name="author_description"
                                value={formData.author_description}
                                onChange={handleChange}
                                rows={5}
                                className="w-full border rounded p-2 mt-1"
                            />

                            {errors.author_description && (
                                <p className="text-red-500 text-xs mt-1">
                                    {errors.author_description}
                                </p>
                            )}
                        </div>
                    </div>

                    <div className="flex justify-end gap-2 mt-6">
                        <button
                            type="button"
                            onClick={handleClose}
                            className="px-4 py-2 border rounded"
                        >
                            Cancel
                        </button>

                        <button
                            type="submit"
                            disabled={loading}
                            className="px-4 py-2 bg-blue-600 text-white rounded"
                        >
                            {loading
                                ? "Saving..."
                                : action === "add"
                                    ? "Create Author"
                                    : "Update Author"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}