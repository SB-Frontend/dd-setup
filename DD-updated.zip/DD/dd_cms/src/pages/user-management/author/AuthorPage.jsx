import React, { useCallback, useEffect, useMemo, useState } from "react";
import GenericTable from "@/components/TableStructure";
import { apiDelete, apiGet, apiPatch, apiPost } from "@/utils/api";
import { usePermission } from "@/hooks/usePermission";
import NoAccess from "@/components/NoAccess";
import AuthorModal from "./AuthorModal";
import { Pencil, Trash2 } from "lucide-react";
import toast from "react-hot-toast";

import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";

const MySwal = withReactContent(Swal);

const AuthorPage = () => {
  const [loading, setLoading] = useState(false);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [action, setAction] = useState("add");
  const [selectedAuthor, setSelectedAuthor] = useState(null);

  const [refresh, setRefresh] = useState(false);

  // const authorPerm = usePermission(8) || {};
  // const canRead = authorPerm.read === 1;
  // const canCreate = authorPerm.create === 1;
  // const canEdit = authorPerm.update === 1;
  // const canDelete = authorPerm.delete === 1;

  //   console.log( "UserPerm", userPerm)

  const handleAdd = () => {
    setAction("add");
    setSelectedAuthor(null);
    setIsModalOpen(true);
  };

  const handleEdit = (author) => {
    // console.log(author)
    setAction("edit");
    setSelectedAuthor(author);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedAuthor(null);
  };

  const columns = useMemo(() => {
    const cols = [
      {
        accessorKey: "author_id",
        header: "ID",
        sortable: true,
        cell: (info) => info.getValue(),
      },
      {
        accessorKey: "author_name",
        header: "Author Name",
        cell: (info) => info.getValue(),
      },
      {
        accessorKey: "author_display_name",
        header: "Author Display Name",
        cell: (info) => info.getValue(),
      },
      {
        accessorKey: "author_email_id",
        header: "Author Email",
        cell: ({ getValue }) => <span>{getValue()}</span>,
      },
    ];

    // if (canEdit || canDelete) {
      cols.push(
        {
          accessorKey: "status",
          header: "Status",
          cell: ({ row }) => {
            const author = row.original;
            const currentStatus = author.status;
            return (
              <>
                {/* {canEdit && ( */}
                <span
                  className={`px-2 py-1 rounded-full text-xs font-medium cursor-pointer ${
                    currentStatus === 1
                      ? "text-green-700 bg-green-100 dark:bg-green-700 dark:text-white"
                      : "text-red-700 bg-red-100 dark:bg-red-700 dark:text-white"
                  }`}
                  onClick={() => handleToggleStatus(author, currentStatus)}
                >
                  {currentStatus === 1 ? "Active" : "Inactive"}
                </span>
                {/* )} */}
              </>
            );
          },
        },
        {
          accessorKey: "actions",
          header: "Action",
          cell: ({ row }) => {
            const id = row.original.author_id;
            const author = row.original;
            return (
              <div className="flex gap-2">
                {/* {canEdit && ( */}
                  <button
                    onClick={() => handleEdit(author)}
                    className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition"
                  >
                    <Pencil size={20} />
                  </button>
                {/* )} */}
                {/* {canDelete && ( */}
                  <button
                    onClick={() => handleDelete(author)}
                    className="p-1 text-red-600 hover:bg-red-100 dark:hover:bg-red-700 dark:hover:text-white rounded transition"
                  >
                    <Trash2 size={20} />
                  </button>
                {/* )} */}
              </div>
            );
          },
        },
      );
    // }

    return cols;
  }, []);
  // }, [canEdit, canDelete]);

  // Frontend pagination, search, sort
  const fetchDataFunction = useCallback(
    async ({ page, limit, search, sort, order }) => {
      return apiGet(
        `/author/getlist?page=${page}&limit=${limit}&search=${search}&sort=${sort}&order=${order}`,
      );
    },
    [],
  );

  const handleSubmitAuthor = async (formData) => {
    // console.log(formData);

    try {
      const payload = new FormData();

      Object.keys(formData).forEach((key) => {
        if (key !== "author_photo_preview" && formData[key] !== null) {
          payload.append(key, formData[key]);
        }
      });

      if (action === "add") {
        const response = await apiPost("/author/create", payload, true);

        toast.success(response?.message || "Author created successfully");

        setIsModalOpen(false);
        setRefresh((prev) => !prev);
      } else {
        const response = await apiPatch(
          `/author/update/${selectedAuthor.author_id}`,
          payload,
          true,
        );
        toast.success(response?.message || "Author Updated successfully");
      }
      setRefresh((prev) => !prev);
    } catch (error) {
      console.error(error);
      toast.error(
        error?.response?.data?.message ||
          error?.message ||
          "Something went wrong",
      );
    }
  };

  const handleDelete = async (author) => {
    const result = await MySwal.fire({
      title: "Delete Author?",
      text: `Are you sure you want to delete "${author.author_display_name}"?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Delete",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#dc2626",
    });

    if (!result.isConfirmed) return;

    try {
      const response = await apiDelete(`/author/delete/${author.author_id}`);

      toast.success(response?.message || "Author deleted successfully");

      const result = await apiGet("/author/getlist");
      setAllData(result.aaData || []);
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to delete author");
    }
  };

  const handleToggleStatus = async (author, currentStatus) => {
    const actionText = currentStatus === 1 ? "Deactivate" : "Activate";

    const result = await MySwal.fire({
      title: `${actionText} Author?`,
      text: `Are you sure you want to ${actionText.toLowerCase()} "${author.author_display_name}"?`,
      icon: "question",
      showCancelButton: true,
      confirmButtonText: `Yes, ${actionText}`,
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    try {
      const response = await apiPatch(`/author/status/${author.author_id}`);

      toast.success(response?.message || "Status updated successfully");

      setRefresh((prev) => !prev);
    } catch (error) {
      toast.error(error?.response?.data?.message || "Failed to update status");
    }
  };

  // if (!canRead) {
  //   return <NoAccess />;
  // }

  const renderExpandedRow = useCallback((row) => {
    return (
      <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-md space-y-3">
        <div>
          <strong>Author Description:</strong> {row.author_description || "-"}
        </div>
        <div>
          <strong>Website Link:</strong> {row.author_website_link || "-"}
        </div>
        <div>
          <strong>Linkdin Link:</strong> {row.author_linkdin_link || "-"}
        </div>
      </div>
    );
  }, []);

  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          Author List
        </h2>
        {/* {canCreate && ( */}
          <div
            rel="stylesheet"
            className="me-2 px-4 py-2 text-sm text-white bg-blue-600 hover:bg-blue-700 rounded-md cursor-pointer"
            onClick={handleAdd}
          >
            Add Author
          </div>
        {/* )} */}
      </div>
      <GenericTable
        columnsConfig={columns}
        fetchDataFunction={fetchDataFunction}
        title=""
        loading={loading}
        enableExpansion={true}
        renderExpandedRow={renderExpandedRow}
        initialSort={{
          key: "author_id",
          order: "desc",
        }}
        refresh={refresh}
      />

      <AuthorModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        // onClose={() => setIsModalOpen(false)}
        action={action}
        initialData={selectedAuthor}
        onSubmit={handleSubmitAuthor}
      />
    </div>
  );
};

export default AuthorPage;
