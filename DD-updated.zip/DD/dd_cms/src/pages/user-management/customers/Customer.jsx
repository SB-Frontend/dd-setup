import React, { useEffect, useState } from "react";
import GenericTable from "@/components/TableStructure";
import { apiGet } from "@/utils/api";
import { usePermission } from '@/hooks/usePermission';
import NoAccess from '@/components/NoAccess';


const CustomerList = () => {
  const [allData, setAllData] = useState([]);
  const [loading, setLoading] = useState(false);

  const columns = [
    {
      accessorKey: "id",
      header: "ID",
      sortable: true,
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "name",
      header: "Name",
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "email",
      header: "Email",
      cell: ({ getValue }) => <span>{getValue()}</span>,
    },

    {
      accessorKey: "mobile_number",
      header: "Phone",
      cell: ({ getValue }) => <span>{getValue()}</span>,
    },

    {
      accessorKey: "industry",
      header: "Industry",
      cell: ({ getValue }) => <span>{getValue()}</span>,
    },
    {
      accessorKey: "designation",
      header: "designation",
      cell: ({ getValue }) => <span>{getValue()}</span>,
    },

    {
      accessorKey: "is_verified",
      header: "Is Verified",
      sortable: true,
      // cell: (info) =>
      //   new Date(info.getValue()).toLocaleDateString("en-US", {
      //     day: "numeric",
      //     month: "long",
      //     year: "numeric",
      //   }),
    },

    {
      accessorKey: "createdAt",
      header: "Registered Date",
      sortable: true,
      cell: (info) =>
        new Date(info.getValue()).toLocaleDateString("en-US", {
          day: "numeric",
          month: "long",
          year: "numeric",
        }),
    },
  ];

  // Fetch all customer data once
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const result = await apiGet(`/user/public/getlist`);
      console.log("Fetched result in CustomerList:", result); // ✅
      setAllData(result.aaData || []);
      setLoading(false);
    };
    fetchData();
  }, []);

  // Frontend pagination, search, sort
  const fetchDataFunction = async ({ page, limit, search, sort, order }) => {
    let filtered = [...allData];

    // Search
    if (search) {
      filtered = filtered.filter((item) =>
        item.name.toLowerCase().includes(search.toLowerCase())
      );
    }

    // Sort
    if (sort) {
      filtered.sort((a, b) => {
        const aVal = a[sort];
        const bVal = b[sort];
        if (typeof aVal === "string") {
          return order === "asc"
            ? aVal.localeCompare(bVal)
            : bVal.localeCompare(aVal);
        }
        return order === "asc" ? aVal - bVal : bVal - aVal;
      });
    }

    // Paginate
    const start = (page - 1) * limit;
    const paginated = filtered.slice(start, start + limit);

    return {
      aaData: paginated,
      iTotalRecords: allData.length,
      iTotalDisplayRecords: filtered.length,
    };
  };

  // const customerPerm = usePermission(2);
  // const canRead = customerPerm.p_read === 1;
  // if (!canRead) {
  //   return <NoAccess />;
  // }


  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          End User List
        </h2>
      </div>
      <GenericTable
        columnsConfig={columns}
        fetchDataFunction={fetchDataFunction}
        title=""
        loading={loading}
      />
    </div>
  );
};

export default CustomerList;
