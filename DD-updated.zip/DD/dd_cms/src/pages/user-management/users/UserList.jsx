import React, { useState, useEffect, useRef } from "react";
import GenericTable from "@/components/TableStructure";
import { apiDelete, apiGet, apiPost, apiPut } from "@/utils/api";
import { Pencil, Trash2 } from "lucide-react";
import { DeleteModal, Edit_AddUserModal } from "@/utils/frontendUtils";
import toast from "react-hot-toast";
import { getUsersList } from "../../../utils/api";
import { usePermission } from "@/hooks/usePermission";
// Frontend pagination, search, sort

const UserList = () => {
  const [allData, setAllData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshFlag, setRefreshFlag] = useState(false);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDeleteUser, setSelectedDeleteUser] = useState({});
  const [isModalOpen2, setIsModalOpen2] = useState(false);
  const [subModal, setSubModal] = useState(false);
  const [selectedEditUser, setSelectedEditUser] = useState({});
  const [action, setAction] = useState("edit");
  const scrollRef = useRef(null);
  const [errors, setErrors] = useState({});
  const triggerTableReload = () => {
    setRefreshFlag((prev) => !prev); // Toggling it causes GenericTable to refetch
  };
  // role fetching
  const [roles, setRoles] = useState([]);
  // console.log("check roles ", roles);


  const userPerm = usePermission(3) || {};
  // const canRead = userPerm.read === 1;
  // const canCreate = userPerm.create === 1;
  // const canEdit = userPerm.update === 1;
  // const canDelete = userPerm.delete === 1;

  // useEffect(() => {
  //   const fetchRoles = async () => {
  //     const result = await apiGet("/roles");
  //     setRoles(result.roles || []);
  //   };
  //   fetchRoles();
  // }, []);


  // action functions
  const handleEdit = (user) => {
    // console.log("does is in handle edit", user);
    setSelectedEditUser(user);
    setIsModalOpen(!isModalOpen);
    setAction("edit");
  };

  // delete user
  const handleDelete = (id) => {
    setSelectedDeleteUser(id);
    setIsModalOpen2(!isModalOpen2);
  };
  const confirmDelete = async () => {
    try {
      const response = await apiDelete(
        `/auth/users/${selectedDeleteUser.user_id}`
      );

      setAllData((prev) =>
        prev.filter((instance) => instance.user_id != selectedDeleteUser.user_id)
      );

      // console.log(response);

      toast.success(`User ${selectedDeleteUser.user_id} deleted successfully!`);
    } catch (error) {
      console.log("Failed to Delete the user", error);
    }
  };
  // update status
  const handleToggleStatus = async (user, currentStatus) => {
    // console.log(user.user_id)
    try {
      // Determine new status (toggle)
      const newStatus = currentStatus === 1 ? 0 : 1;

      // console.log(newStatus)

      const response = await apiPut(`/auth/update-status/${user.user_id}`, {
        user_status: newStatus,
      });

      // console.log("Status update response:", response);

      if (response) {
        // Update UI state
        setAllData((prevData) =>
          prevData.map((item) =>
            item.user_id === user.user_id
              ? { ...item, user_status: newStatus }
              : item
          )
        );

        // Dynamic toast message
        const actionMessage = newStatus === 1 ? "activated" : "deactivated";
        toast.success(
          `User ${user.user_name} has been ${actionMessage} successfully!`
        );
        triggerTableReload();
      } else {
        toast.error("Failed to update user status. Please try again.");
      }
    } catch (error) {
      console.error("Error updating status:", error);
      toast.error("Something went wrong while updating status.");
    }
  };

  // list


  // add
  const confirmAdd = async () => {
    try {
      //  console.log("selectedEditUser", selectedEditUser);
    // console.log("display_name", selectedEditUser.display_name);

      const { author_photo_preview, ...sanitizedUser } =
        selectedEditUser;

      // If user is NOT an author, clear all author fields
      if (!sanitizedUser.is_author) {
        sanitizedUser.author_photo = null;
        sanitizedUser.author_description = "";
      }

      // console.log("sanitizedUser", sanitizedUser);

      const formData = new FormData();

      for (const key in sanitizedUser) {
        // Skip preview field
        if (key.endsWith("_preview")) continue;

        // Skip author fields if user is not author
        if (
          !sanitizedUser.is_author &&
          [
            "author_photo",
            "author_description",
          ].includes(key)
        ) {
          continue;
        }

        // Skip null / undefined values
        if (
          sanitizedUser[key] === null ||
          sanitizedUser[key] === undefined
        ) {
          continue;
        }

        formData.append(key, sanitizedUser[key]);
      }

      // console.log("FORM DATA");

      // for (const [key, value] of formData.entries()) {
      //   // console.log(key, value);
      // }

      const response = await apiPost(
        "/auth/register",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      // console.log("response", response);

      if (response) {
        toast.success("User successfully created!");

        const addingUserLocally = {
          ...sanitizedUser,
          id: response.user?.id,
        };

        setAllData((prevData) => [
          ...prevData,
          addingUserLocally,
        ]);
      }

      setIsModalOpen(false);
    } catch (error) {
      console.log("check user error", error);

      let errorMessage =
        "User creation failed!";

      const data = error?.data;

      if (data) {
        if (
          Array.isArray(data.errors) &&
          data.errors.length > 0
        ) {
          errorMessage = data.errors
            .map(
              (e) =>
                `${e.field}: ${e.message}`
            )
            .join(", ");
        } else if (data.message) {
          errorMessage = data.message;
        }
      }

      toast.error(errorMessage);
    }
  };
  // Edit
  const confirmEdit = async () => {
    try {
      // console.log("selectedEditUse in edit action ->", selectedEditUser);

      // const completeRole = roles.find(
      //   (role) => role.rolename === selectedEditUser.rolename
      // );

      const { author_photo_preview, ...sanitizedUser } = selectedEditUser;
      const formData = new FormData();
      for (const key in sanitizedUser) {
        if (key.endsWith("_preview")) continue; // skip preview-only fields
        formData.append(key, sanitizedUser[key]);
      }
      // console.log("formdata is", formData);
      // for (const [key, value] of formData.entries()) {
      //   // console.log(key, value);
      // }
      // const response = await apiPut(`/admin-dash/update/${sanitizedUser.id}`, {
      //   ...sanitizedUser,
      //   // roles: completeRole.id,
      // });
      const response = await apiPut(
        `/auth/users/${sanitizedUser.user_id}`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
      // console.log("response", response);
      toast.success(
        `User ${selectedEditUser.user_name} information updated successfully!`
      );

      setAllData((prev) =>
        prev.map((instance) =>
          instance.id === selectedEditUser.id
            ? { ...instance, ...selectedEditUser } //roles: completeRole.id,
            : instance
        )
      );
      //  triggerTableReload();
      // console.log(response);
    } catch (error) {
      toast.error(
        `User ${selectedEditUser.name} information updatedtion Failed!`
      );
      console.log("Failed to Edit the user", error);
    }
  };
  const columns = [
    {
      accessorKey: "user_id",
      header: "ID",
      sortable: true,
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "display_name",
      header: "Display Name",
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "user_name",
      header: "Username",
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "user_email",
      header: "Email",
      cell: ({ getValue }) => <span>{getValue()}</span>,
    },

    // {
    //   accessorKey: "role_id",
    //   header: "Role",
    //   cell: ({ getValue }) => {
    //     const roleId = getValue();

    //     const role = roles.find((r) => r.id === roleId);

    //     return <span>{role?.role || "-"}</span>;
    //   },
    // },

  ];

  // if (canEdit || canDelete) {
    columns.push(
      {
        accessorKey: "user_status",
        header: "Status",
        cell: ({ row }) => {
          const user = row.original;
          const currentStatus = user.user_status;
          return (
            <>
              {/* {canEdit && ( */}
                <span
                  className={`px-2 py-1 rounded-full text-xs font-medium cursor-pointer ${currentStatus === 1
                    ? "text-green-700 bg-green-100 dark:bg-green-700 dark:text-white"
                    : "text-red-700 bg-red-100 dark:bg-red-700 dark:text-white"
                    }`}
                  onClick={() => handleToggleStatus(user, currentStatus)}
                >
                  {currentStatus === 1 ? "Active" : "Inactive"}
                </span>
              {/* )} */}
            </>
          );
        },
      },
      {
        accessorKey: "actions",
        header: "Action",
        cell: ({ row }) => {
          const id = row.original.user_id;
          const user = row.original;

          return (
            <div className="flex gap-2">
              {/* {canEdit && canCreate && ( */}
                <button
                  onClick={() => handleEdit(user)}
                  className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition"
                >
                  <Pencil size={20} />
                </button>
              {/* )} */}
              {/* {canDelete && ( */}
                <button
                  onClick={() => handleDelete(user)}
                  className="p-1 text-red-600 hover:bg-red-100 dark:hover:bg-red-700 dark:hover:text-white rounded transition"
                >
                  <Trash2 size={20} />
                </button>
              {/* )} */}
            </div>
          );
        },
      },)
  // }

  // if (!canRead) {
  //   return <NoAccess />;
  // }


  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          User List
        </h2>

        {/* {canCreate && ( */}
          <div
            rel="stylesheet"
            className="me-2 px-4 py-2 text-sm text-white bg-blue-600 hover:bg-blue-700 rounded-md cursor-pointer"
            onClick={() => {
              setIsModalOpen(!isModalOpen);
              setAction("add");
              setSelectedEditUser({});
            }}
          >
            Add User
          </div>
        {/* )} */}
      </div>
      <GenericTable
        columnsConfig={columns}
        fetchDataFunction={getUsersList}
        title=""
        //  loading={loading}
        refresh={triggerTableReload}
      />
      <Edit_AddUserModal
        isOpen={isModalOpen}
        toggleModal={() => {
          setIsModalOpen(!isModalOpen);
        }}
        onConfirm={action === "edit" ? confirmEdit : confirmAdd}
        selectedEditUser={selectedEditUser}
        setSelectedEditUser={setSelectedEditUser}
        subModal={subModal}
        setSubModal={setSubModal}
        roles={roles}
        action={action}
        errors={errors}
        setErrors={setErrors}
        scrollRef={scrollRef}
      />
      <DeleteModal
        isOpen={isModalOpen2}
        toggleModal={() => setIsModalOpen2(!isModalOpen2)}
        onConfirm={confirmDelete}
        title={"Are you sure you want to delete this user?"}
      />
    </div>
  );
};

export default UserList
