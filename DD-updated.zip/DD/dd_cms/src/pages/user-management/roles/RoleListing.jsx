import React, { useEffect, useState } from "react";
import GenericTable from "@/components/TableStructure";
import { apiGet, apiPut, apiPost } from "@/utils/api";
import { ShieldCheck } from "lucide-react";
import toast from "react-hot-toast";
import { usePermission } from "@/hooks/usePermission";

const RoleListing = () => {
  // const [roles, setRoles] = useState([]);
  const [refreshFlag, setRefreshFlag] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState(null);
  const [permissions, setPermissions] = useState([]);
  const [tempPermissions, setTempPermissions] = useState([]);
  const [showDiscardModal, setShowDiscardModal] = useState(false);
  const [isAddRoleModalOpen, setIsAddRoleModalOpen] = useState(false);
  const [showCancelRoleModal, setShowCancelRoleModal] = useState(false);

  const [newRole, setNewRole] = useState({
    role: "",
    rolename: "",
  });

  const rolePerm = usePermission(6) || {};
  const canRead = rolePerm.read === 1;
  const canCreate = rolePerm.create === 1;
  const canEdit = rolePerm.update === 1;
  const canDelete = rolePerm.delete === 1;

  // =========================================
  // FETCH ROLES
  // =========================================
  // useEffect(() => {
  //   fetchRoles();
  // }, []);

  // const fetchRoles = async () => {
  //   try {
  //     const response = await apiGet("/roles");

  //     setRoles(response?.roles || []);
  //   } catch (error) {
  //     console.error("Error fetching roles:", error);
  //   }
  // };

  // =========================================
  // FETCH ROLE PERMISSIONS
  // =========================================
  const openPermissionModal = async (role) => {
    try {
      setSelectedRole(role);

      const response = await apiGet(`/role_perm/${role.id}`);

      setPermissions(response || []);
      setTempPermissions(response || []);

      setIsModalOpen(true);
    } catch (error) {
      console.error("Error fetching permissions:", error);
    }
  };

  const handleAddRole = async () => {
    try {
      if (!newRole.role || !newRole.rolename) {
        toast.error("All fields are required");
        return;
      }

      await apiPost("/roles", {
        role: newRole.role,
        rolename: newRole.rolename,
      });

      toast.success("Role added successfully");

      setIsAddRoleModalOpen(false);

      setNewRole({
        role: "",
        rolename: "",
      });

      setRefreshFlag((prev) => !prev);
    } catch (error) {
      console.error(error);

      toast.error("Failed to add role");
    }
  };

  // =========================================
  // HANDLE CHECKBOX CHANGE
  // =========================================
  const handlePermissionChange = (permId, field, value) => {
    setTempPermissions((prev) =>
      prev.map((perm) =>
        perm.perm_id === permId
          ? {
            ...perm,
            [field]: value ? 1 : 0,
          }
          : perm,
      ),
    );
  };

  const handleSubmitPermissions = async () => {
    try {
      for (const perm of tempPermissions) {
        await apiPut(`/role_perm/${perm.role_id}/${perm.perm_id}`, {
          p_create: perm.create,
          p_read: perm.read,
          p_update: perm.update,
          p_delete: perm.delete,
        });
      }

      setPermissions(tempPermissions);

      toast.success("Permissions updated successfully");

      setIsModalOpen(false);
    } catch (error) {
      console.error(error);

      toast.error("Failed to update permissions");
    }
  };

  // =========================================
  // TABLE FETCH FUNCTION
  // =========================================
const getRoles = async ({
  page = 1,
  limit = 10,
  search = "",
  sort = "created_at",
  order = "desc",
}) => {
   console.log("limit =", limit);
  const response = await apiPost(
    "/roles/list",
    {
      page,
      limit: limit,
      search,
      sort,
      order,
    }
  );

  return {
    aaData: response.aaData || [],

    iTotalDisplayRecords:
      response.iTotalDisplayRecords || 0,

    iTotalRecords:
      response.iTotalRecords || 0,
  };
};
  // =========================================
  // TABLE COLUMNS
  // =========================================
  const columnsConfig = [
    {
      accessorKey: "id",
      header: "ID",
    },

    {
      accessorKey: "role",
      header: "Role",
    },

    {
      accessorKey: "rolename",
      header: "Role Slug",
    },

    {
      accessorKey: "created_at",
      header: "Created At",

      cell: ({ getValue }) =>
        getValue()
          ? new Date(getValue()).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })
          : "-",
    }
  ];

  if (canEdit) {
    columnsConfig.push(
      {
        accessorKey: "actions",
        header: "Action",
        cell: ({ row }) => {
          return (
            <button
              onClick={() => openPermissionModal(row.original)}
              className="flex items-center gap-2 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm"
            >
              <ShieldCheck size={16} />
              Permissions
            </button>
          );
        },
      },)
  }

  if (!canRead) {
    return <NoAccess />;
  }

  // const PermissionCheckbox = ({
  //   checked,
  //   onChange,
  //   color = "emerald",
  // }) => {
  //   const colors = {
  //     emerald: "peer-checked:bg-emerald-500 peer-checked:border-emerald-500",
  //     blue: "peer-checked:bg-blue-500 peer-checked:border-blue-500",
  //     amber: "peer-checked:bg-amber-500 peer-checked:border-amber-500",
  //     red: "peer-checked:bg-red-500 peer-checked:border-red-500",
  //   };

  //   return (
  //     <label className="group relative inline-flex cursor-pointer items-center justify-center">
  //       <input
  //         type="checkbox"
  //         className="peer sr-only"
  //         checked={checked}
  //         onChange={onChange}
  //       />

  //       <div
  //         className={`
  //         flex h-6 w-6 items-center justify-center
  //         rounded-lg border-2 border-slate-300
  //         bg-white shadow-sm
  //         transition-all duration-200
  //         group-hover:scale-110
  //         dark:border-slate-600
  //         dark:bg-slate-800
  //         ${colors[color]}
  //       `}
  //       >
  //         <svg
  //           className="h-3.5 w-3.5 text-white opacity-0 transition-opacity duration-200 peer-checked:opacity-100"
  //           fill="none"
  //           stroke="currentColor"
  //           strokeWidth="3"
  //           viewBox="0 0 24 24"
  //         >
  //           <path
  //             strokeLinecap="round"
  //             strokeLinejoin="round"
  //             d="M5 13l4 4L19 7"
  //           />
  //         </svg>
  //       </div>
  //     </label>
  //   );
  // };

  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg p-4">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          Role Listing
        </h2>

        {canCreate && (
          <button
            onClick={() => {
              setShowCancelRoleModal(false);
              setIsAddRoleModalOpen(true);
            }}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium"
          >
            Add Role
          </button>
        )}
      </div>

      {/* Generic Table */}
      <GenericTable
        title=""
        fetchDataFunction={getRoles}
        columnsConfig={columnsConfig}
        refresh={refreshFlag}
        initialSort={{ key: "id", order: "asc" }}
      />

      {/* ========================================= */}
      {/* Permission Modal */}
      {/* ========================================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg w-full max-w-3xl p-6 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
                Permissions - {selectedRole?.role}
              </h2>

              <button
                onClick={() => setShowDiscardModal(true)}
                className="text-gray-500 hover:text-red-500 text-xl"
              >
                ✕
              </button>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full border border-gray-200 dark:border-gray-700">
                <thead className="bg-gray-100 dark:bg-gray-800">
                  <tr>
                    <th className="p-3 text-left border">Permission</th>

                    <th className="p-3 border">Create</th>

                    <th className="p-3 border">Read</th>

                    <th className="p-3 border">Update</th>

                    <th className="p-3 border">Delete</th>
                  </tr>
                </thead>

                <tbody>
                  {tempPermissions.map((perm) => (
                    <tr key={perm.id} className="border-t dark:border-gray-700">
                      <td className="p-3 ">{perm.permission_name || "-"}</td>

                      {/* CREATE */}
                      <td className="p-3 text-center ">
                        <input
                          type="checkbox"
                          checked={perm.create === 1}
                          onChange={(e) =>
                            handlePermissionChange(
                              perm.perm_id,
                              "create",
                              e.target.checked,
                            )
                          }
                        />
                      </td>

                      {/* READ */}
                      <td className="p-3 text-center ">
                        <input
                          type="checkbox"
                          checked={perm.read === 1}
                          onChange={(e) =>
                            handlePermissionChange(
                              perm.perm_id,
                              "read",
                              e.target.checked,
                            )
                          }
                        />
                      </td>

                      {/* UPDATE */}
                      <td className="p-3 text-center ">
                        <input
                          type="checkbox"
                          checked={perm.update === 1}
                          onChange={(e) =>
                            handlePermissionChange(
                              perm.perm_id,
                              "update",
                              e.target.checked,
                            )
                          }
                        />
                      </td>

                      {/* DELETE */}
                      <td className="p-3 text-center ">
                        <input
                          type="checkbox"
                          checked={perm.delete === 1}
                          onChange={(e) =>
                            handlePermissionChange(
                              perm.perm_id,
                              "delete",
                              e.target.checked,
                            )
                          }
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Footer */}
            <div className="flex justify-center gap-4 mt-6">
              <button
                onClick={() => setShowDiscardModal(true)}
                className="px-5 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-md"
              >
                Discard
              </button>

              <button
                onClick={handleSubmitPermissions}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )
      }
      {
        showDiscardModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-sm p-6">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                Are you sure?
              </h2>

              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Unsaved permission changes will be lost.
              </p>

              <div className="flex justify-center gap-4">
                <button
                  onClick={() => setShowDiscardModal(false)}
                  className="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-md"
                >
                  No
                </button>

                <button
                  onClick={() => {
                    setTempPermissions(permissions);
                    setShowDiscardModal(false);
                    setIsModalOpen(false);

                  }}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md"
                >
                  Yes
                </button>
              </div>
            </div>
          </div>
        )
      }
      {
        isAddRoleModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
            <div
              className="bg-white dark:bg-gray-900 rounded-lg shadow-lg w-full max-w-3xl p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
                  Add Role
                </h2>

                <button
                  onClick={() => setShowCancelRoleModal(true)}
                  className="text-gray-500 hover:text-red-500 text-xl"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
                    Role Name
                  </label>

                  <input
                    type="text"
                    value={newRole.role}
                    onChange={(e) =>
                      setNewRole((prev) => ({
                        ...prev,
                        role: e.target.value,
                      }))
                    }
                    placeholder="Enter role name"
                    className="w-full border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white rounded-md px-3 py-2"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
                    Role Slug
                  </label>

                  <input
                    type="text"
                    value={newRole.rolename}
                    onChange={(e) =>
                      setNewRole((prev) => ({
                        ...prev,
                        rolename: e.target.value,
                      }))
                    }
                    placeholder="Enter role slug"
                    className="w-full border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white rounded-md px-3 py-2"
                  />
                </div>
              </div>

              <div className="flex justify-center gap-4 mt-6">
                <button
                  onClick={() => setShowCancelRoleModal(true)}
                  className="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-md"
                >
                  Cancel
                </button>

                <button
                  onClick={handleAddRole}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md"
                >
                  Submit
                </button>
              </div>

              {showCancelRoleModal && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50">
                  <div
                    className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-sm p-6"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                      Are you sure?
                    </h2>

                    <p className="text-gray-600 dark:text-gray-300 mb-6">
                      Unsaved role data will be lost.
                    </p>

                    <div className="flex justify-center gap-4">
                      <button
                        onClick={() => setShowCancelRoleModal(false)}
                        className="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-md"
                      >
                        No
                      </button>

                      <button
                        onClick={() => {
                          setNewRole({
                            role: "",
                            rolename: "",
                          });

                          setShowCancelRoleModal(false);
                          setIsAddRoleModalOpen(false);
                        }}
                        className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md"
                      >
                        Yes
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )
      }
    </div >
  );
};

export default RoleListing;
