import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useForm } from "react-hook-form";
import { apiPost } from "@/utils/api"; // Adjust path
import { useAuth } from "@/context/AuthContext"; // Adjust path
import { AArrowDown, Eye, EyeOff } from "lucide-react";

const ResetPassword = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);

    const token = queryParams.get("t");
    const email = queryParams.get("e");

    const [formErrorMessage, setFormErrorMessage] = useState("");
    const [paramErrorMessage, setParamErrorMessage] = useState("");
    const [successMessage, setSuccessMessage] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    useEffect(() => {
        if (!token || !email) {
            setParamErrorMessage("Invalid password reset link. Missing token or email.");
        }
    }, [token, email]);



    const {
        register,
        handleSubmit,
        watch,
        reset,
        formState: { errors },
    } = useForm();

    const password = watch("password");

    useEffect(() => {
        if (user) {
            navigate("/dashboard", { replace: true });
        }
    }, [user, navigate]);

    const onSubmit = async (data) => {
        try {
            console.log(data);

            const response = await apiPost("/auth/reset-password", data);
            console.log(response);
            setFormErrorMessage("");
            setSuccessMessage(response.message);
            reset();
            // setFormErrorMessage("");
            // // Optionally redirect or show success message
            // navigate("/login");
        } catch (err) {
            console.error(err.data.message);
            setFormErrorMessage(err.data.message);
            setSuccessMessage("");
        }
    };




    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-100 dark:bg-gray-800">
        <div className="w-full max-w-md p-8 bg-white dark:bg-gray-900 rounded-lg shadow-lg">
          <div className="flex justify-center mb-4">
            <img
              src="/assets/logo/martech360_logo.png"
              alt="Logo"
              className="w-28 h-auto"
            />
          </div>
          {paramErrorMessage ? (
            <div className="text-red-600 text-sm text-center mt-4">
              {paramErrorMessage}
            </div>
          ) : (
            <>
              {" "}
              <div className="mb-3">
                <h2 className="text-xl font-bold text-center text-blue-500 dark:text-white">
                  Reset Password
                </h2>
                <p className="text-sm text-center text-gray-700 dark:text-white">
                  Enter your new Password.
                </p>
              </div>
              {formErrorMessage && (
                <div className="text-red-500 text-sm text-center mb-4">
                  {formErrorMessage}
                </div>
              )}
              {successMessage && (
                <div className="text-green-600 text-center mb-4">
                  {successMessage}
                </div>
              )}
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <input type="hidden" value={email} {...register("email")} />
                <input type="hidden" value={token} {...register("token")} />

                <div className="relative">
                  <label
                    htmlFor="password"
                    className="block text-sm font-medium text-gray-700 dark:text-gray-300"
                  >
                    New Password
                  </label>

                  <input
                    type={showPassword ? "text" : "password"}
                    id="password"
                    placeholder="Enter new password"
                    className={`mt-1 text-sm block w-full px-3 py-2 border rounded-md shadow-sm pr-10 focus:outline-none focus:ring-1 ${
                      errors.password
                        ? "border-red-500 ring-red-500"
                        : "border-gray-300 dark:border-gray-600 focus:ring-blue-500"
                    } dark:bg-gray-800 dark:text-white`}
                    {...register("password", {
                      required: "Password is required",
                      minLength: {
                        value: 6,
                        message: "Password must be at least 6 characters",
                      },
                      onChange: () => {
                        if (formErrorMessage || successMessage) {
                          setFormErrorMessage("");
                          setSuccessMessage("");
                        }
                      },
                    })}
                  />

                  <span
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-[2rem] cursor-pointer text-gray-400 hover:text-gray-600 dark:hover:text-white"
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </span>

                  {errors.password && (
                    <p className="text-red-600 text-xs mt-1">
                      {errors.password.message}
                    </p>
                  )}
                </div>

                <div className="relative">
                  <label
                    htmlFor="confirmPassword"
                    className="block text-sm font-medium text-gray-700 dark:text-gray-300"
                  >
                    Confirm Password
                  </label>

                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    id="confirmPassword"
                    placeholder="Re-enter new password"
                    className={`mt-1 text-sm block w-full px-3 py-2 border rounded-md shadow-sm pr-10 focus:outline-none focus:ring-1 ${
                      errors.confirmPassword
                        ? "border-red-500 ring-red-500"
                        : "border-gray-300 dark:border-gray-600 focus:ring-blue-500"
                    } dark:bg-gray-800 dark:text-white`}
                    {...register("confirmPassword", {
                      required: "Please confirm your password",
                      validate: (value) =>
                        value === password || "Passwords do not match",
                      onChange: () => {
                        if (formErrorMessage || successMessage) {
                          setFormErrorMessage("");
                          setSuccessMessage("");
                        }
                      },
                    })}
                  />

                  <span
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-[2rem] cursor-pointer text-gray-400 hover:text-gray-600 dark:hover:text-white"
                  >
                    {showConfirmPassword ? (
                      <EyeOff size={20} />
                    ) : (
                      <Eye size={20} />
                    )}
                  </span>

                  {errors.confirmPassword && (
                    <p className="text-red-600 text-xs mt-1">
                      {errors.confirmPassword.message}
                    </p>
                  )}
                </div>

                <div>
                  <button
                    type="submit"
                    className="w-full py-2 px-4 bg-blue-500 hover:bg-blue-600 text-white font-semibold rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    Reset Password
                  </button>
                </div>
              </form>
            </>
          )}
          <div className="flex justify-end text-end mt-5 ">
            <p className="me-2 text-md">
              <button
                type="button"
                onClick={() => navigate("/forgot-password", { replace: true })}
                className="text-blue-600 hover:underline"
              >
                Resend Password Reset Link
              </button>
            </p>{" "}
            |
            <p className="ms-2 text-md ">
              <button
                type="button"
                onClick={() => navigate("/login", { replace: true })}
                className="text-blue-600 hover:underline"
              >
                Login
              </button>
            </p>
          </div>
        </div>
      </div>
    );
};

export default ResetPassword;
