// src/pages/Login.jsx
import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import { apiGet, apiPost } from "@/utils/api"; // Adjust the import path as necessary
import { useAuth } from "@/context/AuthContext"; // Adjust the import path as necessary

const Login = () => {
  const { user, login, token } = useAuth();
  // console.log('check user in login page', user);
  const [user_email, setUserEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (user) {
      navigate("/dashboard", { replace: true }); // or another route
    }
  }, [user, navigate]);

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      const data = await apiPost(
        "/auth/login",
        {
          user_email,
          user_password: password
        }
      );

      // console.log("login data =>", data);

      const {
        id,
        user_name,
        user_email: email,
        role,
        rolename,
        token,
        role_id
      } = data.user;

      // const perms = await apiGet(`/role_perm/${role_id}`);

      // console.log(perms, "perms")

      const user = {
        id,
        name: user_name,
        email,
        role,
        role_id,
        rolename
      };

      login(user, token);

      navigate("/dashboard");

    } catch (err) {

      console.log(err);

      setErrorMessage("Invalid credentials");

    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[var(--background)] px-4">
      <div className="w-full max-w-md rounded-xl border border-[var(--border)] bg-[var(--card)] p-8 shadow-lg">

        {/* Logo */}
        <div className="mb-6 flex justify-center">
          <img
            src="/assets/logo/datademand-logo.webp"
            alt="DataDemand"
            className="h-auto w-56"
          />
        </div>

        {/* Heading */}
        <div className="mb-6 text-center">
          <h2 className="text-2xl font-bold text-[var(--foreground)]">
            Sign In
          </h2>

          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            Sign in to access your dashboard
          </p>
        </div>

        {/* Error */}
        {errorMessage && (
          <div className="mb-4 rounded-md border border-[var(--error)] bg-[var(--error-light)] px-3 py-2 text-center text-sm text-[var(--error)]">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Email */}
          <div>
            <label
              htmlFor="user_email"
              className="mb-1.5 block text-sm font-medium text-[var(--foreground)]"
            >
              Email Address
            </label>

            <input
              type="text"
              id="user_email"
              value={user_email}
              onChange={(e) => setUserEmail(e.target.value)}
              required
              placeholder="Enter your email"
              className="
              block w-full rounded-md border
              border-[var(--input)]
              bg-[var(--background)]
              px-3 py-2.5
              text-sm text-[var(--foreground)]
              placeholder:text-[var(--muted-foreground)]
              outline-none
              transition
              focus:border-[var(--primary)]
              focus:ring-2
              focus:ring-[var(--primary)]/15
            "
            />
          </div>

          {/* Password */}
          <div>
            <label
              htmlFor="password"
              className="mb-1.5 block text-sm font-medium text-[var(--foreground)]"
            >
              Password
            </label>

            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="Enter your password"
                className="
                block w-full rounded-md border
                border-[var(--input)]
                bg-[var(--background)]
                px-3 py-2.5 pr-10
                text-sm text-[var(--foreground)]
                placeholder:text-[var(--muted-foreground)]
                outline-none
                transition
                focus:border-[var(--primary)]
                focus:ring-2
                focus:ring-[var(--primary)]/15
              "
              />

              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="
                absolute inset-y-0 right-0 flex items-center
                px-3 text-[var(--muted-foreground)]
                transition
                hover:text-[var(--primary)]
              "
              >
                {showPassword ? <EyeOff size={19} /> : <Eye size={19} />}
              </button>
            </div>
          </div>

          {/* Login */}
          <button
            type="submit"
            className="
            w-full rounded-md
            bg-[var(--primary)]
            px-4 py-2.5
            text-sm font-semibold
            text-[var(--primary-foreground)]
            transition
            hover:bg-[var(--primary-hover)]
            focus:outline-none
            focus:ring-2
            focus:ring-[var(--ring)]/30
            focus:ring-offset-2
          "
          >
            Login
          </button>
        </form>

        {/* Reset password */}
        <div className="mt-5 text-center">
          <button
            type="button"
            onClick={() => navigate("/forgot-password")}
            className="
            text-sm font-medium
            text-[var(--brand-primary)]
            transition
            hover:text-[var(--brand-accent)]
            hover:underline
          "
          >
            Reset Password?
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
