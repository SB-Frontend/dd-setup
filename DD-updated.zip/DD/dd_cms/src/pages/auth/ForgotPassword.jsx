// src/pages/Login.jsx
import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AArrowDown, Eye, EyeOff } from "lucide-react";
import { apiPost } from "@/utils/api"; // Adjust the import path as necessary
import { useAuth } from "@/context/AuthContext"; // Adjust the import path as necessary
import { useForm } from "react-hook-form";

const ForgotPassword = () => {
    const { user, login } = useAuth();

    const [errorMessage, setErrorMessage] = useState("");
    const [successMessage, setSuccessMessage] = useState("");

    const navigate = useNavigate();
    const location = useLocation();

    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm();


    useEffect(() => {
        if (user) {
            navigate("/dashboard", { replace: true }); // or another route
        }
    }, [user, navigate]);

    const onSubmit = async (data) => {
        console.log("ForgotPassword form submitted");

        // console.log('Imported login function:', loginApi);

        // e.preventDefault();
        try {

            console.log(data);
            const response = await apiPost("/auth/forgot-password", data);
            console.log('check respone', response)
            setErrorMessage("");
            setSuccessMessage("Password reset link has been sent to your email.");
            reset();

        } catch (err) {
            console.log(err.data.message);

            setSuccessMessage("");
            setErrorMessage(err.data?.message || "Something went wrong.");
        }
    };

    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-100 dark:bg-gray-800">
        <div className="w-full max-w-md p-8  bg-white dark:bg-gray-900 rounded-lg shadow-lg">
          <div className="flex justify-center mb-4">
            <img
              src="/assets/logo/martech360_logo.png"
              alt="Logo"
              className="w-28 h-auto"
            />
          </div>
          <div className="mb-3">
            <h2 className="text-xl font-bold text-center text-gray-600 dark:text-white">
              Forgot Password
            </h2>
            <p className=" text-sm text-center text-gray-700 dark:text-white">
              Enter your email to reset your password.
            </p>
          </div>
          {successMessage && (
            <div className="text-green-600 text-center mb-4">
              {successMessage}
            </div>
          )}
          {errorMessage && (
            <div className="text-red-500 text-center mb-4">{errorMessage}</div>
          )}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-gray-700 dark:text-gray-300"
              >
                Email Address
              </label>
              <input
                type="text"
                id="email"
                placeholder="Enter your email"
                className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-1
                                ${
                                  errors.email
                                    ? "border-red-500 ring-red-500"
                                    : "border-gray-300 dark:border-gray-600 focus:ring-blue-500 focus:border-blue-500"
                                }
                                    dark:bg-gray-800 dark:text-white`}
                {...register("email", {
                  required: "Email is required",
                  pattern: {
                    value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                    message: "Invalid email address",
                  },
                  onChange: () => {
                    if (errorMessage || successMessage) {
                      setErrorMessage("");
                      setSuccessMessage("");
                    }
                  },
                })}
              />
              {errors.email && (
                <p className="text-red-600 text-xs mt-1 ms-2">
                  {errors.email.message}
                </p>
              )}
            </div>

            <div>
              <button
                type="submit"
                className="w-full py-2 px-4 bg-blue-500 hover:bg-blue-600 text-white font-semibold rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                Send Mail
              </button>
            </div>
          </form>
          <div className="text-end mt-3">
            <button
              type="button"
              onClick={() => navigate("/login", { replace: true })}
              className="text-blue-600 hover:underline"
            >
              Login
            </button>
          </div>
        </div>
      </div>
    );
};

export default ForgotPassword;
