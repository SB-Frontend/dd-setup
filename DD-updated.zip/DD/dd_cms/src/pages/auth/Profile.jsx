import React, { useEffect, useState } from "react";
import {
  Mail,
  Phone,
  Briefcase,
  Calendar,
  Shield,
  Hash,
  Clock, User
} from "lucide-react";
import { apiGet } from "@/utils/api";
import { useAuth } from "@/context/AuthContext";

export default function UserProfilePage() {
  const { user, permissions } = useAuth();
  console.log("user is", user);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      if (!user?.id) return;
      try {
        setLoading(true);
        const res = await apiGet(`/auth/users/${user.id}`);
        console.log("respons is", res.user);

        setUserData(res.user);
      } catch (err) {
        console.error("Error fetching user data:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [user?.id]);

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto p-6">
        <div className="animate-pulse flex flex-col sm:flex-row gap-6 items-center">
          <div className="w-32 h-32 bg-gray-300 dark:bg-gray-700 rounded-full"></div>
          <div className="flex-1 space-y-3 w-full">
            <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-1/3"></div>
            <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-1/4"></div>
            <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-1/5"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!userData) {
    return (
      <div className="text-center text-gray-500 dark:text-gray-400">
        User not found.
      </div>
    );
  }

  function InfoCard({ icon, label, value }) {
    return (
      <div
        className="
        flex items-center gap-3
        rounded-xl
        border border-gray-200 dark:border-gray-700
        bg-white dark:bg-gray-800/50
        px-4 py-3
      "
      >
        <div
          className="
          flex h-10 w-10 shrink-0
          items-center justify-center
          rounded-lg
          bg-[#37afad]/10
          text-[#37afad]
        "
        >
          {icon}
        </div>

        <div className="min-w-0">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {label}
          </p>

          <p className="truncate text-sm font-semibold text-gray-900 dark:text-white">
            {value}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          Profile
        </h2>
      </div>
      <div className="mx-auto space-y-6">
        <div className="overflow-hidden rounded-3xl bg-white dark:bg-gray-800 shadow-xl border border-gray-100 dark:border-gray-700">
          {/* Cover */}
          <div
            className="relative h-32 overflow-hidden rounded-t-3xl"
            style={{
              background:
                "linear-gradient(135deg, #2f8f8d 0%, #37afad 55%, #58c6c4 100%)",
            }}
          >
            <svg
              className="absolute inset-0 w-full h-full opacity-15"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <pattern
                  id="grid"
                  width="40"
                  height="40"
                  patternUnits="userSpaceOnUse"
                >
                  <path
                    d="M40 0H0V40"
                    fill="none"
                    stroke="white"
                    strokeWidth="1"
                  />
                </pattern>
              </defs>

              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>

            <div className="absolute right-0 top-0 h-40 w-40 rounded-full bg-white/10 blur-3xl" />
            <div className="absolute left-20 bottom-0 h-24 w-24 rounded-full bg-white/5 blur-2xl" />
          </div>

          {/* Content */}
          <div className="px-8 pb-8">
            {/* Avatar */}
            <div className="-mt-16 flex flex-col md:flex-row md:items-end gap-6 ">
              <img
                src={userData?.author_img || "/assets/user-icon.svg"}
                alt={userData?.user_name}
                className="h-32 w-32 rounded-3xl object-cover border-4 border-white dark:border-gray-800 shadow-xl z-20" />

              <div className="flex-1 z-20">
                <div className="flex flex-wrap items-center gap-3">
                  <h1 className="text-3xl font-bold text-white dark:text-white uppercase">
                    {userData?.user_name}
                  </h1>

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold
                      ${userData?.user_status
                        ? "bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-500"
                        : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                      }`}
                  >
                    {userData?.user_status ? "Active" : "Inactive"}
                  </span>
                </div>

                <div className="mt-2 flex items-center gap-2 text-gray-500 dark:text-gray-400">
                  <Briefcase size={16} />
                  <span>{userData?.designation || "No Designation"}</span>
                </div>

                <div className="mt-2 flex items-center gap-2 text-gray-500 dark:text-gray-400">
                  <Mail size={16} />
                  <span>{userData?.user_email}</span>
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <InfoCard
                icon={<Hash size={18} />}
                label="User ID"
                value={userData?.username}
              />

              <InfoCard
                icon={<User size={18} />}
                label="Author"
                value={userData?.is_author === 1 ? "Yes" : "No"}
              />

              <InfoCard
                icon={<Calendar size={18} />}
                label="Joined"
                value={
                  userData?.createdAt
                    ? new Date(userData.createdAt).toLocaleDateString("en-GB")
                    : "-"
                }
              />

              <InfoCard
                icon={<Clock size={18} />}
                label="Last Updated"
                value={
                  userData?.updatedAt
                    ? new Date(userData.updatedAt).toLocaleDateString("en-GB")
                    : "-"
                }
              />
            </div>
          </div>
        </div>

        {/* Permissions */}
        {/* <div className="bg-white text-sm dark:bg-gray-800 rounded-2xl shadow-lg p-6">
                    <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900 dark:text-gray-100">
                        <Shield size={20} className="text-blue-500" /> Permissions
                    </h2>
                    <div className="grid gap-3">
                        {permissions.map((perm) => (
                            <div
                                key={perm.perm_id}
                                className="bg-gray-100 dark:bg-gray-700 px-4 py-2 rounded-lg shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between"
                            >
                                <div className="font-medium text-gray-900 dark:text-gray-100 mb-2 sm:mb-0">
                                    {perm.perm}
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {["Read", "Create", "Update", "Delete"].map((label, idx) => (
                                        <span
                                            key={idx}
                                            className={`px-3 py-1 text-xs font-medium rounded-full ${[perm.read, perm.create, perm.update, perm.delete][idx]
                                                ? "bg-green-100 text-green-700 dark:bg-green-800 dark:text-green-200"
                                                : "bg-red-100 text-red-700 dark:bg-red-800 dark:text-red-200"
                                                }`}
                                        >
                                            {label}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div> */}
      </div>
    </div>
  );
}
