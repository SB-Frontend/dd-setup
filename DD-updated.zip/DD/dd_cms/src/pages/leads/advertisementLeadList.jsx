import React, { useState } from "react";
import GenericTable from "@/components/TableStructure";
import Modal from "@/components/InputModal";
import { useForm } from "react-hook-form";
import {
  apiPost,
  apiPut,
} from "../../utils/api";
import { getDateTime } from "../../hooks/getDateTime";
import { MessageSquare } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { showTailwindAlert } from "@/utils/showTailwindAlert";
import { useNavigate, Link } from "react-router-dom";
import { usePermission } from "@/hooks/usePermission";
import NoAccess from "@/components/NoAccess";
const AdvertisementLeadList = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [showModalForId, setShowModalForId] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedPostId, setSelectedPostId] = useState(null);

  const [refreshFlag, setRefreshFlag] = useState(false);
const LeadPerm = usePermission(4);
  const canRead = LeadPerm.read === 1;
  const canCreate = LeadPerm.create === 1;
  const canEdit = LeadPerm?.update === 1;
  const canDelete = LeadPerm?.delete === 1;
  if (!canRead) {
    return <NoAccess />;
  }
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  const triggerTableReload = () => {
    setRefreshFlag((prev) => !prev); // Toggling it causes GenericTable to refetch
  };

const getLeadList = async (params) => {
  const {
    page = 1,
    limit = 10,
    search = "",
    sort = "createdAt",
    order = "desc",
  } = params;

  const response = await apiPost(
    "/contact/all_advertise",
    {
      page,
      limit,
      search,
      sort,
      order,
    }
  );

  return {
    aaData: response?.aaData || [],
    iTotalRecords: response?.iTotalRecords || 0,
    iTotalDisplayRecords:
      response?.iTotalDisplayRecords || 0,
  };
};

  const onSubmitComment = async (data) => {
    try {
      // console.log("Comment:", data.comments);
      // console.log("Post ID:", selectedPostId);
      const userComment = `<b>By ${user.name} [${getDateTime()}]:</b> ${data.comment}`;

      await apiPut(`/contact/add-advertise-comment/${selectedPostId}`, {
        comment: userComment,
      });

      await showTailwindAlert({
        title: "Success!",
        text: "Comment added successfully.",
        icon: "success",
      });

      reset();
      setModalOpen(false);

      triggerTableReload();
    } catch (error) {
      await showTailwindAlert({
        title: "Error!",
        text: error.message,
        icon: "error",
      });
    }
  };

  const getLastComment = (html) => {
    if (!html) return "-";

    const parts = html.split("<br>").filter(Boolean);

    return parts[parts.length - 1]?.replace(/(<([^>]+)>)/gi, "").trim();
  };

  const handleDownload = async () => {
    try {
      const response = await fetch(
        "http://localhost:3010/api/download/advertisments",
      );

      if (!response.ok) {
        throw new Error("Failed to download CSV");
      }

      // get blob
      const blob = await response.blob();

      // create download url
      const url = window.URL.createObjectURL(blob);

      // create temporary anchor
      const link = document.createElement("a");
      link.href = url;
      link.download = "leads_data.csv";

      document.body.appendChild(link);
      link.click();

      // cleanup
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);

      showTailwindAlert({
        title: "Error",
        text: error.message,
        icon: "error",
      });
    }
  };

  const columnsConfig = [
    { accessorKey: "id", header: "Id", sortable: true },
    { accessorKey: "name", header: "Name" },
    { accessorKey: "email", header: "Email" }, //
    { accessorKey: "ad_format", header: "Subject" },
    {
      accessorKey: "createdAt",
      header: "Date",
      sortable: true,
      cell: ({ getValue }) =>
        getValue()
          ? new Date(getValue()).toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            })
          : "-",
    },
    {
      accessorKey: "actions",
      header: "Action",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setSelectedPostId(row.original.id);
              setModalOpen(true);
            }}
            className="p-1 text-blue-600 hover:bg-blue-100 dark:hover:bg-blue-700 dark:hover:text-white rounded"
          >
            <MessageSquare size={16} />
          </button>
        </div>
      ),
    },
  ];

  const renderExpandedRow = (row) => {
    return (
      <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-md space-y-3">
        <div>
          <strong>company:</strong> {row.company || "-"}
        </div>
        <div>
          <strong>goals:</strong> {row.goals || "-"}
        </div>

        <div>
          <strong>Comments:</strong>

          {row.comments ? (
            <div
              className="mt-2 text-sm text-gray-700 dark:text-gray-200 leading-7"
              dangerouslySetInnerHTML={{
                __html: row.comments,
              }}
            />
          ) : (
            <span className="ml-2 text-gray-500">No comments</span>
          )}
        </div>
      </div>
    );
  };
   
  // publihs/unpublish blog handler function

  return (
    <>
      <div className="container mx-auto dark:bg-gray-900 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
            Advertisement Leads
          </h2>
          <button
            onClick={handleDownload}
            className="px-4 py-2 text-sm text-white bg-green-600 hover:bg-green-700 rounded-md"
          >
            Download CSV
          </button>
        </div>
        <GenericTable
          title=""
          fetchDataFunction={getLeadList}
          columnsConfig={columnsConfig}
          enableExpansion={true}
          renderExpandedRow={renderExpandedRow}
          refresh={refreshFlag}
        />
        <Modal
          isOpen={modalOpen}
          title="Add Comment"
          onCancel={() => {
            reset();
            setModalOpen(false);
          }}
          onSave={handleSubmit(onSubmitComment)}
        >
          <label className="block mb-2 font-medium text-sm">Comment</label>

          <textarea
            {...register("comment", {
              required: "Comment is required",
            })}
            rows={4}
            className={`w-full border rounded-md p-2 dark:bg-gray-800 dark:text-white ${
              errors.comment ? "border-red-500" : "border-gray-300"
            }`}
            placeholder="Enter comment..."
          />

          {errors.comment && (
            <p className="text-red-500 text-sm mt-1">
              {errors.comment.message}
            </p>
          )}
        </Modal>
      </div>
    </>
  );
};

export default AdvertisementLeadList;
