import React, { useState } from "react";
import GenericTable from "@/components/TableStructure";
import { apiPost } from "../../utils/api";
import { showTailwindAlert } from "@/utils/showTailwindAlert";
import { usePermission } from "@/hooks/usePermission";
import NoAccess from "@/components/NoAccess";

const BrandKitLeadList = () => {
  const [refreshFlag, setRefreshFlag] = useState(false);

  const LeadPerm = usePermission(4);
  const canRead = LeadPerm.read === 1;

  if (!canRead) {
    return <NoAccess />;
  }

  const getBrandKitLeadList = async ({
    page = 1,
    limit = 10,
    search = "",
    sort = "created_at",
    order = "desc",
  }) => {
    return await apiPost("/contact/brand-kit/getlist", {
      page,
      limit,
      search,
      sort,
      order,
    });
  };

  const handleDownload = async () => {
    try {
      const response = await fetch(
        "http://localhost:3010/api/download/brand-kits"
      );

      if (!response.ok) {
        throw new Error("Failed to download CSV");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.download = "brand_kit_leads.csv";

      document.body.appendChild(link);
      link.click();

      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);

      showTailwindAlert({
        title: "Error",
        text: error.message,
        icon: "error",
      });
    }
  };

  const columnsConfig = [
    {
      accessorKey: "id",
      header: "Id",
      sortable: true,
    },
    {
      accessorKey: "full_name",
      header: "Name",
    },
    {
      accessorKey: "company",
      header: "Company",
    },
    {
      accessorKey: "work_email",
      header: "Email",
    },
    {
      accessorKey: "job_title",
      header: "Job Title",
    },
   {
  accessorKey: "opt_in",
  header: "Opt In",
  sortable: true,
  cell: ({ row }) => {
    const value = row.original.opt_in;

    return (
      <span
        className={`px-2 py-1 rounded-full text-xs font-medium ${
          value
            ? "bg-green-100 text-green-700"
            : "bg-gray-200 text-gray-700"
        }`}
      >
        {value ? "Yes" : "No"}
      </span>
    );
  },
},
    {
      accessorKey: "created_at",
      header: "Date",
      sortable: true,
      cell: ({ getValue }) =>
        getValue()
          ? new Date(getValue()).toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            })
          : "-",
    },
  ];

  return (
    <div className="container mx-auto dark:bg-gray-900 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
          Brand-Kit Leads
        </h2>

        <button
          onClick={handleDownload}
          className="px-4 py-2 text-sm text-white bg-green-600 hover:bg-green-700 rounded-md"
        >
          Download CSV
        </button>
      </div>

      <GenericTable
        title=""
        fetchDataFunction={getBrandKitLeadList}
        columnsConfig={columnsConfig}
        enableExpansion={false}
        refresh={refreshFlag}
      />
    </div>
  );
};

export default BrandKitLeadList;