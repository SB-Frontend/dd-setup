"use client";
import React, { useEffect, useState } from "react";
import GenericTable from "@/components/TableStructure";
import ConfirmationModal from "@/components/ConfirmationModal";
import { apiGet, apiPost, apiPut, apiDelete } from "@/utils/api";
import { Pencil, Trash2 } from "lucide-react";
import FormInput from "@/components/FormInput";
import toast from "react-hot-toast";
import { usePermission } from "@/hooks/usePermission";
import NoAccess from "@/components/NoAccess";

const CategoryPage = () => {
  const [allData, setAllData] = useState([]);
  const [formData, setFormData] = useState({
    cat_name: "",
    cat_slug: "",
    meta_title: "",
    meta_desc: "",
    meta_keywords: "",
  });
  const [editId, setEditId] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  // const rcatPerm = usePermission(5) || {};
  // const canRead = rcatPerm.read === 1;
  // const canCreate = rcatPerm.create === 1;
  // const canEdit = rcatPerm.update === 1;
  // const canDelete = rcatPerm.delete === 1;


  // const handleInputChange = (name, value) => {
  //   setFormData((prev) => ({
  //     ...prev,
  //     [name]: value,
  //   }));
  // };

  const handleInputChange = (name, value) => {
    setFormData((prev) => {
        const updated = {
            ...prev,
            [name]: value,
        };

        if (name === "cat_name") {
            updated.cat_slug = value
                .trim()
                .toLowerCase()
                .replace(/\s+/g, "-")
                .replace(/[^a-z0-9-]/g, "");
        }

        return updated;
    });
};

  const handleCancel = () => {
    setFormData({
      cat_name: "",
      cat_slug: "",
      meta_title: "",
      meta_desc: "",
      meta_keywords: "",
    });
    setIsEditing(false);
    setEditId(null);
    setEditId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.cat_name || !formData.cat_slug) {
      toast.error("Category Title and Slug are required!");
      return;
    }
    try {
      if (editId) {
        await apiPut(`/category/${editId}`, formData);
        toast.success("Category updated successfully!");
      } else {
        await apiPost("/category", formData);
        toast.success("Category added successfully!");
      }
      const updatedData = await apiGet("/category/get_all_categories");
      setAllData(updatedData.data || []);
      handleCancel();
    } catch (err) {
      toast.error("Operation failed");
      console.error(err);
    }
  };

  const handleEdit = (id) => {
    const selected = allData.find((item) => item.cat_id === id);
    if (selected) {
      setFormData({
        cat_name: selected.cat_name || "",
        cat_slug: selected.cat_slug || "",
        meta_title: selected.meta_title || "",
        meta_desc: selected.meta_desc || "",
        meta_keywords: selected.meta_keywords || "",
      });
      setIsEditing(true);
      setEditId(id);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleDelete = (id) => {
    setDeleteId(id);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!deleteId) return;
    try {
      await apiDelete(`/category/${deleteId}`);
      toast.success("Category deleted successfully!");
      const updatedData = await apiGet("/category/get_all_categories");
      setAllData(updatedData.data || []);
    } catch (err) {
      toast.error("Failed to delete category.");
    }
    setDeleteId(null);
    setIsDeleteModalOpen(false);
  };

  const columns = [
    { accessorKey: "cat_id", header: "ID" },
    { accessorKey: "cat_name", header: "Category Title" },
    { accessorKey: "cat_slug", header: "Category Slug" },
  ];

  // if (canEdit || canDelete) {
    columns.push({
      accessorKey: "actions",
      header: "Action",
      cell: ({ row }) => {
        const id = row.original.cat_id;
        return (
          <div className="flex gap-2 justify-center items-center">
           
            {/* {canEdit && ( */}
              <button
                onClick={() => handleEdit(id)}
                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition"
                title="Edit"
                aria-label="Edit"
              >
                <Pencil size={20} />
              </button>
             {/* )}  */}
            {/* {canDelete && ( */}
              <button
                onClick={() => handleDelete(id)}
                className="p-1 text-red-600 hover:bg-red-100 dark:hover:bg-red-700 dark:hover:text-white rounded transition"
                title="Delete"
                aria-label="Delete"
              >
                <Trash2 size={20} />
              </button>
             {/* )}  */}
          </div>
        );
      },
    });
  // }

  useEffect(() => {
    const fetchData = async () => {
      const result = await apiGet("/category/get_all_categories");
      setAllData(result.data || []);
    };
    fetchData();
  }, []);

  const fetchDataFunction = async ({ page, limit, search }) => {
    let filtered = [...allData];
    if (search) {
      filtered = filtered.filter((item) =>
        item.cat_name.toLowerCase().includes(search.toLowerCase())
      );
    }
    const start = (page - 1) * limit;
    const paginated = filtered.slice(start, start + limit);
    return {
      aaData: paginated,
      iTotalRecords: allData.length,
      iTotalDisplayRecords: filtered.length,
    };
  };


  // if (!canRead) {
  //   return <NoAccess />;
  // }

  return (
    <>
      <div className="container mx-auto dark:bg-gray-900 rounded-lg ">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Category</h2>
        </div>
        <div className="space-y-8">
          {/* {canCreate && ( */}
            <div className="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
                {editId ? "Edit Category" : "Add Category"} Information
              </h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormInput
                    name="cat_name"
                    label="Category Title"
                    placeholder="Category"
                    value={formData.cat_name}
                    onChange={handleInputChange}
                    required
                  />
                  <FormInput
                    name="cat_slug"
                    label="Category Slug"
                    placeholder="Category Slug"
                    value={formData.cat_slug}
                    onChange={handleInputChange}
                    required
                  />
                  <FormInput
                    name="meta_title"
                    label="Meta Title"
                    placeholder="Meta Title"
                    value={formData.meta_title}
                    onChange={handleInputChange}
                     required
                  />
                  <FormInput
                    name="meta_desc"
                    label="Meta Desc"
                    placeholder="Meta Description"
                    value={formData.meta_desc}
                    onChange={handleInputChange}
                     required
                  />
                  <FormInput
                    name="meta_keywords"
                    label="Meta Keywords"
                    placeholder="Meta Keywords"
                    value={formData.meta_keywords}
                    onChange={handleInputChange}
                    className="md:col-span-2"
                  />
                </div>
                <div className="flex justify-end gap-4">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="px-4 py-2 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-white rounded-md"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md"
                  >
                    {editId ? "Update Category" : "Add Category"}
                  </button>
                </div>
              </form>
            </div>
           {/* )}  */}

          {/* Table Section */}
          <GenericTable
            columnsConfig={columns}
            fetchDataFunction={fetchDataFunction}
            title="Category List"
          />

          {/* Confirmation Modal */}
          <ConfirmationModal
            isOpen={isDeleteModalOpen}
            onClose={() => setIsDeleteModalOpen(false)}
            onConfirm={confirmDelete}
            title="Delete Category?"
            message="This action will permanently delete the category."
            confirmText="Delete"
            cancelText="Cancel"
          />
        </div>
      </div>
    </>
  );
};

export default CategoryPage;
