import React, { useState, useEffect } from "react";
import SmallCard from "@/components/SmallCard";
import { Link } from "react-router-dom";
import YoutubeModal from "./YoutubeModal";
import BrandKitModal from "./BrandKitModal";
import {
  ClipboardCheck,
  NotepadTextDashed,
  Podcast,
  CalendarClock,
  UserPlus,
  Inbox,
  Send,
  FileText,
  Boxes,
} from "lucide-react";
import { apiGet } from "@/utils/api";
import ContentChart from "./chart.jsx/ContentChart";
import { useAuth } from "@/context/AuthContext";
import KpiStatsCard from "./KpiStatsCard";
import dashboardBg from "@/assets/dashboard-bg.webp"; // Adjust the path as necessary
// import dashboardBg from "@/assets/dashboardbg.jpg";
function Dashboard() {
  const [stats, setStats] = useState({
    totalPosts: 0,
  });

  // const { user } = useAuth();
  // const [youtubeId, setYoutubeId] = useState("");
  // const [showYoutubeModal, setShowYoutubeModal] = useState(false);
  // const [brandKitPdf, setBrandKitPdf] = useState("");
  // const [showBrandKitModal, setShowBrandKitModal] = useState(false);

  // const fetchYoutubeId = async () => {
  //   try {
  //     const res = await apiGet("/youtube/latest");
  //     setYoutubeId(res?.data?.youtube_id || "");
  //   } catch (err) {
  //     console.error(err);
  //   }
  // };

  // const fetchBrandKitPdf = async () => {
  //   try {
  //     const res = await apiGet(`contact/brand-kit/pdf`);
  //     setBrandKitPdf(res?.pdf || "");
  //   } catch (err) {
  //     console.error(err);
  //   }
  // };

  // useEffect(() => {
  //   fetchYoutubeId();
  //   fetchBrandKitPdf();
  // }, []);



  useEffect(() => {
    async function fetchData() {
      try {

        const [
          dashboardResult
        ] = await Promise.all([
          apiGet("/posts/all_post_count"),
        ]);

        setStats({
          totalPosts: dashboardResult.total_posts || 0,
        });
      } catch (error) {
        console.error(
          "Error fetching dashboard data:",
          error
        );
      }
    }


      fetchData();
    

  }, []);



  // const chartData = [
  //   { name: "News", value: stats.news },
  //   { name: "Voices", value: stats.voices },
  //   { name: "Events", value: stats.events },
  //   { name: "Podcast", value: stats.podcast },
  //   { name: "Insights", value: stats.insights },
  // ];

  // const COLORS = [
  //   "#22c55e",
  //   "#3b82f6",
  //   "#f59e0b",
  //   "#a855f7",
  //   "#ef4444",
  // ];

return (
  <div className="relative min-h-screen overflow-hidden bg-[#050b1a]">

    {/* Background Image */}
    <div
      className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105 blur-[2px]"
      style={{
        backgroundImage: `url(${dashboardBg})`,
      }}
    />

    {/* Dark Blue Overlay */}
    <div className="absolute inset-0 bg-[#06142d]/80" />

    {/* Gradient Overlay */}
    <div className="absolute inset-0 bg-gradient-to-b from-[#06142d]/70 via-[#07152d]/80 to-[#020617]/95" />

    {/* Content */}
    <div className="relative z-10 min-h-screen p-6">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white">
            Dashboard Overview
          </h2>

          <p className="mt-2 text-sm text-gray-300">
            Real-time analytics & content summary
          </p>
        </div>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
        <Link to="/posts/list">
          <SmallCard
            icon={<Boxes />}
            title="Posts"
            value={stats.totalPosts}
            color="indigo"
          />
        </Link>
      </div>

    </div>
  </div>
);
}

export default Dashboard;
