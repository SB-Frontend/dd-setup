import { ChevronRight } from "lucide-react";
import CountUp from "react-countup";

export default function KpiStatsCard({
    icon,
    title,
    value,
    description,
    color = "blue",
    trend,
}) {
    const colors = {
        blue: {
            text: "text-blue-700",
            bg: "bg-blue-100",
            icon: "bg-blue-100 text-blue-600",
            border: "hover:border-blue-300",
        },
        green: {
            text: "text-green-700",
            bg: "bg-green-100",
            icon: "bg-green-100 text-green-600",
            border: "hover:border-green-300",
        },
        yellow: {
            text: "text-yellow-500",
            bg: "bg-yellow-100",
            icon: "bg-yellow-100 text-yellow-600",
            border: "hover:border-yellow-300",
        },
    };

    const style = colors[color];

    return (
        <div
            className={`
        group relative overflow-hidden
        rounded-2xl
        border border-gray-200 dark:border-gray-800
        bg-white dark:bg-gray-800
        p-5
        transition-all duration-300
        hover:-translate-y-1
        hover:shadow-lg dark:hover:shadow-black/20
        ${style.border}
      `}
        >
            {/* Top Section */}
            <div className="absolute right-5 z-20 top-5 flex items-start justify-between">
                <div className="relative">
                    <div className={`p-3 rounded-xl ${style.icon}`}>
                        {icon}
                    </div>

                    {value > 0 && (
                        <span className="absolute -top-1 -right-1 flex h-3 w-3">
                            <span className="absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75 animate-ping" />
                            <span className="relative inline-flex h-3 w-3 rounded-full bg-red-500" />
                        </span>
                    )}
                </div>

                {trend && (
                    <div className="mt-4">
                        <span className="
              inline-flex items-center
              rounded-full
              px-2.5 py-1
              text-xs font-medium
              bg-green-100 text-green-700
              dark:bg-green-900/30
              dark:text-green-400
            ">
                            {trend}
                        </span>
                    </div>
                )}
            </div>

            {/* Stats */}
            <div className="">
                <h3 className="text-sm font-medium text-gray-500">
                    {title}
                </h3>

                <p className={`mt-1 text-4xl font-bold ${style.text}`}>
                    <CountUp end={value} duration={2} /> 
                </p>

                <p className="mt-2 text-sm text-gray-500">
                    {description}
                </p>
            </div>

            {/* Footer */}
            {/* <div className="mt-5 flex items-center text-sm font-medium text-gray-600 group-hover:text-gray-900">
                View Details
                <ChevronRight
                    size={16}
                    className="ml-1 transition-transform group-hover:translate-x-1"
                />
            </div> */}

            {/* Decorative Gradient */}
            <div className={` absolute -right-10 -top-10 h-24 w-24 rounded-full ${style.bg} opacity-60 `} />
        </div>
    );
}