import {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    CartesianGrid,
    Cell,
    LabelList,
} from "recharts";

const colors = [
    "url(#green)",
    "url(#blue)",
    "url(#yellow)",
    "url(#purple)",
    "url(#red)",
];

const getPath = (x, y, width, height) => {
    return `
    M${x},${y + height}
    C${x + width / 3},${y + height}
    ${x + width / 2},${y + height / 3}
    ${x + width / 2},${y}
    C${x + width / 2},${y + height / 3}
    ${x + (2 * width) / 3},${y + height}
    ${x + width},${y + height}
    Z
  `;
};

const TriangleBar = (props) => {
    const { fill, x, y, width, height } = props;

    return (
        <path
            d={getPath(x, y, width, height)}
            stroke="none"
            fill={fill}
        />
    );
};

export default function ContentChart({ data }) {
    return (
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm">
            <div className="mb-5">
                <h3 className="font-semibold text-lg text-gray-900 dark:text-white">
                    Content Distribution
                </h3>

                <p className="text-sm text-gray-500">
                    Posts by category
                </p>
            </div>

            <div className="h-[350px] ">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                        data={data}
                        margin={{
                            top: 30,
                            right: 0,
                            left: 10,
                            // bottom: 10,
                        }}
                    >
                        <defs>
                            <linearGradient id="indigo" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#818CF8" />
                                <stop offset="100%" stopColor="#4F46E5" />
                            </linearGradient>

                            <linearGradient id="green" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#34D399" />
                                <stop offset="100%" stopColor="#059669" />
                            </linearGradient>
                        </defs>

                        <CartesianGrid
                            strokeDasharray="3 3"
                            stroke="#374151"
                            opacity={0.1}
                        />

                        <XAxis
                            dataKey="name"
                            tick={{ fill: "#9CA3AF" }}
                            axisLine={false}
                            tickLine={false}
                        />

                        <YAxis
                            tick={{ fill: "#9CA3AF" }}
                            axisLine={false}
                            tickLine={false}
                        />

                        <Tooltip
                            contentStyle={{
                                background: "#111827",
                                border: "none",
                                borderRadius: "12px",
                                color: "#fff",
                            }}
                        />

                        <Bar
                            dataKey="value"
                            shape={<TriangleBar />}
                        >
                            {data.map((entry, index) => (
                                <Cell
                                    key={index}
                                    fill={colors[index % colors.length]}
                                />
                            ))}

                            <LabelList
                                dataKey="value"
                                position="top"
                                style={{
                                    fill: "#6B7280",
                                    fontWeight: 600,
                                }}
                            />
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
}