import React, { useState, useEffect } from "react";
import { apiPut } from "@/utils/api";
import toast from "react-hot-toast";

const BrandKitModal = ({
  isOpen,
  onClose,
  onSaved,
  currentBrandKitPdf,
}) => {
  const [pdfFile, setPdfFile] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setPdfFile(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = async () => {
    if (!pdfFile) {
      toast.error("Please select a PDF file");
      return;
    }

    try {
      setLoading(true);

      const formData = new FormData();
      formData.append("pdf", pdfFile);

      await apiPut("/contact/brand-kit/pdf", formData);

      toast.success("Brand Kit PDF updated successfully");

      await onSaved();

      setPdfFile(null);
      onClose();
    } catch (err) {
      console.error("Brand Kit upload error:", err);
      toast.error(
        err?.response?.data?.message ||
        "Failed to update Brand Kit PDF"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
      <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-md shadow-xl p-6">

        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-5">
          Change Brand Kit PDF
        </h2>

        {/* Current PDF */}
        <div className="mb-5">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Current Brand Kit PDF
          </label>

          <div className="px-3 py-2 border rounded-md bg-gray-100 dark:bg-gray-700 dark:text-white break-all">
            {currentBrandKitPdf || "No Brand Kit PDF Found"}
          </div>
        </div>

        {/* New PDF */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            New Brand Kit PDF
          </label>

          <input
            type="file"
            accept=".pdf,application/pdf"
            onChange={(e) =>
              setPdfFile(e.target.files?.[0] || null)
            }
            className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 dark:bg-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />

          {pdfFile && (
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
              Selected: {pdfFile.name}
            </p>
          )}
        </div>

        {/* Buttons */}
        <div className="flex justify-end gap-3">
          <button
            onClick={() => {
              setPdfFile(null);
              onClose();
            }}
            disabled={loading}
            className="px-4 py-2 rounded-md bg-gray-300 hover:bg-gray-400 text-gray-800 transition disabled:opacity-50"
          >
            Cancel
          </button>

          <button
            onClick={handleSave}
            disabled={loading}
            className="px-4 py-2 rounded-md bg-blue-600 hover:bg-blue-700 text-white transition disabled:opacity-50"
          >
            {loading ? "Uploading..." : "Upload"}
          </button>
        </div>

      </div>
    </div>
  );
};

export default BrandKitModal;