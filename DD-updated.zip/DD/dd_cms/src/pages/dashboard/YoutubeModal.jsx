import React, { useState, useEffect } from "react";
import { apiPost } from "@/utils/api";
import toast from "react-hot-toast";

const YoutubeModal = ({
  isOpen,
  onClose,
  onSaved,
  currentYoutubeId,
}) => {
  const [youtubeId, setYoutubeId] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setYoutubeId("");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = async () => {
    if (!youtubeId.trim()) {
      toast.error("Please enter Youtube ID");
      return;
    }

    try {
      setLoading(true);

      await apiPost("/youtube", {
        youtube_id: youtubeId.trim(),
      });

      toast.success("Youtube ID updated");

      onSaved();

      setYoutubeId("");

      onClose();
    } catch (err) {
      console.error(err);
      toast.error("Failed to update Youtube ID");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
      <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-md shadow-xl p-6">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-5">
          Change Youtube ID
        </h2>

        <div className="mb-5">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Current Youtube ID
          </label>

          <div className="px-3 py-2 border rounded-md bg-gray-100 dark:bg-gray-700 dark:text-white">
            {currentYoutubeId || "No Youtube ID Found"}
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            New Youtube ID
          </label>

          <input
            type="text"
            value={youtubeId}
            onChange={(e) => setYoutubeId(e.target.value)}
            placeholder="Enter Youtube ID"
            className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 dark:bg-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

       <div className="flex justify-end gap-3">
  <button
    onClick={() => {
      setYoutubeId("");
      onClose();
    }}
    disabled={loading}
    className="px-4 py-2 rounded-md bg-gray-300 hover:bg-gray-400 text-gray-800 transition disabled:opacity-50"
  >
    Cancel
  </button>

  <button
    onClick={handleSave}
    disabled={loading}
    className="px-4 py-2 rounded-md bg-blue-600 hover:bg-blue-700 text-white transition disabled:opacity-50"
  >
    {loading ? "Saving..." : "Save"}
  </button>
</div>
      </div>
    </div>
  );
};

export default YoutubeModal;