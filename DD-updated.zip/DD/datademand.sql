-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 12, 2026 at 04:53 AM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `datademand`
--

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int UNSIGNED DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_authors_slug` (`slug`),
  KEY `ix_authors_status_display_name` (`status`,`display_name`),
  KEY `ix_authors_created_by` (`created_by`),
  KEY `ix_authors_updated_by` (`updated_by`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `name`, `display_name`, `slug`, `bio`, `image`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(44, 'Alex Morgan', 'Alex Morgan', 'alex-morgan', '<p>Writes about the intersection of media buying and machine learning.</p>', NULL, 1, 187, 187, '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(45, 'Sarah Mitchell', 'Sarah Mitchell', 'sarah-mitchell', '<p>Covers search, content strategy and how audiences actually find things.</p>', NULL, 1, 187, 187, '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(46, 'Daniel Carter', 'Daniel Carter', 'daniel-carter', '<p>Follows the advertising technology stack and the money moving through it.</p>', NULL, 1, 187, 187, '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(47, 'Emily Wilson', 'Emily Wilson', 'emily-wilson', '<p>Reports on social platforms, community and the commerce built on top of them.</p>', NULL, 1, 187, 187, '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(48, 'Michael Anderson', 'Michael Anderson', 'michael-anderson', '<p>Writes about measurement, customer data and the systems that hold them.</p>', NULL, 1, 187, 187, '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_categories_slug` (`slug`),
  KEY `ix_categories_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `status`, `meta_title`, `meta_description`, `meta_keywords`, `created_at`, `updated_at`, `deleted_at`) VALUES
(44, 'Digital Marketing', 'digital-marketing', 1, 'Digital Marketing', 'Campaigns, channels and strategy across digital marketing.', 'digital marketing', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(45, 'Artificial Intelligence', 'artificial-intelligence', 1, 'Artificial Intelligence', 'Applied AI for marketing and commercial teams.', 'artificial intelligence', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(46, 'Advertising Technology', 'advertising-technology', 1, 'Advertising Technology', 'The platforms and pipes behind modern advertising.', 'advertising technology', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(47, 'Social Media', 'social-media', 1, 'Social Media', 'Social platforms, community and social commerce.', 'social media', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(48, 'Data & Analytics', 'data-analytics', 1, 'Data & Analytics', 'Measurement, attribution and customer data.', 'data & analytics', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(49, 'Martech', 'martech', 1, 'Martech', 'The marketing technology stack and how teams run it.', 'martech', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
CREATE TABLE IF NOT EXISTS `leads` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_leads_email` (`email`),
  KEY `ix_leads_status` (`status`),
  KEY `ix_leads_created_at` (`created_at`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `lead_notes`
--

DROP TABLE IF EXISTS `lead_notes`;
CREATE TABLE IF NOT EXISTS `lead_notes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_lead_notes_lead_created` (`lead_id`,`created_at`),
  KEY `ix_lead_notes_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int UNSIGNED DEFAULT NULL,
  `storage_path` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'posts',
  `uploaded_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_media_filename` (`filename`),
  KEY `ix_media_uploaded_by` (`uploaded_by`),
  KEY `ix_media_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_permissions_permission_name` (`permission_name`),
  UNIQUE KEY `uq_permissions_permission_slug` (`permission_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_name`, `permission_slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Dashboard Management', 'dashboard_management', 'Access the CMS dashboard', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(2, 'Post Management', 'post_management', 'Create and edit posts', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(3, 'Post Publishing', 'post_publishing', 'Change a post status to published', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(4, 'User Management', 'user_management', 'Manage CMS user accounts and roles', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(5, 'Lead Management', 'lead_management', 'View and annotate leads and subscribers', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(6, 'Category Management', 'category_management', 'Manage categories and subcategories', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(7, 'Role Management', 'role_management', 'Manage roles and their permissions', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(8, 'Advertisement Management', 'advertisement_management', 'Manage advertisements', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(9, 'Author Management', 'author_management', 'Manage public author profiles', '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(10, 'Media Management', 'media_management', 'Upload and manage media', '2026-09-09 20:35:50', '2026-09-09 20:35:50');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `author_id` int UNSIGNED DEFAULT NULL,
  `category_id` int UNSIGNED DEFAULT NULL,
  `subcategory_id` int UNSIGNED DEFAULT NULL,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_banner` tinyint(1) NOT NULL DEFAULT '1',
  `reading_time` smallint UNSIGNED DEFAULT NULL,
  `priority` smallint NOT NULL DEFAULT '0',
  `auto_publish` tinyint(1) NOT NULL DEFAULT '0',
  `published_at` datetime DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_posts_slug` (`slug`),
  KEY `ix_posts_status_published_at` (`status`,`published_at`),
  KEY `ix_posts_category_status_published` (`category_id`,`status`,`published_at`),
  KEY `ix_posts_subcategory` (`subcategory_id`),
  KEY `ix_posts_author` (`author_id`),
  KEY `ix_posts_created_at` (`created_at`),
  KEY `ix_posts_created_by` (`created_by`),
  KEY `ix_posts_updated_by` (`updated_by`)
) ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `excerpt`, `status`, `author_id`, `category_id`, `subcategory_id`, `banner_image`, `show_banner`, `reading_time`, `priority`, `auto_publish`, `published_at`, `meta_title`, `meta_description`, `meta_keywords`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(183, 'How AI Is Changing Digital Marketing Strategies', 'ai-changing-digital-marketing-strategies', '<p>How AI Is Changing Digital Marketing Strategies is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of content marketing are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the digital marketing stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of content marketing usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes content marketing simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at ai is changing digital marketing strategies, and what it actually changes for digital marketing teams.', 'published', 44, 44, 16, NULL, 1, 8, 0, 0, '2026-06-09 22:47:40', 'How AI Is Changing Digital Marketing Strategies', 'A practical look at ai is changing digital marketing strategies, and what it actually changes for digital marketing teams.', 'digital marketing, content marketing', 187, 188, '2026-06-09 22:47:40', '2026-06-11 22:47:40', NULL),
(184, 'The Future of Generative AI in Marketing', 'future-of-generative-ai-in-marketing', '<p>The Future of Generative AI in Marketing is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of generative ai are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the artificial intelligence stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of generative ai usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes generative ai simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at future of generative ai in marketing, and what it actually changes for artificial intelligence teams.', 'published', 44, 45, 17, NULL, 1, 11, 0, 0, '2026-06-14 22:47:41', 'The Future of Generative AI in Marketing', 'A practical look at future of generative ai in marketing, and what it actually changes for artificial intelligence teams.', 'artificial intelligence, generative ai', 188, 189, '2026-06-14 22:47:41', '2026-06-16 22:47:41', NULL),
(185, 'Programmatic Advertising Trends for Modern Brands', 'programmatic-advertising-trends-modern-brands', '<p>Programmatic Advertising Trends for Modern Brands is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of programmatic advertising are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the advertising technology stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of programmatic advertising usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes programmatic advertising simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at programmatic advertising trends for modern brands, and what it actually changes for advertising technology teams.', 'published', 46, 46, 19, NULL, 1, 7, 0, 0, '2026-06-20 22:47:41', 'Programmatic Advertising Trends for Modern Brands', 'A practical look at programmatic advertising trends for modern brands, and what it actually changes for advertising technology teams.', 'advertising technology, programmatic advertising', 189, 187, '2026-06-20 22:47:41', '2026-06-22 22:47:41', NULL),
(186, 'Building a Better SEO Content Strategy', 'building-a-better-seo-content-strategy', '<p>Building a Better SEO Content Strategy is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of seo are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the digital marketing stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of seo usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes seo simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at a better seo content strategy, and what it actually changes for digital marketing teams.', 'published', 45, 44, 15, NULL, 1, 9, 0, 0, '2026-06-25 22:47:41', 'Building a Better SEO Content Strategy', 'A practical look at a better seo content strategy, and what it actually changes for digital marketing teams.', 'digital marketing, seo', 187, 188, '2026-06-25 22:47:41', '2026-06-27 22:47:41', NULL),
(187, 'Marketing Automation: From Leads to Revenue', 'marketing-automation-from-leads-to-revenue', '<p>Marketing Automation: From Leads to Revenue is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of marketing automation are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the martech stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of marketing automation usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes marketing automation simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at marketing automation: from leads to revenue, and what it actually changes for martech teams.', 'published', 48, 49, 25, NULL, 1, 12, 0, 0, '2026-07-01 22:47:41', 'Marketing Automation: From Leads to Revenue', 'A practical look at marketing automation: from leads to revenue, and what it actually changes for martech teams.', 'martech, marketing automation', 188, 189, '2026-07-01 22:47:41', '2026-07-03 22:47:41', NULL),
(188, 'How Social Commerce Is Changing Online Retail', 'how-social-commerce-is-changing-online-retail', '<p>How Social Commerce Is Changing Online Retail is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of social commerce are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the social media stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of social commerce usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes social commerce simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at social commerce is changing online retail, and what it actually changes for social media teams.', 'published', 47, 47, 22, NULL, 1, 6, 0, 0, '2026-07-07 22:47:41', 'How Social Commerce Is Changing Online Retail', 'A practical look at social commerce is changing online retail, and what it actually changes for social media teams.', 'social media, social commerce', 189, 187, '2026-07-07 22:47:41', '2026-07-09 22:47:41', NULL),
(189, 'Using Marketing Analytics to Improve Campaign Performance', 'using-marketing-analytics-to-improve-campaign-performance', '<p>Using Marketing Analytics to Improve Campaign Performance is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of marketing analytics are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the data & analytics stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of marketing analytics usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes marketing analytics simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at marketing analytics to improve campaign performance, and what it actually changes for data & analytics teams.', 'published', 48, 48, 23, NULL, 1, 10, 0, 0, '2026-07-13 22:47:41', 'Using Marketing Analytics to Improve Campaign Performance', 'A practical look at marketing analytics to improve campaign performance, and what it actually changes for data & analytics teams.', 'data & analytics, marketing analytics', 187, 188, '2026-07-13 22:47:41', '2026-07-15 22:47:41', NULL),
(190, 'The Role of Customer Data Platforms in Martech', 'role-of-customer-data-platforms-in-martech', '<p>The Role of Customer Data Platforms in Martech is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of crm are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the martech stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of crm usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes crm simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at role of customer data platforms in martech, and what it actually changes for martech teams.', 'published', 48, 49, 26, NULL, 1, 13, 0, 0, '2026-07-19 22:47:41', 'The Role of Customer Data Platforms in Martech', 'A practical look at role of customer data platforms in martech, and what it actually changes for martech teams.', 'martech, crm', 188, 189, '2026-07-19 22:47:41', '2026-07-21 22:47:41', NULL),
(191, 'AI-Powered Personalization in Digital Marketing', 'ai-powered-personalization-in-digital-marketing', '<p>AI-Powered Personalization in Digital Marketing is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of ai automation are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the artificial intelligence stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of ai automation usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes ai automation simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at ai-powered personalization in digital marketing, and what it actually changes for artificial intelligence teams.', 'published', 44, 45, 18, NULL, 1, 8, 0, 0, '2026-07-24 22:47:41', 'AI-Powered Personalization in Digital Marketing', 'A practical look at ai-powered personalization in digital marketing, and what it actually changes for artificial intelligence teams.', 'artificial intelligence, ai automation', 189, 187, '2026-07-24 22:47:41', '2026-07-26 22:47:41', NULL),
(192, 'How Brands Can Improve Their Content Distribution', 'how-brands-can-improve-content-distribution', '<p>How Brands Can Improve Their Content Distribution is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of digital marketing are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the digital marketing stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of digital marketing usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes digital marketing simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at brands can improve their content distribution, and what it actually changes for digital marketing teams.', 'published', 45, 44, NULL, NULL, 1, 5, 0, 0, '2026-07-30 22:47:41', 'How Brands Can Improve Their Content Distribution', 'A practical look at brands can improve their content distribution, and what it actually changes for digital marketing teams.', 'digital marketing', 187, 188, '2026-07-30 22:47:41', '2026-08-01 22:47:41', NULL),
(193, 'Programmatic Buying and the Evolution of Digital Advertising', 'programmatic-buying-evolution-of-digital-advertising', '<p>Programmatic Buying and the Evolution of Digital Advertising is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of ad platforms are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the advertising technology stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of ad platforms usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes ad platforms simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at programmatic buying and the evolution of digital advertising, and what it actually changes for advertising technology teams.', 'published', 46, 46, 20, NULL, 1, 14, 0, 0, '2026-08-04 22:47:41', 'Programmatic Buying and the Evolution of Digital Advertising', 'A practical look at programmatic buying and the evolution of digital advertising, and what it actually changes for advertising technology teams.', 'advertising technology, ad platforms', 188, 189, '2026-08-04 22:47:41', '2026-08-06 22:47:41', NULL),
(194, 'Social Media Listening for Better Customer Insights', 'social-media-listening-for-better-customer-insights', '<p>Social Media Listening for Better Customer Insights is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of social media marketing are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the social media stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of social media marketing usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes social media marketing simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at social media listening for better customer insights, and what it actually changes for social media teams.', 'published', 47, 47, 21, NULL, 1, 7, 0, 0, '2026-08-10 22:47:41', 'Social Media Listening for Better Customer Insights', 'A practical look at social media listening for better customer insights, and what it actually changes for social media teams.', 'social media, social media marketing', 189, 187, '2026-08-10 22:47:41', '2026-08-12 22:47:41', NULL),
(195, 'Generative AI Tools for Marketing Teams', 'generative-ai-tools-for-marketing-teams', '<p>Generative AI Tools for Marketing Teams is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of artificial intelligence are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the artificial intelligence stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of artificial intelligence usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes artificial intelligence simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at generative ai tools for marketing teams, and what it actually changes for artificial intelligence teams.', 'published', 44, 45, NULL, NULL, 1, 4, 0, 0, '2026-08-15 22:47:41', 'Generative AI Tools for Marketing Teams', 'A practical look at generative ai tools for marketing teams, and what it actually changes for artificial intelligence teams.', 'artificial intelligence', 187, 188, '2026-08-15 22:47:41', '2026-08-17 22:47:41', NULL),
(196, 'Measuring ROI Across Digital Marketing Channels', 'measuring-roi-across-digital-marketing-channels', '<p>Measuring ROI Across Digital Marketing Channels is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of marketing analytics are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the data & analytics stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of marketing analytics usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes marketing analytics simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at roi across digital marketing channels, and what it actually changes for data & analytics teams.', 'published', 48, 48, 23, NULL, 1, 11, 0, 0, '2026-08-19 22:47:41', 'Measuring ROI Across Digital Marketing Channels', 'A practical look at roi across digital marketing channels, and what it actually changes for data & analytics teams.', 'data & analytics, marketing analytics', 188, 189, '2026-08-19 22:47:41', '2026-08-21 22:47:41', NULL),
(197, 'Marketing Automation Workflows Every Team Should Consider', 'marketing-automation-workflows-every-team-should-consider', '<p>Marketing Automation Workflows Every Team Should Consider is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of marketing automation are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the martech stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of marketing automation usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes marketing automation simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at marketing automation workflows every team should consider, and what it actually changes for martech teams.', 'published', 45, 49, 25, NULL, 1, 9, 0, 0, '2026-08-24 22:47:41', 'Marketing Automation Workflows Every Team Should Consider', 'A practical look at marketing automation workflows every team should consider, and what it actually changes for martech teams.', 'martech, marketing automation', 189, 187, '2026-08-24 22:47:41', '2026-08-26 22:47:41', NULL),
(198, 'The Growing Importance of First-Party Data', 'growing-importance-of-first-party-data', '<p>The Growing Importance of First-Party Data is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of customer data are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the data & analytics stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of customer data usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes customer data simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at growing importance of first-party data, and what it actually changes for data & analytics teams.', 'published', 48, 48, 24, NULL, 1, 6, 0, 0, '2026-08-29 22:47:41', 'The Growing Importance of First-Party Data', 'A practical look at growing importance of first-party data, and what it actually changes for data & analytics teams.', 'data & analytics, customer data', 187, 188, '2026-08-29 22:47:41', '2026-08-31 22:47:41', NULL),
(199, 'SEO Strategies for Content-Heavy Websites', 'seo-strategies-for-content-heavy-websites', '<p>SEO Strategies for Content-Heavy Websites is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of seo are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the digital marketing stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of seo usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes seo simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at seo strategies for content-heavy websites, and what it actually changes for digital marketing teams.', 'draft', 45, 44, 15, NULL, 1, 10, 0, 0, NULL, 'SEO Strategies for Content-Heavy Websites', 'A practical look at seo strategies for content-heavy websites, and what it actually changes for digital marketing teams.', 'digital marketing, seo', 188, 189, '2026-09-01 22:47:41', '2026-09-03 22:47:41', NULL),
(200, 'How Martech Platforms Improve Customer Engagement', 'how-martech-platforms-improve-customer-engagement', '<p>How Martech Platforms Improve Customer Engagement is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of martech are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the martech stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of martech usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes martech simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at martech platforms improve customer engagement, and what it actually changes for martech teams.', 'draft', 48, 49, NULL, NULL, 1, 8, 0, 0, NULL, 'How Martech Platforms Improve Customer Engagement', 'A practical look at martech platforms improve customer engagement, and what it actually changes for martech teams.', 'martech', 189, 187, '2026-09-03 22:47:41', '2026-09-05 22:47:41', NULL),
(201, 'Data-Driven Decision Making for Marketing Teams', 'data-driven-decision-making-for-marketing-teams', '<p>Data-Driven Decision Making for Marketing Teams is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of social media are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the social media stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of social media usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes social media simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at data-driven decision making for marketing teams, and what it actually changes for social media teams.', 'draft', 47, 47, NULL, NULL, 1, 7, 0, 0, NULL, 'Data-Driven Decision Making for Marketing Teams', 'A practical look at data-driven decision making for marketing teams, and what it actually changes for social media teams.', 'social media', 187, 188, '2026-09-05 22:47:41', '2026-09-07 22:47:41', NULL),
(202, 'Emerging Trends in Advertising Technology', 'emerging-trends-in-advertising-technology', '<p>Emerging Trends in Advertising Technology is a question a lot of teams are working through right now. The pressure is rarely the technology itself - it is deciding which parts of advertising technology are worth the operational cost of adopting.</p><h2>Where teams usually start</h2><p>Most teams begin with the measurement problem rather than the tooling problem. Until it is clear what a campaign is supposed to move, adding another platform to the advertising technology stack tends to add reporting overhead rather than clarity.</p><ul><li>Agree what the campaign is accountable for before choosing tooling.</li><li>Instrument the handful of events that actually change a decision.</li><li>Give the work somewhere to live once the pilot finishes.</li></ul><h2>What changes in practice</h2><p>The teams that get value out of advertising technology usually treat it as a workflow change rather than a purchase. That means someone owns the output, someone reviews it, and there is an agreed way to tell whether it worked.</p><blockquote>The constraint is almost never the model or the platform. It is whether anyone downstream is set up to act on what comes out.</blockquote><h2>Where it tends to go wrong</h2><p>Two failure modes come up repeatedly: buying capability nobody has time to operate, and running a pilot with no route into the day job. Both are avoidable, and both are cheaper to avoid than to unwind.</p><p>None of this makes advertising technology simple. It does make it tractable, which is usually the more useful outcome.</p>', 'A practical look at emerging trends in advertising technology, and what it actually changes for advertising technology teams.', 'draft', 46, 46, NULL, NULL, 1, 15, 0, 0, '2026-09-09 22:49:34', 'Emerging Trends in Advertising Technology', 'A practical look at emerging trends in advertising technology, and what it actually changes for advertising technology teams.', 'advertising technology', 188, 188, '2026-09-07 22:47:41', '2026-09-09 22:50:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_role_name` (`role_name`),
  UNIQUE KEY `uq_roles_role_slug` (`role_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `role_slug`, `description`, `is_system`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin', 'Full access to every module', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(2, 'Content Management', 'content_management', 'Owns the editorial pipeline', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(3, 'SEO Manager', 'seo_manager', 'Post metadata and taxonomy', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(4, 'Content Head', 'content_head', 'Editorial approval and publishing', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(5, 'Marketing Head', 'marketing_head', 'Leads, subscribers and advertisements', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(6, 'Graphics Team', 'graphics_team', 'Media assets', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(7, 'Content Writer', 'content_writer', 'Drafts posts, cannot publish', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(8, 'SEO Team', 'seo_team', 'Post metadata and taxonomy', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(9, 'Publisher', 'publisher', 'Reviews and publishes posts', 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE IF NOT EXISTS `role_permissions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` int UNSIGNED NOT NULL,
  `permission_id` int UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_permissions_role_permission` (`role_id`,`permission_id`),
  KEY `ix_role_permissions_permission` (`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`id`, `role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(2, 1, 2, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(3, 1, 3, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(4, 1, 4, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(5, 1, 5, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(6, 1, 6, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(7, 1, 7, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(8, 1, 8, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(9, 1, 9, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(10, 1, 10, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(11, 2, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(12, 2, 2, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(13, 2, 3, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(14, 2, 6, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(15, 2, 9, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(16, 2, 10, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(17, 4, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(18, 4, 2, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(19, 4, 3, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(20, 4, 6, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(21, 4, 9, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(22, 4, 10, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(23, 3, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(24, 3, 2, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(25, 3, 6, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(26, 3, 10, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(27, 5, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(28, 5, 5, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(29, 5, 8, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(30, 5, 10, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(31, 9, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(32, 9, 2, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(33, 9, 3, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(34, 8, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(35, 8, 2, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(36, 8, 6, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(37, 7, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(38, 7, 2, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(39, 7, 10, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(40, 6, 1, '2026-09-09 20:35:50', '2026-09-09 20:35:50'),
(41, 6, 10, '2026-09-09 20:35:50', '2026-09-09 20:35:50');

-- --------------------------------------------------------

--
-- Table structure for table `sequelize_meta`
--

DROP TABLE IF EXISTS `sequelize_meta`;
CREATE TABLE IF NOT EXISTS `sequelize_meta` (
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `sequelize_meta`
--

INSERT INTO `sequelize_meta` (`name`) VALUES
('20260908000001-baseline-schema.js'),
('20260910000001-drop-legacy-schema.js'),
('20260910000002-create-users.js'),
('20260910000003-create-rbac.js'),
('20260910000004-create-authors.js'),
('20260910000005-create-categories.js'),
('20260910000006-create-media.js'),
('20260910000007-create-posts.js'),
('20260910000008-create-leads.js'),
('20260910000009-create-subscriptions.js'),
('20260910000010-seed-rbac.js'),
('20260910000011-add-soft-delete.js');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

DROP TABLE IF EXISTS `subcategories`;
CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` int UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subcategories_category_slug` (`category_id`,`slug`),
  KEY `ix_subcategories_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `name`, `slug`, `status`, `meta_title`, `meta_description`, `meta_keywords`, `created_at`, `updated_at`, `deleted_at`) VALUES
(15, 44, 'SEO', 'seo', 1, 'SEO', 'SEO coverage within Digital Marketing.', 'seo', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(16, 44, 'Content Marketing', 'content-marketing', 1, 'Content Marketing', 'Content Marketing coverage within Digital Marketing.', 'content marketing', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(17, 45, 'Generative AI', 'generative-ai', 1, 'Generative AI', 'Generative AI coverage within Artificial Intelligence.', 'generative ai', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(18, 45, 'AI Automation', 'ai-automation', 1, 'AI Automation', 'AI Automation coverage within Artificial Intelligence.', 'ai automation', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(19, 46, 'Programmatic Advertising', 'programmatic-advertising', 1, 'Programmatic Advertising', 'Programmatic Advertising coverage within Advertising Technology.', 'programmatic advertising', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(20, 46, 'Ad Platforms', 'ad-platforms', 1, 'Ad Platforms', 'Ad Platforms coverage within Advertising Technology.', 'ad platforms', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(21, 47, 'Social Media Marketing', 'social-media-marketing', 1, 'Social Media Marketing', 'Social Media Marketing coverage within Social Media.', 'social media marketing', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(22, 47, 'Social Commerce', 'social-commerce', 1, 'Social Commerce', 'Social Commerce coverage within Social Media.', 'social commerce', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(23, 48, 'Marketing Analytics', 'marketing-analytics', 1, 'Marketing Analytics', 'Marketing Analytics coverage within Data & Analytics.', 'marketing analytics', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(24, 48, 'Customer Data', 'customer-data', 1, 'Customer Data', 'Customer Data coverage within Data & Analytics.', 'customer data', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(25, 49, 'Marketing Automation', 'marketing-automation', 1, 'Marketing Automation', 'Marketing Automation coverage within Martech.', 'marketing automation', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL),
(26, 49, 'CRM', 'crm', 1, 'CRM', 'CRM coverage within Martech.', 'crm', '2026-09-09 22:47:40', '2026-09-09 22:47:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'subscribed',
  `unsubscribed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subscriptions_email` (`email`),
  KEY `ix_subscriptions_status` (`status`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `ix_users_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `full_name`, `email`, `password`, `status`, `last_login_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(187, 'admin', 'System Admin', 'admin@datademand.local', '$2b$10$jrYUGvepr0mG.xkkOMiM9ePfQpMDTBCjFYBpGq.2nYnhh.7my5uX.', 1, '2026-09-09 22:50:09', '2026-09-09 22:47:40', '2026-09-09 22:50:09', NULL),
(188, 'editor.one', 'Content Editor One', 'editor.one@datademand.local', '$2b$10$hvI6oJA/aYT2i.hwvaTLVOe2f1/Bo3g5bQ80pu0ds481ZwW91S4Qe', 1, '2026-09-09 22:50:10', '2026-09-09 22:47:40', '2026-09-09 22:50:10', NULL),
(189, 'editor.two', 'Content Editor Two', 'editor.two@datademand.local', '$2b$10$T07ybK6iuTUZfdqCgkkUVuqaSJ0v4Y7vQYbq6TD4jZXFE4o00fEZm', 1, '2026-09-09 22:50:10', '2026-09-09 22:47:40', '2026-09-09 22:50:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int UNSIGNED NOT NULL,
  `role_id` int UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_roles_user_role` (`user_id`,`role_id`),
  KEY `ix_user_roles_role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(144, 187, 1, '2026-09-09 22:47:40', '2026-09-09 22:47:40'),
(145, 188, 2, '2026-09-09 22:47:40', '2026-09-09 22:47:40'),
(146, 189, 7, '2026-09-09 22:47:40', '2026-09-09 22:47:40');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `authors`
--
ALTER TABLE `authors`
  ADD CONSTRAINT `fk_authors_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_authors_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT;

--
-- Constraints for table `lead_notes`
--
ALTER TABLE `lead_notes`
  ADD CONSTRAINT `fk_lead_notes_lead` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_lead_notes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT;

--
-- Constraints for table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `fk_media_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `fk_posts_author` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_posts_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_posts_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_posts_subcategory` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_posts_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `fk_subcategories_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `fk_user_roles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_user_roles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
