// routes/subscribe.route.js
//
// DEPRECATED. Replaced by routes/website/subscribe.routes.js (submit) and
// routes/admin/subscriptions.routes.js (read).

const express = require('express');
const subscribeController = require('../controllers/subscribe.controller');

const { authenticate } = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/permission.middleware');
const { PERMISSIONS } = require('../config/permissions');
const {
  publicWriteLimiter,
  adminLimiter,
} = require('../middleware/rateLimit.middleware');
const { sanitize } = require('../middleware/sanitize.middleware');

const router = express.Router();

// PUBLIC - website newsletter form
router.post('/', publicWriteLimiter, sanitize.publicSubscribe(), subscribeController.subscribe);

// ADMIN - previously exposed the entire subscriber list anonymously
router.post(
  '/all_subscribe',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.SUBSCRIPTIONS_READ),
  subscribeController.getAllSubscription
);

module.exports = router;
