// routes/website/categories.routes.js
//
// PUBLIC. No authentication middleware, by design.

const express = require("express");
const router = express.Router();

const categories = require("../../controllers/website/categories.controller");
const { CACHE } = require("../../middleware/httpCache.middleware");

router.get("/", CACHE.taxonomy, categories.listCategories);
router.get("/meta/:slug", CACHE.taxonomy, categories.getCategoryMeta);

module.exports = router;
