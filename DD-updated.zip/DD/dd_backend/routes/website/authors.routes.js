// routes/website/authors.routes.js
//
// PUBLIC. No authentication middleware, by design.
//
// Reads the authors table. Returns only public profile fields; no CMS
// account data of any kind is exposed here.

const express = require("express");
const router = express.Router();

const authors = require("../../controllers/website/authors.controller");
const { CACHE } = require("../../middleware/httpCache.middleware");

router.get("/", CACHE.authors, authors.listAuthors);

// Public author page.
router.get("/:slug", CACHE.authors, authors.getAuthorBySlug);

module.exports = router;
