// routes/website/subscribe.routes.js
//
// PUBLIC WRITE. No authentication middleware — this is the website newsletter
// form. Rate limiting is required here and is flagged for a later phase.
//
// Reading subscribers is an admin concern and lives in
// routes/admin/subscriptions.routes.js.

const express = require("express");
const router = express.Router();

const subscribeController = require("../../controllers/subscribe.controller");
const { sanitize } = require("../../middleware/sanitize.middleware");

// POST /api/website/subscribe
router.post("/", sanitize.publicSubscribe(), subscribeController.subscribe);

module.exports = router;
