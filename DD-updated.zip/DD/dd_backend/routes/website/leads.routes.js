// routes/website/leads.routes.js
//
// PUBLIC WRITE. No authentication middleware — this is the website contact
// form. Rate limiting is required here and is flagged for a later phase.
//
// Reading leads is an admin concern and lives in routes/admin/leads.routes.js.

const express = require("express");
const router = express.Router();

const leadsController = require("../../controllers/leads.controller");
const { sanitize } = require("../../middleware/sanitize.middleware");

// POST /api/website/leads
router.post("/", sanitize.publicLead(), leadsController.createLead);

module.exports = router;
