// routes/website/subcategories.routes.js
//
// PUBLIC. No authentication middleware, by design.

const express = require("express");
const router = express.Router();

const subcategories = require("../../controllers/website/subcategories.controller");
const { CACHE } = require("../../middleware/httpCache.middleware");

router.get("/", CACHE.taxonomy, subcategories.listSubcategories);
router.get("/by-category/:category_id", CACHE.taxonomy, subcategories.listByCategory);
router.get("/meta/:slug", CACHE.taxonomy, subcategories.getSubcategoryMeta);

module.exports = router;
