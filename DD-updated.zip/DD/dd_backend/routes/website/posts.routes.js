// routes/website/posts.routes.js
//
// PUBLIC. No authentication middleware, by design.

const express = require("express");
const router = express.Router();

const posts = require("../../controllers/website/posts.controller");
const { CACHE } = require("../../middleware/httpCache.middleware");

// GET /api/website/posts
// ?search= &page= &limit= &cat_id=1,2 &reading_time=5-10 &sort= &order= &exclude_id=
router.get("/", CACHE.postList, posts.listPosts);

// Registered before "/:slug" so "meta" is never captured as a slug.
router.get("/meta/:slug", CACHE.postDetail, posts.getPostMeta);

router.get("/:slug", CACHE.postDetail, posts.getPostBySlug);

module.exports = router;
