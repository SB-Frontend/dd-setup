// routes/website/sitemap.routes.js
//
// PUBLIC. No authentication middleware, by design.

const express = require("express");
const router = express.Router();

const posts = require("../../controllers/website/posts.controller");
const categories = require("../../controllers/website/categories.controller");
const subcategories = require("../../controllers/website/subcategories.controller");
const { CACHE } = require("../../middleware/httpCache.middleware");

router.get("/posts", CACHE.sitemap, posts.getPostSitemap);
router.get("/categories", CACHE.sitemap, categories.getCategorySitemap);
router.get("/subcategories", CACHE.sitemap, subcategories.getSubcategorySitemap);

module.exports = router;
