// routes/website/index.js
//
// Mounted at /api/website
//
// PUBLIC SURFACE. Authentication middleware must NOT be added here or to any
// router below it. These endpoints serve the Next.js website.

const express = require("express");
const router = express.Router();

const postRoutes = require("./posts.routes");
const categoryRoutes = require("./categories.routes");
const subcategoryRoutes = require("./subcategories.routes");
const authorRoutes = require("./authors.routes");
const sitemapRoutes = require("./sitemap.routes");
const leadRoutes = require("./leads.routes");
const subscribeRoutes = require("./subscribe.routes");

const {
  websiteReadLimiter,
  publicWriteLimiter,
} = require("../../middleware/rateLimit.middleware");

// Reads are deliberately generous: normal browsing must never be throttled,
// and if the Next.js site renders server-side every visitor shares one IP.
router.use("/posts", websiteReadLimiter, postRoutes);
router.use("/categories", websiteReadLimiter, categoryRoutes);
router.use("/subcategories", websiteReadLimiter, subcategoryRoutes);
router.use("/authors", websiteReadLimiter, authorRoutes);
router.use("/sitemap", websiteReadLimiter, sitemapRoutes);

// Anonymous writes that insert rows. This is the spam surface, so the
// budget is far smaller than for reads.
router.use("/leads", publicWriteLimiter, leadRoutes);
router.use("/subscribe", publicWriteLimiter, subscribeRoutes);

module.exports = router;
