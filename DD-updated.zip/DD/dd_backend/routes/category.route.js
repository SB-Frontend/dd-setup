// routes/category.route.js
//
// DEPRECATED. Replaced by routes/website/categories.routes.js (public) and
// routes/admin/categories.routes.js (CMS). Same controllers, same
// authorization, same schema.

const express = require('express');
const router = express.Router();

const categoryController = require('../controllers/category.controller');
const websiteCategories = require('../controllers/website/categories.controller');

const {
  websiteReadLimiter,
  adminLimiter,
} = require('../middleware/rateLimit.middleware');
const { sanitize } = require('../middleware/sanitize.middleware');
const { authenticate } = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/permission.middleware');
const { PERMISSIONS } = require('../config/permissions');

// PUBLIC WEBSITE
router.get('/get_all_categories', websiteReadLimiter, websiteCategories.listCategories);
router.get('/meta/:slug', websiteReadLimiter, websiteCategories.getCategoryMeta);
router.get('/sitemap', websiteReadLimiter, websiteCategories.getCategorySitemap);

// ADMIN
router.post(
  '/',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.CATEGORIES_CREATE),
  sanitize.category(),
  categoryController.createCategory
);

router.put(
  '/:id',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.CATEGORIES_UPDATE),
  sanitize.category(),
  categoryController.updateCategory
);

router.delete(
  '/:id',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.CATEGORIES_DELETE),
  categoryController.deleteCategory
);

module.exports = router;
