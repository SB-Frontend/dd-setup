// routes/post.route.js
//
// DEPRECATED. Replaced by routes/website/posts.routes.js (public) and
// routes/admin/posts.routes.js (CMS).
//
// These paths now run exactly the same controllers, authorization and schema
// as their replacements - a legacy path must never be a way around the new
// rules. Only the URLs differ.

const express = require("express");
const router = express.Router();

const postController = require("../controllers/post.controller");
const websitePosts = require("../controllers/website/posts.controller");
const upload = require("../middleware/uploadPostImage");

const {
  websiteReadLimiter,
  adminLimiter,
} = require("../middleware/rateLimit.middleware");
const { sanitize } = require("../middleware/sanitize.middleware");
const { authenticate } = require("../middleware/auth.middleware");
const { authorize } = require("../middleware/permission.middleware");
const { PERMISSIONS } = require("../config/permissions");

// ==========================================
// PUBLIC WEBSITE - no authentication, same handlers as /api/website/posts
// ==========================================
router.get("/get_post/:slug", websiteReadLimiter, websitePosts.getPostBySlug);
router.get("/meta/:slug", websiteReadLimiter, websitePosts.getPostMeta);
router.get("/sitemap", websiteReadLimiter, websitePosts.getPostSitemap);
router.post("/website/posts", websiteReadLimiter, (req, res, next) => {
  // The legacy public listing took its parameters in the body.
  req.query = { ...req.query, ...(req.body || {}) };

  return websitePosts.listPosts(req, res, next);
});

// ==========================================
// ADMIN
// ==========================================
router.post(
  "/create",
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.POSTS_CREATE),
  upload.single("banner_image"),
  sanitize.post(),
  postController.createPost
);

router.post(
  "/get_all_posts",
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.POSTS_READ),
  postController.getAllPosts
);

router.get(
  "/all_post_count",
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.POSTS_READ),
  postController.getPostCount
);

router.put(
  "/:id",
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.POSTS_UPDATE),
  upload.single("banner_image"),
  sanitize.post(),
  postController.updatePost
);

// Publishing is its own permission, here as well as on the new path.
router.patch(
  "/status/:id",
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.POSTS_PUBLISH),
  postController.updateStatus
);

module.exports = router;
