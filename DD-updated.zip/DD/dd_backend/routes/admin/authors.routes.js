// routes/admin/authors.routes.js
//
// PUBLIC CONTENT AUTHORS - admin CRUD.
//
// Authorised by author_management, NEVER user_management. Those are separate
// domains on purpose: Author Management must not let someone change a CMS
// account's email, password or roles, which would be a privilege-escalation
// path. The tables are separate, so the boundary is enforced by construction.

const express = require("express");
const router = express.Router();

const authorController = require("../../controllers/author.controller");
const uploadAuthorImage = require("../../middleware/uploadAuthorImage");

const { authenticate } = require("../../middleware/auth.middleware");
const { authorize } = require("../../middleware/permission.middleware");
const { sanitize } = require("../../middleware/sanitize.middleware");
const { PERMISSIONS } = require("../../config/permissions");

router.get(
  "/",
  authenticate,
  authorize(PERMISSIONS.AUTHORS_READ),
  authorController.listAuthors
);

router.post(
  "/list",
  authenticate,
  authorize(PERMISSIONS.AUTHORS_READ),
  authorController.listAuthors
);

router.get(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.AUTHORS_READ),
  authorController.getAuthor
);

// authenticate runs before multer so an unauthorised request never writes a
// file to disk.
router.post(
  "/",
  authenticate,
  authorize(PERMISSIONS.AUTHORS_CREATE),
  uploadAuthorImage.single("image"),
  sanitize.author(),
  authorController.createAuthor
);

router.put(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.AUTHORS_UPDATE),
  uploadAuthorImage.single("image"),
  sanitize.author(),
  authorController.updateAuthor
);

// Soft delete. Posts keep existing; only the byline is cleared.
router.delete(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.AUTHORS_DELETE),
  authorController.deleteAuthor
);

module.exports = router;
