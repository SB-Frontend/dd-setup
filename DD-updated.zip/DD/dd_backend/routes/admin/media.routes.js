// routes/admin/media.routes.js
//
// Every route here requires authentication.
// authenticate runs before multer, so unauthenticated uploads no longer
// reach the filesystem. Size limits and content validation remain a later
// phase (Phase 0 risk R12).

const express = require("express");
const router = express.Router();

const mediaController = require("../../controllers/media.controller");
const uploadMedia = require("../../middleware/uploadPostImage");
const queryAsBody = require("../../middleware/queryAsBody.middleware");

const { authenticate } = require("../../middleware/auth.middleware");
const { authorize } = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");
const { sanitize } = require("../../middleware/sanitize.middleware");

router.get(
  "/",
  authenticate,
  authorize(PERMISSIONS.MEDIA_READ),
  queryAsBody,
  mediaController.getMediaList
);

router.post(
  "/list",
  authenticate,
  authorize(PERMISSIONS.MEDIA_READ),
  mediaController.getMediaList
);

router.post(
  "/",
  authenticate,
  authorize(PERMISSIONS.MEDIA_CREATE),
  uploadMedia.single("file"),
  sanitize.media(),
  mediaController.createMedia
);

router.get(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.MEDIA_READ),
  mediaController.getMediaById
);

router.put(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.MEDIA_UPDATE),
  uploadMedia.single("file"),
  sanitize.media(),
  mediaController.updateMedia
);

router.delete(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.MEDIA_DELETE),
  mediaController.deleteMediaById
);

module.exports = router;
