// routes/admin/leads.routes.js
//
// Every route here requires authentication. Lead submission stays public in
// routes/website/leads.routes.js.
//
// KNOWN BUG (bug-fix phase): getAllLeads throws ReferenceError when "search"
// is non-empty, because Op is not imported in leads.controller.js.

const express = require("express");
const router = express.Router();

const leadsController = require("../../controllers/leads.controller");
const queryAsBody = require("../../middleware/queryAsBody.middleware");

const { authenticate } = require("../../middleware/auth.middleware");
const { authorize } = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");
const { sanitize } = require("../../middleware/sanitize.middleware");

router.get(
  "/",
  authenticate,
  authorize(PERMISSIONS.LEADS_READ),
  queryAsBody,
  leadsController.getAllLeads
);

router.post(
  "/list",
  authenticate,
  authorize(PERMISSIONS.LEADS_READ),
  leadsController.getAllLeads
);

router.put(
  "/:id/comment",
  authenticate,
  authorize(PERMISSIONS.LEADS_UPDATE),
  sanitize.leadComment(),
  leadsController.addComment
);

// GET /api/admin/leads/:id/notes
router.get(
  "/:id/notes",
  authenticate,
  authorize(PERMISSIONS.LEADS_READ),
  leadsController.getLeadNotes
);

module.exports = router;
