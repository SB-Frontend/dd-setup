// routes/admin/subcategories.routes.js
//
// Every route here requires authentication.

const express = require("express");
const router = express.Router();

const subcategoryController = require("../../controllers/subcategory.controller");

const { authenticate } = require("../../middleware/auth.middleware");
const { authorize } = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");
const { sanitize } = require("../../middleware/sanitize.middleware");

router.get(
  "/",
  authenticate,
  authorize(PERMISSIONS.SUBCATEGORIES_READ),
  subcategoryController.getAllSubcategories
);

router.get(
  "/by-category/:cat_id",
  authenticate,
  authorize(PERMISSIONS.SUBCATEGORIES_READ),
  subcategoryController.getSubcategoriesByCategory
);

router.post(
  "/",
  authenticate,
  authorize(PERMISSIONS.SUBCATEGORIES_CREATE),
  sanitize.subcategory(),
  subcategoryController.createSubcategory
);

router.put(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.SUBCATEGORIES_UPDATE),
  sanitize.subcategory(),
  subcategoryController.updateSubcategory
);

router.delete(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.SUBCATEGORIES_DELETE),
  subcategoryController.deleteSubcategory
);

module.exports = router;
