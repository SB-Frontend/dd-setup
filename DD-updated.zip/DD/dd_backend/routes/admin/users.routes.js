// routes/admin/users.routes.js
//
// Every route here requires authentication.
//
// PUT /:id uses allowSelfOr rather than a flat permission check: a user may
// edit their own record, but editing anyone else needs users.update. This is
// the fix for the pre-Phase-2 IDOR where any valid token could reset any
// other user's password.

const express = require("express");
const router = express.Router();

const userController = require("../../controllers/user.controller");
const uploadAuthorImage = require("../../middleware/uploadAuthorImage");

const { authenticate } = require("../../middleware/auth.middleware");
const {
  authorize,
  allowSelfOr,
  denySelfTarget,
} = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");
const { sanitize } = require("../../middleware/sanitize.middleware");

// GET /api/admin/users?page=&limit=&search=&status=
router.get(
  "/",
  authenticate,
  authorize(PERMISSIONS.USERS_READ),
  userController.getUsers
);

// NOTE: the author list used to live here as /users/authors, deriving
// "authors" from users.is_author. Public authors are now their own entity;
// see routes/admin/authors.routes.js.

// PUT /api/admin/users/:id
router.put(
  "/:id",
  authenticate,
  allowSelfOr(PERMISSIONS.USERS_UPDATE),
  // No image on CMS accounts - see routes/admin/authors.routes.js.
  uploadAuthorImage.none(),
  sanitize.user(),
  userController.updateUser
);

// DELETE /api/admin/users/:id   (soft delete, sets deleted_at)
// denySelfTarget stops an operator soft-deleting their own account.
router.delete(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.USERS_DELETE),
  denySelfTarget("id", "You cannot delete your own account."),
  userController.deleteUser
);

// PATCH /api/admin/users/:id/status
router.patch(
  "/:id/status",
  authenticate,
  authorize(PERMISSIONS.USERS_UPDATE),
  denySelfTarget("id", "You cannot change your own account status."),
  userController.updateStatus
);

// =====================================
// USER ROLES
//
// Guarded by role_management, not user_management: managing an account and
// deciding what that account may do are separate privileges, so a holder of
// user_management alone cannot hand out authority.
//
// denySelfTarget is what makes self-escalation impossible. Even an operator
// holding role_management cannot point these routes at their own account, so
// there is no route through which a user can raise their own permissions.
// =====================================

// GET /api/admin/users/:id/roles
router.get(
  "/:id/roles",
  authenticate,
  authorize(PERMISSIONS.USERS_READ),
  userController.getUserRoles
);

// POST /api/admin/users/:id/roles     add roles
router.post(
  "/:id/roles",
  authenticate,
  authorize(PERMISSIONS.ROLES_UPDATE),
  denySelfTarget("id", "You cannot change your own roles."),
  userController.setUserRoles
);

// PUT /api/admin/users/:id/roles      replace the whole set
router.put(
  "/:id/roles",
  authenticate,
  authorize(PERMISSIONS.ROLES_UPDATE),
  denySelfTarget("id", "You cannot change your own roles."),
  userController.setUserRoles
);

// DELETE /api/admin/users/:id/roles/:roleId
router.delete(
  "/:id/roles/:roleId",
  authenticate,
  authorize(PERMISSIONS.ROLES_UPDATE),
  denySelfTarget("id", "You cannot change your own roles."),
  userController.revokeUserRole
);

module.exports = router;
