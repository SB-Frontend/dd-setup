// routes/admin/index.js
//
// Mounted at /api/admin
//
// ADMIN / CMS SURFACE.
//
// Authentication is deliberately NOT applied at this level. Per the Phase 1
// brief, admin routes are only prepared for auth here. Permissions differ per
// route and are wired up in Phase 2, route by route, in the files below.
//
// The only auth currently active is authMiddleware on
// PUT/DELETE /api/admin/users/:id, carried over unchanged from the
// pre-Phase-1 routes so that no existing protection is lost.

const express = require("express");
const router = express.Router();

const authRoutes = require("./auth.routes");
const userRoutes = require("./users.routes");
const postRoutes = require("./posts.routes");
const categoryRoutes = require("./categories.routes");
const subcategoryRoutes = require("./subcategories.routes");
const mediaRoutes = require("./media.routes");
const leadRoutes = require("./leads.routes");
const subscriptionRoutes = require("./subscriptions.routes");
const authorRoutes = require("./authors.routes");
const roleRoutes = require("./roles.routes");

const {
  authLimiter,
  adminLimiter,
} = require("../../middleware/rateLimit.middleware");

// Login and registration are the brute-force surface and get the tight
// budget. Each attempt also costs a bcrypt comparison server-side.
router.use("/auth", authLimiter, authRoutes);

// Everything else is authenticated CMS traffic.
//
// NOTE: mounted here it runs before authenticate, so it keys on IP. The
// limiter also supports per-user keying, which activates if it is ever
// moved after authentication in the individual route files.
// Public content authors. A separate domain from /users, guarded by
// author_management rather than user_management.
router.use("/authors", adminLimiter, authorRoutes);

router.use("/users", adminLimiter, userRoutes);

// Roles and the read-only permission catalogue. Guarded by role_management.
router.use("/roles", adminLimiter, roleRoutes);
router.use("/posts", adminLimiter, postRoutes);
router.use("/categories", adminLimiter, categoryRoutes);
router.use("/subcategories", adminLimiter, subcategoryRoutes);
router.use("/media", adminLimiter, mediaRoutes);
router.use("/leads", adminLimiter, leadRoutes);
router.use("/subscriptions", adminLimiter, subscriptionRoutes);

module.exports = router;
