// routes/admin/roles.routes.js
//
// Role Management. Every route authenticates first and then requires a
// role_management-derived permission.
//
// This is the most sensitive surface in the CMS: it decides what every other
// account may do. There is no self-service path here and no route that lets a
// caller act on their own authorization.

const express = require("express");
const router = express.Router();

const roleController = require("../../controllers/role.controller");

const { authenticate } = require("../../middleware/auth.middleware");
const { authorize } = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");
const { sanitize } = require("../../middleware/sanitize.middleware");

// GET /api/admin/roles
router.get("/", authenticate, authorize(PERMISSIONS.ROLES_READ), roleController.listRoles);

// GET /api/admin/roles/permissions
// The catalogue Role Management offers as a checklist. Read only: permissions
// are seeded system definitions, never created through the API.
// Declared before /:id so "permissions" is not read as a role identifier.
router.get(
  "/permissions",
  authenticate,
  authorize(PERMISSIONS.PERMISSIONS_READ),
  roleController.listPermissions
);

// GET /api/admin/roles/:id      accepts an id or a role_slug
router.get("/:id", authenticate, authorize(PERMISSIONS.ROLES_READ), roleController.getRole);

// POST /api/admin/roles
router.post(
  "/",
  authenticate,
  authorize(PERMISSIONS.ROLES_CREATE),
  sanitize.role(),
  roleController.createRole
);

// PUT /api/admin/roles/:id      label and description only
router.put(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.ROLES_UPDATE),
  sanitize.role(),
  roleController.updateRole
);

// PUT /api/admin/roles/:id/permissions     replaces the grant set atomically
router.put(
  "/:id/permissions",
  authenticate,
  authorize(PERMISSIONS.ROLES_UPDATE),
  roleController.setRolePermissions
);

// DELETE /api/admin/roles/:id
router.delete(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.ROLES_DELETE),
  roleController.deleteRole
);

module.exports = router;
