// routes/admin/categories.routes.js
//
// Every route here requires authentication.

const express = require("express");
const router = express.Router();

const categoryController = require("../../controllers/category.controller");

const { authenticate } = require("../../middleware/auth.middleware");
const { authorize } = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");
const { sanitize } = require("../../middleware/sanitize.middleware");

router.get(
  "/",
  authenticate,
  authorize(PERMISSIONS.CATEGORIES_READ),
  categoryController.getAllCategories
);

router.post(
  "/",
  authenticate,
  authorize(PERMISSIONS.CATEGORIES_CREATE),
  sanitize.category(),
  categoryController.createCategory
);

router.put(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.CATEGORIES_UPDATE),
  sanitize.category(),
  categoryController.updateCategory
);

// Soft delete. The controller refuses when posts still reference the
// category, because a soft delete is an UPDATE and does not trip the
// RESTRICT foreign key.
router.delete(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.CATEGORIES_DELETE),
  categoryController.deleteCategory
);

module.exports = router;
