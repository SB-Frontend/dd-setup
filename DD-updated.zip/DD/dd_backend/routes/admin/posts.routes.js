// routes/admin/posts.routes.js
//
// Every route here requires authentication.
// authenticate runs before multer so an unauthenticated or unauthorised
// request never writes an uploaded banner to disk.

const express = require("express");
const router = express.Router();

const postController = require("../../controllers/post.controller");
const upload = require("../../middleware/uploadPostImage");
const queryAsBody = require("../../middleware/queryAsBody.middleware");

const { authenticate } = require("../../middleware/auth.middleware");
const { authorize } = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");
const { sanitize } = require("../../middleware/sanitize.middleware");

// GET /api/admin/posts/count
router.get(
  "/count",
  authenticate,
  authorize(PERMISSIONS.POSTS_READ),
  postController.getPostCount
);

// LIST ALL POSTS (drafts included). DataTables response shape.
router.get(
  "/",
  authenticate,
  authorize(PERMISSIONS.POSTS_READ),
  queryAsBody,
  postController.getAllPosts
);

router.post(
  "/list",
  authenticate,
  authorize(PERMISSIONS.POSTS_READ),
  postController.getAllPosts
);

// POST /api/admin/posts
// created_by and updated_by are taken from req.user by the controller and are
// never accepted from the request body.
router.post(
  "/",
  authenticate,
  authorize(PERMISSIONS.POSTS_CREATE),
  upload.single("banner_img"),
  sanitize.post(),
  postController.createPost
);

// PUT /api/admin/posts/:id
router.put(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.POSTS_UPDATE),
  upload.single("banner_img"),
  sanitize.post(),
  postController.updatePost
);

// PATCH /api/admin/posts/:id/status
// Publishing is a separate permission from editing.
router.patch(
  "/:id/status",
  authenticate,
  authorize(PERMISSIONS.POSTS_PUBLISH),
  postController.updateStatus
);

// DELETE /api/admin/posts/:id  (soft delete)
router.delete(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.POSTS_DELETE),
  postController.deletePost
);

module.exports = router;
