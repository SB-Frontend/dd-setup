// routes/admin/subscriptions.routes.js
//
// Every route here requires authentication. Subscribing stays public in
// routes/website/subscribe.routes.js.
//
// KNOWN BUG (bug-fix phase): getAllSubscription throws ReferenceError when
// "search" is non-empty, because Op is not imported in
// subscribe.controller.js.

const express = require("express");
const router = express.Router();

const subscribeController = require("../../controllers/subscribe.controller");
const queryAsBody = require("../../middleware/queryAsBody.middleware");

const { authenticate } = require("../../middleware/auth.middleware");
const { authorize } = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");

router.get(
  "/",
  authenticate,
  authorize(PERMISSIONS.SUBSCRIPTIONS_READ),
  queryAsBody,
  subscribeController.getAllSubscription
);

router.post(
  "/list",
  authenticate,
  authorize(PERMISSIONS.SUBSCRIPTIONS_READ),
  subscribeController.getAllSubscription
);

module.exports = router;
