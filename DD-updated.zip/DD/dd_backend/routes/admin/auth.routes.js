// routes/admin/auth.routes.js
//
// CMS authentication.

const express = require("express");
const router = express.Router();

const userController = require("../../controllers/user.controller");
const uploadAuthorImage = require("../../middleware/uploadAuthorImage");

const { authenticate } = require("../../middleware/auth.middleware");
const {
  authorize,
  allowFirstUserOr,
} = require("../../middleware/permission.middleware");
const { PERMISSIONS } = require("../../config/permissions");
const { sanitize } = require("../../middleware/sanitize.middleware");

// POST /api/admin/auth/login
// PUBLIC BY NECESSITY. Rate limiting is a later phase.
router.post("/login", userController.login);

// POST /api/admin/auth/register
// Creating CMS users is an administrative action, not self-service signup.
// allowFirstUserOr permits exactly one unauthenticated registration while the
// users table is empty, so a fresh install can be bootstrapped, then closes.
// authenticate runs before multer so an unauthenticated request never writes
// an uploaded file to disk.
router.post(
  "/register",
  allowFirstUserOr(authenticate, authorize(PERMISSIONS.USERS_CREATE)),
  // CMS accounts have no image. Public author photos live on authors.image.
  // multer still parses the body so multipart form posts keep working.
  uploadAuthorImage.none(),
  sanitize.user(),
  userController.createUser
);

module.exports = router;
