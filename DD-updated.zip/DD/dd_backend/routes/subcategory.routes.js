// routes/subcategory.routes.js
//
// DEPRECATED. Replaced by routes/website/subcategories.routes.js (public) and
// routes/admin/subcategories.routes.js (CMS).

const express = require('express');
const router = express.Router();

const subcategoryController = require('../controllers/subcategory.controller');
const websiteSubcategories = require('../controllers/website/subcategories.controller');

const {
  websiteReadLimiter,
  adminLimiter,
} = require('../middleware/rateLimit.middleware');
const { sanitize } = require('../middleware/sanitize.middleware');
const { authenticate } = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/permission.middleware');
const { PERMISSIONS } = require('../config/permissions');

// PUBLIC WEBSITE
router.get('/get_all_subcategories', websiteReadLimiter, websiteSubcategories.listSubcategories);
router.get('/by-category/:category_id', websiteReadLimiter, websiteSubcategories.listByCategory);
router.get('/meta/:slug', websiteReadLimiter, websiteSubcategories.getSubcategoryMeta);
router.get('/sitemap', websiteReadLimiter, websiteSubcategories.getSubcategorySitemap);

// ADMIN
router.post(
  '/',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.SUBCATEGORIES_CREATE),
  sanitize.subcategory(),
  subcategoryController.createSubcategory
);

router.put(
  '/:id',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.SUBCATEGORIES_UPDATE),
  sanitize.subcategory(),
  subcategoryController.updateSubcategory
);

router.delete(
  '/:id',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.SUBCATEGORIES_DELETE),
  subcategoryController.deleteSubcategory
);

module.exports = router;
