// routes/routesHandler.routes.js
//
// Mounted at /api by server.js
//
// Phase 1 introduced two explicitly separated API surfaces:
//
//   /api/website/*   PUBLIC. Consumed by the Next.js site.
//                    Authentication middleware must never be added here.
//
//   /api/admin/*     ADMIN / CMS. Prepared for authentication and per-route
//                    permissions, which are wired up in Phase 2.
//
// The original flat routes below are kept temporarily so nothing breaks while
// the website and CMS frontends migrate. They are DEPRECATED and will be
// removed once both clients have moved over.

const express = require("express");
const router = express.Router();

const deprecated = require("../middleware/deprecation.middleware");

// ==========================================
// PHASE 1 SURFACES
// ==========================================

const websiteRoutes = require("./website");
const adminRoutes = require("./admin");

router.use("/website", websiteRoutes);
router.use("/admin", adminRoutes);

// ==========================================
// DEPRECATED  (pre-Phase-1 flat routes)
//
// Behaviour is unchanged. Only advisory response headers are added:
//   Deprecation: true
//   X-API-Deprecated: true
//   X-API-Replaced-By: <new path>
//
// Remove this whole block once the website and CMS use the namespaced routes.
// ==========================================

const leadsRoutes = require("./leads.route");
const subscribeRoutes = require("./subscribe.route");
const userRoutes = require("./user.routes");
const postRoutes = require("./post.route");
const categoryRoutes = require("./category.route");
const subcategoryRoutes = require("./subcategory.routes");
const mediaRoutes = require("./media.route");

router.use(
  "/leads",
  deprecated("/api/website/leads (submit) or /api/admin/leads (read)"),
  leadsRoutes
);

router.use(
  "/subscribe",
  deprecated(
    "/api/website/subscribe (submit) or /api/admin/subscriptions (read)"
  ),
  subscribeRoutes
);

router.use(
  "/auth",
  deprecated("/api/admin/auth and /api/admin/users"),
  userRoutes
);

router.use(
  "/posts",
  deprecated("/api/website/posts (public) or /api/admin/posts (CMS)"),
  postRoutes
);

router.use(
  "/category",
  deprecated("/api/website/categories (public) or /api/admin/categories (CMS)"),
  categoryRoutes
);

router.use(
  "/subcategory",
  deprecated(
    "/api/website/subcategories (public) or /api/admin/subcategories (CMS)"
  ),
  subcategoryRoutes
);

router.use("/media", deprecated("/api/admin/media"), mediaRoutes);

module.exports = router;
