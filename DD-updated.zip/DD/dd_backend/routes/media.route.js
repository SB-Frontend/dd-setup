// routes/media.route.js
//
// DEPRECATED. Replaced by routes/admin/media.routes.js.
// Every route here is an admin operation, so all are protected.

const express = require("express");
const router = express.Router();

const mediaController = require("../controllers/media.controller");
const uploadMedia = require("../middleware/uploadPostImage");

const { authenticate } = require("../middleware/auth.middleware");
const { authorize } = require("../middleware/permission.middleware");
const { PERMISSIONS } = require("../config/permissions");
const { adminLimiter } = require("../middleware/rateLimit.middleware");
const { sanitize } = require("../middleware/sanitize.middleware");

// Every route in this deprecated file is an admin operation.
router.use(adminLimiter);

router.post(
  "/",
  authenticate,
  authorize(PERMISSIONS.MEDIA_CREATE),
  uploadMedia.single("file"),
  sanitize.media(),
  mediaController.createMedia
);

router.post(
  "/getlist",
  authenticate,
  authorize(PERMISSIONS.MEDIA_READ),
  mediaController.getMediaList
);

router.get(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.MEDIA_READ),
  mediaController.getMediaById
);

router.put(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.MEDIA_UPDATE),
  uploadMedia.single("file"),
  sanitize.media(),
  mediaController.updateMedia
);

router.delete(
  "/:id",
  authenticate,
  authorize(PERMISSIONS.MEDIA_DELETE),
  mediaController.deleteMediaById
);

module.exports = router;
