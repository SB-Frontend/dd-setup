// routes/leads.route.js
//
// DEPRECATED. Replaced by routes/website/leads.routes.js (submit) and
// routes/admin/leads.routes.js (read).
//
// Phase 2: admin operations here are protected. Without this, every
// protection added to /api/admin/* would be bypassable through these paths.
// Public submission stays open.

const express = require('express');
const leadsController = require('../controllers/leads.controller');

const { authenticate } = require('../middleware/auth.middleware');
const { authorize } = require('../middleware/permission.middleware');
const { PERMISSIONS } = require('../config/permissions');
const {
  publicWriteLimiter,
  adminLimiter,
} = require('../middleware/rateLimit.middleware');
const { sanitize } = require('../middleware/sanitize.middleware');

const router = express.Router();

// PUBLIC - website contact form
router.post('/', publicWriteLimiter, sanitize.publicLead(), leadsController.createLead);

// ADMIN
router.post(
  '/all_leads',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.LEADS_READ),
  leadsController.getAllLeads
);

router.put(
  '/add-comment/:id',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.LEADS_UPDATE),
  sanitize.leadComment(),
  leadsController.addComment
);

module.exports = router;
