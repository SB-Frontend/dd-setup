// routes/user.routes.js
//
// DEPRECATED. Replaced by routes/admin/auth.routes.js,
// routes/admin/users.routes.js and routes/website/authors.routes.js.

const express = require('express');
const router = express.Router();

const userController = require('../controllers/user.controller');
const websiteAuthors = require('../controllers/website/authors.controller');
const upload = require('../middleware/uploadAuthorImage');

const {
  authLimiter,
  adminLimiter,
  websiteReadLimiter,
} = require('../middleware/rateLimit.middleware');
const { sanitize } = require('../middleware/sanitize.middleware');
const { authenticate } = require('../middleware/auth.middleware');
const {
  authorize,
  allowSelfOr,
  denySelfTarget,
  allowFirstUserOr,
} = require('../middleware/permission.middleware');
const { PERMISSIONS } = require('../config/permissions');

// PUBLIC
router.post('/login', authLimiter, userController.login);

// PUBLIC. Now served from the authors table, not from users.is_author.
router.get('/author-list', websiteReadLimiter, websiteAuthors.listAuthors);

// ADMIN
router.post(
  '/register',
  authLimiter,
  allowFirstUserOr(authenticate, authorize(PERMISSIONS.USERS_CREATE)),
  upload.none(),
  sanitize.user(),
  userController.createUser
);

router.get(
  '/users',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.USERS_READ),
  userController.getUsers
);

router.put(
  '/users/:id',
  adminLimiter,
  authenticate,
  allowSelfOr(PERMISSIONS.USERS_UPDATE),
  upload.none(),
  sanitize.user(),
  userController.updateUser
);

router.put(
  '/update-status/:id',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.USERS_UPDATE),
  denySelfTarget('id', 'You cannot change your own account status.'),
  userController.updateStatus
);

router.delete(
  '/users/:id',
  adminLimiter,
  authenticate,
  authorize(PERMISSIONS.USERS_DELETE),
  denySelfTarget('id', 'You cannot delete your own account.'),
  userController.deleteUser
);

module.exports = router;
