require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const sequelize = require('./models');
const routesHandler = require('./routes/routesHandler.routes.js');
const {
  notFoundHandler,
  errorHandler,
} = require('./middleware/error.middleware');
const { cleanupFailedUploads } = require('./middleware/upload.middleware');
const { UPLOAD_ROOT } = require('./config/uploads');
const {
  corsOptions,
  helmetOptions,
  trustProxySetting,
  warnOnMisconfiguration,
} = require('./config/security');
const { assertSecretUsable } = require('./utils/jwt');

const app = express();
const PORT = process.env.PORT || 3000;

// Fail fast on a missing or weak signing key in production. Only the length
// is ever reported, never the value.
assertSecretUsable();
warnOnMisconfiguration();

// Rate limiting keys on the client IP. Behind a proxy Express needs to know
// how many hops to trust, otherwise every request looks like it came from the
// proxy. Off unless TRUST_PROXY is set: trusting a proxy that is not in front
// of the app would let clients spoof their own IP via X-Forwarded-For.
app.set('trust proxy', trustProxySetting());

// Advertising the framework and version helps nobody but an attacker.
app.disable('x-powered-by');

// Security headers. Must come before the routes so every response carries
// them, including error responses.
app.use(helmet(helmetOptions()));

// Origins come from CORS_ORIGINS. Nothing is hardcoded, and credentials are
// only ever paired with an explicit allowlist match, never a wildcard.
app.use(cors(corsOptions));

app.use(express.json());

// Removes an uploaded file when the request it belonged to ends 4xx/5xx.
// Must run before the routes so the hook is registered before multer writes.
app.use(cleanupFailedUploads);

// Uploaded images. PUBLIC AND READ-ONLY, and required: the Next.js site
// renders post banners and author photos, and controllers persist only the
// bare filename, so the client resolves /uploads/posts/<filename>.
//
// Nothing else in uploads/ is reachable, because only GET/HEAD are served,
// directory listings are off, dotfiles are refused, and the upload policy
// permits only jpg/png/webp - never SVG, which would execute script on this
// origin. nosniff stops a browser reinterpreting a file as HTML.
app.use(
  '/uploads',
  express.static(UPLOAD_ROOT, {
    index: false,
    dotfiles: 'deny',
    etag: true,
    maxAge: '30d',
    setHeaders(res) {
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
      res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    },
  })
);

app.use('/api', routesHandler);

// Error handling. Order matters and both must stay last: notFoundHandler
// converts an unmatched route into a 404 ApiError, and errorHandler is the
// single place any error becomes a response.
//
// These replace Express's built-in finalhandler, which returned an HTML page
// containing the stack trace whenever NODE_ENV was unset.
app.use(notFoundHandler);
app.use(errorHandler);

sequelize.authenticate()
  .then(() => {
    console.log(' MySQL connected via Sequelize');
    // Schema is owned by migrations (see migrations/ and db/schema-baseline.sql).
    // sequelize.sync() was removed here in Phase 6: on an empty database it
    // created post_view and category_subcategory_view as real BASE TABLES,
    // permanently shadowing the two views the public website reads through.
    // Run `npm run db:migrate` to apply schema changes.
    app.listen(PORT, () => console.log(` Server running on http://localhost:${PORT}`));
  })
  .catch(err => console.error(' DB connection error:', err));
