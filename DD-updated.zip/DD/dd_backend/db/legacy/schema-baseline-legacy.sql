-- db/schema-baseline.sql
--
-- Canonical baseline schema for the `datademand` database.
--
-- PROVENANCE: derived from datademand-database.sql (phpMyAdmin 5.2.1 dump,
-- generated 2026-09-03 from 127.0.0.1:3306, MySQL 8.3.0).
--
-- STATUS: PROVISIONAL. This must be regenerated from PRODUCTION with
--   mysqldump --no-data --routines --triggers
-- and re-reviewed before migration 001 is marked as applied in production.
--
-- This file captures the schema AS IT IS, including known defects, because a
-- baseline must describe reality. The defects are corrected by later
-- migrations so that fresh and existing databases converge on the same state.
-- Known defects preserved here on purpose:
--   * users carries 60 duplicate UNIQUE indexes on user_email (migration 002)
--   * leads, media_list, post_data, p_cat, users are MyISAM: no transactions,
--     no foreign keys (migration 003)
--   * p_cat.cat_id BIGINT vs post_data.cat_id INT UNSIGNED vs p_sub_cat.p_cat
--     INT - three types for one logical key (migration 004)
--   * post_data.post_Created uses a capital C

SET NAMES utf8mb4;

-- ============================================================
-- TABLES
-- ============================================================

-- ---------- leads ----------
CREATE TABLE IF NOT EXISTS `leads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `comments` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- media_list ----------
CREATE TABLE IF NOT EXISTS `media_list` (
  `media_id` int NOT NULL AUTO_INCREMENT,
  `media_title` varchar(255) NOT NULL,
  `media_path` text NOT NULL,
  `user_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`media_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- post_data ----------
CREATE TABLE IF NOT EXISTS `post_data` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_slug` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_date` datetime NOT NULL,
  `reading_time` int DEFAULT NULL,
  `post_author` int UNSIGNED DEFAULT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_modified` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `banner_show` int DEFAULT '1',
  `auto_publish` int NOT NULL DEFAULT '0',
  `cat_id` int UNSIGNED DEFAULT NULL,
  `meta_keywords` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `banner_img` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `meta_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `meta_description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `post_Created` datetime DEFAULT CURRENT_TIMESTAMP,
  `session_user` int NOT NULL,
  `comments` text NOT NULL,
  `post_updated_date` datetime DEFAULT NULL,
  `post_priority` int DEFAULT NULL,
  `comment_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_name` (`post_slug`),
  KEY `post_author` (`post_author`,`post_date`),
  KEY `post_status` (`post_status`,`cat_id`),
  KEY `post_Created` (`post_Created`,`session_user`),
  KEY `post_modified` (`post_modified`)
) ENGINE=MyISAM AUTO_INCREMENT=83034 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- p_cat ----------
CREATE TABLE IF NOT EXISTS `p_cat` (
  `cat_id` bigint NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cat_slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `meta_title` varchar(250) NOT NULL,
  `meta_desc` varchar(250) NOT NULL,
  `meta_keywords` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `cat_id` (`cat_id`,`cat_slug`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- p_sub_cat ----------
CREATE TABLE IF NOT EXISTS `p_sub_cat` (
  `subcat_id` int NOT NULL AUTO_INCREMENT,
  `subcat_name` varchar(50) NOT NULL,
  `subcat_slug` varchar(50) NOT NULL,
  `p_cat` int NOT NULL,
  `meta_title` varchar(250) NOT NULL,
  `meta_desc` varchar(250) NOT NULL,
  `meta_keywords` varchar(250) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`subcat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- roles ----------
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  `rolename` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_role` (`role`),
  KEY `roles_rolename` (`rolename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- subscriptions ----------
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- users ----------
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(110) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `author_photo` text,
  `author_description` text,
  `user_status` int NOT NULL DEFAULT '1',
  `is_author` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_email` (`user_email`),
  UNIQUE KEY `user_email_5` (`user_email`),
  UNIQUE KEY `user_email_6` (`user_email`),
  UNIQUE KEY `user_email_7` (`user_email`),
  UNIQUE KEY `user_email_8` (`user_email`),
  UNIQUE KEY `user_email_9` (`user_email`),
  UNIQUE KEY `user_email_10` (`user_email`),
  UNIQUE KEY `user_email_11` (`user_email`),
  UNIQUE KEY `user_email_12` (`user_email`),
  UNIQUE KEY `user_email_13` (`user_email`),
  UNIQUE KEY `user_email_14` (`user_email`),
  UNIQUE KEY `user_email_15` (`user_email`),
  UNIQUE KEY `user_email_16` (`user_email`),
  UNIQUE KEY `user_email_17` (`user_email`),
  UNIQUE KEY `user_email_18` (`user_email`),
  UNIQUE KEY `user_email_19` (`user_email`),
  UNIQUE KEY `user_email_20` (`user_email`),
  UNIQUE KEY `user_email_21` (`user_email`),
  UNIQUE KEY `user_email_22` (`user_email`),
  UNIQUE KEY `user_email_23` (`user_email`),
  UNIQUE KEY `user_email_24` (`user_email`),
  UNIQUE KEY `user_email_25` (`user_email`),
  UNIQUE KEY `user_email_26` (`user_email`),
  UNIQUE KEY `user_email_27` (`user_email`),
  UNIQUE KEY `user_email_28` (`user_email`),
  UNIQUE KEY `user_email_29` (`user_email`),
  UNIQUE KEY `user_email_30` (`user_email`),
  UNIQUE KEY `user_email_31` (`user_email`),
  UNIQUE KEY `user_email_32` (`user_email`),
  UNIQUE KEY `user_email_33` (`user_email`),
  UNIQUE KEY `user_email_34` (`user_email`),
  UNIQUE KEY `user_email_35` (`user_email`),
  UNIQUE KEY `user_email_36` (`user_email`),
  UNIQUE KEY `user_email_37` (`user_email`),
  UNIQUE KEY `user_email_38` (`user_email`),
  UNIQUE KEY `user_email_39` (`user_email`),
  UNIQUE KEY `user_email_40` (`user_email`),
  UNIQUE KEY `user_email_41` (`user_email`),
  UNIQUE KEY `user_email_42` (`user_email`),
  UNIQUE KEY `user_email_43` (`user_email`),
  UNIQUE KEY `user_email_44` (`user_email`),
  UNIQUE KEY `user_email_45` (`user_email`),
  UNIQUE KEY `user_email_46` (`user_email`),
  UNIQUE KEY `user_email_47` (`user_email`),
  UNIQUE KEY `user_email_48` (`user_email`),
  UNIQUE KEY `user_email_49` (`user_email`),
  UNIQUE KEY `user_email_50` (`user_email`),
  UNIQUE KEY `user_email_51` (`user_email`),
  UNIQUE KEY `user_email_52` (`user_email`),
  UNIQUE KEY `user_email_53` (`user_email`),
  UNIQUE KEY `user_email_54` (`user_email`),
  UNIQUE KEY `user_email_55` (`user_email`),
  UNIQUE KEY `user_email_56` (`user_email`),
  UNIQUE KEY `user_email_57` (`user_email`),
  UNIQUE KEY `user_email_58` (`user_email`),
  UNIQUE KEY `user_email_59` (`user_email`),
  UNIQUE KEY `user_email_60` (`user_email`),
  UNIQUE KEY `user_email_61` (`user_email`),
  UNIQUE KEY `user_email_62` (`user_email`),
  UNIQUE KEY `uq_user_email` (`user_email`),
  UNIQUE KEY `user_email_2` (`user_email`),
  UNIQUE KEY `user_email_3` (`user_email`),
  KEY `users_user_status_created_at_is_author` (`user_status`,`created_at`,`is_author`)
) ENGINE=MyISAM AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------- user_roles ----------
CREATE TABLE IF NOT EXISTS `user_roles` (
  `role_id` int NOT NULL,
  `user_id` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ============================================================
-- VIEWS
--
-- These exist ONLY inside the MySQL server today; they were in no
-- repository before this file. Every public website endpoint reads through
-- them, so losing them means losing the public site.
--
-- Two deliberate changes from the dump, both for portability:
--   * DEFINER=`root`@`localhost` removed - a restore onto any server without
--     that exact account fails outright.
--   * SQL SECURITY DEFINER -> INVOKER - the view then runs with the calling
--     application user's privileges instead of root's. The app user already
--     has SELECT on every underlying table, so behaviour is unchanged, but
--     the view no longer silently escalates privileges.
-- Flagged for your approval before this is applied anywhere.
-- ============================================================

-- ---------- category_subcategory_view ----------
CREATE OR REPLACE ALGORITHM=UNDEFINED SQL SECURITY INVOKER VIEW `category_subcategory_view` AS
SELECT `c`.`cat_id` AS `cat_id`, `c`.`cat_name` AS `cat_name`, `c`.`cat_slug` AS `cat_slug`, `s`.`subcat_id` AS `subcat_id`, `s`.`subcat_name` AS `subcat_name`, `s`.`subcat_slug` AS `subcat_slug` FROM (`p_cat` `c` left join `p_sub_cat` `s` on((`c`.`cat_id` = `s`.`p_cat`)));

-- ---------- post_view ----------
CREATE OR REPLACE ALGORITHM=UNDEFINED SQL SECURITY INVOKER VIEW `post_view` AS
SELECT `p`.`id` AS `id`, `p`.`post_title` AS `post_title`, `p`.`post_content` AS `post_content`, `p`.`reading_time` AS `reading_time`, `p`.`post_slug` AS `post_slug`, `p`.`post_author` AS `post_author`, `au`.`user_id` AS `author_id`, `au`.`user_name` AS `author_name`, `au`.`display_name` AS `author_display_name`, `au`.`author_photo` AS `author_photo`, `au`.`author_description` AS `author_description`, `p`.`post_status` AS `post_status`, `p`.`banner_img` AS `banner_img`, `p`.`banner_show` AS `banner_show`, `p`.`post_date` AS `post_date`, `p`.`auto_publish` AS `auto_publish`, `p`.`cat_id` AS `cat_id`, `c`.`cat_name` AS `cat_name`, `c`.`cat_slug` AS `cat_slug`, `p`.`meta_title` AS `meta_title`, `p`.`meta_description` AS `meta_description`, `p`.`meta_keywords` AS `meta_keywords`, `p`.`post_Created` AS `post_created`, `p`.`post_modified` AS `post_modified`, `p`.`session_user` AS `session_user`, `su`.`user_name` AS `session_user_name`, `p`.`comments` AS `comments`, `p`.`comment_by` AS `comment_by`, `cu`.`user_name` AS `comment_by_name`, `p`.`post_updated_date` AS `post_updated_date`, `p`.`post_priority` AS `post_priority` FROM ((((`post_data` `p` left join `p_cat` `c` on((`p`.`cat_id` = `c`.`cat_id`))) left join `users` `au` on((`p`.`post_author` = `au`.`user_id`))) left join `users` `cu` on((`p`.`comment_by` = `cu`.`user_id`))) left join `users` `su` on((`p`.`session_user` = `su`.`user_id`)));
