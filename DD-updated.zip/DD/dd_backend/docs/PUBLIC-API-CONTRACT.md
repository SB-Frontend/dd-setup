# Public Website API Contract

For the Next.js frontend developer. Covers `/api/website/*` and the legacy
public aliases only — admin APIs are not documented here.

Established in Phase D5, re-verified against live responses in D7. The frontend
is not in this repository, so this document is the contract.

**In one paragraph:** every endpoint below is anonymous — never send an
`Authorization` header, and never expect one to be required. Only published
posts are ever returned, on every endpoint including search and the sitemap, so
the site does not filter. Bylines come from the `authors` table and carry
exactly six fields; no CMS account data exists on this surface at all. Every
response is `{ success, data }`, with a sibling `meta` on paginated lists.

Related: [ADMIN-API.md](ADMIN-API.md) ·
[AUTH-AND-RBAC.md](AUTH-AND-RBAC.md) ·
[ARCHITECTURE-DECISIONS.md](ARCHITECTURE-DECISIONS.md)

---

## Ground rules

**No authentication.** Nothing under `/api/website/*` requires a JWT, an admin
token, CMS credentials, a user id, a role or a permission. Sending an
`Authorization` header is harmless and ignored — an expired or garbage token
does not break a public read.

**Publication is enforced server-side.** Only `status = "published"` posts are
ever returned, on every endpoint including search, filters and the sitemap. The
frontend does not need to filter, and cannot widen the set with any query
parameter. Requesting a draft by slug returns `404`, not an empty body.

**Authors come from `authors`, never from `users`.** A public author has no CMS
account, no role and no permissions. `password`, `username`, `email`, `roles`,
`permissions`, `created_by`, `updated_by`, `deleted_at`, `last_login_at` and
`user_id` never appear anywhere on this surface.

**Envelope.** Every endpoint returns the same shape:

```json
{ "success": true, "data": ... }
```

Collections that paginate add a sibling `meta` object. Errors return
`{ "success": false, "error": "...", "message": "..." }`.

**Rate limiting.** Reads share a generous budget (`websiteReadLimiter`) sized
for server-side rendering, where every visitor may share one IP. Anonymous
writes (`/leads`, `/subscribe`) have a much smaller budget.

**Caching.** Responses carry `Cache-Control: public, max-age=…,
stale-while-revalidate=…` and `Vary: Accept-Encoding`. Caches key on the full
URL, so different filters, pages and slugs never share an entry. Values:
listings 60s, detail 300s, taxonomy and authors 600s, sitemap 3600s.
Server-side, the taxonomy is held in a 60s in-process cache
(`CATEGORY_CACHE_TTL_MS`) that the CMS clears immediately on any category or
subcategory write.

---

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/website/posts` | Paginated published post listing |
| GET | `/api/website/posts/:slug` | One published post + related |
| GET | `/api/website/posts/meta/:slug` | SEO metadata only |
| GET | `/api/website/authors` | Active public authors |
| GET | `/api/website/authors/:slug` | One public author |
| GET | `/api/website/categories` | Active categories |
| GET | `/api/website/categories/meta/:slug` | Category SEO metadata |
| GET | `/api/website/subcategories` | Active subcategories |
| GET | `/api/website/subcategories/by-category/:category_id` | Subcategories of one category |
| GET | `/api/website/subcategories/meta/:slug` | Subcategory SEO metadata |
| GET | `/api/website/sitemap/posts` | Every published post, for `sitemap.xml` |
| GET | `/api/website/sitemap/categories` | Category slugs |
| GET | `/api/website/sitemap/subcategories` | Category/subcategory slug pairs |
| POST | `/api/website/leads` | Contact form |
| POST | `/api/website/subscribe` | Newsletter signup |

### Legacy aliases

Still served, same controllers, same behaviour. Prefer the `/api/website/*`
paths in new code.

| Legacy | Equivalent |
|---|---|
| `GET /api/posts/get_post/:slug` | `/api/website/posts/:slug` |
| `GET /api/posts/meta/:slug` | `/api/website/posts/meta/:slug` |
| `GET /api/posts/sitemap` | `/api/website/sitemap/posts` |
| `POST /api/posts/website/posts` | `/api/website/posts` (body instead of query) |
| `GET /api/category/get_all_categories` | `/api/website/categories` |
| `GET /api/category/meta/:slug` | `/api/website/categories/meta/:slug` |
| `GET /api/category/sitemap` | `/api/website/sitemap/categories` |
| `GET /api/subcategory/get_all_subcategories` | `/api/website/subcategories` |
| `GET /api/subcategory/by-category/:category_id` | `/api/website/subcategories/by-category/:id` |
| `GET /api/subcategory/sitemap` | `/api/website/sitemap/subcategories` |
| `GET /api/auth/author-list` | `/api/website/authors` |

---

## `GET /api/website/posts`

### Query parameters

| Param | Type | Default | Notes |
|---|---|---|---|
| `page` | integer ≥ 1 | `1` | Garbage or negative falls back to 1 |
| `limit` | integer 1–50 | `10` | **Hard cap 50.** Higher is clamped, not rejected |
| `search` | string | — | Matches the **title** only. Cannot reach drafts |
| `category_id` | int or CSV | — | `?category_id=1,2`. `cat_id` is accepted as an alias |
| `subcategory_id` | int or CSV | — | |
| `exclude_id` | int or CSV | — | Removes posts from both the rows and the count |
| `reading_time` | enum | — | `under-5`, `5-10`, `10-plus`. Anything else is ignored |
| `sort` | enum | `published_at` | `published_at`, `created_at`, `updated_at`, `reading_time`, `title` |
| `order` | enum | `DESC` | `ASC` or `DESC` |

Unknown parameters are ignored. An unknown `sort` or `order` falls back to the
default rather than erroring — nothing a client sends reaches `ORDER BY`.
Invalid pagination never reaches SQL as `NaN`.

`meta.total` always describes the same filtered set as `data`.

### Response

```json
{
  "success": true,
  "data": [
    {
      "id": 42,
      "title": "Post title",
      "slug": "post-title",
      "banner_image": "banner.webp",
      "excerpt": "Short summary",
      "meta_description": "…",
      "published_at": "2026-01-10T00:00:00.000Z",
      "updated_at": "2026-02-02T09:15:00.000Z",
      "reading_time": 7,
      "category_id": 3,
      "subcategory_id": 4,

      "category_name": "Technology",
      "category_slug": "technology",
      "subcategory_name": "Artificial Intelligence",
      "subcategory_slug": "artificial-intelligence",

      "category":    { "id": 3, "name": "Technology", "slug": "technology" },
      "subcategory": { "id": 4, "name": "Artificial Intelligence", "slug": "artificial-intelligence" }
    }
  ],
  "meta": {
    "page": 1, "limit": 10, "total": 137,
    "total_pages": 14, "has_more": true,
    "sort": "published_at", "order": "DESC"
  }
}
```

`content` is never in a listing — it is a `LONGTEXT` column. Use the detail
endpoint.

**Taxonomy shape.** The flat `category_name` / `category_slug` pair is the
original contract and is unchanged. The nested `category` / `subcategory`
objects were **added** in D5; nothing was removed, so existing pages keep
working.

**Nulls are real.** `category_id` and `subcategory_id` are both nullable. A
post with no category returns `category: null` and `category_slug: null`; a
post with no subcategory returns `subcategory: null`. Nothing is manufactured
— check one field (`category`) rather than three.

---

## `GET /api/website/posts/:slug`

`404` if the slug is unknown **or** the post is not published. The two are
indistinguishable by design.

```json
{
  "success": true,
  "data": {
    "post": {
      "id": 42,
      "title": "Post title",
      "slug": "post-title",
      "content": "<p>Full HTML body…</p>",
      "excerpt": "Short summary",
      "banner_image": "banner.webp",
      "published_at": "2026-01-10T00:00:00.000Z",
      "created_at": "2026-01-02T11:00:00.000Z",
      "updated_at": "2026-02-02T09:15:00.000Z",
      "reading_time": 7,
      "meta_title": "…", "meta_description": "…", "meta_keywords": "…",

      "category_id": 3, "subcategory_id": 4,
      "category_name": "Technology", "category_slug": "technology",
      "subcategory_name": "Artificial Intelligence",
      "subcategory_slug": "artificial-intelligence",
      "category":    { "id": 3, "name": "…", "slug": "…" },
      "subcategory": { "id": 4, "name": "…", "slug": "…" },

      "author": {
        "id": 8,
        "name": "Jane Doe",
        "display_name": "Jane D.",
        "slug": "jane-doe",
        "bio": "<p>Biography HTML</p>",
        "image": "jane.webp"
      }
    },
    "related": [ /* listing-shaped rows, same category, this post excluded */ ]
  }
}
```

**`author` is `null` when there is no byline** — the post has no author, or the
author is hidden (`status != 1`), or the author was deleted. Deleting an author
never deletes or unpublishes the article; `posts.author_id` is `ON DELETE SET
NULL`. Render the article without a byline.

The author object has exactly these six fields, always. `content` is sanitised
server-side (allowlisted HTML) and is safe to render.

`?related_limit=` accepts 1–12, default 5.

---

## `GET /api/website/posts/meta/:slug`

Published only, `404` otherwise. Everything `<head>` needs, without the body.

```json
{
  "success": true,
  "data": {
    "title": "…", "slug": "post-title",
    "meta_title": "…", "meta_description": "…", "meta_keywords": "…",
    "banner_image": "banner.webp",
    "published_at": "2026-01-10T00:00:00.000Z",
    "updated_at": "2026-02-02T09:15:00.000Z",
    "author_display_name": "Jane D.",
    "category_name": "…", "category_slug": "…",
    "subcategory_name": "…", "subcategory_slug": "…",
    "category": { "id": 3, "name": "…", "slug": "…" },
    "subcategory": null
  }
}
```

`author_display_name` is `null` when there is no byline.

---

## Authors

`GET /api/website/authors` → `{ "success": true, "data": [ … ] }`
`GET /api/website/authors/:slug` → `{ "success": true, "data": { … } }`, `404` if unknown or hidden.

Every author object, everywhere on this surface, is exactly:

```json
{
  "id": 8,
  "name": "Jane Doe",
  "display_name": "Jane D.",
  "slug": "jane-doe",
  "bio": "<p>Biography HTML</p>",
  "image": "jane.webp"
}
```

Only `status = 1` authors are listed. `bio` is sanitised HTML (inline
formatting only, no images or scripts). `image` is a bare filename — prefix it
with your uploads path.

---

## Categories and subcategories

`GET /api/website/categories` — active only, ordered by name:

```json
{ "success": true, "data": [ { "id": 3, "name": "Technology", "slug": "technology" } ] }
```

`GET /api/website/subcategories` and `.../by-category/:category_id`:

```json
{
  "success": true,
  "data": [
    {
      "id": 4, "name": "Artificial Intelligence", "slug": "artificial-intelligence",
      "category_id": 3, "category_name": "Technology", "category_slug": "technology"
    }
  ]
}
```

A non-numeric `:category_id` returns `400`. A subcategory whose parent category
is inactive is not listed.

`GET /api/website/categories/meta/:slug` and
`GET /api/website/subcategories/meta/:slug`:

```json
{
  "success": true,
  "data": { "name": "…", "slug": "…", "meta_title": "…", "meta_description": "…", "meta_keywords": "…" }
}
```

Note the column is `meta_description` — the legacy `meta_desc` name is gone.

---

## Sitemap

`GET /api/website/sitemap/posts` — every published post, no pagination:

```json
{
  "success": true,
  "data": [
    {
      "id": 42,
      "slug": "post-title",
      "post_slug": "post-title",
      "category_slug": "technology",
      "subcategory_slug": null,
      "status": "published",
      "updated_at": "2026-02-02T09:15:00.000Z",
      "published_at": "2026-01-10T00:00:00.000Z",
      "last_modified": "2026-02-02T09:15:00.000Z"
    }
  ]
}
```

`last_modified` is `updated_at` falling back to `published_at`, ready for
`<lastmod>YYYY-MM-DD</lastmod>`. `slug` and `post_slug` are the same value;
both are present so either name works. `updated_at` is offered alongside
`last_modified` for the same reason.

**`category_slug` can be `null`.** Before D5 those rows were silently dropped
and the pages were never indexed. They are now returned — decide in the
generator whether to emit a URL for a post with no category, or route it under
a fallback path.

`GET /api/website/sitemap/categories` → `[{ "category_slug": "technology" }]`
`GET /api/website/sitemap/subcategories` → `[{ "category_slug": "…", "subcategory_slug": "…" }]`

Drafts never appear in any sitemap response.

---

## Public writes

`POST /api/website/leads`

```json
{ "firstName": "…", "lastName": "…", "email": "…", "company": "…", "phone": "…", "message": "…" }
```

`POST /api/website/subscribe`

```json
{ "name": "…", "email": "…" }
```

Both are anonymous, tightly rate limited, and strip all HTML from every field.

---

## Errors

| Situation | Status | Body |
|---|---|---|
| Unknown or unpublished slug | `404` | `{ "success": false, "error": "Not Found", "message": "Post not found." }` |
| Non-numeric path id | `400` | `{ "success": false, "error": "Bad Request", "message": "…" }` |
| Invalid pagination / sort | `200` | Silently normalised; `meta` reports what was used |
| Server failure | `500` | Generic message only |

In production, responses never contain stack traces, SQL, filesystem paths,
database credentials, JWT details or model internals.

---

## Building a report URL

The article page is keyed on the post slug. Category and subcategory slugs are
available on every post object if the route needs them:

```
/report/{post.slug}
/{locale}/report/{post.slug}
/{post.category_slug}/{post.slug}     // category_slug may be null
```

Guard on `category_slug` before using it in a path.
