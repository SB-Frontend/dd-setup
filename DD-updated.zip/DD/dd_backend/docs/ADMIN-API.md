# Admin API

Everything under `/api/admin/*`. For the public surface see
[PUBLIC-API-CONTRACT.md](PUBLIC-API-CONTRACT.md).

## Ground rules

**Every route except `POST /auth/login` requires authentication.** Send the JWT
as `Authorization: Bearer <token>`.

**Every route also requires a permission.** The tables below name the *action*
permission each route checks. Actions are granted through modules — see
[AUTH-AND-RBAC.md](AUTH-AND-RBAC.md) for the full mapping.

**Status codes are consistent:**

| Situation | Status |
|---|---|
| No token / invalid / expired / user deleted or suspended | `401` |
| Authenticated but missing the permission | `403` |
| Acting on your own account where that is forbidden | `403` |
| Unknown id | `404` |
| Duplicate, or an operation the system state forbids | `409` |
| Invalid input | `400` |

Denials are deliberately terse — a `403` says you lack permission, not which
one, and a failed login cannot distinguish a wrong password from an unknown
account.

**Nothing here is cacheable.** Admin responses carry no cache headers.

**Rate limiting:** `/auth/*` gets a tight budget (each attempt costs a bcrypt
comparison); everything else gets the general admin budget.

---

## Authentication — `/api/admin/auth`

| Method | Path | Auth | Permission |
|---|---|---|---|
| POST | `/login` | none | — |
| POST | `/register` | yes* | `users.create` |

\* `/register` is open **only** while the `users` table is empty, for the
first-account bootstrap. It closes permanently once any account exists.

### `POST /api/admin/auth/login`

```json
{ "email": "you@example.com", "password": "…" }
```

```json
{
  "success": true,
  "message": "Login successful",
  "user": {
    "id": 1, "username": "you", "full_name": "You", "email": "you@example.com",
    "roles": ["admin"],
    "modules": ["post_management", "user_management", "…"],
    "permissions": ["posts.read", "posts.publish", "…"],
    "token": "eyJ…"
  }
}
```

`roles`, `modules` and `permissions` are **UI hints** — render menus with them.
They are re-resolved from the database on every request and a copy sent back by
the client is ignored. The token itself carries identity only (`id`, `iss`,
`aud`, `iat`, `exp`) and no authorization claims.

### `POST /api/admin/auth/register`

```json
{ "username": "…", "email": "…", "password": "…", "roles": ["content_writer"] }
```

`roles` is optional and requires `roles.update`; supplying it without that
permission is `403`. During bootstrap the first account is granted `admin`
automatically.

---

## Users — `/api/admin/users`

| Method | Path | Permission | Notes |
|---|---|---|---|
| GET | `/` | `users.read` | `?page= &limit= &search= &status=` |
| PUT | `/:id` | `users.update` **or self** | Profile only |
| DELETE | `/:id` | `users.delete` | Soft delete; never self |
| PATCH | `/:id/status` | `users.update` | `{ "status": 0 \| 1 }`; never self |
| GET | `/:id/roles` | `users.read` | |
| POST | `/:id/roles` | `roles.update` | Add roles; never self |
| PUT | `/:id/roles` | `roles.update` | Replace roles; never self |
| DELETE | `/:id/roles/:roleId` | `roles.update` | Never self |

`PUT /:id` accepts `username`, `full_name`, `email`, `password` only. Sending
`roles` or `status` to it returns **403** — refused outright rather than
silently dropped, so a caller cannot believe it worked. Those live on their own
endpoints, behind `roles.update` and `denySelfTarget`.

**Deleting or suspending an account is refused with `409`** when it would leave
nobody able to administer the system. See "Lockout protection" in
[AUTH-AND-RBAC.md](AUTH-AND-RBAC.md).

Deleting a CMS user never deletes their content: `posts.created_by`,
`authors.created_by` and `media.uploaded_by` become `NULL`.

Response shape (list):

```json
{
  "success": true,
  "users": [ { "id": 1, "username": "…", "full_name": "…", "email": "…",
               "status": 1, "last_login_at": "…", "created_at": "…" } ],
  "pagination": { "total": 12, "page": 1, "limit": 10, "totalPages": 2 }
}
```

The password hash is excluded by the model's default scope and by an explicit
attribute list.

---

## Roles and permissions — `/api/admin/roles`

| Method | Path | Permission | Notes |
|---|---|---|---|
| GET | `/` | `roles.read` | Roles with their granted modules |
| GET | `/permissions` | `permissions.read` | The catalogue, **read-only** |
| GET | `/:id` | `roles.read` | Accepts an id **or** a `role_slug` |
| POST | `/` | `roles.create` | |
| PUT | `/:id` | `roles.update` | Label and description only |
| PUT | `/:id/permissions` | `roles.update` | Replaces the whole grant set, atomically |
| DELETE | `/:id` | `roles.delete` | |

```json
{
  "success": true,
  "data": {
    "id": 3, "role_name": "Content Writer", "role_slug": "content_writer",
    "description": "Drafts posts, cannot publish", "is_system": true,
    "modules": ["dashboard_management", "post_management", "media_management"],
    "permissions": ["dashboard.read", "posts.read", "posts.create", "…"]
  }
}
```

`modules` are the rows in `permissions`; `permissions` are the action slugs
those modules expand to, which is what route guards check.

Rules worth knowing:

- **Permissions cannot be created, renamed or deleted through the API.** They
  are seeded system definitions matched by constants in the code; an endpoint
  that minted new ones would be an escalation path, and renaming a
  `permission_slug` would silently detach every route guard from its grants.
- A new role starts with exactly the permissions requested — never all of them.
- Granting an unknown permission is `400`, and **nothing is applied**.
- `role_slug` is fixed at creation. Changing it is `400`.
- A **system role cannot be deleted** (`403`) — removing `admin` would take
  Role Management away with no way to grant it back.
- A role still assigned to users cannot be deleted (`409`). Deleting a role
  never deletes the users holding it.

---

## Posts — `/api/admin/posts`

| Method | Path | Permission |
|---|---|---|
| GET | `/` | `posts.read` |
| POST | `/list` | `posts.read` |
| GET | `/count` | `posts.read` |
| POST | `/` | `posts.create` |
| PUT | `/:id` | `posts.update` |
| PATCH | `/:id/status` | **`posts.publish`** |
| DELETE | `/:id` | `posts.delete` |

> ### Legacy response envelope — intentional
>
> `GET /api/admin/posts` and `POST /api/admin/posts/list` answer in the jQuery
> DataTables server-side format the existing CMS consumes:
>
> ```json
> { "draw": 1, "iTotalRecords": 137, "iTotalDisplayRecords": 12, "aaData": [ … ] }
> ```
>
> `draw` echoes the **sanitised** page number. This differs from the
> `{ pagination: {…} }` shape used by `/api/admin/users`, and it is retained
> deliberately: converting it would be an API contract break for the CMS.
> Pagination and sorting are validated identically on both.

**Publishing is a separate right.** `posts.update` lets a user edit a draft;
only `posts.publish` can change `status`, and it is the *only* way status
changes — the field is not writable through `PUT /:id`. `published_at` is
stamped by the server on first publish and is never accepted from the client.

**Three different people, three different columns:**

```
author_id   → authors.id   the public byline, chosen by the editor
created_by  → users.id     the CMS operator who created the row
updated_by  → users.id     the CMS operator who last touched it
```

`created_by` / `updated_by` come from the session and are never read from the
request body. A new post is always created as a `draft`. An unknown
`author_id` is `404`, an inactive one is `400`, a non-numeric one is `400`.
Deletes are soft (`deleted_at`).

---

## Authors — `/api/admin/authors`

| Method | Path | Permission |
|---|---|---|
| GET | `/` | `authors.read` |
| POST | `/list` | `authors.read` |
| GET | `/:id` | `authors.read` |
| POST | `/` | `authors.create` |
| PUT | `/:id` | `authors.update` |
| DELETE | `/:id` | `authors.delete` |

Fields: `name`, `display_name`, `slug`, `bio`, `image`, `status`. Accepts
`multipart/form-data` with an `image` file.

**`author_management` confers no user rights whatsoever.** It cannot read,
create, edit or delete CMS accounts, and cannot assign roles. Creating an
author does not create a user, and the two tables are never joined.

`created_by` / `updated_by` record which CMS operator maintained the profile —
that does **not** make them the author.

Deleting an author leaves their articles published; `posts.author_id` becomes
`NULL` and the byline simply disappears from the site. The response reports
`affected_posts`.

---

## Categories and subcategories

| Method | Path | Permission |
|---|---|---|
| GET | `/api/admin/categories` | `categories.read` |
| POST | `/api/admin/categories` | `categories.create` |
| PUT | `/api/admin/categories/:id` | `categories.update` |
| DELETE | `/api/admin/categories/:id` | `categories.delete` |
| GET | `/api/admin/subcategories` | `subcategories.read` |
| GET | `/api/admin/subcategories/by-category/:cat_id` | `subcategories.read` |
| POST | `/api/admin/subcategories` | `subcategories.create` |
| PUT | `/api/admin/subcategories/:id` | `subcategories.update` |
| DELETE | `/api/admin/subcategories/:id` | `subcategories.delete` |

Both sets of actions are granted by the single `category_management` module.
A category still holding posts or subcategories cannot be deleted — the foreign
keys are `RESTRICT`. Writes invalidate the public taxonomy cache immediately.

---

## Media — `/api/admin/media`

| Method | Path | Permission |
|---|---|---|
| GET | `/` | `media.read` |
| POST | `/list` | `media.read` |
| GET | `/:id` | `media.read` |
| POST | `/` | `media.create` |
| PUT | `/:id` | `media.update` |
| DELETE | `/:id` | `media.delete` |

Upload field name is **`file`**. `uploaded_by` comes from the session, never
the body. Uploads are validated by extension, declared MIME type **and**
magic bytes; a file is only written to disk after all three pass, so a forged
image never lands on the filesystem. Size limits are enforced (`413`).

---

## Leads and subscriptions

| Method | Path | Permission |
|---|---|---|
| GET | `/api/admin/leads` | `leads.read` |
| POST | `/api/admin/leads/list` | `leads.read` |
| PUT | `/api/admin/leads/:id/comment` | `leads.update` |
| GET | `/api/admin/leads/:id/notes` | `leads.read` |
| GET | `/api/admin/subscriptions` | `subscriptions.read` |
| POST | `/api/admin/subscriptions/list` | `subscriptions.read` |

Both are granted by the `lead_management` module. A comment creates a row in
`lead_notes`; notes are their own records, not an appended text column.

> A lead note's `author` is the **CMS user** who wrote it, exposed as
> `{ id, username, full_name }`. This alias is admin-only and must never be
> copied into anything serving `/api/website/*` — see
> [ARCHITECTURE-DECISIONS.md](ARCHITECTURE-DECISIONS.md).

---

## Legacy admin routes

Older top-level paths are still served for the existing CMS. **They are not a
bypass:** each one authenticates and requires the same permission as its
`/api/admin/*` equivalent, runs the same controller, and uses the same schema.

| Legacy | Equivalent | Permission |
|---|---|---|
| `POST /api/posts/create` | `POST /api/admin/posts` | `posts.create` |
| `POST /api/posts/get_all_posts` | `GET /api/admin/posts` | `posts.read` |
| `PATCH /api/posts/status/:id` | `PATCH /api/admin/posts/:id/status` | `posts.publish` |
| `GET /api/auth/users` | `GET /api/admin/users` | `users.read` |
| `PUT /api/auth/users/:id` | `PUT /api/admin/users/:id` | `users.update` or self |
| `POST /api/media/getlist` | `GET /api/admin/media` | `media.read` |
| `POST /api/leads/all_leads` | `GET /api/admin/leads` | `leads.read` |
| `POST /api/subscribe/all_subscribe` | `GET /api/admin/subscriptions` | `subscriptions.read` |
| `DELETE /api/category/:id` | `DELETE /api/admin/categories/:id` | `categories.delete` |

Prefer the `/api/admin/*` paths in new code. Deprecation headers are sent where
implemented. The test suite asserts each legacy path returns `401` without a
token and `403` for an authenticated user lacking the permission.
