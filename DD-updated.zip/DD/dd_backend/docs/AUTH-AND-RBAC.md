# Authentication and RBAC

How a CMS user proves who they are, and how the backend decides what they may
do. Written for a developer joining the project.

## The one distinction to internalise first

```
users     CMS login accounts    can authenticate, hold roles, create content
authors   public bylines        no login, no role, no permission, no JWT
```

They are separate tables with no link between them. A public author does not
need — and usually does not have — a CMS account. A CMS user is not
automatically an author.

```
posts.author_id   → authors.id     who the article is BY      (public)
posts.created_by  → users.id       who typed it into the CMS  (internal)
posts.updated_by  → users.id       who last edited it         (internal)
```

There is no `authors.user_id`, no `users.is_author`, no `users.author_id`, and
none may be added. Deleting an author leaves the article published with the
byline removed; deleting a CMS user leaves their content with the audit column
nulled.

---

## Authentication

```
POST /api/admin/auth/login
  ↓  User.scope("withPassword").findOne({ email })   hash fetched only here
  ↓  status !== 1                    → 401  (checked before the hash compare)
  ↓  bcrypt compare                  → 401  message identical to unknown email
  ↓  resolveUserAccess(user)                roles / modules / permissions
  ↓  signAccessToken({ id })                HS256 · iss · aud · exp
  ↓  200 with safe user fields + token
```

Every subsequent request:

```
Authorization: Bearer <token>
  ↓  verifyAccessToken()      algorithm PINNED, issuer + audience + expiry checked
  ↓  User.findByPk(decoded.id)              → 401 if the account is gone
  ↓  Number(status) !== 1                   → 401 "no longer active"
  ↓  resolveUserAccess(user)                fresh from the database, every request
  ↓  req.user = { id, username, full_name, email, status, roles, modules, permissions }
```

### What the token does and does not carry

The JWT carries **identity only**: `id`, `iss`, `aud`, `iat`, `exp`. No role,
no permission list, no `is_admin`.

That is deliberate. Authorization is read from the database on every request,
so revoking a role, stripping a permission or suspending an account takes
effect on the **next request** rather than whenever the token happens to
expire. A token carrying a permission snapshot would be a stale copy, and a
tempting one to trust.

Claims a client invents are ignored. A validly signed token containing
`"roles": ["admin"]` gets exactly the permissions its account holds — the test
suite asserts this, as it does for `permissions` sent in a request body.

### Configuration

| | |
|---|---|
| Algorithm | HS256, pinned in `verify()` — a token cannot pick its own |
| Issuer / audience | Both set and both validated |
| Expiry | `JWT_EXPIRES_IN`, default 24h |
| Secret | `JWT_SECRET_KEY`, ≥ 32 chars, from the environment only |

There is no hardcoded fallback secret. In production a missing or weak secret
throws at startup rather than signing tokens with a guessable key.

### Passwords

bcrypt, hashed in a model hook on create and on change. The model's default
scope excludes the hash, so a password cannot be returned by accident — the
`withPassword` scope is needed to read it, and login is the only caller. No
password, hash or token is ever logged.

---

## The first account

Nothing is seeded — no user, no default password, no hardcoded admin. That
would be a permanent backdoor.

Instead, while `users` is **empty**, exactly one unauthenticated registration is
allowed. That account is granted the `admin` **role in the database**, in the
same transaction that creates it:

```
users empty?  →  yes  →  create account + INSERT INTO user_roles (admin)
              →  no   →  normal rules: authenticate + users.create
```

Once any account exists the path closes permanently. A request cannot re-open
it by sending `isBootstrap: true` — the flag is set by the server and any
client-supplied value is deleted first.

The bootstrap account then authorises through the ordinary chain like everyone
else. There is no `if (user.id === 1)` anywhere in the codebase.

---

## Authorization

### The chain

```
req.user.id
  ↓  user_roles          which roles this account holds
  ↓  roles
  ↓  role_permissions
  ↓  permissions         MODULE slugs: post_management, author_management, …
  ↓  expandSlugs()       config/permissions.js
  ↓  ACTION slugs:       posts.read, posts.publish, authors.create, …
  ↓  authorize(PERMISSIONS.X)     → 403 if absent
  ↓  controller
```

One query walks the whole chain. Multiple roles union their permissions.
Everything resolves by **slug** — no role id or permission id appears anywhere
in application code, because auto-increment values differ between environments.

### Two levels, on purpose

The database stores **module** permissions because that is the language the
business and the CMS UI use ("Post Management"). Routes check **action**
permissions because that is the granularity a route needs (`posts.read` vs
`posts.publish`). `MODULE_PERMISSIONS` in `config/permissions.js` is the bridge.

| Module (in the database) | Grants |
|---|---|
| `dashboard_management` | `dashboard.read` |
| `post_management` | `posts.read` `posts.create` `posts.update` `posts.delete` |
| `post_publishing` | `posts.publish` |
| `author_management` | `authors.read` `authors.create` `authors.update` `authors.delete` |
| `user_management` | `users.read` `users.create` `users.update` `users.delete` |
| `role_management` | `roles.read` `roles.create` `roles.update` `roles.delete` `permissions.read` |
| `category_management` | `categories.*` and `subcategories.*` |
| `media_management` | `media.*` |
| `lead_management` | `leads.read` `leads.update` `subscriptions.read` |
| `advertisement_management` | nothing — no such feature yet |

An action slug can also be stored directly in `permissions` if finer grain is
ever needed; `expandSlugs()` passes it through unchanged, with no code change.

### Seeded roles

`admin`, `content_management`, `content_head`, `seo_manager`, `marketing_head`,
`graphics_team`, `content_writer`, `seo_team`, `publisher` — all `is_system`,
so none can be deleted through the API. Their grants come from migration
`20260910000010-seed-rbac`.

### An account with no roles has nothing

No implicit role, no environment-variable default. Before D4 this module
granted a fallback role — defaulting to `admin` — to any account with no rows
in `user_roles`, which silently made every account a full administrator. That
fallback is gone and a test asserts it stays gone.

---

## Publishing is separate from editing

`post_management` lets a user create and edit drafts. Only `post_publishing`
can change a post's status. This is what makes "Content Writer drafts,
Publisher publishes" expressible, and it is enforced at the route:

```
PATCH /api/admin/posts/:id/status    →  authorize(posts.publish)
```

`status` is not writable through `PUT /:id`, so there is no way around it by
manipulating the request body. `published_at` is stamped by the server.

Do not merge these two permissions.

---

## Privilege escalation is closed

`user_roles` is written only by routes guarded with **both** `roles.update` and
`denySelfTarget`. Managing accounts and handing out authority are separate
rights:

| Attempt | Result |
|---|---|
| `user_management` holder grants themselves `admin` | 403 — needs `roles.update` |
| `user_management` holder grants anyone a role | 403 |
| `user_management` holder registers an account with `roles: ["admin"]` | 403 |
| **Admin** changes their own roles | 403 — `denySelfTarget` |
| **Admin** revokes their own roles | 403 |
| `roles` sent to `PUT /users/:id` (profile) | 403 — refused, not ignored |
| `status` sent to `PUT /users/:id` | 403 |
| Forged `roles` / `permissions` / `is_admin` in a signed JWT | ignored |
| `permissions` in a request body | ignored |
| Anonymous request claiming `isBootstrap: true` | 401 |

The pattern: **nobody can raise their own privileges**, because every route
that writes authorization refuses to target the caller's own account. Changing
someone's authority always requires a second person.

`allowSelfOr` is the mirror image — it lets a user edit their *own profile*
without holding `users.update`, while still requiring it to touch anyone else.
Self-service stops at the profile; it never reaches roles or status.

---

## Lockout protection

Because authorization is now exactly what the database says, it became possible
to remove the last account able to administer the system — unrecoverable
through the API, since nobody would be left who could grant the permission
back.

An account is **recovery-capable** when its roles grant both `users.update` and
`roles.update`. Any operation that would leave zero active, non-deleted,
recovery-capable accounts is refused with **409**:

- deleting a user
- suspending a user (`status = 0`)
- revoking a role
- replacing a user's role set
- replacing a role's permissions

`409` rather than `403`: the caller is permitted to do this, the system state
is what forbids it. The guard never fires while another such account remains.

It is defined by `RECOVERY_PERMISSIONS` in `config/permissions.js` and
implemented in `services/rbac.service.js`.

---

## Where the code lives

| File | Role |
|---|---|
| `utils/jwt.js` | The only place tokens are signed or verified |
| `middleware/auth.middleware.js` | `authenticate` — token → database user → `req.user` |
| `middleware/permission.middleware.js` | `authorize`, `allowSelfOr`, `denySelfTarget`, `allowFirstUserOr` |
| `config/permissions.js` | Permission catalogue, module→action map, `resolveUserAccess` |
| `services/rbac.service.js` | The only writer of `user_roles` / `role_permissions`; lockout guard |
| `controllers/user.controller.js` | Login, account CRUD, user-role endpoints |
| `controllers/role.controller.js` | Role CRUD, permission catalogue |

Authorization is centralised. Controllers never check a role name — there is no
`if (user.role === "admin")` anywhere, and adding one would be a regression.
Routes declare what they need; the middleware decides.

## Test coverage

`tests/security/rbac.test.js` (88), `tests/auth/auth.test.js` (69),
`tests/auth/bootstrap.test.js` (18) and `tests/security/jwt.test.js` (27) cover
this document end to end against real accounts and real grants — no stubbed
sessions, so every assertion walks the full
`users → user_roles → roles → role_permissions → permissions` chain.
