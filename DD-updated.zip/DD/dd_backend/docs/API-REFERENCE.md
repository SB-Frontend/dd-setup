# DD_SETUP — Complete API Reference

Every endpoint the backend serves, in one place. **105 endpoints**: 15 public
website, 51 admin/CMS, 39 deprecated legacy aliases.

Generated from the live router tree, not from memory.

| Surface | Base path | Authentication | Consumer |
|---|---|---|---|
| **Website (frontend)** | `/api/website/*` | **none, ever** | The Next.js public site |
| **Admin (CMS)** | `/api/admin/*` | JWT + permission | The CMS |
| **Legacy** | `/api/posts`, `/api/auth`, … | same as their modern equivalent | Older clients, being migrated off |

Deeper documentation:
[PUBLIC-API-CONTRACT.md](PUBLIC-API-CONTRACT.md) (request/response detail for
the frontend) · [ADMIN-API.md](ADMIN-API.md) (admin behaviour and rules) ·
[AUTH-AND-RBAC.md](AUTH-AND-RBAC.md) (how permissions resolve).

---

# Part 1 — Frontend / Website API

**15 endpoints. None requires authentication.** Sending an `Authorization`
header is ignored, and an invalid or expired token does not break a read.

Only `status = "published"` content is ever returned — on every endpoint,
including search, filters and the sitemap. The frontend never has to filter.

Envelope: `{ "success": true, "data": … }`, plus a sibling `meta` on paginated
lists. Errors: `{ "success": false, "error": "…", "message": "…" }`.

## Posts

| # | Method | Endpoint | Purpose |
|---|---|---|---|
| 1 | GET | `/api/website/posts` | Paginated published listing |
| 2 | GET | `/api/website/posts/:slug` | One published post + related posts |
| 3 | GET | `/api/website/posts/meta/:slug` | SEO metadata only (no body) |

**Query parameters for `/api/website/posts`**

| Param | Type | Default | Notes |
|---|---|---|---|
| `page` | int ≥ 1 | `1` | Garbage/negative → 1 |
| `limit` | int 1–50 | `10` | **Hard cap 50**, clamped not rejected |
| `search` | string | — | Title only; cannot reach drafts |
| `category_id` | int or CSV | — | `cat_id` accepted as an alias |
| `subcategory_id` | int or CSV | — | |
| `exclude_id` | int or CSV | — | Removes from both rows and count |
| `reading_time` | enum | — | `under-5` · `5-10` · `10-plus` |
| `sort` | enum | `published_at` | `published_at` `created_at` `updated_at` `reading_time` `title` |
| `order` | enum | `DESC` | `ASC` · `DESC` |

Unknown parameters are ignored. An unknown `sort`/`order` falls back to the
default — nothing a client sends reaches `ORDER BY`. `meta.total` always
describes the same filtered set as `data`.

`/api/website/posts/:slug` also accepts `related_limit` (1–12, default 5).
Unknown **or** unpublished slug → `404`, indistinguishable by design.

## Taxonomy

| # | Method | Endpoint | Purpose |
|---|---|---|---|
| 4 | GET | `/api/website/categories` | Active categories |
| 5 | GET | `/api/website/categories/meta/:slug` | Category SEO metadata |
| 6 | GET | `/api/website/subcategories` | Active subcategories, each with its parent |
| 7 | GET | `/api/website/subcategories/by-category/:category_id` | Children of one category |
| 8 | GET | `/api/website/subcategories/meta/:slug` | Subcategory SEO metadata |

A non-numeric `:category_id` → `400`.

## Authors

| # | Method | Endpoint | Purpose |
|---|---|---|---|
| 9 | GET | `/api/website/authors` | Active public authors |
| 10 | GET | `/api/website/authors/:slug` | One public author |

Every author object on this surface is exactly six fields:

```json
{ "id": 8, "name": "…", "display_name": "…", "slug": "…", "bio": "<p>…</p>", "image": "…" }
```

Authors come from the `authors` table. **No CMS account data exists on this
surface** — `password`, `username`, `email`, `roles`, `permissions`,
`created_by`, `updated_by`, `deleted_at`, `last_login_at` and `user_id` never
appear.

## Sitemap

| # | Method | Endpoint | Purpose |
|---|---|---|---|
| 11 | GET | `/api/website/sitemap/posts` | Every published post |
| 12 | GET | `/api/website/sitemap/categories` | Category slugs |
| 13 | GET | `/api/website/sitemap/subcategories` | Category/subcategory slug pairs |

Post rows carry `id`, `slug`, `post_slug`, `category_slug`,
`subcategory_slug`, `status`, `updated_at`, `published_at` and
`last_modified` (= `updated_at` falling back to `published_at`, ready for
`<lastmod>`). `category_slug` may be `null` — guard before building a URL.

## Public writes

| # | Method | Endpoint | Body |
|---|---|---|---|
| 14 | POST | `/api/website/leads` | `firstName` `lastName` `email` `company` `phone` `message` |
| 15 | POST | `/api/website/subscribe` | `name` `email` |

Anonymous, tightly rate limited, all HTML stripped from every field.

## Caching

`Cache-Control: public, max-age=…, stale-while-revalidate=…` and
`Vary: Accept-Encoding`. Listings 60s · detail 300s · taxonomy and authors
600s · sitemap 3600s. Caches key on the full URL, so filters and pages never
share an entry.

---

# Part 2 — CMS / Admin API

**51 endpoints.** All require `Authorization: Bearer <token>` except
`POST /auth/login`. Each also requires the permission named below.

| Status | Meaning |
|---|---|
| `401` | No token / invalid / expired / user deleted or suspended |
| `403` | Authenticated but missing the permission, or acting on your own account where forbidden |
| `404` | Unknown id |
| `409` | Duplicate, or an operation the system state forbids (e.g. last administrator) |
| `400` | Invalid input |

## Authentication

| # | Method | Endpoint | Permission | Notes |
|---|---|---|---|---|
| 1 | POST | `/api/admin/auth/login` | — | Returns the JWT |
| 2 | POST | `/api/admin/auth/register` | `users.create` | Open **only** while `users` is empty (first-account bootstrap) |

## Users — `user_management`

| # | Method | Endpoint | Permission | Guard |
|---|---|---|---|---|
| 3 | GET | `/api/admin/users` | `users.read` | |
| 4 | PUT | `/api/admin/users/:id` | `users.update` **or self** | Profile fields only |
| 5 | DELETE | `/api/admin/users/:id` | `users.delete` | never self · lockout guard |
| 6 | PATCH | `/api/admin/users/:id/status` | `users.update` | never self · lockout guard |

## User roles — `role_management`

| # | Method | Endpoint | Permission | Guard |
|---|---|---|---|---|
| 7 | GET | `/api/admin/users/:id/roles` | `users.read` | |
| 8 | POST | `/api/admin/users/:id/roles` | `roles.update` | **never self** |
| 9 | PUT | `/api/admin/users/:id/roles` | `roles.update` | **never self** · replaces the set |
| 10 | DELETE | `/api/admin/users/:id/roles/:roleId` | `roles.update` | **never self** |

> Assigning roles requires `role_management`, not `user_management`, and can
> never target the caller's own account. Together that closes self-escalation:
> changing anyone's authority always takes a second person.

## Roles and permissions — `role_management`

| # | Method | Endpoint | Permission | Notes |
|---|---|---|---|---|
| 11 | GET | `/api/admin/roles` | `roles.read` | |
| 12 | GET | `/api/admin/roles/permissions` | `permissions.read` | Catalogue, **read-only** |
| 13 | GET | `/api/admin/roles/:id` | `roles.read` | Accepts an id **or** a `role_slug` |
| 14 | POST | `/api/admin/roles` | `roles.create` | Atomic: role + grants in one transaction |
| 15 | PUT | `/api/admin/roles/:id` | `roles.update` | Label/description only; `role_slug` is fixed |
| 16 | PUT | `/api/admin/roles/:id/permissions` | `roles.update` | Replaces the grant set atomically |
| 17 | DELETE | `/api/admin/roles/:id` | `roles.delete` | Refuses system roles (403) and roles in use (409) |

Permissions cannot be created, renamed or deleted through the API.

## Posts — `post_management` + `post_publishing`

| # | Method | Endpoint | Permission |
|---|---|---|---|
| 18 | GET | `/api/admin/posts` | `posts.read` |
| 19 | POST | `/api/admin/posts/list` | `posts.read` |
| 20 | GET | `/api/admin/posts/count` | `posts.read` |
| 21 | POST | `/api/admin/posts` | `posts.create` |
| 22 | PUT | `/api/admin/posts/:id` | `posts.update` |
| 23 | PATCH | `/api/admin/posts/:id/status` | **`posts.publish`** |
| 24 | DELETE | `/api/admin/posts/:id` | `posts.delete` |

> **Legacy envelope, intentional.** `GET /api/admin/posts` and
> `POST /api/admin/posts/list` return the jQuery DataTables shape
> `{ draw, iTotalRecords, iTotalDisplayRecords, aaData }`, not
> `{ pagination }`. `draw` echoes the *sanitised* page. Retained because the
> existing CMS consumes it.

> **Publishing is separate.** `posts.update` edits drafts; only
> `posts.publish` changes `status`, and `status` is not writable through
> `PUT /:id`. `published_at` is stamped by the server.

Three different people, three different columns: `author_id → authors.id`
(the public byline), `created_by` / `updated_by → users.id` (the CMS
operators, taken from the session, never the body).

## Authors — `author_management`

| # | Method | Endpoint | Permission |
|---|---|---|---|
| 25 | GET | `/api/admin/authors` | `authors.read` |
| 26 | POST | `/api/admin/authors/list` | `authors.read` |
| 27 | GET | `/api/admin/authors/:id` | `authors.read` |
| 28 | POST | `/api/admin/authors` | `authors.create` |
| 29 | PUT | `/api/admin/authors/:id` | `authors.update` |
| 30 | DELETE | `/api/admin/authors/:id` | `authors.delete` |

Fields: `name` `display_name` `slug` `bio` `image` `status`. Accepts
`multipart/form-data` with an `image` file.

`author_management` confers **no** user rights: it cannot read, create, edit or
delete CMS accounts, and cannot assign roles. Creating an author never creates
a user. Deleting an author leaves their articles published with the byline
removed.

## Categories — `category_management`

| # | Method | Endpoint | Permission |
|---|---|---|---|
| 31 | GET | `/api/admin/categories` | `categories.read` |
| 32 | POST | `/api/admin/categories` | `categories.create` |
| 33 | PUT | `/api/admin/categories/:id` | `categories.update` |
| 34 | DELETE | `/api/admin/categories/:id` | `categories.delete` |

## Subcategories — `category_management`

| # | Method | Endpoint | Permission |
|---|---|---|---|
| 35 | GET | `/api/admin/subcategories` | `subcategories.read` |
| 36 | GET | `/api/admin/subcategories/by-category/:cat_id` | `subcategories.read` |
| 37 | POST | `/api/admin/subcategories` | `subcategories.create` |
| 38 | PUT | `/api/admin/subcategories/:id` | `subcategories.update` |
| 39 | DELETE | `/api/admin/subcategories/:id` | `subcategories.delete` |

Both sets come from the single `category_management` module. Writes invalidate
the public taxonomy cache immediately.

## Media — `media_management`

| # | Method | Endpoint | Permission |
|---|---|---|---|
| 40 | GET | `/api/admin/media` | `media.read` |
| 41 | POST | `/api/admin/media/list` | `media.read` |
| 42 | GET | `/api/admin/media/:id` | `media.read` |
| 43 | POST | `/api/admin/media` | `media.create` |
| 44 | PUT | `/api/admin/media/:id` | `media.update` |
| 45 | DELETE | `/api/admin/media/:id` | `media.delete` |

Upload field name is **`file`**. Validated by extension, declared MIME type
**and** magic bytes; the file is written only after all three pass, so a forged
image never reaches disk. Over-size → `413`. `uploaded_by` comes from the
session.

## Leads and subscriptions — `lead_management`

| # | Method | Endpoint | Permission |
|---|---|---|---|
| 46 | GET | `/api/admin/leads` | `leads.read` |
| 47 | POST | `/api/admin/leads/list` | `leads.read` |
| 48 | PUT | `/api/admin/leads/:id/comment` | `leads.update` |
| 49 | GET | `/api/admin/leads/:id/notes` | `leads.read` |
| 50 | GET | `/api/admin/subscriptions` | `subscriptions.read` |
| 51 | POST | `/api/admin/subscriptions/list` | `subscriptions.read` |

A comment creates a row in `lead_notes`. A note's `author` is the **CMS user**
who wrote it — admin-only, and never to be copied onto the public surface.

## Permission → module map

Routes check **action** slugs; the database stores **module** slugs.

| Module (in `permissions`) | Grants |
|---|---|
| `dashboard_management` | `dashboard.read` |
| `post_management` | `posts.read` `posts.create` `posts.update` `posts.delete` |
| `post_publishing` | `posts.publish` |
| `author_management` | `authors.read` `authors.create` `authors.update` `authors.delete` |
| `user_management` | `users.read` `users.create` `users.update` `users.delete` |
| `role_management` | `roles.read` `roles.create` `roles.update` `roles.delete` `permissions.read` |
| `category_management` | `categories.*` and `subcategories.*` |
| `media_management` | `media.*` |
| `lead_management` | `leads.read` `leads.update` `subscriptions.read` |
| `advertisement_management` | nothing — no such feature yet |

Seeded roles: `admin` · `content_management` · `content_head` · `seo_manager`
· `marketing_head` · `graphics_team` · `content_writer` · `seo_team` ·
`publisher`.

---

# Part 3 — Legacy endpoints (deprecated)

**39 endpoints**, kept so existing clients keep working. They send
`Deprecation: true`, `X-API-Deprecated: true` and `X-API-Replaced-By: <path>`.

**They are not a security bypass.** Every legacy admin route authenticates and
requires the same permission as its modern equivalent, runs the same
controller, and uses the same schema. The test suite asserts each returns `401`
without a token and `403` for an authenticated user lacking the permission.

## Legacy public (no auth — correct)

| Method | Legacy endpoint | Replaced by |
|---|---|---|
| GET | `/api/posts/get_post/:slug` | `/api/website/posts/:slug` |
| GET | `/api/posts/meta/:slug` | `/api/website/posts/meta/:slug` |
| GET | `/api/posts/sitemap` | `/api/website/sitemap/posts` |
| POST | `/api/posts/website/posts` | `/api/website/posts` (body instead of query) |
| GET | `/api/category/get_all_categories` | `/api/website/categories` |
| GET | `/api/category/meta/:slug` | `/api/website/categories/meta/:slug` |
| GET | `/api/category/sitemap` | `/api/website/sitemap/categories` |
| GET | `/api/subcategory/get_all_subcategories` | `/api/website/subcategories` |
| GET | `/api/subcategory/by-category/:category_id` | `/api/website/subcategories/by-category/:id` |
| GET | `/api/subcategory/meta/:slug` | `/api/website/subcategories/meta/:slug` |
| GET | `/api/subcategory/sitemap` | `/api/website/sitemap/subcategories` |
| GET | `/api/auth/author-list` | `/api/website/authors` |
| POST | `/api/leads` | `/api/website/leads` |
| POST | `/api/subscribe` | `/api/website/subscribe` |
| POST | `/api/auth/login` | `/api/admin/auth/login` |
| POST | `/api/auth/register` | `/api/admin/auth/register` (bootstrap-gated) |

## Legacy admin (authenticated + permission-checked)

| Method | Legacy endpoint | Permission | Replaced by |
|---|---|---|---|
| POST | `/api/posts/create` | `posts.create` | `POST /api/admin/posts` |
| POST | `/api/posts/get_all_posts` | `posts.read` | `GET /api/admin/posts` |
| GET | `/api/posts/all_post_count` | `posts.read` | `GET /api/admin/posts/count` |
| PUT | `/api/posts/:id` | `posts.update` | `PUT /api/admin/posts/:id` |
| PATCH | `/api/posts/status/:id` | `posts.publish` | `PATCH /api/admin/posts/:id/status` |
| POST | `/api/category` | `categories.create` | `POST /api/admin/categories` |
| PUT | `/api/category/:id` | `categories.update` | `PUT /api/admin/categories/:id` |
| DELETE | `/api/category/:id` | `categories.delete` | `DELETE /api/admin/categories/:id` |
| POST | `/api/subcategory` | `subcategories.create` | `POST /api/admin/subcategories` |
| PUT | `/api/subcategory/:id` | `subcategories.update` | `PUT /api/admin/subcategories/:id` |
| DELETE | `/api/subcategory/:id` | `subcategories.delete` | `DELETE /api/admin/subcategories/:id` |
| GET | `/api/auth/users` | `users.read` | `GET /api/admin/users` |
| PUT | `/api/auth/users/:id` | `users.update` or self | `PUT /api/admin/users/:id` |
| PUT | `/api/auth/update-status/:id` | `users.update` · never self | `PATCH /api/admin/users/:id/status` |
| DELETE | `/api/auth/users/:id` | `users.delete` · never self | `DELETE /api/admin/users/:id` |
| POST | `/api/media` | `media.create` | `POST /api/admin/media` |
| POST | `/api/media/getlist` | `media.read` | `GET /api/admin/media` |
| GET | `/api/media/:id` | `media.read` | `GET /api/admin/media/:id` |
| PUT | `/api/media/:id` | `media.update` | `PUT /api/admin/media/:id` |
| DELETE | `/api/media/:id` | `media.delete` | `DELETE /api/admin/media/:id` |
| POST | `/api/leads/all_leads` | `leads.read` | `GET /api/admin/leads` |
| PUT | `/api/leads/add-comment/:id` | `leads.update` | `PUT /api/admin/leads/:id/comment` |
| POST | `/api/subscribe/all_subscribe` | `subscriptions.read` | `GET /api/admin/subscriptions` |

Prefer the namespaced paths in new code. This whole block can be deleted once
both clients have migrated.

---

# Cross-cutting

**Rate limiting** — four separate budgets: authentication (tight, each attempt
costs a bcrypt compare) · admin · website reads (generous, sized for
server-side rendering where every visitor shares one IP) · public writes
(small, the spam surface).

**Security headers** — Helmet on every response. CORS is an explicit
configured allowlist (`CORS_ORIGINS`), never `*`.

**Sanitisation** — three profiles: RICH (post bodies, allowlisted HTML), BASIC
(bios and notes, inline formatting), PLAIN (everything else, markup stripped).

**Errors** — one central handler. Production responses never contain stack
traces, SQL, filesystem paths, database credentials or JWT internals.

**Uploads** — served from `/uploads/*` with `X-Content-Type-Options: nosniff`,
a restrictive CSP and no directory listing. Path traversal and dotfiles are
refused.
