# Architecture decisions and known intentional items

Why the backend is shaped the way it is, and which oddities are deliberate.
Read this before "fixing" something in the lists below.

---

## Part 1 — The decisions that shape everything

### CMS users and public authors are separate tables

`users` holds login accounts. `authors` holds bylines. Nothing links them.

The old schema conflated the two: a public author was a row in `users` with
`is_author = 1`, carrying `author_photo` and `author_description` alongside a
password hash and a login name. That meant a guest contributor needed a CMS
account to be credited, the public API served a table full of credentials, and
"can manage authors" implied "can manage logins".

```
posts.author_id   → authors.id     the public byline
posts.created_by  → users.id       the CMS operator
posts.updated_by  → users.id
```

**Never add `authors.user_id`, `users.is_author` or `users.author_id`.** An
author does not need a login. If a CMS user also writes articles, they get an
`authors` row too — two records, on purpose.

### The public API is genuinely public

Nothing under `/api/website/*` requires a token, and no auth middleware is
mounted anywhere beneath it. Publication filtering happens server-side, so the
website never decides what is safe to show.

Adding authentication there would break the site and defeat the split.

### The schema belongs to migrations

`sequelize.sync()` is not used and must not return. On an empty database it
once created `post_view` and `category_subcategory_view` as real **base
tables**, permanently shadowing the views the public site read through. A test
scans every source file to assert no one calls it.

```
migrations/  →  MySQL schema  →  Sequelize models  →  controllers
```

### Editing and publishing are different rights

`post_management` drafts; `post_publishing` puts live. Keeping them separate is
the entire reason both "Content Writer" and "Publisher" exist as roles. Do not
merge them.

### Nothing cascades into content

Deleting a person never deletes what they made. Every audit foreign key is
`ON DELETE SET NULL`; the only `CASCADE`s in the database are
`lead_notes → leads`, `user_roles → users` and `role_permissions → roles`,
which are join/child rows with no independent meaning.

### Authorization is read fresh, every request

The JWT carries identity only. Roles and permissions come from the database on
each request, so a revoked role takes effect immediately rather than when the
token expires. A permission list inside a token would be a stale copy — and a
tempting one to trust.

---

## Part 2 — Known intentional items

These are all deliberate. Each says what it is, why it stays, and what would
have to be true to change it.

### 1. WAMP's SQL mode is permissive

`@@GLOBAL.sql_mode` on the local WAMP MySQL 8.4 is **empty**, and the session
mode is `IGNORE_SPACE`. MySQL's own default is strict
(`STRICT_TRANS_TABLES`, `NO_ZERO_DATE`, `ONLY_FULL_GROUP_BY`, …).

Developing under a laxer mode than production can hide truncation and coercion
bugs, so rather than trusting it, `tests/database/schema.test.js` re-runs the
critical inserts, joins and a `GROUP BY` under MySQL's real strict mode. They
pass. The application is strict-safe regardless of the local setting.

*Not changed because:* `my.ini` is developer-machine configuration, not
project code, and the compatibility question is answered by test rather than by
assumption. Setting `sql-mode` in `my.ini` to match production is a reasonable
one-line change whenever you want the local server to behave like production.

### 2. `/api/admin/posts` keeps the DataTables envelope

```json
{ "draw": 1, "iTotalRecords": 137, "iTotalDisplayRecords": 12, "aaData": [ … ] }
```

`/api/admin/users`, by contrast, returns `{ pagination: { page, limit, … } }`.
Two shapes on one surface is not ideal.

*Not changed because:* the existing CMS frontend consumes the DataTables shape.
Converting it is an API contract break, not a cleanup. Both endpoints validate
pagination and sorting identically — `draw` echoes the **sanitised** page, so
the normalisation is observable either way.

*Change it when:* the CMS frontend is rewritten, and both can move together.

### 3. `sequelize_meta` is utf8mb3

Every application table is `utf8mb4`. `sequelize_meta` is not, because
sequelize-cli hardcodes `CHARSET=utf8` when it creates its own bookkeeping
table.

*Not changed because:* it stores ASCII migration filenames. Altering a table
the CLI owns invites a conflict on the next upgrade. The schema test excludes
it from the charset assertion for exactly this reason, and says so.

### 4. `advertisement_management` grants nothing

It is seeded as a permission and mapped to an empty action list, because the
role list includes "Marketing Head" and that role is defined as holding it.
There is no advertisements table and no advertisement feature.

*Harmless:* an empty grant list means holding it authorises nothing. Either
implement the feature or drop the permission and its grants in a migration —
but do not leave it half-built.

### 5. `LeadNote → User` uses the alias `author`

```js
LeadNote.belongsTo(User, { foreignKey: "user_id", as: "author" });
```

Here "author" means *the CMS operator who wrote the internal note*, not a
public content author. It is a `User` on purpose: a lead note is CMS data,
readable only through `GET /api/admin/leads/:id/notes`, which is guarded by
`leads.read` and exposes `{ id, username, full_name }`.

*Not renamed because:* renaming an association during a verification phase is
churn with no behavioural gain, and the alias is correct in its own context.

**But do not copy this include into anything serving `/api/website/*`.** The
word "author" is reserved for the `authors` table everywhere on the public
surface, and a `User` include there would reintroduce the exact conflation the
redesign removed. The association carries a comment saying so.

### 6. Legacy admin routes are still served

Top-level paths like `POST /api/posts/create` and `GET /api/auth/users` remain
alongside `/api/admin/*` for the existing CMS.

They are **not** a bypass: each authenticates, requires the same permission,
runs the same controller and uses the same schema. The suite asserts every one
returns `401` unauthenticated and `403` for a user missing the permission.

*Remove them when:* the CMS has migrated to the `/api/admin/*` paths.

### 7. `.env.backup-before-wamp`

A copy of `.env` taken before the XAMPP→WAMP migration, containing the same
local credentials. It is gitignored (`.env.backup-*`).

*Left in place because:* it is the developer's file and the credentials rule
for this project is not to remove local credentials unannounced. Safe to delete
once you are satisfied the WAMP configuration is settled.

### 8. Legacy identifiers still appear in comments and migrations

A scan for `session_user`, `handover_to`, `comment_by`, `is_author`,
`category_subcategory_view` and friends returns hits — all of them in:

- migration files that document what was replaced (history, do not edit),
- comments recording why a field is absent,
- tests asserting a field is **not** present.

There are none in live application code. Migration history is deliberately left
alone: rewriting it to make a grep cleaner would falsify the record.

---

## Part 3 — Things that would be regressions

Not a checklist of preferences — each of these undoes something the redesign
fixed:

| Do not | Because |
|---|---|
| Add `authors.user_id` or `users.is_author` | Re-conflates logins with bylines |
| Serve a `User` include on `/api/website/*` | Leaks CMS accounts as public authors |
| Call `sequelize.sync()` | Silently rewrites the schema; created fake tables once already |
| Merge `post_management` and `post_publishing` | Removes the editorial gate |
| Grant a role implicitly when a user has none | This exact bug made every account an admin |
| Put roles or permissions in the JWT | Stale authorization that survives revocation |
| Add auth to `/api/website/*` | Breaks the public site |
| Let `PUT /users/:id` write `roles` or `status` | Self-escalation path |
| Remove `denySelfTarget` from a role route | Same |
| Cascade a delete into `posts` | Deleting a person would delete published content |
