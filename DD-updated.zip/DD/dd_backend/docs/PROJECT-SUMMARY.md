# DD_SETUP backend — what was done and what it achieved

A record of the rebuild, phase by phase, with the defects it found and the
state it ended in. Written so someone who was not present can understand what
changed and why.

---

## Where it started, and where it ended

| | Before | After |
|---|---|---|
| Schema owner | `sequelize.sync()` at boot | 12 versioned migrations |
| Foreign keys | **0** | **15**, every delete rule deliberate |
| CHECK constraints | 0 | 3, all verified to actually fire |
| Database views | 2 fake ones, created as base tables by `sync()` | 0 |
| Unauthenticated admin endpoints | **31** | 0 |
| Authorization | none, then an implicit-admin fallback | RBAC resolved from the database per request |
| Public authors | rows in `users` with `is_author = 1` | their own `authors` table, no login |
| Error responses | HTML stack traces, 29 raw `error.message` leaks | one central handler, nothing internal disclosed |
| Uploads | unvalidated, unlimited | extension + MIME + magic bytes, size-capped |
| Tests | none | **801 assertions, 15 suites, 0 failures** |
| Database engine | MariaDB 10.4 via XAMPP (crashing) | MySQL 8.4.7 via WAMP |

---

## The phases

### Phase 0 — Read-only architecture review
A full audit with no changes: architecture, database, bugs, memory, API design,
security, performance, error handling, production readiness. It produced the
roadmap everything after followed.

### Phase 1 — Website and admin API separation
Split one flat, undifferentiated API into two explicit surfaces:
`/api/website/*` for the public site and `/api/admin/*` for the CMS. The old
flat routes were kept as deprecated aliases so nothing broke mid-migration.

### Phase 2 — Authentication and authorization
**Found: 31 admin endpoints reachable with no token at all**, and a
privilege-escalation chain that let an anonymous caller reach administrator.
Added JWT authentication and per-route permission checks — deliberately not as
a blanket middleware, so the public surface stayed public.

### Phase 3 — Centralized error handling
**Found: Express's default handler returned HTML pages containing stack traces
whenever `NODE_ENV` was unset**, and 29 places echoed raw `error.message` (and
therefore SQL) to clients. Replaced with one handler that decides what is safe
to disclose.

### Phase 4 — Functional bug fixes
Ten real defects, including: a missing `Op` import that broke search entirely,
partial updates that NULLed every field the caller omitted, `NaN` reaching SQL
from unvalidated pagination, and sort/order parameters passed straight into
`ORDER BY`.

### Phase 5 — Schema baseline
An investigation, not a change. Established what the database actually
contained — and corrected two of my own earlier conclusions in the process
(`post_view` was 1:1 with `post_data`, not a row multiplier; `post_data` did
have five indexes).

### Phase 6 — Migration system
Introduced sequelize-cli migrations and **removed `sequelize.sync()`**, which
on an empty database had been creating `post_view` and
`category_subcategory_view` as real base tables that permanently shadowed the
views the website read through.

### Phase 7 — Upload security
**Found: uploads accepted any file, any size.** Rebuilt around in-memory
buffering plus magic-byte verification, so a forged file is rejected before it
ever reaches disk — strictly better than the original write-then-check design,
which a Windows `EPERM` bug had exposed as unworkable anyway.

### Phase 8 — Public website API quality
Fixed the `post_data` / `post_view` count mismatch, N+1 queries, and pagination
correctness on the public surface.

### Stage A — Tests brought into the repository
~140 assertions moved into `tests/` behind a small custom harness — no
framework introduced, developer-specific paths removed, no production
credentials.

### Stage B — Security hardening
Helmet, rate limiting (four separate budgets), a CORS allowlist, an XSS
sanitiser with three deliberate profiles, JWT configuration (HS256 pinned,
issuer, audience, expiry, no hardcoded fallback secret) and environment
hygiene.

### Phase C — Schema audit and target design
A read-only design exercise. **You issued the correction that shaped everything
after it:** users and authors must be separate entities. `posts.author_id` must
reference `authors.id`, and `authors.user_id` must not exist. My earlier
recommendation had been wrong.

### D1 — Clean schema
12 migrations building 14 tables with 15 foreign keys and 3 CHECK constraints,
all InnoDB, all `utf8mb4`. No user and no password seeded — a default
credential would be a permanent backdoor.

### D2 — Models and associations
35 associations wired explicitly. Paranoid soft delete. **No cascade reaches
`posts`**: deleting a person never deletes published content.

### D3 — Application alignment
Controllers, services, routes and tests rewritten against the new schema. The
legacy handover/session/comment workflow was removed outright.

### D4 — Authentication and RBAC
**The most serious defect in the whole project.** `resolveUserAccess()` granted
a fallback role — defaulting to `admin` — to any account with no rows in
`user_roles`. Since D1 seeded no grants, **every CMS account created was
silently a full administrator** and the entire RBAC chain was decorative.

Removed the fallback, built role management, made the first-user bootstrap
grant a real `admin` role row, and closed every self-escalation path.

### D5 — Public API contract
**Found: the sitemap silently dropped published posts.** `posts.category_id` is
nullable, and `getPostSitemap` skipped any row whose category could not be
resolved — so a published post with no category was never indexed. Also added
the subcategory relationship, which had been entirely absent from public
responses.

### D6 — Full testing and security regression
Added 257 assertions covering what the suite could not yet prove: schema
integrity, the bootstrap *opening* path, injection and pagination hardening
across both surfaces. Found and fixed a non-atomic `createRole()`.

### D7 — Cleanup, documentation and final audit
Removed the misspelled `middlewear/` directory, an unused dependency and dead
exports. Wrote the documentation set. Verified every architectural and security
control one final time.

### Environment migration
The local XAMPP/MariaDB server began crashing — traced to a corrupted
phpMyAdmin InnoDB tablespace (`pma__designer_settings`), 204 fatal aborts in
one day, and then a missing Aria log file that stopped it starting at all.
Migrated to WAMP/MySQL 8.4.7. All 12 migrations applied first time with no
dialect changes.

### Development seed data
An idempotent, transactional seed: 3 CMS users, 6 categories, 12
subcategories, 5 public authors, 20 posts.

---

## The defects that mattered most

1. **Every CMS account was an administrator.** An implicit role fallback made
   RBAC decorative. Nothing in the code looked wrong; the bug was in what the
   code *didn't* do.
2. **31 admin endpoints had no authentication.** Including an anonymous path to
   administrator.
3. **`sequelize.sync()` was corrupting the schema at boot**, creating fake base
   tables that shadowed the views the public site depended on.
4. **Stack traces and SQL were being returned to clients** whenever `NODE_ENV`
   was unset.
5. **Published posts were silently missing from the sitemap** — invisible to
   search engines, and invisible in testing too, because nothing errored.
6. **Zero foreign keys**, so nothing prevented orphaned or contradictory rows.
7. **CMS logins were being served as public author profiles.**

Four of these seven produced no error message of any kind. They were found by
asking what the code should be doing, not by watching it fail.

---

## Corrections made along the way

Worth recording, because being wrong in public is part of the record:

- My Phase C recommendation to keep authors inside `users` was **wrong**. You
  corrected it, and the separation became the spine of the architecture.
- I twice misread the legacy schema in Phase 5 and corrected both claims.
- In D6 I reported five test failures on `/api/admin/posts` before checking the
  actual response contract — it returns a DataTables envelope, and my
  assertion was wrong, not the application.
- During the seed verification, an assertion "failed" because three post slugs
  legitimately contain the word `content`. My substring check was sloppy; the
  API was correct.

In each case the fix was the test or the assumption, never a weakened check.

---

## What the system enforces now

**CMS users are not public authors.** Separate tables, no link, no
`authors.user_id`. An author needs no login; a post's `author_id` points at
`authors` while `created_by`/`updated_by` point at `users`.

**The public API is genuinely public.** No auth middleware exists anywhere
under `/api/website/*`, and publication filtering is server-side — the website
never decides what is safe to show.

**Authorization is read fresh every request.** The JWT carries identity only.
Revoking a role takes effect on the next request, not when the token expires.
Forged role claims in a signed token are ignored.

**Nobody can raise their own privileges.** Every route that writes
authorization requires `role_management` *and* refuses to target the caller's
own account.

**Nobody can lock everyone out.** An operation that would leave no active
account able to manage users and roles is refused with `409`.

**Editing is not publishing.** `post_management` drafts; `post_publishing` puts
live; `status` is not writable through the update route.

**Deleting a person never deletes content.** Every audit foreign key is
`ON DELETE SET NULL`.

---

## Final state

```
Node v22.13.1 · MySQL 8.4.7 · Sequelize 6.37.7 · mysql2 3.16.2
127.0.0.1:3306 / datademand

Schema      14 tables · 15 foreign keys · 3 CHECK constraints
            all InnoDB · all utf8mb4 · 0 views · 12/12 migrations · 0 pending
API         105 endpoints — 15 public · 51 admin · 39 deprecated aliases
Tests       801 assertions · 15 suites · 0 failed · 0 skipped · ~58s
Seed        3 users · 5 authors · 6 categories · 12 subcategories · 20 posts
```

Live probes: public `200`, admin without a token `401`, legacy admin without a
token `401`.

## Known intentional items

Eight, all documented with the reasoning and the conditions under which they
should change, in
[ARCHITECTURE-DECISIONS.md](ARCHITECTURE-DECISIONS.md). The main ones: the
permissive local `sql_mode` (compatibility proven by test instead), the
retained DataTables envelope on `/api/admin/posts`, and the legacy route
aliases.

## Where to read next

| Document | For |
|---|---|
| [API-REFERENCE.md](API-REFERENCE.md) | Every endpoint, both surfaces, in one list |
| [PUBLIC-API-CONTRACT.md](PUBLIC-API-CONTRACT.md) | The frontend developer |
| [ADMIN-API.md](ADMIN-API.md) | The CMS developer |
| [AUTH-AND-RBAC.md](AUTH-AND-RBAC.md) | Anyone touching authentication or permissions |
| [ARCHITECTURE-DECISIONS.md](ARCHITECTURE-DECISIONS.md) | Anyone about to "fix" something odd |
| [../README.md](../README.md) | Setting the project up |
