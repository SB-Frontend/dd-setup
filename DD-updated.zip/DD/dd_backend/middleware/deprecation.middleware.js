// middleware/deprecation.middleware.js
//
// Marks the pre-Phase-1 flat routes as deprecated without changing their
// behaviour. Response bodies are untouched; only advisory headers are added.
//
// These legacy mounts stay in place until the Next.js website and the CMS
// frontend have both moved to /api/website/* and /api/admin/*.

module.exports = function deprecated(replacement) {
  return function markDeprecated(req, res, next) {
    res.set("Deprecation", "true");
    res.set("X-API-Deprecated", "true");
    res.set("X-API-Replaced-By", replacement);

    next();
  };
};
