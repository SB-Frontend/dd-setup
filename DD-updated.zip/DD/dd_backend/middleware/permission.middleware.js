// middleware/permission.middleware.js
//
// Authorization for the admin/CMS surface. Always runs AFTER authenticate.
//
// MUST NOT be mounted on /api/website/* - those routes are public by design.
//
// Phase 3: denials are handed to next() as ApiError so every error response
// is produced in middleware/error.middleware.js. The client-visible body is
// unchanged in production.

const ApiError = require("../utils/ApiError");
const { hasPermission } = require("../config/permissions");

// Guards against a route being wired with permissions but without
// authenticate in front of it. Fails closed rather than allowing through.
function requireAuthenticated(req, next) {
  if (!req.user) {
    next(ApiError.unauthorized("No authentication token provided."));

    return false;
  }

  return true;
}

// ==========================================
// authorize(...permissions)
//
// Passes when the caller's role grants EVERY listed permission.
// ==========================================
function authorize(...required) {
  return function checkPermission(req, res, next) {
    if (!requireAuthenticated(req, next)) return;

    const missing = required.filter(
      (permission) => !hasPermission(req.user.permissions, permission)
    );

    if (missing.length > 0) {
      return next(
        ApiError.forbidden("You do not have permission to perform this action.")
      );
    }

    return next();
  };
}

// ==========================================
// allowSelfOr(permission, [param])
//
// Lets a user act on their own record without holding the permission, while
// still requiring it to act on anyone else.
//
// This is the fix for the pre-Phase-2 IDOR: PUT /users/:id previously let any
// authenticated user edit any other user, including resetting an admin's
// password.
// ==========================================
function allowSelfOr(permission, param = "id") {
  return function checkSelfOrPermission(req, res, next) {
    if (!requireAuthenticated(req, next)) return;

    const targetId = Number(req.params[param]);
    const callerId = Number(req.user.id);

    const isSelf =
      Number.isInteger(targetId) &&
      Number.isInteger(callerId) &&
      targetId === callerId;

    if (isSelf) return next();

    if (hasPermission(req.user.permissions, permission)) return next();

    return next(
      ApiError.forbidden("You do not have permission to modify other users.")
    );
  };
}

// ==========================================
// denySelfTarget([param], [message])
//
// Blocks destructive operations against your own account, so an operator
// cannot lock themselves (or the last admin) out of the CMS.
// ==========================================
function denySelfTarget(
  param = "id",
  message = "You cannot perform this action on your own account."
) {
  return function checkNotSelf(req, res, next) {
    if (!requireAuthenticated(req, next)) return;

    const targetId = Number(req.params[param]);
    const callerId = Number(req.user.id);

    if (Number.isInteger(targetId) && targetId === callerId) {
      return next(ApiError.forbidden(message));
    }

    return next();
  };
}

// ==========================================
// allowFirstUserOr(...chain)
//
// Bootstrap escape hatch for user creation.
//
// Protecting POST /auth/register with users.create is correct, but it makes
// an empty users table unrecoverable through the API: there is nobody to
// authenticate as in order to create the first account. This allows exactly
// one unauthenticated registration while the users table is empty, then
// closes permanently on its own.
//
// It fails CLOSED: if the count query errors, the normal protected chain runs.
//
// D4: the bootstrap account is granted the `admin` role in the database by
// controllers/user.controller.js, so it authorises through the normal
// user_roles -> roles -> role_permissions chain like everyone else. There is
// no hardcoded "user id 1 is admin" bypass anywhere in the application.
// ==========================================
function allowFirstUserOr(...chain) {
  return async function checkBootstrap(req, res, next) {
    // A client-supplied value must never look like the server's own flag.
    delete req.isBootstrap;

    // Required lazily so this module does not pull in models unless used.
    const User = require("../models/user.model");

    let isBootstrap = false;

    try {
      isBootstrap = (await User.count()) === 0;
    } catch (error) {
      console.error("Bootstrap check failed:", error);
      isBootstrap = false;
    }

    if (isBootstrap) {
      console.warn(
        "[auth] users table is empty - allowing unauthenticated bootstrap registration"
      );

      // The controller reads this to grant the first account the bootstrap
      // role in the same transaction that creates it. Set on the request by
      // the server, never accepted from the client: a body field of the same
      // name would be ignored because the controller only reads req.
      req.isBootstrap = true;

      return next();
    }

    // Run the protected chain in order, stopping if any layer responds or
    // passes an error along.
    let index = 0;

    const runNext = (err) => {
      if (err) return next(err);
      if (index >= chain.length) return next();

      const layer = chain[index++];

      return layer(req, res, runNext);
    };

    return runNext();
  };
}

module.exports = {
  authorize,
  allowSelfOr,
  denySelfTarget,
  allowFirstUserOr,
};
