// middleware/uploadAuthorImage.js
//
// The hardened uploader for author profile images, as a single shared
// instance. Route files import this rather than calling createUploader()
// themselves, so every author upload goes through one configuration.
//
// Writes to uploads/author. See middleware/upload.middleware.js for the
// extension, MIME and magic-byte checks.

const { createUploader } = require("./upload.middleware");

module.exports = createUploader("author");
