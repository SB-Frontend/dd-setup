// middleware/sanitize.middleware.js
//
// Allowlist sanitisation of request bodies, applied at the route.
//
// Doing it here rather than inside controllers keeps the business logic
// untouched and makes the policy visible next to the route it protects.
//
// ORDERING: on multipart routes this MUST come after multer, because until
// multer has run there is no req.body to sanitise.

const sanitizeHtml = require("sanitize-html");

const { PROFILES, FIELDS } = require("../config/sanitize");

function sanitizeValue(value, profileName) {
  if (typeof value !== "string") return value;

  const build = PROFILES[profileName];

  if (!build) throw new Error(`Unknown sanitize profile: ${profileName}`);

  return sanitizeHtml(value, build());
}

/**
 * sanitizeBody({ post_content: "rich", post_title: "plain" })
 *
 * Only fields present in the body are touched, so a partial update stays
 * partial: an absent field is not created as an empty string.
 */
function sanitizeBody(fieldMap) {
  return function sanitizeRequestBody(req, res, next) {
    if (!req.body || typeof req.body !== "object") return next();

    try {
      for (const [field, profile] of Object.entries(fieldMap)) {
        if (!Object.prototype.hasOwnProperty.call(req.body, field)) continue;

        const original = req.body[field];

        if (typeof original !== "string") continue;

        const cleaned = sanitizeValue(original, profile);

        if (cleaned !== original) {
          console.warn(
            `[sanitize] ${req.method} ${req.originalUrl} field "${field}" was modified ` +
              `(${original.length} -> ${cleaned.length} chars)`
          );
        }

        req.body[field] = cleaned;
      }

      return next();
    } catch (error) {
      return next(error);
    }
  };
}

// Convenience wrappers so route files read as intent rather than field lists.
const sanitize = {
  post: () => sanitizeBody(FIELDS.post),
  author: () => sanitizeBody(FIELDS.author),
  category: () => sanitizeBody(FIELDS.category),
  subcategory: () => sanitizeBody(FIELDS.subcategory),
  user: () => sanitizeBody(FIELDS.user),
  role: () => sanitizeBody(FIELDS.role),
  media: () => sanitizeBody(FIELDS.media),
  leadComment: () => sanitizeBody(FIELDS.leadComment),
  publicLead: () => sanitizeBody(FIELDS.publicLead),
  publicSubscribe: () => sanitizeBody(FIELDS.publicSubscribe),
};

module.exports = { sanitizeBody, sanitizeValue, sanitize };
