// middleware/queryAsBody.middleware.js
//
// Adapter for list endpoints whose controllers read their parameters from
// `req.body` (they were originally exposed as POST, DataTables-style).
//
// Express 5 leaves `req.body` undefined on GET requests, so those controllers
// would throw `TypeError: Cannot destructure property 'page' of 'req.body'`
// if mounted directly on a GET route.
//
// This lets the same controller serve both GET (query string) and POST (body)
// without touching any controller code.
//
// Phase 1: routing-layer adapter only.
// Later: move list parameters into a validation layer and read req.query
//        directly, then delete this file.

module.exports = function queryAsBody(req, res, next) {
  if (req.method === "GET" || req.method === "HEAD") {
    req.body = { ...req.query };
  }

  next();
};
