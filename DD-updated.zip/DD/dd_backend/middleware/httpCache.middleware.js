// middleware/httpCache.middleware.js
//
// Cache-Control for public website reads.
//
// These endpoints are anonymous and identical for every visitor, so they are
// safe to cache in a CDN or reverse proxy. Nothing here is applied to
// /api/admin/*, which must never be cached.
//
// stale-while-revalidate lets a proxy serve the previous copy while it
// refreshes in the background, so a cache expiry never becomes a latency
// spike for a visitor.

function publicCache(seconds, staleSeconds) {
  const stale = staleSeconds === undefined ? seconds * 5 : staleSeconds;

  return function setCacheControl(req, res, next) {
    // Only cache safe, successful reads. A write or an error must not be
    // stored by an intermediary.
    if (req.method === "GET" || req.method === "HEAD") {
      res.set(
        "Cache-Control",
        `public, max-age=${seconds}, stale-while-revalidate=${stale}`
      );
      res.set("Vary", "Accept-Encoding");
    } else {
      res.set("Cache-Control", "no-store");
    }

    next();
  };
}

// Sensible defaults per content class, kept in one place so they can be
// tuned without hunting through route files.
const CACHE = {
  postList: publicCache(60, 300),
  postDetail: publicCache(300, 1800),
  taxonomy: publicCache(600, 3600),
  sitemap: publicCache(3600, 21600),
  authors: publicCache(600, 3600),
};

module.exports = { publicCache, CACHE };
