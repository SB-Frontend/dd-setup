// middleware/rateLimit.middleware.js
//
// Per-surface rate limits.
//
// One global limit would be wrong here: a login attempt and a website page
// render have nothing in common. Four limiters are defined instead, each
// tuned to what the endpoint actually costs and what abusing it would buy.
//
// ONE THING TO WATCH IN PRODUCTION
// If the Next.js site renders on the server, every website API call arrives
// from a single IP - the Next.js host - and a per-IP limit would throttle the
// entire site at once. Two escape hatches exist:
//   RATE_LIMIT_ALLOWLIST=10.0.0.5,10.0.0.6   bypass for known infrastructure
//   TRUST_PROXY=1                            key on the real client IP
// The website read limit is also set high for this reason.

const { rateLimit, ipKeyGenerator } = require("express-rate-limit");

const ApiError = require("../utils/ApiError");

const MINUTE = 60 * 1000;

const num = (value, fallback) => {
  const n = Number(value);

  return Number.isFinite(n) && n > 0 ? n : fallback;
};

function allowlist() {
  return String(process.env.RATE_LIMIT_ALLOWLIST || "")
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean);
}

const disabled = () => process.env.RATE_LIMIT_DISABLED === "true";

// Rejections go through next() so they get the same JSON envelope as every
// other error, instead of the library default text body.
function limitHandler(req, res, next) {
  next(
    new ApiError(429, "Too many requests. Please slow down and try again shortly.", {
      error: "Too Many Requests",
    })
  );
}

function createLimiter({ windowMs, limit, name, byUser = false }) {
  return rateLimit({
    windowMs,
    limit,

    // draft-8 sends the combined RateLimit header.
    standardHeaders: "draft-8",
    legacyHeaders: false,

    // For authenticated traffic, key on the user. A whole office behind one
    // NAT address would otherwise share a single admin budget.
    keyGenerator: (req) => {
      if (byUser && req.user && req.user.id) return `user:${req.user.id}`;

      // ipKeyGenerator takes the IP string (not the request) and normalises
      // IPv6 into a subnet, so a client cannot walk addresses within its own
      // prefix to reset the counter. req.ip can be undefined on a socket with
      // no remote address, so fall back to a constant bucket.
      return ipKeyGenerator(req.ip || "unknown");
    },

    skip: (req) => {
      if (disabled()) return true;

      const list = allowlist();

      if (list.length > 0 && list.includes(req.ip)) return true;

      // Preflight carries no credentials and does nothing expensive.
      return req.method === "OPTIONS";
    },

    handler: limitHandler,

    // Surfaces in logs as the limiter that fired.
    identifier: name,
  });
}

// ==========================================
// LIMITERS
// ==========================================

// Login and registration. Deliberately tight: this is the brute-force
// surface, and bcrypt makes each attempt expensive for the server too.
const authLimiter = createLimiter({
  name: "auth",
  windowMs: num(process.env.RATE_LIMIT_AUTH_WINDOW_MS, 15 * MINUTE),
  limit: num(process.env.RATE_LIMIT_AUTH_MAX, 10),
});

// Public writes: the website contact form and newsletter signup. Anonymous
// and they insert rows, so they are the spam surface.
const publicWriteLimiter = createLimiter({
  name: "public-write",
  windowMs: num(process.env.RATE_LIMIT_PUBLIC_WRITE_WINDOW_MS, 15 * MINUTE),
  limit: num(process.env.RATE_LIMIT_PUBLIC_WRITE_MAX, 10),
});

// Public website reads. Generous on purpose - normal browsing, and possibly
// a whole site rendering from one server address, must never be throttled.
const websiteReadLimiter = createLimiter({
  name: "website-read",
  windowMs: num(process.env.RATE_LIMIT_WEBSITE_WINDOW_MS, MINUTE),
  limit: num(process.env.RATE_LIMIT_WEBSITE_MAX, 600),
});

// Authenticated admin traffic, keyed per user.
const adminLimiter = createLimiter({
  name: "admin",
  windowMs: num(process.env.RATE_LIMIT_ADMIN_WINDOW_MS, 15 * MINUTE),
  limit: num(process.env.RATE_LIMIT_ADMIN_MAX, 600),
  byUser: true,
});

module.exports = {
  createLimiter,
  authLimiter,
  publicWriteLimiter,
  websiteReadLimiter,
  adminLimiter,
  allowlist,
  disabled,
};
