// middleware/error.middleware.js
//
// Centralised error handling. Mounted last in server.js, after all routes.
//
// DISCLOSURE POLICY
// -----------------
// Only ApiError instances are considered client-safe. Every other error is
// translated into a curated status + message here; its raw text never reaches
// the client in production.
//
// Specifically never sent to a client in production:
//   * stack traces
//   * err.sql / err.parameters  (Sequelize puts the full query on the error)
//   * err.original / err.parent (raw mysql2 driver errors)
//   * filesystem paths (ENOENT etc. carry absolute paths)
//   * connection / credential details
//
// Verbose output requires NODE_ENV === "development" explicitly. An unset
// NODE_ENV is treated as production, so a deployment that forgets to set it
// fails safe. This is deliberately stricter than the Express default, which
// treats unset as development.

const ApiError = require("../utils/ApiError");

const isDevelopment = () => process.env.NODE_ENV === "development";

// Sequelize validation messages read "Post.post_title cannot be null".
// The field name is useful to a client; the model name is internal.
function stripModelPrefix(message) {
  return String(message).replace(/^[A-Za-z0-9_]+\./, "");
}

function fieldErrors(err) {
  if (!Array.isArray(err.errors)) return undefined;

  return err.errors.map((e) => ({
    field: e.path,
    message: stripModelPrefix(e.message),
  }));
}

// ==========================================
// TRANSLATION
// Maps a raw error onto { statusCode, error, message, details }.
// ==========================================
function translate(err) {
  // Already client-safe.
  if (err instanceof ApiError) {
    return {
      statusCode: err.statusCode,
      error: err.error || "Error",
      message: err.message,
      details: err.details,
    };
  }

  // ---- multer / busboy ----
  if (err.name === "MulterError") {
    const map = {
      LIMIT_FILE_SIZE: [413, "Uploaded file is too large."],
      LIMIT_FIELD_VALUE: [413, "A form field exceeded the maximum size."],
      LIMIT_FILE_COUNT: [400, "Too many files uploaded."],
      LIMIT_FIELD_COUNT: [400, "Too many form fields."],
      LIMIT_PART_COUNT: [400, "Too many form parts."],
      LIMIT_UNEXPECTED_FILE: [400, "Unexpected file field."],
      LIMIT_FIELD_KEY: [400, "A form field name was too long."],
    };

    const [status, message] = map[err.code] || [400, "File upload failed."];

    // err.field is a client-supplied field name, safe to echo back.
    return {
      statusCode: status,
      error: "Upload Failed",
      message,
      details: err.field ? { field: err.field } : undefined,
    };
  }

  // fileFilter rejections are plain Errors thrown by our own middleware.
  if (/only .*(images|allowed)/i.test(err.message || "")) {
    return {
      statusCode: 400,
      error: "Upload Failed",
      message: err.message,
    };
  }

  // ---- body-parser ----
  if (err.type === "entity.parse.failed") {
    return {
      statusCode: 400,
      error: "Bad Request",
      message: "Request body is not valid JSON.",
    };
  }

  if (err.type === "entity.too.large") {
    return {
      statusCode: 413,
      error: "Payload Too Large",
      message: "Request body is too large.",
    };
  }

  // ---- Sequelize ----
  // Field names are part of the API contract, so they are echoed. SQL text,
  // driver errors and connection details are not.
  if (err.name === "SequelizeValidationError") {
    return {
      statusCode: 400,
      error: "Validation Failed",
      message: "One or more fields are invalid.",
      details: fieldErrors(err),
    };
  }

  if (err.name === "SequelizeUniqueConstraintError") {
    return {
      statusCode: 409,
      error: "Conflict",
      message: "A record with these values already exists.",
      details: fieldErrors(err),
    };
  }

  if (err.name === "SequelizeForeignKeyConstraintError") {
    return {
      statusCode: 409,
      error: "Conflict",
      message: "This record is referenced by other data.",
    };
  }

  if (
    err.name === "SequelizeConnectionError" ||
    err.name === "SequelizeConnectionRefusedError" ||
    err.name === "SequelizeHostNotFoundError" ||
    err.name === "SequelizeAccessDeniedError" ||
    err.name === "SequelizeConnectionTimedOutError" ||
    err.name === "SequelizeConnectionAcquireTimeoutError"
  ) {
    // Never echo the message: it can contain host, port, user and database.
    return {
      statusCode: 503,
      error: "Service Unavailable",
      message: "The service is temporarily unavailable. Please try again.",
    };
  }

  // SequelizeDatabaseError carries err.sql and err.parameters. Generic only.
  if (typeof err.name === "string" && err.name.startsWith("Sequelize")) {
    return {
      statusCode: 500,
      error: "Internal Server Error",
      message: "A database error occurred.",
    };
  }

  // ---- filesystem ----
  // err.path is an absolute server path, so it is never included.
  if (err.code === "ENOENT" || err.code === "EACCES" || err.code === "EPERM") {
    return {
      statusCode: 500,
      error: "Internal Server Error",
      message: "The server could not access a required storage location.",
    };
  }

  // ---- anything with an explicit status ----
  if (Number.isInteger(err.status) && err.status >= 400 && err.status < 600) {
    return {
      statusCode: err.status,
      error: err.status < 500 ? "Bad Request" : "Internal Server Error",
      message:
        err.status < 500 ? "The request could not be processed." : "An unexpected error occurred.",
    };
  }

  // ---- unknown ----
  return {
    statusCode: 500,
    error: "Internal Server Error",
    message: "An unexpected error occurred.",
  };
}

// ==========================================
// 404 - unknown route
// Mounted after all routers, before the error handler.
// ==========================================
function notFoundHandler(req, res, next) {
  next(
    ApiError.notFound(
      `Route ${req.method} ${req.originalUrl} does not exist.`
    )
  );
}

// ==========================================
// TERMINAL ERROR HANDLER
// Must keep all four parameters, or Express will not treat it as one.
// ==========================================
function errorHandler(err, req, res, next) {
  const { statusCode, error, message, details } = translate(err);

  // Full detail always goes to the server log, never to the client.
  const logLine = `[error] ${req.method} ${req.originalUrl} -> ${statusCode}`;

  if (statusCode >= 500) {
    console.error(logLine, err);
  } else {
    console.warn(logLine, err.message);
  }

  // Streaming already started; hand back to Express to destroy the socket.
  if (res.headersSent) return next(err);

  const body = {
    success: false,
    error,
    message,
  };

  if (details) body.details = details;

  if (isDevelopment()) {
    body.debug = {
      name: err.name,
      message: err.message,
      stack: String(err.stack || "").split("\n").slice(0, 12),
    };
  }

  return res.status(statusCode).json(body);
}

module.exports = { notFoundHandler, errorHandler, translate };
