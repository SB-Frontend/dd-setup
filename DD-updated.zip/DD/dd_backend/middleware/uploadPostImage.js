// middleware/uploadPostImage.js
//
// The hardened uploader for post banners AND for the media library, as a
// single shared instance.
//
// Both write to uploads/posts, which is where the existing media rows already
// point. See middleware/upload.middleware.js for the extension, MIME and
// magic-byte checks.

const { createUploader } = require("./upload.middleware");

module.exports = createUploader("posts");
