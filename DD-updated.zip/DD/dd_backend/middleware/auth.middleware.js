// middleware/auth.middleware.js
//
// JWT authentication for the admin/CMS surface.
//
// MUST NOT be mounted on /api/website/* - those routes are public by design.
//
// This is the only authentication implementation in the codebase. The
// misspelled middlewear/ directory that once shimmed it was removed in D7.
//
// Phase 3: failures are handed to next() as ApiError rather than being
// written here, so every error response in the application is produced in one
// place (middleware/error.middleware.js). The client-visible body is
// unchanged in production.

const User = require("../models/user.model");
const ApiError = require("../utils/ApiError");
const { resolveUserAccess } = require("../config/permissions");
const { verifyAccessToken } = require("../utils/jwt");

// ==========================================
// TOKEN EXTRACTION
// ==========================================
function extractToken(req) {
  const header = req.headers.authorization;

  if (!header || !header.startsWith("Bearer ")) return null;

  const token = header.slice(7).trim();

  return token.length > 0 ? token : null;
}

// ==========================================
// AUTHENTICATE
// ==========================================
async function authenticate(req, res, next) {
  const token = extractToken(req);

  // Missing token
  if (!token) {
    return next(ApiError.unauthorized("No authentication token provided."));
  }

  let decoded;

  try {
    // Pinned algorithm plus issuer and audience checks live in utils/jwt.
    decoded = verifyAccessToken(token);
  } catch (error) {
    // Expired token
    if (error.name === "TokenExpiredError") {
      return next(
        ApiError.unauthorized("Your session has expired. Please log in again.")
      );
    }

    // Invalid token (bad signature, malformed, wrong algorithm)
    return next(ApiError.unauthorized("Invalid authentication credentials."));
  }

  try {
    // The token only identifies the user. Everything else comes from the DB,
    // so a token issued before deactivation or deletion stops working.
    const user = await User.findByPk(decoded.id);

    if (!user) {
      return next(ApiError.unauthorized("Invalid authentication credentials."));
    }

    if (Number(user.status) !== 1) {
      return next(ApiError.unauthorized("This account is no longer active."));
    }

    // Roles and permissions are resolved from the database on every request:
    //   user_roles -> roles -> role_permissions -> permissions
    // so a permission change takes effect immediately instead of waiting for
    // the token to expire. Nothing about authorization comes from the token or
    // from the request body - since D4 an account with no roles has no
    // permissions, and there is no implicit role to fall back on.
    const access = await resolveUserAccess(user);

    // CMS account only. There is deliberately no author profile here - a CMS
    // user is not a public author. See models/author.model.js.
    //
    // No password hash, and nothing the client sent. This object is internal:
    // it is never serialised onto a public website response.
    req.user = {
      id: user.id,
      username: user.username,
      full_name: user.full_name,
      email: user.email,
      status: Number(user.status),

      // roles     - role slugs held, for display and logging
      // modules   - module permission slugs granted (the CMS UI vocabulary)
      // permissions - action slugs, what authorize() actually checks
      roles: access.roles,
      modules: access.modules,
      permissions: access.permissions,
    };

    return next();
  } catch (error) {
    // Unexpected failure (database down, etc). The error middleware decides
    // what is safe to disclose.
    return next(error);
  }
}

module.exports = { authenticate, extractToken };
