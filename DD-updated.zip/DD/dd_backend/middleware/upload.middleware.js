// middleware/upload.middleware.js
//
// Hardened multer configuration. Replaces the two ad-hoc configs that once
// lived in the misspelled middlewear/ directory (removed in D7),
// which now re-export from here so there is one implementation.
//
// What changed and why:
//
//  * limits        there were none. fileSize was unbounded, and the busboy
//                  default fieldSize of 1 MB silently aborted long
//                  post_content with LIMIT_FIELD_VALUE.
//  * destinations  uploads/author did not exist, so every author photo upload
//                  failed with ENOENT. Directories are created at load.
//  * fileFilter    the old regex /jpeg|jpg|png|webp/ was UNANCHORED and tested
//                  against the client-supplied mimetype and filename, so
//                  "evil.jpg.php" and a forged Content-Type both passed.
//  * filenames     Date.now() alone collided within a millisecond and
//                  preserved every inner dot, so double extensions survived.
//  * signature     nothing looked inside the file. Content is now checked
//                  against the real byte signature and deleted if it lies.
//  * cleanup       a rejected or failed request left its file on disk forever.
//
// Stored value format is unchanged: controllers still persist the bare
// filename, which is what media.filename, posts.banner_image and
// authors.image all hold.

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const multer = require("multer");

const ApiError = require("../utils/ApiError");
const {
  DESTINATIONS,
  LIMITS,
  ALLOWED_EXTENSIONS,
  findByExtension,
} = require("../config/uploads");

// ==========================================
// DIRECTORIES
// Created once at load. Previously uploads/author simply did not exist.
// ==========================================
function ensureDirectories() {
  for (const dir of Object.values(DESTINATIONS)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

ensureDirectories();

// ==========================================
// FILENAMES
//
// Every dot is stripped from the base name and exactly one canonical
// extension is appended, so "shell.php.jpg" becomes
// "<ts>-<random>-shell-php.jpg" and can never carry a second extension.
//
// 8 random bytes make same-millisecond collisions effectively impossible.
// The previous Date.now() scheme silently overwrote concurrent uploads.
// ==========================================
function safeFilename(originalName, entry) {
  const raw = String(originalName || "file");

  const base = path
    .basename(raw, path.extname(raw))
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);

  const stamp = Date.now();
  const random = crypto.randomBytes(8).toString("hex");

  return `${stamp}-${random}-${base || "file"}${entry.ext}`;
}

// ==========================================
// FILTER
// Extension, declared MIME type, and the agreement between them.
// The bytes themselves are checked later by verifySignature.
// ==========================================
function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname || "").toLowerCase();
  const entry = findByExtension(ext);

  if (!entry) {
    return cb(
      ApiError.badRequest(
        `Unsupported file type. Allowed extensions: ${ALLOWED_EXTENSIONS.join(", ")}`
      )
    );
  }

  const mime = String(file.mimetype || "").toLowerCase();

  // The declared type must be one this extension is allowed to carry, which
  // blocks a .jpg announced as application/x-httpd-php and vice versa.
  if (!entry.mimes.includes(mime)) {
    return cb(
      ApiError.badRequest(
        `File content type "${file.mimetype}" does not match the "${ext}" extension.`
      )
    );
  }

  file._uploadPolicy = entry;

  return cb(null, true);
}

// ==========================================
// SIGNATURE VERIFICATION
//
// The upload is buffered in memory and only written to disk once its bytes
// have been confirmed to be a real image.
//
// The first attempt used diskStorage and re-opened the written file to check
// it. That is worse in two ways: a forged file briefly exists on disk, and
// re-opening it immediately after multer closes it fails with EPERM on
// Windows while an antivirus scanner still holds the handle. Buffering first
// removes both problems, and limits.fileSize bounds the memory used.
// ==========================================
function matchesMagic(buffer, entry) {
  const startsWith = entry.magic.some((sig) =>
    sig.every((byte, i) => buffer[i] === byte)
  );

  if (!startsWith) return false;

  // WEBP additionally carries "WEBP" at offset 8.
  if (entry.magicAt8) {
    return entry.magicAt8.every((byte, i) => buffer[8 + i] === byte);
  }

  return true;
}

function persistUpload(destinationKey) {
  return async function persist(req, res, next) {
    if (!req.file || !req.file.buffer) return next();

    const entry =
      req.file._uploadPolicy ||
      findByExtension(path.extname(req.file.originalname));

    // Nothing is written unless the bytes themselves prove the file is the
    // image type it claims to be.
    if (!entry || req.file.buffer.length < 4 || !matchesMagic(req.file.buffer, entry)) {
      console.warn(
        `[upload] rejected ${req.file.originalname}: content is not a valid image`
      );

      return next(
        ApiError.badRequest(
          "The uploaded file is not a valid image. Its contents do not match its extension."
        )
      );
    }

    try {
      const dir = DESTINATIONS[destinationKey];

      fs.mkdirSync(dir, { recursive: true });

      const filename = safeFilename(req.file.originalname, entry);
      const destination = path.join(dir, filename);

      // "wx" fails if the path already exists, so a collision can never
      // silently overwrite an existing upload.
      await fs.promises.writeFile(destination, req.file.buffer, { flag: "wx" });

      // Shape req.file the way diskStorage would have, so controllers that
      // read req.file.filename keep working unchanged, and so the cleanup
      // hook can find the file by path.
      req.file.filename = filename;
      req.file.path = destination;
      req.file.destination = dir;

      // Release the buffer promptly rather than holding it for the request.
      delete req.file.buffer;

      return next();
    } catch (error) {
      return next(error);
    }
  };
}

// ==========================================
// CLEANUP ON FAILURE
//
// Mounted once, before the routes. Any response that ends 4xx/5xx removes the
// file the request uploaded, so a duplicate-slug 409, a validation error or a
// database failure no longer leaves an orphan on disk.
// ==========================================
function cleanupFailedUploads(req, res, next) {
  let done = false;

  const remove = () => {
    if (done) return;
    done = true;

    if (res.statusCode < 400) return;

    const files = [];

    if (req.file) files.push(req.file);
    if (Array.isArray(req.files)) files.push(...req.files);

    for (const file of files) {
      if (!file || !file.path) continue;

      fs.promises.unlink(file.path).then(
        () =>
          console.warn(
            `[upload] removed orphaned file after ${res.statusCode}: ${file.filename}`
          ),
        (error) => {
          if (error.code !== "ENOENT") {
            console.error("[upload] cleanup failed:", error.message);
          }
        }
      );
    }
  };

  res.on("finish", remove);
  res.on("close", remove);

  return next();
}

// ==========================================
// UPLOADER
//
// .single() returns [multer, verifySignature]. Express flattens arrays of
// handlers, so all ten existing call sites keep working unchanged while
// gaining signature verification.
// ==========================================
function createUploader(destinationKey) {
  const instance = multer({
    storage: multer.memoryStorage(),
    fileFilter,
    limits: LIMITS,
  });

  const persist = persistUpload(destinationKey);

  return {
    single(field) {
      return [instance.single(field), persist];
    },
    none() {
      return [instance.none()];
    },
    _multer: instance,
  };
}

module.exports = {
  createUploader,
  cleanupFailedUploads,
  persistUpload,
  safeFilename,
  matchesMagic,
  ensureDirectories,
};
