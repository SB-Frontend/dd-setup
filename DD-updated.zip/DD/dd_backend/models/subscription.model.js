// models/subscription.model.js
//
// Newsletter signups. Anonymous: no relationship to users or authors.
//
// Not paranoid, deliberately. A subscriber may ask for their data to be
// erased, and a soft delete would keep it. Opting out is modelled with
// status + unsubscribed_at instead, which preserves the proof that they
// unsubscribed without hiding a row that was asked to be removed.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const Subscription = sequelize.define(
  "Subscription",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    email: {
      type: DataTypes.STRING(254),
      allowNull: false,
      unique: true,
      validate: { isEmail: true },
    },

    name: { type: DataTypes.STRING(150), allowNull: true },

    status: {
      type: DataTypes.STRING(20),
      allowNull: false,
      defaultValue: "subscribed",
      validate: { isIn: [["subscribed", "unsubscribed"]] },
    },

    unsubscribed_at: { type: DataTypes.DATE, allowNull: true },
  },
  {
    tableName: "subscriptions",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: false,
  }
);

module.exports = Subscription;
