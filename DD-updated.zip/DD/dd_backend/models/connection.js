// models/connection.js
//
// The Sequelize instance, and nothing else.
//
// It lives in its own module so that model files can depend on it without a
// cycle. Previously the instance and the association wiring shared
// models/index.js, which produced:
//
//   post.model -> index -> associations -> post.model (still executing)
//
// and Author.hasMany() then received a half-initialised module. Splitting the
// connection out removes the cycle entirely:
//
//   index -> associations -> each model -> connection      (a plain tree)

const { Sequelize } = require("sequelize");
require("dotenv").config();

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT) || 3306,
    dialect: "mysql",
    logging: false,

    // Store and read DATETIME as UTC. Previously unset, which left every
    // timestamp at the mercy of whatever zone the app server ran in.
    timezone: "+00:00",
  }
);

module.exports = sequelize;
