// models/subcategory.model.js
//
// Replaces the legacy p_sub_cat table.
//   subcat_id -> id   subcat_name -> name   subcat_slug -> slug
//   p_cat     -> category_id   (a foreign key named after a table, fixed)
//
// slug is unique WITHIN a category, not globally: two categories may each
// legitimately have a "tools" subcategory and public URLs are
// /{category}/{subcategory}.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const Subcategory = sequelize.define(
  "Subcategory",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    category_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },

    name: { type: DataTypes.STRING(100), allowNull: false },
    slug: { type: DataTypes.STRING(120), allowNull: false },

    status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 1 },

    meta_title: { type: DataTypes.STRING(255), allowNull: true },
    meta_description: { type: DataTypes.STRING(500), allowNull: true },
    meta_keywords: { type: DataTypes.STRING(255), allowNull: true },
  },
  {
    tableName: "subcategories",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: true,
    deletedAt: "deleted_at",
    indexes: [{ unique: true, fields: ["category_id", "slug"] }],
  }
);

module.exports = Subcategory;
