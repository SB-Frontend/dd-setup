// models/index.js
//
// Entry point for the data layer. Still exports the Sequelize instance
// directly, so every existing `require("../models")` keeps working unchanged.
//
// Requiring this file also loads every model and wires all associations, so
// `include` is available to anything that has the instance.
//
// Load order is a plain tree, no cycles:
//   index -> associations -> each model -> connection

const sequelize = require("./connection");

// Registers all models on the instance and defines the relationships.
require("./associations");

module.exports = sequelize;
