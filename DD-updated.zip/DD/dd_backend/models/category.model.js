// models/category.model.js
//
// Replaces the legacy p_cat table.
//   cat_id   -> id        cat_name  -> name       cat_slug  -> slug
//   meta_desc -> meta_description  (matches posts and subcategories)
//
// Paranoid: posts reference categories, so removing one must be reversible.
// NOTE: a soft delete is an UPDATE, so it does not trip the RESTRICT foreign
// key from posts.category_id. Blocking the soft delete of a category that
// still owns posts is an application-level check.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const Category = sequelize.define(
  "Category",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    name: { type: DataTypes.STRING(100), allowNull: false },
    slug: { type: DataTypes.STRING(120), allowNull: false, unique: true },

    // 1 = visible, 0 = hidden
    status: { type: DataTypes.TINYINT, allowNull: false, defaultValue: 1 },

    meta_title: { type: DataTypes.STRING(255), allowNull: true },
    meta_description: { type: DataTypes.STRING(500), allowNull: true },
    meta_keywords: { type: DataTypes.STRING(255), allowNull: true },
  },
  {
    tableName: "categories",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: true,
    deletedAt: "deleted_at",
  }
);

module.exports = Category;
