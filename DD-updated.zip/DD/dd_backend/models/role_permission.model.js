// models/role_permission.model.js
//
// Join table: which permissions each role carries.
// UNIQUE(role_id, permission_id) prevents a duplicate grant.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const RolePermission = sequelize.define(
  "RolePermission",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    role_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
    permission_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  },
  {
    tableName: "role_permissions",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: false,
    indexes: [{ unique: true, fields: ["role_id", "permission_id"] }],
  }
);

module.exports = RolePermission;
