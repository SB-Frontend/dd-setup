// models/role.model.js
//
// A CMS role. Roles are granted to users through user_roles and carry
// permissions through role_permissions.
//
// role_slug is the stable identifier the application authorises against;
// role_name is a display label an operator may edit. Renaming the label must
// never change behaviour, which is why both exist.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const Role = sequelize.define(
  "Role",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    role_name: { type: DataTypes.STRING(100), allowNull: false, unique: true },
    role_slug: { type: DataTypes.STRING(100), allowNull: false, unique: true },

    description: { type: DataTypes.STRING(255), allowNull: true },

    // Seeded roles. Role Management must refuse to delete these, or an
    // operator can remove the role that grants access to Role Management.
    is_system: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0,
    },
  },
  {
    tableName: "roles",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    // Not paranoid: a revoked role should disappear, not linger as hidden
    // access-control state.
    paranoid: false,
  }
);

module.exports = Role;
