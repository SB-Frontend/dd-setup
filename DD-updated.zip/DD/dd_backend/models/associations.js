// models/associations.js
//
// Every relationship in the schema, in one place.
//
// Until now the codebase had ZERO associations - relationships existed only as
// bare integer columns held together by convention, which is why two database
// views were needed to do the JOINs. With these defined, `include` replaces
// both views.
//
// Required once from models/index.js, AFTER that file assigns module.exports,
// so the circular require back to the Sequelize instance resolves cleanly.
//
// ON DELETE / ON UPDATE are declared here to document intent and to keep the
// models honest about the database. The real enforcement lives in the
// migrations; Sequelize only emits these when synchronising, which this
// project deliberately never does.
//
// NO JS-LEVEL CASCADE.
// Sequelize only deletes associated rows itself when an association sets
// `hooks: true`. None do, so `author.destroy()` can never reach into posts.
// Combined with the schema (nothing CASCADEs into posts), an article cannot be
// removed as a side effect of deleting anything else.

const User = require("./user.model");
const Author = require("./author.model");
const Role = require("./role.model");
const Permission = require("./permission.model");
const UserRole = require("./user_role.model");
const RolePermission = require("./role_permission.model");
const Category = require("./category.model");
const Subcategory = require("./subcategory.model");
const Post = require("./post.model");
const Media = require("./media.model");
const Lead = require("./lead.model");
const LeadNote = require("./lead_note.model");
const Subscription = require("./subscription.model");

// ==========================================
// RBAC
//   users --< user_roles >-- roles --< role_permissions >-- permissions
// ==========================================
User.belongsToMany(Role, {
  through: UserRole,
  foreignKey: "user_id",
  otherKey: "role_id",
  as: "roles",
  onDelete: "CASCADE",
  onUpdate: "RESTRICT",
});

Role.belongsToMany(User, {
  through: UserRole,
  foreignKey: "role_id",
  otherKey: "user_id",
  as: "users",
  onDelete: "RESTRICT",
  onUpdate: "RESTRICT",
});

Role.belongsToMany(Permission, {
  through: RolePermission,
  foreignKey: "role_id",
  otherKey: "permission_id",
  as: "permissions",
  onDelete: "CASCADE",
  onUpdate: "RESTRICT",
});

Permission.belongsToMany(Role, {
  through: RolePermission,
  foreignKey: "permission_id",
  otherKey: "role_id",
  as: "roles",
  onDelete: "RESTRICT",
  onUpdate: "RESTRICT",
});

// Direct access to the join rows, for granting and revoking.
UserRole.belongsTo(User, { foreignKey: "user_id", as: "user" });
UserRole.belongsTo(Role, { foreignKey: "role_id", as: "role" });
User.hasMany(UserRole, { foreignKey: "user_id", as: "userRoles" });
Role.hasMany(UserRole, { foreignKey: "role_id", as: "userRoles" });

RolePermission.belongsTo(Role, { foreignKey: "role_id", as: "role" });
RolePermission.belongsTo(Permission, {
  foreignKey: "permission_id",
  as: "permission",
});
Role.hasMany(RolePermission, { foreignKey: "role_id", as: "rolePermissions" });
Permission.hasMany(RolePermission, {
  foreignKey: "permission_id",
  as: "rolePermissions",
});

// ==========================================
// TAXONOMY
//   categories (1) --< (N) subcategories
// ==========================================
Category.hasMany(Subcategory, {
  foreignKey: "category_id",
  as: "subcategories",
  onDelete: "RESTRICT",
  onUpdate: "RESTRICT",
});

Subcategory.belongsTo(Category, {
  foreignKey: "category_id",
  as: "category",
});

// ==========================================
// POSTS
//
// The distinction this whole redesign exists for:
//   author  -> Author   who is displayed as the author  (public)
//   creator -> User     which operator created the record
//   updater -> User     which operator last edited it
// ==========================================
Author.hasMany(Post, {
  foreignKey: "author_id",
  as: "posts",
  onDelete: "SET NULL",
  onUpdate: "RESTRICT",
});

Post.belongsTo(Author, {
  foreignKey: "author_id",
  as: "author",
});

Category.hasMany(Post, {
  foreignKey: "category_id",
  as: "posts",
  onDelete: "RESTRICT",
  onUpdate: "RESTRICT",
});

Post.belongsTo(Category, {
  foreignKey: "category_id",
  as: "category",
});

Subcategory.hasMany(Post, {
  foreignKey: "subcategory_id",
  as: "posts",
  onDelete: "SET NULL",
  onUpdate: "RESTRICT",
});

Post.belongsTo(Subcategory, {
  foreignKey: "subcategory_id",
  as: "subcategory",
});

Post.belongsTo(User, { foreignKey: "created_by", as: "creator" });
Post.belongsTo(User, { foreignKey: "updated_by", as: "updater" });

User.hasMany(Post, { foreignKey: "created_by", as: "createdPosts" });
User.hasMany(Post, { foreignKey: "updated_by", as: "updatedPosts" });

// ==========================================
// AUTHOR AUDIT
// Which CMS operator maintained the author record. This is NOT the author.
// ==========================================
Author.belongsTo(User, { foreignKey: "created_by", as: "creator" });
Author.belongsTo(User, { foreignKey: "updated_by", as: "updater" });

User.hasMany(Author, { foreignKey: "created_by", as: "createdAuthors" });
User.hasMany(Author, { foreignKey: "updated_by", as: "updatedAuthors" });

// ==========================================
// MEDIA
// Uploading is a CMS action, so this points at users, never authors.
// ==========================================
Media.belongsTo(User, { foreignKey: "uploaded_by", as: "uploader" });

User.hasMany(Media, {
  foreignKey: "uploaded_by",
  as: "uploads",
  onDelete: "SET NULL",
  onUpdate: "RESTRICT",
});

// ==========================================
// LEADS
// Anonymous submissions: no relationship to users or authors. lead_notes is
// the only child, and it carries the operator who wrote each note.
// ==========================================
Lead.hasMany(LeadNote, {
  foreignKey: "lead_id",
  as: "notes",
  onDelete: "CASCADE",
  onUpdate: "RESTRICT",
});

LeadNote.belongsTo(Lead, { foreignKey: "lead_id", as: "lead" });
// NOTE ON THE ALIAS: "author" here is the CMS operator who wrote the internal
// note, NOT a public content author. It is a User on purpose - a lead note is
// CMS data and is only ever read through /api/admin/leads/:id/notes.
// The public author entity is the separate `authors` table and is never a
// User; see the Post.author association below. Do not copy this include into
// anything that serves /api/website/*.
LeadNote.belongsTo(User, { foreignKey: "user_id", as: "author" });

User.hasMany(LeadNote, { foreignKey: "user_id", as: "leadNotes" });

// Subscription is intentionally standalone - it has no associations at all.
void Subscription;

module.exports = {
  User,
  Author,
  Role,
  Permission,
  UserRole,
  RolePermission,
  Category,
  Subcategory,
  Post,
  Media,
  Lead,
  LeadNote,
  Subscription,
};
