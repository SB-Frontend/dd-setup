// models/media.model.js
//
// Replaces the legacy media_list table.
//   media_id   -> id
//   media_path -> filename   (it always held a bare filename, not a path)
//   media_title-> title
//   user_id    -> uploaded_by
//
// uploaded_by points at users, never authors: uploading is a CMS action by a
// logged-in operator and says nothing about who wrote an article.
//
// Paranoid, because a row here points at a real file on disk. Removing the
// row outright would orphan the file with no record of what it was.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const Media = sequelize.define(
  "Media",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    // Generated stored name: timestamp + random bytes + sanitised base + one
    // canonical extension. Unique, mirroring the wx write flag used on disk.
    filename: { type: DataTypes.STRING(255), allowNull: false, unique: true },

    original_filename: { type: DataTypes.STRING(255), allowNull: true },

    title: { type: DataTypes.STRING(255), allowNull: true },

    mime_type: { type: DataTypes.STRING(100), allowNull: true },

    file_size: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },

    // Which upload directory holds the file. Previously implicit.
    storage_path: {
      type: DataTypes.STRING(50),
      allowNull: false,
      defaultValue: "posts",
    },

    uploaded_by: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },
  },
  {
    tableName: "media",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: true,
    deletedAt: "deleted_at",
  }
);

module.exports = Media;
