// models/post.model.js
//
// Replaces the legacy post_data table.
//
// ============================================================================
// REMOVED LEGACY POST WORKFLOW FIELDS
// ----------------------------------------------------------------------------
//   session_user       session_user_name    comments
//   comment_by         comment_by_name      handover_to
//   handover_to_name   handover_time        podcast_link
//
// These belonged to the previous handover/session/comment workflow and are not
// part of the clean post ownership model. They are NOT reintroduced here under
// different names.
//
// CMS activity is now created_by / updated_by -> users.id
// Public authorship is now author_id -> authors.id
// ============================================================================
//
// THREE DIFFERENT PEOPLE, THREE DIFFERENT COLUMNS
//   author_id  -> authors.id   who is displayed as the author  (public)
//   created_by -> users.id     which operator created the record
//   updated_by -> users.id     which operator last edited it
// The legacy session_user collapsed all three into one column that defaulted
// to user 1.
//
// SOFT DELETE
// Paranoid. Articles are the product: destroy() retires a post instead of
// removing it, and nothing in the schema cascades a delete into this table -
// every inbound relationship is SET NULL or RESTRICT.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

// The values the application actually accepts. Mirrors the CHECK constraint
// in migration 20260910000007 and POST_STATUSES in post.controller.js.
const POST_STATUSES = ["draft", "published"];

const Post = sequelize.define(
  "Post",
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    title: { type: DataTypes.STRING(255), allowNull: false },

    // Unique. This is what makes the create path race-safe: the previous
    // check-then-insert could be beaten by a concurrent request.
    slug: { type: DataTypes.STRING(200), allowNull: false, unique: true },

    content: { type: DataTypes.TEXT("long"), allowNull: false },

    // Short listing summary, so meta_description is not doubling as one.
    excerpt: { type: DataTypes.STRING(500), allowNull: true },

    status: {
      type: DataTypes.STRING(20),
      allowNull: false,
      defaultValue: "draft",
      validate: { isIn: [POST_STATUSES] },
    },

    // Public author. Nullable so that removing an author never removes the
    // article (the foreign key is ON DELETE SET NULL).
    author_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },

    // Authoritative classification. Kept alongside subcategory_id because
    // subcategory_id is nullable, so category cannot be derived through it.
    category_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },

    subcategory_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },

    banner_image: { type: DataTypes.STRING(255), allowNull: true },

    show_banner: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
    },

    reading_time: { type: DataTypes.SMALLINT.UNSIGNED, allowNull: true },

    priority: { type: DataTypes.SMALLINT, allowNull: false, defaultValue: 0 },

    auto_publish: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0,
    },

    // Editorial publication date. NULL until the post is published, which also
    // makes scheduled publishing expressible later without a new column.
    published_at: { type: DataTypes.DATE, allowNull: true },

    meta_title: { type: DataTypes.STRING(255), allowNull: true },
    meta_description: { type: DataTypes.STRING(500), allowNull: true },
    meta_keywords: { type: DataTypes.STRING(255), allowNull: true },

    // CMS audit. NOT the public author.
    created_by: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },
    updated_by: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },
  },
  {
    tableName: "posts",

    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",

    paranoid: true,
    deletedAt: "deleted_at",

    scopes: {
      // Everything the public website is allowed to see.
      published: { where: { status: "published" } },

      // Listings never need the article body, which is a LONGTEXT column.
      listing: { attributes: { exclude: ["content"] } },
    },
  }
);

Post.STATUSES = POST_STATUSES;

module.exports = Post;
