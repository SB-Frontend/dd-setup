// models/user.model.js
//
// A CMS account: someone who can log into the admin system.
//
// THIS IS NOT A PUBLIC AUTHOR. Public author profiles live in
// models/author.model.js and are completely independent - an author needs no
// CMS account, and holding a CMS account does not make someone an author.
//
// Removed from the legacy users table, deliberately:
//   is_author, display_name, author_photo, author_description
// All four were public author profile fields and now belong to `authors`.
//
// Renamed:
//   user_id -> id, user_name -> username, user_email -> email,
//   user_password -> password, user_status -> status
//
// STATUS vs DELETED_AT - these mean different things and both are needed:
//   status = 0    the account is suspended but still exists and can be
//                 re-enabled. Checked on every authenticated request.
//   deleted_at    the account has been retired. Paranoid hides it from every
//                 query while preserving who did what in the audit columns
//                 on posts, authors and media.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const User = sequelize.define(
  "User",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    username: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
    },

    // The CMS operator's own name, for the admin user list. Distinct from
    // authors.name and authors.display_name, which are public bylines.
    full_name: {
      type: DataTypes.STRING(150),
      allowNull: true,
    },

    email: {
      type: DataTypes.STRING(254),
      allowNull: false,
      unique: true,
      validate: { isEmail: true },
    },

    // bcrypt hash. The hooks below guarantee a plaintext value is never
    // written, whichever path sets it.
    password: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },

    // 1 = active, 0 = suspended
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
    },

    last_login_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: "users",

    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",

    paranoid: true,
    deletedAt: "deleted_at",

    // The hash is never selected unless explicitly asked for, so it cannot
    // leak into an API response by accident.
    defaultScope: {
      attributes: { exclude: ["password"] },
    },

    scopes: {
      // Used by login, which needs the hash to compare against.
      withPassword: { attributes: {} },
    },
  }
);

// ==========================================
// PASSWORD HASHING
//
// Instance-level hooks, carried over from the previous model. They fire on
// create() and on instance.save()/update().
//
// They do NOT fire on Model.update() or bulkCreate() unless those are called
// with individualHooks: true - a bulk write without it would store plaintext.
// ==========================================
const bcrypt = require("bcrypt");

const BCRYPT_ROUNDS = Number(process.env.BCRYPT_ROUNDS) || 10;

async function hashPassword(user) {
  if (!user.changed("password")) return;

  const salt = await bcrypt.genSalt(BCRYPT_ROUNDS);

  user.password = await bcrypt.hash(user.password, salt);
}

User.beforeCreate(hashPassword);
User.beforeUpdate(hashPassword);

/**
 * Compare a plaintext candidate against this account's hash.
 * Returns false rather than throwing when the instance was loaded without the
 * password attribute (the default scope excludes it).
 */
User.prototype.verifyPassword = function verifyPassword(candidate) {
  if (!this.password) return Promise.resolve(false);

  return bcrypt.compare(String(candidate), this.password);
};

module.exports = User;
