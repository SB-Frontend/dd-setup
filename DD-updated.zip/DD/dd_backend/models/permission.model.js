// models/permission.model.js
//
// A CMS capability. Module-level today (Post Management, Media Management).
//
// permission_slug is what the authorization layer compares against, so it is
// the column that must never change once seeded. permission_name is display
// text and is safe to edit.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const Permission = sequelize.define(
  "Permission",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    permission_name: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
    },

    permission_slug: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
    },

    description: { type: DataTypes.STRING(255), allowNull: true },
  },
  {
    tableName: "permissions",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: false,
  }
);

module.exports = Permission;
