// models/lead_note.model.js
//
// One note per row against a lead, replacing the old append-forever
// leads.comments TEXT column. Every note now has its own author and timestamp.
//
// Not paranoid: notes belong to a lead, and if the lead is erased on request
// the notes must go with it (the foreign key CASCADEs).

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const LeadNote = sequelize.define(
  "LeadNote",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    lead_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },

    // CMS operator who wrote the note. Null once that account is removed.
    user_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },

    note: { type: DataTypes.TEXT, allowNull: false },
  },
  {
    tableName: "lead_notes",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: false,
  }
);

module.exports = LeadNote;
