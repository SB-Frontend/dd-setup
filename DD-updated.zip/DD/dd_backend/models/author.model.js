// models/author.model.js
//
// A public content author: the person displayed as the author of an article.
//
// AN AUTHOR IS NOT A CMS USER.
// An author needs no login and need not exist in `users` at all, which is
// what makes external, guest, contributor and historical authors possible.
//
//   users   = CMS authentication / administration identity
//   authors = public content author identity
//
// THERE IS DELIBERATELY NO user_id COLUMN.
// The only link to users is CMS audit metadata:
//   created_by  which operator created this record
//   updated_by  which operator last edited it
// Neither says anything about who the author is. Both are nullable and become
// NULL when that operator is removed, because an author profile must outlive
// the account that happened to create it.
//
// Paranoid: posts point at authors, so removing one must be reversible. The
// posts.author_id foreign key is ON DELETE SET NULL, so even a hard delete
// would never remove an article.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const Author = sequelize.define(
  "Author",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    // Actual / internal name.
    name: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },

    // Public byline shown on articles. NOT unique - two people may
    // legitimately publish under the same name.
    display_name: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },

    // Public URL identifier for author pages. Unique, because it addresses a
    // single page.
    slug: {
      type: DataTypes.STRING(160),
      allowNull: false,
      unique: true,
    },

    bio: {
      type: DataTypes.TEXT,
      allowNull: true,
    },

    // Stored filename, matching how uploads are persisted elsewhere.
    image: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },

    // 1 = visible on the website, 0 = hidden
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
    },

    // CMS audit only. NOT author identity.
    created_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: true,
    },

    updated_by: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: true,
    },
  },
  {
    tableName: "authors",

    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",

    paranoid: true,
    deletedAt: "deleted_at",

    scopes: {
      // What the public website may see.
      published: {
        where: { status: 1 },
        attributes: ["id", "display_name", "slug", "bio", "image"],
      },
    },
  }
);

module.exports = Author;
