// models/user_role.model.js
//
// Join table: which CMS users hold which roles.
// UNIQUE(user_id, role_id) prevents a duplicate grant.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const UserRole = sequelize.define(
  "UserRole",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    user_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
    role_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  },
  {
    tableName: "user_roles",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: false,
    indexes: [{ unique: true, fields: ["user_id", "role_id"] }],
  }
);

module.exports = UserRole;
