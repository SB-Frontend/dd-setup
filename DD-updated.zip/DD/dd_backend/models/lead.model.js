// models/lead.model.js
//
// Anonymous contact-form submissions. No relationship to users or authors.
//
// Changes from the legacy table:
//   comments      -> the lead_notes table (one row per note, with an author
//                    and a timestamp instead of one appended TEXT blob)
//   lead_modified -> removed. It never existed as a column; the controller
//                    wrote it and Sequelize silently discarded it.
//   company/phone -> nullable, matching what the controller always assumed
//   status        -> added, so the CMS has a workflow state
//
// Not paranoid: a person may ask for their submission to be erased, and a
// soft delete would quietly keep it.

const { DataTypes } = require("sequelize");
const sequelize = require("./connection");

const Lead = sequelize.define(
  "Lead",
  {
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      primaryKey: true,
      autoIncrement: true,
    },

    first_name: { type: DataTypes.STRING(100), allowNull: false },
    last_name: { type: DataTypes.STRING(100), allowNull: false },

    email: {
      type: DataTypes.STRING(254),
      allowNull: false,
      validate: { isEmail: true },
    },

    company: { type: DataTypes.STRING(255), allowNull: true },
    phone: { type: DataTypes.STRING(50), allowNull: true },

    message: { type: DataTypes.TEXT, allowNull: false },

    status: {
      type: DataTypes.STRING(20),
      allowNull: false,
      defaultValue: "new",
      validate: { isIn: [["new", "contacted", "qualified", "closed"]] },
    },
  },
  {
    tableName: "leads",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    paranoid: false,
  }
);

module.exports = Lead;
