// config/security.js
//
// Helmet, CORS and proxy settings, all driven by environment variables.
//
// Nothing here hardcodes an origin. CORS_ORIGINS is the single source of
// truth, so development, staging and production differ only by env file.

const isProduction = () => process.env.NODE_ENV === "production";

// ==========================================
// CORS
// ==========================================

function allowedOrigins() {
  return String(process.env.CORS_ORIGINS || "")
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean);
}

const corsOptions = {
  origin(origin, callback) {
    // No Origin header: same-origin requests, curl, and server-to-server
    // calls such as Next.js server-side rendering. CORS does not apply.
    if (!origin) return callback(null, true);

    if (allowedOrigins().includes(origin)) return callback(null, true);

    // Refuse by omitting the CORS headers rather than raising, so a
    // disallowed origin gets a normal response the browser then blocks,
    // instead of a 500 that looks like a server fault.
    return callback(null, false);
  },

  // PATCH was missing before, so PATCH /api/admin/posts/:id/status and
  // /api/admin/users/:id/status failed preflight from any browser.
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],

  allowedHeaders: ["Content-Type", "Authorization"],

  // Without this the browser hides them from client code.
  exposedHeaders: [
    "Deprecation",
    "X-API-Deprecated",
    "X-API-Replaced-By",
    "RateLimit",
    "RateLimit-Policy",
    "Retry-After",
  ],

  // Never combined with a wildcard: origin is always an explicit allowlist
  // match above.
  credentials: true,

  maxAge: 600,
  optionsSuccessStatus: 204,
};

// ==========================================
// HELMET
// ==========================================

function helmetOptions() {
  return {
    // The API returns JSON, so a restrictive policy costs nothing and still
    // covers any HTML a proxy or framework might emit on an error path.
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'none'"],
        frameAncestors: ["'none'"],
        baseUri: ["'none'"],
        formAction: ["'none'"],
      },
    },

    // Same-origin by default. The /uploads static handler overrides this with
    // cross-origin, because the website loads those images from another host.
    crossOriginResourcePolicy: { policy: "same-origin" },

    // Would break cross-origin image loading and buys nothing for a JSON API.
    crossOriginEmbedderPolicy: false,

    referrerPolicy: { policy: "no-referrer" },

    // Only meaningful over HTTPS, and setting it while developing over plain
    // HTTP can pin a browser to https://localhost.
    hsts: isProduction()
      ? { maxAge: 15552000, includeSubDomains: true, preload: false }
      : false,
  };
}

// ==========================================
// PROXY
//
// Rate limiting keys on the client IP, so behind a load balancer Express has
// to be told how many proxy hops to trust. Left off by default: trusting a
// proxy that is not there lets a client spoof its own IP with
// X-Forwarded-For.
// ==========================================

function trustProxySetting() {
  const raw = process.env.TRUST_PROXY;

  if (raw === undefined || raw === "" || raw === "false") return false;
  if (raw === "true") return true;

  const asNumber = Number(raw);

  return Number.isInteger(asNumber) ? asNumber : raw;
}

function warnOnMisconfiguration() {
  if (allowedOrigins().length === 0) {
    console.warn(
      "[security] CORS_ORIGINS is empty - every cross-origin browser request will be blocked. " +
        "Set CORS_ORIGINS in your environment file."
    );
  }
}

module.exports = {
  corsOptions,
  helmetOptions,
  trustProxySetting,
  allowedOrigins,
  warnOnMisconfiguration,
  isProduction,
};
