// config/permissions.js
//
// Authorization vocabulary and resolution.
//
// TWO LEVELS, ON PURPOSE
//   The database stores MODULE permissions, because that is the language the
//   business uses and the CMS UI shows: "Post Management", "Author Management".
//   The middleware checks ACTION permissions, because that is the granularity
//   a route needs: posts.read vs posts.publish.
//
//   MODULE_PERMISSIONS is the bridge. A role that holds post_management gets
//   posts.read/create/update/delete; post_publishing is separate, which is what
//   makes "Content Writer drafts, Publisher publishes" expressible.
//
//   Action-level rows can be added to the permissions table later with no
//   middleware change: any slug that is already an action constant is used
//   directly. That is why permission_slug exists as a stable identifier.
//
// RESOLUTION
//   authenticated user -> user_roles -> roles -> role_permissions -> permissions
//
//   Resolved per request in middleware/auth.middleware.js, so a permission
//   change takes effect immediately rather than waiting for a token to expire.
//
// D4: THERE IS NO LONGER A ROLE FALLBACK.
//   This module previously granted DEFAULT_ROLE (which defaulted to `admin`)
//   to any account holding no rows in user_roles. Because D1 seeds no users
//   and no grants, every CMS account created since then resolved to full
//   administrator and the entire RBAC chain was decorative. A user with no
//   roles now has no permissions. The first administrator is granted the admin
//   role in the database by the bootstrap path in controllers/user.controller.js,
//   so even the first account authorises through the normal chain.

// ==========================================
// ACTION PERMISSIONS - what routes check
// ==========================================
const PERMISSIONS = Object.freeze({
  POSTS_READ: "posts.read",
  POSTS_CREATE: "posts.create",
  POSTS_UPDATE: "posts.update",
  POSTS_DELETE: "posts.delete",
  POSTS_PUBLISH: "posts.publish",

  AUTHORS_READ: "authors.read",
  AUTHORS_CREATE: "authors.create",
  AUTHORS_UPDATE: "authors.update",
  AUTHORS_DELETE: "authors.delete",

  CATEGORIES_READ: "categories.read",
  CATEGORIES_CREATE: "categories.create",
  CATEGORIES_UPDATE: "categories.update",
  CATEGORIES_DELETE: "categories.delete",

  SUBCATEGORIES_READ: "subcategories.read",
  SUBCATEGORIES_CREATE: "subcategories.create",
  SUBCATEGORIES_UPDATE: "subcategories.update",
  SUBCATEGORIES_DELETE: "subcategories.delete",

  MEDIA_READ: "media.read",
  MEDIA_CREATE: "media.create",
  MEDIA_UPDATE: "media.update",
  MEDIA_DELETE: "media.delete",

  LEADS_READ: "leads.read",
  LEADS_UPDATE: "leads.update",

  SUBSCRIPTIONS_READ: "subscriptions.read",

  USERS_READ: "users.read",
  USERS_CREATE: "users.create",
  USERS_UPDATE: "users.update",
  USERS_DELETE: "users.delete",

  ROLES_READ: "roles.read",
  ROLES_CREATE: "roles.create",
  ROLES_UPDATE: "roles.update",
  ROLES_DELETE: "roles.delete",

  // The permission catalogue is readable so Role Management can offer a
  // checklist. It is deliberately not writable through the API: permissions
  // are system authorization definitions seeded by migration, and an endpoint
  // that mints new ones is an escalation path.
  PERMISSIONS_READ: "permissions.read",

  DASHBOARD_READ: "dashboard.read",
});

// ==========================================
// MODULE -> ACTION MAPPING
// Keys are the permission_slug values seeded into the database.
// ==========================================
const MODULE_PERMISSIONS = Object.freeze({
  dashboard_management: [PERMISSIONS.DASHBOARD_READ],

  post_management: [
    PERMISSIONS.POSTS_READ,
    PERMISSIONS.POSTS_CREATE,
    PERMISSIONS.POSTS_UPDATE,
    PERMISSIONS.POSTS_DELETE,
  ],

  // Deliberately NOT part of post_management: editing a draft and putting it
  // live are different privileges.
  post_publishing: [PERMISSIONS.POSTS_PUBLISH],

  // Author Management covers the authors table ONLY. It must never imply
  // user_management - that would be a privilege-escalation path, because
  // editing a CMS user record can change an email, a password or a role.
  author_management: [
    PERMISSIONS.AUTHORS_READ,
    PERMISSIONS.AUTHORS_CREATE,
    PERMISSIONS.AUTHORS_UPDATE,
    PERMISSIONS.AUTHORS_DELETE,
  ],

  // Manages CMS accounts: create, edit, suspend, remove. It does NOT confer
  // the right to decide what those accounts may do - that is role_management.
  user_management: [
    PERMISSIONS.USERS_READ,
    PERMISSIONS.USERS_CREATE,
    PERMISSIONS.USERS_UPDATE,
    PERMISSIONS.USERS_DELETE,
  ],

  category_management: [
    PERMISSIONS.CATEGORIES_READ,
    PERMISSIONS.CATEGORIES_CREATE,
    PERMISSIONS.CATEGORIES_UPDATE,
    PERMISSIONS.CATEGORIES_DELETE,
    PERMISSIONS.SUBCATEGORIES_READ,
    PERMISSIONS.SUBCATEGORIES_CREATE,
    PERMISSIONS.SUBCATEGORIES_UPDATE,
    PERMISSIONS.SUBCATEGORIES_DELETE,
  ],

  media_management: [
    PERMISSIONS.MEDIA_READ,
    PERMISSIONS.MEDIA_CREATE,
    PERMISSIONS.MEDIA_UPDATE,
    PERMISSIONS.MEDIA_DELETE,
  ],

  lead_management: [
    PERMISSIONS.LEADS_READ,
    PERMISSIONS.LEADS_UPDATE,
    PERMISSIONS.SUBSCRIPTIONS_READ,
  ],

  // Grants authority over what everyone else may do, so it is the most
  // sensitive module in the system and gates every user_roles and
  // role_permissions write.
  role_management: [
    PERMISSIONS.ROLES_READ,
    PERMISSIONS.ROLES_CREATE,
    PERMISSIONS.ROLES_UPDATE,
    PERMISSIONS.ROLES_DELETE,
    PERMISSIONS.PERMISSIONS_READ,
  ],

  // Seeded so Marketing Head can hold it, but no advertisement feature exists
  // yet, so it currently grants nothing.
  advertisement_management: [],
});

const ALL_ACTIONS = Object.values(PERMISSIONS);

// ==========================================
// LOCKOUT PROTECTION
//
// An installation stays recoverable only while at least one active account can
// both create/repair users AND hand out roles. Losing that combination is
// unrecoverable through the API: nobody could grant it back. Operations that
// would remove the last such account are refused - see services/rbac.service.js.
// ==========================================
const RECOVERY_PERMISSIONS = Object.freeze([
  PERMISSIONS.USERS_UPDATE,
  PERMISSIONS.ROLES_UPDATE,
]);

// The role the very first account is granted during bootstrap. A slug, never
// an id: ids differ between environments.
const BOOTSTRAP_ROLE_SLUG = "admin";

/**
 * Expand permission slugs into the action set they grant.
 * A slug that is already an action constant is kept as-is, so action-level
 * rows can be added to the database without touching this file.
 */
function expandSlugs(slugs) {
  const actions = new Set();

  for (const slug of slugs) {
    if (MODULE_PERMISSIONS[slug]) {
      MODULE_PERMISSIONS[slug].forEach((a) => actions.add(a));
    } else if (ALL_ACTIONS.includes(slug)) {
      actions.add(slug);
    }
  }

  return [...actions];
}

/**
 * Resolve a user's roles and effective action permissions from the database.
 *
 * The database is the only source. An account with no roles gets nothing;
 * there is no implicit role and no environment variable that can grant one.
 * Loading the models lazily keeps this module free of a circular dependency
 * on the data layer.
 */
async function resolveUserAccess(user) {
  if (!user) {
    return { roles: [], modules: [], permissions: [], source: "none" };
  }

  const { UserRole, Role, Permission } = require("../models/associations");

  // One query walks the whole chain:
  //   user_roles -> roles -> role_permissions -> permissions
  const grants = await UserRole.findAll({
    attributes: ["role_id"],
    where: { user_id: user.id },
    include: [
      {
        model: Role,
        as: "role",
        attributes: ["id", "role_slug"],
        required: true,
        include: [
          {
            model: Permission,
            as: "permissions",
            attributes: ["permission_slug"],
            through: { attributes: [] },
          },
        ],
      },
    ],
  });

  const heldRoles = grants.map((g) => g.role).filter(Boolean);

  // Several roles union their permissions rather than conflicting.
  const modules = [
    ...new Set(
      heldRoles.flatMap((r) => r.permissions.map((p) => p.permission_slug))
    ),
  ];

  return {
    roles: heldRoles.map((r) => r.role_slug),
    modules,
    permissions: expandSlugs(modules),
    source: heldRoles.length > 0 ? "database" : "no-roles",
  };
}

function hasPermission(granted, required) {
  if (!Array.isArray(granted)) return false;

  return granted.includes(required);
}

module.exports = {
  PERMISSIONS,
  MODULE_PERMISSIONS,
  ALL_ACTIONS,
  RECOVERY_PERMISSIONS,
  BOOTSTRAP_ROLE_SLUG,
  expandSlugs,
  resolveUserAccess,
  hasPermission,
};
