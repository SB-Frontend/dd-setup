// config/sanitize.js
//
// THE SANITIZATION BOUNDARY
//
// The website intentionally publishes rich HTML, so stripping all markup is
// not an option. Three profiles are defined instead, and every writable text
// field is assigned to exactly one of them.
//
//   RICH   post_content only. Article bodies authored in the CMS. Full
//          formatting, links, images, tables and a narrow set of embed hosts.
//
//   BASIC  Fields that are displayed as HTML but are notes or bios rather
//          than articles: post comments, lead comments, author_description.
//          Inline formatting and links only. No images, no embeds.
//
//   PLAIN  Everything else - titles, slugs, meta tags, names, emails, the
//          public contact-form message. All markup is removed.
//
// WHAT IS BLOCKED IN EVERY PROFILE
//   * <script>, <object>, <embed>, <form>, <input>, <link>, <meta>, <base>
//   * <svg> and <math>, both of which can carry script
//   * every event-handler attribute (onclick, onerror, onload, ...), because
//     sanitize-html drops any attribute not explicitly allowed
//   * javascript: and data: URLs - only http, https and mailto are permitted
//   * style attributes, which can smuggle expression() and url() payloads
//
// EMBEDS
// <iframe> survives in RICH only, and only when its src host is in
// allowedIframeHostnames. That list is the one thing likely to need editing;
// it is env-overridable via SANITIZE_IFRAME_HOSTS.
//
// SCOPE
// Sanitizing happens on WRITE. Rows already stored are not rewritten, so any
// unsafe HTML saved before this change is still in the database. Cleaning it
// needs a one-off backfill, which is deliberately not part of this stage.

const DEFAULT_IFRAME_HOSTS = [
  "www.youtube.com",
  "youtube.com",
  "www.youtube-nocookie.com",
  "player.vimeo.com",
  "open.spotify.com",
  "w.soundcloud.com",
];

function iframeHosts() {
  const configured = String(process.env.SANITIZE_IFRAME_HOSTS || "")
    .split(",")
    .map((h) => h.trim())
    .filter(Boolean);

  return configured.length > 0 ? configured : DEFAULT_IFRAME_HOSTS;
}

// data: is excluded on purpose. A data: URL on an <img> can carry an SVG
// document, and an SVG document can carry script. Editors should reference
// uploaded files instead.
const SAFE_SCHEMES = ["http", "https", "mailto"];

const RICH = () => ({
  allowedTags: [
    "h1", "h2", "h3", "h4", "h5", "h6",
    "p", "br", "hr", "div", "span",
    "strong", "b", "em", "i", "u", "s", "sub", "sup", "mark", "small",
    "ul", "ol", "li", "dl", "dt", "dd",
    "blockquote", "pre", "code",
    "a", "img",
    "figure", "figcaption",
    "table", "thead", "tbody", "tfoot", "tr", "th", "td", "caption",
    "iframe",
  ],

  allowedAttributes: {
    a: ["href", "title", "target", "rel"],
    img: ["src", "alt", "title", "width", "height", "loading"],
    iframe: ["src", "width", "height", "title", "allow", "allowfullscreen", "frameborder"],
    th: ["colspan", "rowspan", "scope"],
    td: ["colspan", "rowspan"],
    div: ["class"],
    span: ["class"],
    p: ["class"],
    code: ["class"],
    pre: ["class"],
  },

  allowedSchemes: SAFE_SCHEMES,
  allowedSchemesAppliedToAttributes: ["href", "src"],
  allowProtocolRelative: false,
  allowedIframeHostnames: iframeHosts(),

  // A link that opens a new tab must not hand the opener to the target page.
  transformTags: {
    a: (tagName, attribs) => {
      const next = { ...attribs };

      if (next.target === "_blank") next.rel = "noopener noreferrer";

      return { tagName, attribs: next };
    },
  },

  disallowedTagsMode: "discard",
});

const BASIC = () => ({
  allowedTags: [
    "p", "br",
    "strong", "b", "em", "i", "u",
    "ul", "ol", "li",
    "a",
  ],
  allowedAttributes: { a: ["href", "title"] },
  allowedSchemes: SAFE_SCHEMES,
  allowedSchemesAppliedToAttributes: ["href"],
  allowProtocolRelative: false,
  disallowedTagsMode: "discard",
});

const PLAIN = () => ({
  allowedTags: [],
  allowedAttributes: {},
  disallowedTagsMode: "discard",
});

const PROFILES = { rich: RICH, basic: BASIC, plain: PLAIN };

// ==========================================
// FIELD MAP
// Which profile each writable field gets, referenced from the route files.
// ==========================================
const FIELDS = {
  post: {
    // The article body is the one genuinely rich field on the whole surface.
    content: "rich",
    title: "plain",
    slug: "plain",
    excerpt: "plain",
    meta_title: "plain",
    meta_description: "plain",
    meta_keywords: "plain",
  },

  // Public author profiles. bio is displayed as HTML on the site, so it gets
  // the basic profile; everything else is plain text.
  author: {
    name: "plain",
    display_name: "plain",
    slug: "plain",
    bio: "basic",
  },

  category: {
    name: "plain",
    slug: "plain",
    meta_title: "plain",
    meta_description: "plain",
    meta_keywords: "plain",
  },

  subcategory: {
    name: "plain",
    slug: "plain",
    meta_title: "plain",
    meta_description: "plain",
    meta_keywords: "plain",
  },

  // CMS accounts. No public-author fields here by design.
  user: {
    username: "plain",
    full_name: "plain",
    email: "plain",
  },

  // Role labels. role_slug is not listed: it is generated by the controller
  // from the name and is never taken from the request on update.
  role: {
    role_name: "plain",
    description: "plain",
  },

  media: { title: "plain" },

  leadComment: { comment: "basic" },

  // Public, anonymous writes. Everything is plain text.
  publicLead: {
    firstName: "plain",
    lastName: "plain",
    email: "plain",
    company: "plain",
    phone: "plain",
    message: "plain",
  },

  publicSubscribe: { name: "plain", email: "plain" },
};

module.exports = { PROFILES, FIELDS, DEFAULT_IFRAME_HOSTS, iframeHosts, SAFE_SCHEMES };
