// config/database.js
//
// Connection settings for sequelize-cli ONLY. The running application still
// builds its own Sequelize instance in models/index.js; this file exists so
// migrations connect to the same database without duplicating credentials.
//
// Credentials come from .env, never from source control.
//
// NOTE ON PRIVILEGES: migrations need DDL rights (CREATE, ALTER, INDEX, DROP).
// The application runtime does NOT, and should not have them. Once
// sequelize.sync() is gone, the app user can be reduced to
// SELECT/INSERT/UPDATE/DELETE and migrations run under a separate account.
// Set MIGRATION_DB_USER / MIGRATION_DB_PASSWORD to use that separate account.

require("dotenv").config();

const base = {
  username: process.env.MIGRATION_DB_USER || process.env.DB_USER,
  password: process.env.MIGRATION_DB_PASSWORD || process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT) || 3306,
  dialect: "mysql",

  // Snake case, to match every other table in this schema.
  migrationStorageTableName: "sequelize_meta",
  seederStorage: "sequelize",
  seederStorageTableName: "sequelize_seeds",

  logging: console.log,
};

module.exports = {
  development: base,
  test: base,
  production: { ...base, logging: false },
};
