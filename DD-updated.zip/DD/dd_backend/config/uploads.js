// config/uploads.js
//
// Single source of truth for upload policy.
//
// Before Phase 7 the two multer configs had no limits at all, trusted the
// client-supplied mimetype and filename, used an unanchored extension regex,
// and pointed at a directory that did not exist.

const path = require("path");

const UPLOAD_ROOT = path.resolve(__dirname, "..", "uploads");

// Destinations are unchanged from the previous behaviour on purpose.
// Media uploads share the posts directory because that is where the existing
// media_list rows already point; moving them would orphan those records.
const DESTINATIONS = {
  posts: path.join(UPLOAD_ROOT, "posts"),
  author: path.join(UPLOAD_ROOT, "author"),
};

const toBytes = (mb) => Math.round(mb * 1024 * 1024);

const LIMITS = {
  // Was unlimited: a single anonymous request could fill the disk.
  fileSize: toBytes(Number(process.env.UPLOAD_MAX_FILE_MB) || 5),

  // busboy defaults this to 1 MB, which truncated post_content (a LONGTEXT
  // column) and aborted the request with LIMIT_FIELD_VALUE.
  fieldSize: toBytes(Number(process.env.UPLOAD_MAX_FIELD_MB) || 8),

  files: 1,
  fields: 60,
  parts: 70,
  fieldNameSize: 200,
};

// Extension is the key. `mimes` are the Content-Type values accepted for it,
// and `magic` are the byte signatures the file itself must actually start
// with. All three have to agree.
//
// SVG is deliberately absent: it is XML, can carry script, and would execute
// in the browser if served from this origin.
const ALLOWED_TYPES = [
  {
    ext: ".jpg",
    aliases: [".jpeg"],
    mimes: ["image/jpeg", "image/jpg", "image/pjpeg"],
    magic: [[0xff, 0xd8, 0xff]],
  },
  {
    ext: ".png",
    aliases: [],
    mimes: ["image/png"],
    magic: [[0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]],
  },
  {
    ext: ".webp",
    aliases: [],
    mimes: ["image/webp"],
    // RIFF....WEBP - bytes 0-3 and 8-11.
    magic: [[0x52, 0x49, 0x46, 0x46]],
    magicAt8: [0x57, 0x45, 0x42, 0x50],
  },
];

// Look up the policy entry for a file extension, honouring aliases so that
// .jpeg is normalised to .jpg.
function findByExtension(ext) {
  const lower = String(ext || "").toLowerCase();

  return (
    ALLOWED_TYPES.find(
      (t) => t.ext === lower || t.aliases.includes(lower)
    ) || null
  );
}

const ALLOWED_EXTENSIONS = ALLOWED_TYPES.flatMap((t) => [t.ext, ...t.aliases]);
const ALLOWED_MIMES = ALLOWED_TYPES.flatMap((t) => t.mimes);

module.exports = {
  UPLOAD_ROOT,
  DESTINATIONS,
  LIMITS,
  ALLOWED_TYPES,
  ALLOWED_EXTENSIONS,
  ALLOWED_MIMES,
  findByExtension,
};
