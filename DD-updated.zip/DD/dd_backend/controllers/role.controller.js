// controllers/role.controller.js
//
// ROLE MANAGEMENT.
//
// Roles group permissions; permissions are what routes check. Every write here
// goes through services/rbac.service.js so the lockout guard and the
// duplicate handling apply consistently.
//
// PERMISSIONS ARE READ-ONLY THROUGH THE API.
//   The permission catalogue is a system authorization definition, seeded by
//   migration D1-010 and matched by the constants in config/permissions.js. An
//   endpoint that created permissions would let a CMS user invent a slug, and
//   an endpoint that renamed permission_slug would silently detach every route
//   guard from its grants. The catalogue is therefore listable - Role
//   Management needs the checklist - and not writable.

const sequelize = require("../models");
const Role = require("../models/role.model");
const Permission = require("../models/permission.model");
const UserRole = require("../models/user_role.model");

const ApiError = require("../utils/ApiError");
const rbac = require("../services/rbac.service");
const { MODULE_PERMISSIONS, expandSlugs } = require("../config/permissions");

const ROLE_ATTRIBUTES = ["id", "role_name", "role_slug", "description", "is_system"];
const PERMISSION_ATTRIBUTES = ["id", "permission_name", "permission_slug", "description"];

const permissionInclude = () => [
  {
    model: Permission,
    as: "permissions",
    attributes: PERMISSION_ATTRIBUTES,
    through: { attributes: [] },
  },
];

/**
 * Turn a stored name into a stable slug. Slugs identify a role for the life of
 * the installation, so they are generated once at creation and never rewritten
 * by a later rename - renaming a label must not change authorization.
 */
function slugify(value) {
  return String(value)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 100);
}

const shape = (role) => ({
  id: role.id,
  role_name: role.role_name,
  role_slug: role.role_slug,
  description: role.description,
  is_system: Number(role.is_system) === 1,
  modules: (role.permissions || []).map((p) => p.permission_slug),
  permissions: expandSlugs((role.permissions || []).map((p) => p.permission_slug)),
});

// =====================================
// LIST ROLES
// =====================================
exports.listRoles = async (req, res, next) => {
  try {
    const roles = await Role.findAll({
      attributes: ROLE_ATTRIBUTES,
      include: permissionInclude(),
      order: [["id", "ASC"]],
    });

    return res.json({ success: true, data: roles.map(shape) });
  } catch (error) {
    return next(error);
  }
};

// =====================================
// GET ONE ROLE
// =====================================
exports.getRole = async (req, res, next) => {
  try {
    const role = await rbac.findRole(req.params.id, {
      attributes: ROLE_ATTRIBUTES,
      include: permissionInclude(),
    });

    if (!role) return next(ApiError.notFound("Role not found."));

    return res.json({ success: true, data: shape(role) });
  } catch (error) {
    return next(error);
  }
};

// =====================================
// PERMISSION CATALOGUE  (read only)
// =====================================
exports.listPermissions = async (req, res, next) => {
  try {
    const permissions = await Permission.findAll({
      attributes: PERMISSION_ATTRIBUTES,
      order: [["id", "ASC"]],
    });

    return res.json({
      success: true,
      data: permissions.map((p) => ({
        id: p.id,
        permission_name: p.permission_name,
        permission_slug: p.permission_slug,
        description: p.description,

        // What holding this module actually grants, so Role Management can
        // show the consequence rather than just a checkbox label.
        grants: MODULE_PERMISSIONS[p.permission_slug] || [],
      })),
    });
  } catch (error) {
    return next(error);
  }
};

// =====================================
// CREATE ROLE
// =====================================
exports.createRole = async (req, res, next) => {
  try {
    const { role_name, description } = req.body;

    if (!role_name) {
      return next(ApiError.badRequest("role_name is required."));
    }

    const role_slug = slugify(req.body.role_slug || role_name);

    if (!role_slug) {
      return next(ApiError.badRequest("role_name must contain letters or digits."));
    }

    const clash = await Role.findOne({ where: { role_slug } });

    if (clash) {
      return next(ApiError.conflict("A role with that name already exists."));
    }

    // A new role starts with exactly what was asked for. Creating a role must
    // never grant everything by default - that would make role creation an
    // escalation path for anyone holding role_management.
    const requested = Array.isArray(req.body.permissions)
      ? req.body.permissions
      : String(req.body.permissions || "").split(",").map((v) => v.trim()).filter(Boolean);

    // Validated before the role is created, so an unknown slug fails the whole
    // request rather than leaving a role with a partial grant set.
    await rbac.resolvePermissions(requested);

    // The role row and its grants are one unit of work. Without the shared
    // transaction a failure between the two writes leaves a role that exists
    // but grants nothing - harmless in itself, because an empty role fails
    // closed, but it is a half-applied write that an operator would have to
    // notice and repair by hand.
    const role = await sequelize.transaction(async (transaction) => {
      const row = await Role.create(
        {
          role_name,
          role_slug,
          description: description || null,
          is_system: 0,
        },
        { transaction }
      );

      if (requested.length > 0) {
        await rbac.replaceRolePermissions(row.id, requested, { transaction });
      }

      return row;
    });

    const created = await rbac.findRole(role.id, {
      attributes: ROLE_ATTRIBUTES,
      include: permissionInclude(),
    });

    return res.status(201).json({
      success: true,
      message: "Role created successfully",
      data: shape(created),
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Create role error:", error);

    return next(error);
  }
};

// =====================================
// UPDATE ROLE  (label and description only)
// =====================================
exports.updateRole = async (req, res, next) => {
  try {
    const role = await rbac.findRole(req.params.id);

    if (!role) return next(ApiError.notFound("Role not found."));

    const updateData = {};

    if (req.body.role_name !== undefined) updateData.role_name = req.body.role_name;
    if (req.body.description !== undefined) updateData.description = req.body.description;

    // role_slug is the identifier every route guard and grant resolves
    // through. Editing it would detach a role from its permissions without
    // any visible error, so it is fixed at creation.
    if (req.body.role_slug !== undefined && req.body.role_slug !== role.role_slug) {
      return next(ApiError.badRequest("role_slug cannot be changed."));
    }

    await role.update(updateData);

    const updated = await rbac.findRole(role.id, {
      attributes: ROLE_ATTRIBUTES,
      include: permissionInclude(),
    });

    return res.json({
      success: true,
      message: "Role updated successfully",
      data: shape(updated),
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Update role error:", error);

    return next(error);
  }
};

// =====================================
// REPLACE A ROLE'S PERMISSIONS
// =====================================
exports.setRolePermissions = async (req, res, next) => {
  try {
    const role = await rbac.findRole(req.params.id);

    if (!role) return next(ApiError.notFound("Role not found."));

    const requested = Array.isArray(req.body.permissions)
      ? req.body.permissions
      : String(req.body.permissions || "").split(",").map((v) => v.trim()).filter(Boolean);

    // One transaction: a role that lost its old grants but did not receive the
    // new ones is exactly the inconsistent authorization state to avoid.
    const applied = await rbac.replaceRolePermissions(role.id, requested);

    return res.json({
      success: true,
      message: "Role permissions updated successfully",
      data: { role_slug: role.role_slug, modules: applied, permissions: expandSlugs(applied) },
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Set role permissions error:", error);

    return next(error);
  }
};

// =====================================
// DELETE ROLE
// =====================================
exports.deleteRole = async (req, res, next) => {
  try {
    const role = await rbac.findRole(req.params.id);

    if (!role) return next(ApiError.notFound("Role not found."));

    // Seeded roles underpin the permission model; removing `admin` would take
    // Role Management itself away with no way to grant it back.
    if (Number(role.is_system) === 1) {
      return next(ApiError.forbidden("System roles cannot be deleted."));
    }

    // user_roles.role_id is RESTRICT, so the database would refuse this too.
    // Answering here turns a driver error into a clear message, and makes it
    // obvious that deleting a role never deletes the users holding it.
    const holders = await UserRole.count({ where: { role_id: role.id } });

    if (holders > 0) {
      return next(
        ApiError.conflict(
          `This role is assigned to ${holders} user(s). Revoke it first.`
        )
      );
    }

    // role_permissions.role_id is ON DELETE CASCADE, so the grant rows go with
    // it. Nothing else references a role.
    await role.destroy();

    return res.json({ success: true, message: "Role deleted successfully" });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Delete role error:", error);

    return next(error);
  }
};
