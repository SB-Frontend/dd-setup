// controllers/post.controller.js
//
// ADMIN post management.
//
// THREE DIFFERENT PEOPLE, THREE DIFFERENT COLUMNS
//   author_id  -> authors.id   who is displayed as the author  (public)
//   created_by -> users.id     which CMS operator created the record
//   updated_by -> users.id     which CMS operator last edited it
//
// The logged-in operator and the article author are frequently different
// people, so author_id is NEVER derived from req.user, and creating a post
// never creates an author.
//
// The legacy handover/session/comment workflow is gone: session_user,
// session_user_name, comments, comment_by, comment_by_name, handover_to,
// handover_to_name and handover_time no longer exist and are not reintroduced
// under new names. Joins replace the denormalized *_name copies, and the two
// fake database views are replaced by Sequelize includes.

const { Op } = require("sequelize");

const Post = require("../models/post.model");
const Author = require("../models/author.model");
const Category = require("../models/category.model");
const Subcategory = require("../models/subcategory.model");
const User = require("../models/user.model");
const { parsePagination, parseSort, toId, toInt } = require("../utils/queryParams");

// Mirrors the CHECK constraint in the database. Kept in the model so the two
// can never drift.
const POST_STATUSES = Post.STATUSES;

const POST_SORT_FIELDS = [
  "id",
  "title",
  "slug",
  "status",
  "published_at",
  "priority",
  "reading_time",
  "created_at",
  "updated_at",
];

// Public author shape. Never exposes CMS account data.
const PUBLIC_AUTHOR_ATTRIBUTES = [
  "id",
  "name",
  "display_name",
  "slug",
  "bio",
  "image",
];

const adminIncludes = () => [
  { model: Author, as: "author", attributes: PUBLIC_AUTHOR_ATTRIBUTES, required: false },
  { model: Category, as: "category", attributes: ["id", "name", "slug"], required: false },
  { model: Subcategory, as: "subcategory", attributes: ["id", "name", "slug"], required: false },
  { model: User, as: "creator", attributes: ["id", "username", "full_name"], required: false },
  { model: User, as: "updater", attributes: ["id", "username", "full_name"], required: false },
];

/**
 * Validate an optional author reference.
 * Returns { ok } or { ok: false, status, message }.
 */
async function checkAuthor(authorId) {
  if (authorId === undefined || authorId === null || authorId === "") {
    return { ok: true, value: null };
  }

  const id = toId(authorId);

  if (id === null) {
    return { ok: false, status: 400, message: "author_id must be a positive integer" };
  }

  const author = await Author.findByPk(id, { attributes: ["id", "status"] });

  if (!author) {
    return { ok: false, status: 404, message: "Author not found" };
  }

  if (Number(author.status) !== 1) {
    return { ok: false, status: 400, message: "Author is not active" };
  }

  return { ok: true, value: id };
}

async function checkReference(Model, value, label) {
  if (value === undefined || value === null || value === "") {
    return { ok: true, value: null };
  }

  const id = toId(value);

  if (id === null) {
    return { ok: false, status: 400, message: `${label} must be a positive integer` };
  }

  const row = await Model.findByPk(id, { attributes: ["id"] });

  if (!row) {
    return { ok: false, status: 404, message: `${label} not found` };
  }

  return { ok: true, value: id };
}

// ==========================================
// CREATE
// ==========================================
exports.createPost = async (req, res) => {
  try {
    const {
      title,
      slug,
      content,
      excerpt,
      author_id,
      category_id,
      subcategory_id,
      show_banner,
      reading_time,
      priority,
      auto_publish,
      published_at,
      meta_title,
      meta_description,
      meta_keywords,
    } = req.body;

    if (!title || !slug || !content) {
      return res.status(400).json({
        success: false,
        message: "title, slug and content are required",
      });
    }

    const author = await checkAuthor(author_id);
    if (!author.ok) return res.status(author.status).json({ success: false, message: author.message });

    const category = await checkReference(Category, category_id, "category_id");
    if (!category.ok) return res.status(category.status).json({ success: false, message: category.message });

    const subcategory = await checkReference(Subcategory, subcategory_id, "subcategory_id");
    if (!subcategory.ok) return res.status(subcategory.status).json({ success: false, message: subcategory.message });

    const existing = await Post.findOne({ where: { slug }, paranoid: false });

    if (existing) {
      return res.status(409).json({
        success: false,
        message: "Post with this slug already exists.",
      });
    }

    // Posts are always created as drafts. Publishing is a separate action
    // guarded by the post_publishing permission.
    const post = await Post.create({
      title,
      slug,
      content,
      excerpt: excerpt || null,
      status: "draft",
      author_id: author.value,
      category_id: category.value,
      subcategory_id: subcategory.value,
      banner_image: req.file ? req.file.filename : null,
      show_banner: Number(show_banner) === 0 ? 0 : 1,
      reading_time: toInt(reading_time),
      priority: toInt(priority) || 0,
      auto_publish: Number(auto_publish) === 1 ? 1 : 0,
      published_at: published_at || null,
      meta_title: meta_title || null,
      meta_description: meta_description || null,
      meta_keywords: meta_keywords || null,

      // CMS audit, from the session. Never from the request body.
      created_by: req.user ? req.user.id : null,
      updated_by: req.user ? req.user.id : null,
    });

    return res.status(201).json({
      success: true,
      message: "Post created successfully",
      data: post,
    });
  } catch (error) {
    console.error("Create post error:", error);

    return res.status(500).json({
      success: false,
      error: "Failed to create post",
    });
  }
};

// ==========================================
// ADMIN LIST  (DataTables response shape preserved)
// ==========================================
exports.getAllPosts = async (req, res) => {
  try {
    const source = { ...req.query, ...(req.body || {}) };

    const {
      search = "",
      category_id,
      author_id,
      status,
      from_date,
      to_date,
    } = source;

    const { page, limit, offset } = parsePagination(source);

    const { field, order } = parseSort(source, {
      allowed: POST_SORT_FIELDS,
      defaultField: "created_at",
      defaultOrder: "DESC",
    });

    const where = {};

    const categoryId = toInt(category_id);
    if (categoryId !== null) where.category_id = categoryId;

    const authorId = toInt(author_id);
    if (authorId !== null) where.author_id = authorId;

    if (status && POST_STATUSES.includes(status)) where.status = status;

    if (from_date && to_date) {
      where.published_at = {
        [Op.between]: [new Date(`${from_date} 00:00:00`), new Date(`${to_date} 23:59:59`)],
      };
    } else if (from_date) {
      where.published_at = { [Op.gte]: new Date(`${from_date} 00:00:00`) };
    } else if (to_date) {
      where.published_at = { [Op.lte]: new Date(`${to_date} 23:59:59`) };
    }

    if (search) {
      where.title = { [Op.like]: `%${search}%` };
    }

    const totalCount = await Post.count();

    const { count, rows } = await Post.findAndCountAll({
      where,
      attributes: { exclude: ["content"] },
      include: adminIncludes(),
      order: [
        [field, order],
        ["id", "DESC"],
      ],
      limit,
      offset,
      distinct: true,
    });

    return res.json({
      draw: page,
      iTotalRecords: totalCount,
      iTotalDisplayRecords: count,
      aaData: rows,
    });
  } catch (error) {
    console.error("Get posts error:", error);

    return res.status(500).json({
      message: "Failed to fetch posts",
    });
  }
};

// ==========================================
// COUNT
// ==========================================
exports.getPostCount = async (req, res) => {
  try {
    const count = await Post.count();

    return res.status(200).json({ success: true, count });
  } catch (error) {
    console.error("Get post count error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to get post count",
    });
  }
};

// ==========================================
// UPDATE  (partial)
// ==========================================
exports.updatePost = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const post = await Post.findByPk(id);

    if (!post) {
      return res.status(404).json({ success: false, error: "Post not found" });
    }

    const {
      title,
      slug,
      content,
      excerpt,
      author_id,
      category_id,
      subcategory_id,
      show_banner,
      reading_time,
      priority,
      auto_publish,
      published_at,
      meta_title,
      meta_description,
      meta_keywords,
    } = req.body;

    // Only fields the caller actually sent.
    const updateData = {};

    for (const [key, value] of Object.entries({
      title,
      content,
      excerpt,
      meta_title,
      meta_description,
      meta_keywords,
      published_at,
    })) {
      if (value !== undefined) updateData[key] = value;
    }

    if (slug !== undefined && slug !== post.slug) {
      const clash = await Post.findOne({ where: { slug }, paranoid: false });

      if (clash) {
        return res.status(409).json({
          success: false,
          message: "Post with this slug already exists.",
        });
      }

      updateData.slug = slug;
    }

    // Changing the byline is allowed; it never touches the author record.
    if (author_id !== undefined) {
      const author = await checkAuthor(author_id);
      if (!author.ok) return res.status(author.status).json({ success: false, message: author.message });

      updateData.author_id = author.value;
    }

    if (category_id !== undefined) {
      const category = await checkReference(Category, category_id, "category_id");
      if (!category.ok) return res.status(category.status).json({ success: false, message: category.message });

      updateData.category_id = category.value;
    }

    if (subcategory_id !== undefined) {
      const subcategory = await checkReference(Subcategory, subcategory_id, "subcategory_id");
      if (!subcategory.ok) return res.status(subcategory.status).json({ success: false, message: subcategory.message });

      updateData.subcategory_id = subcategory.value;
    }

    if (show_banner !== undefined) updateData.show_banner = Number(show_banner) === 0 ? 0 : 1;
    if (auto_publish !== undefined) updateData.auto_publish = Number(auto_publish) === 1 ? 1 : 0;
    if (reading_time !== undefined) updateData.reading_time = toInt(reading_time);
    if (priority !== undefined) updateData.priority = toInt(priority) || 0;

    // Only replace the banner when a new file was uploaded.
    if (req.file) updateData.banner_image = req.file.filename;

    // created_by is never touched; updated_by always is.
    updateData.updated_by = req.user ? req.user.id : null;

    await post.update(updateData);

    const updatedPost = await Post.findByPk(id, { include: adminIncludes() });

    return res.json({
      success: true,
      message: "Post updated successfully",
      data: updatedPost,
    });
  } catch (error) {
    console.error("Update post error:", error);

    return res.status(500).json({
      success: false,
      error: "Failed to update post",
    });
  }
};

// ==========================================
// PUBLISH / UNPUBLISH
// Guarded by post_publishing, which is deliberately separate from
// post_management: editing a draft and putting it live are different rights.
// ==========================================
exports.updateStatus = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const { status } = req.body;

    if (!POST_STATUSES.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "status must be one of: " + POST_STATUSES.join(", "),
      });
    }

    const post = await Post.findByPk(id);

    if (!post) {
      return res.status(404).json({ success: false, message: "Post not found" });
    }

    const updateData = {
      status,
      updated_by: req.user ? req.user.id : null,
    };

    // Stamp the publication date the first time it goes live, and leave it
    // alone afterwards so re-publishing does not rewrite history.
    if (status === "published" && !post.published_at) {
      updateData.published_at = new Date();
    }

    await post.update(updateData);

    return res.json({
      success: true,
      message: "Status updated successfully",
    });
  } catch (error) {
    console.error("Update status error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update status",
    });
  }
};

// ==========================================
// DELETE  (soft delete)
// ==========================================
exports.deletePost = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const post = await Post.findByPk(id);

    if (!post) {
      return res.status(404).json({ success: false, message: "Post not found" });
    }

    await post.destroy();

    return res.json({ success: true, message: "Post deleted successfully" });
  } catch (error) {
    console.error("Delete post error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to delete post",
    });
  }
};

exports.POST_STATUSES = POST_STATUSES;
exports.POST_SORT_FIELDS = POST_SORT_FIELDS;
exports.PUBLIC_AUTHOR_ATTRIBUTES = PUBLIC_AUTHOR_ATTRIBUTES;
exports.adminIncludes = adminIncludes;
