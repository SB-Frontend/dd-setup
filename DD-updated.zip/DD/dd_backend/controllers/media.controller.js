// controllers/media.controller.js
//
// ADMIN media library.
//
// Field renames from the legacy media_list table:
//   media_id -> id   media_title -> title
//   media_path -> filename   (it always held a bare filename, not a path)
//   user_id -> uploaded_by
//
// uploaded_by references users, never authors: uploading is a CMS action by a
// logged-in operator. An author profile image is author data and lives in
// authors.image.

const { Op } = require("sequelize");

const Media = require("../models/media.model");
const User = require("../models/user.model");
const { parsePagination, parseSort, toId } = require("../utils/queryParams");

const MEDIA_SORT_FIELDS = ["id", "title", "filename", "file_size", "created_at"];

const withUploader = () => [
  { model: User, as: "uploader", attributes: ["id", "username", "full_name"], required: false },
];

exports.createMedia = async (req, res) => {
  try {
    const { title } = req.body;

    if (!req.file) {
      return res.status(400).json({ success: false, message: "A file is required" });
    }

    const media = await Media.create({
      filename: req.file.filename,
      original_filename: req.file.originalname || null,
      title: title || null,
      mime_type: req.file.mimetype || null,
      file_size: req.file.size || null,
      storage_path: "posts",

      // From the session, never the request body.
      uploaded_by: req.user ? req.user.id : null,
    });

    return res.status(201).json({
      success: true,
      message: "Media uploaded successfully",
      data: media,
    });
  } catch (error) {
    console.error("Create media error:", error);

    return res.status(500).json({ success: false, message: "Failed to upload media" });
  }
};

exports.getMediaList = async (req, res) => {
  try {
    const source = { ...req.query, ...(req.body || {}) };

    const { search = "" } = source;

    const { page, limit, offset } = parsePagination(source);

    const { field, order } = parseSort(source, {
      allowed: MEDIA_SORT_FIELDS,
      defaultField: "created_at",
      defaultOrder: "DESC",
    });

    const where = {};

    if (search) {
      where[Op.or] = [
        { title: { [Op.like]: `%${search}%` } },
        { original_filename: { [Op.like]: `%${search}%` } },
      ];
    }

    const totalCount = await Media.count();

    const { count, rows } = await Media.findAndCountAll({
      where,
      include: withUploader(),
      order: [[field, order]],
      limit,
      offset,
      distinct: true,
    });

    return res.status(200).json({
      draw: page,
      iTotalRecords: totalCount,
      iTotalDisplayRecords: count,
      aaData: rows,
    });
  } catch (error) {
    console.error("Get media list error:", error);

    return res.status(500).json({ success: false, message: "Failed to fetch media" });
  }
};

exports.getMediaById = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const media = await Media.findByPk(id, { include: withUploader() });

    if (!media) {
      return res.status(404).json({ success: false, message: "Media not found" });
    }

    return res.status(200).json({ success: true, data: media });
  } catch (error) {
    console.error("Get media by id error:", error);

    return res.status(500).json({ success: false, message: "Failed to fetch media" });
  }
};

exports.updateMedia = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const media = await Media.findByPk(id);

    if (!media) {
      return res.status(404).json({ success: false, message: "Media not found" });
    }

    const { title } = req.body;

    // Only fields the caller actually sent.
    const updateData = {};

    if (title !== undefined) updateData.title = title;

    if (req.file) {
      updateData.filename = req.file.filename;
      updateData.original_filename = req.file.originalname || null;
      updateData.mime_type = req.file.mimetype || null;
      updateData.file_size = req.file.size || null;
    }

    await media.update(updateData);

    return res.status(200).json({
      success: true,
      message: "Media updated successfully",
      data: media,
    });
  } catch (error) {
    console.error("Update media error:", error);

    return res.status(500).json({ success: false, message: "Failed to update media" });
  }
};

// Soft delete: the row is retained so the file on disk is still accounted for.
exports.deleteMediaById = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const media = await Media.findByPk(id);

    if (!media) {
      return res.status(404).json({ success: false, message: "Media not found" });
    }

    await media.destroy();

    return res.status(200).json({ success: true, message: "Media deleted successfully" });
  } catch (error) {
    console.error("Delete media error:", error);

    return res.status(500).json({ success: false, message: "Failed to delete media" });
  }
};

exports.MEDIA_SORT_FIELDS = MEDIA_SORT_FIELDS;
