// controllers/website/posts.controller.js
//
// PUBLIC read endpoints for posts. No authentication, ever.
//
// AUTHOR DATA COMES FROM `authors`, NEVER FROM `users`.
// posts.author_id -> authors.id, and only safe public author fields are
// exposed. CMS account details (username, email, roles, permissions,
// created_by, updated_by) are never returned on this surface.
//
// The two fake database views are gone. Category names still come from a
// cached p_cat map rather than a join, because the listing needs one string
// from a nine-row table on every page render; the author association is a
// real include, used only where a byline is actually shown.

const { Op } = require("sequelize");

const Post = require("../../models/post.model");
const Author = require("../../models/author.model");
const {
  getCategoryMap,
  getSubcategoryMap,
} = require("../../services/category.service");
const { parsePagination, toInt } = require("../../utils/queryParams");

const PUBLISHED = "published";

// Website pages show a few dozen cards; a lower ceiling than the admin cap
// also limits what scraping yields per request.
const MAX_LIMIT = 50;

// Exactly what the public site may see about an author.
const PUBLIC_AUTHOR_ATTRIBUTES = [
  "id",
  "name",
  "display_name",
  "slug",
  "bio",
  "image",
];

// Listings never include `content` - it is a LONGTEXT column.
const LIST_ATTRIBUTES = [
  "id",
  "title",
  "slug",
  "banner_image",
  "excerpt",
  "meta_description",
  "published_at",
  // Needed for <lastmod> and for cache revalidation on the Next.js side.
  "updated_at",
  "reading_time",
  "category_id",
  "subcategory_id",
];

const DETAIL_ATTRIBUTES = [
  "id",
  "title",
  "slug",
  "content",
  "excerpt",
  "banner_image",
  "published_at",
  "created_at",
  "updated_at",
  "reading_time",
  "category_id",
  "subcategory_id",
  "meta_title",
  "meta_description",
  "meta_keywords",
];

const RELATED_ATTRIBUTES = [
  "id",
  "title",
  "slug",
  "banner_image",
  "excerpt",
  "published_at",
  "reading_time",
  "category_id",
  "subcategory_id",
];

// Allowlist. An unknown value falls back to published_at rather than reaching
// ORDER BY, so no query parameter can ever name a column or an expression.
const SORTABLE = [
  "published_at",
  "created_at",
  "updated_at",
  "reading_time",
  "title",
];

const READING_TIME_RANGES = {
  "under-5": { [Op.lt]: 5 },
  "5-10": { [Op.gte]: 5, [Op.lte]: 10 },
  "10-plus": { [Op.gt]: 10 },
};

const publicAuthorInclude = () => ({
  model: Author,
  as: "author",
  attributes: PUBLIC_AUTHOR_ATTRIBUTES,
  required: false,
  // Hidden authors keep their articles visible but lose the byline.
  where: { status: 1 },
});

// Accepts 3, "3", "1,2,3" or ["1","2"].
function parseIdList(raw) {
  if (raw === undefined || raw === null || raw === "") return [];

  const parts = Array.isArray(raw) ? raw : String(raw).split(",");

  return parts.map((p) => toInt(p)).filter((n) => n !== null && n > 0);
}

// Built once and used for both the count and the rows, so the two can never
// describe different sets.
function buildWhere(query) {
  const where = { status: PUBLISHED };

  const categoryIds = parseIdList(query.category_id ?? query.cat_id);

  if (categoryIds.length > 0) where.category_id = { [Op.in]: categoryIds };

  const subcategoryIds = parseIdList(query.subcategory_id);

  if (subcategoryIds.length > 0) where.subcategory_id = { [Op.in]: subcategoryIds };

  const excludeIds = parseIdList(query.exclude_id);

  if (excludeIds.length > 0) where.id = { [Op.notIn]: excludeIds };

  const bucket = READING_TIME_RANGES[query.reading_time];

  if (bucket) where.reading_time = bucket;

  const search = typeof query.search === "string" ? query.search.trim() : "";

  if (search) where.title = { [Op.like]: `%${search}%` };

  return where;
}

function resolveSort(query) {
  const field =
    typeof query.sort === "string" && SORTABLE.includes(query.sort)
      ? query.sort
      : "published_at";

  const requested = typeof query.order === "string" ? query.order.toUpperCase() : null;

  return { field, order: requested === "ASC" ? "ASC" : "DESC" };
}

/**
 * Attach the public taxonomy to a post row.
 *
 * The flat category_name / category_slug pair is the shape the website has
 * always consumed and is kept unchanged. The nested `category` and
 * `subcategory` objects are additive, so an existing page keeps working while
 * a new one can read a single object.
 *
 * A post with no subcategory - the column is nullable and most posts leave it
 * empty - gets `subcategory: null`. Nothing is manufactured, and a caller can
 * test one field rather than three.
 */
function withTaxonomy(row, categories, subcategories) {
  const category = categories.get(Number(row.category_id)) || null;

  const subcategory =
    row.subcategory_id === null || row.subcategory_id === undefined
      ? null
      : subcategories.get(Number(row.subcategory_id)) || null;

  return {
    ...row,

    category_name: category ? category.name : null,
    category_slug: category ? category.slug : null,

    subcategory_name: subcategory ? subcategory.name : null,
    subcategory_slug: subcategory ? subcategory.slug : null,

    category: category
      ? { id: category.id, name: category.name, slug: category.slug }
      : null,

    subcategory: subcategory
      ? { id: subcategory.id, name: subcategory.name, slug: subcategory.slug }
      : null,
  };
}

// ==========================================
// GET /api/website/posts
// ==========================================
exports.listPosts = async (req, res, next) => {
  try {
    const query = req.query;

    const { page, limit, offset } = parsePagination(query, {
      defaultLimit: 10,
      maxLimit: MAX_LIMIT,
    });

    const where = buildWhere(query);
    const { field, order } = resolveSort(query);

    // Count and rows come from the same model with the same WHERE.
    const [total, rows] = await Promise.all([
      Post.count({ where }),
      Post.findAll({
        where,
        attributes: LIST_ATTRIBUTES,
        // id is a tiebreaker so paging is stable when posts share a date.
        order: [
          [field, order],
          ["id", "DESC"],
        ],
        limit,
        offset,
        raw: true,
      }),
    ]);

    // Both maps come from the same TTL cache, so a warm listing is still
    // exactly two queries: the count and the rows.
    const [categories, subcategories] = await Promise.all([
      getCategoryMap(),
      getSubcategoryMap(),
    ]);

    const totalPages = limit > 0 ? Math.ceil(total / limit) : 0;

    return res.json({
      success: true,
      data: rows.map((row) => withTaxonomy(row, categories, subcategories)),
      meta: {
        page,
        limit,
        total,
        total_pages: totalPages,
        has_more: page < totalPages,
        sort: field,
        order,
      },
    });
  } catch (error) {
    return next(error);
  }
};

// ==========================================
// GET /api/website/posts/:slug
// ==========================================
exports.getPostBySlug = async (req, res, next) => {
  try {
    const { slug } = req.params;

    const post = await Post.findOne({
      where: { slug, status: PUBLISHED },
      attributes: DETAIL_ATTRIBUTES,
      include: [publicAuthorInclude()],
    });

    if (!post) {
      return res.status(404).json({
        success: false,
        error: "Not Found",
        message: "Post not found.",
      });
    }

    const relatedLimit = Math.min(
      Math.max(toInt(req.query.related_limit) || 5, 1),
      12
    );

    const related = await Post.findAll({
      where: {
        status: PUBLISHED,
        category_id: post.category_id,
        id: { [Op.ne]: post.id },
      },
      attributes: RELATED_ATTRIBUTES,
      order: [
        ["published_at", "DESC"],
        ["id", "DESC"],
      ],
      limit: relatedLimit,
      raw: true,
    });

    const [categories, subcategories] = await Promise.all([
      getCategoryMap(),
      getSubcategoryMap(),
    ]);

    return res.json({
      success: true,
      data: {
        post: withTaxonomy(post.get({ plain: true }), categories, subcategories),
        related: related.map((row) => withTaxonomy(row, categories, subcategories)),
      },
    });
  } catch (error) {
    return next(error);
  }
};

// ==========================================
// GET /api/website/posts/meta/:slug
//
// The author display name previously came from the post_view projection.
// It now comes from the real association.
// ==========================================
exports.getPostMeta = async (req, res, next) => {
  try {
    const { slug } = req.params;

    const post = await Post.findOne({
      where: { slug, status: PUBLISHED },
      attributes: [
        "id",
        "title",
        "slug",
        "meta_title",
        "meta_description",
        "meta_keywords",
        "banner_image",
        "published_at",
        "updated_at",
        "category_id",
        "subcategory_id",
      ],
      include: [publicAuthorInclude()],
    });

    if (!post) {
      return res.status(404).json({
        success: false,
        error: "Not Found",
        message: "Post not found.",
      });
    }

    const [categories, subcategories] = await Promise.all([
      getCategoryMap(),
      getSubcategoryMap(),
    ]);

    const shaped = withTaxonomy(post.get({ plain: true }), categories, subcategories);

    return res.json({
      success: true,
      data: {
        title: shaped.title,
        slug: shaped.slug,
        meta_title: shaped.meta_title,
        meta_description: shaped.meta_description,
        meta_keywords: shaped.meta_keywords,
        banner_image: shaped.banner_image,
        published_at: shaped.published_at,
        // <lastmod> and revalidation on the Next.js side.
        updated_at: shaped.updated_at,
        author_display_name: post.author ? post.author.display_name : null,
        category_name: shaped.category_name,
        category_slug: shaped.category_slug,
        subcategory_name: shaped.subcategory_name,
        subcategory_slug: shaped.subcategory_slug,
        category: shaped.category,
        subcategory: shaped.subcategory,
      },
    });
  } catch (error) {
    return next(error);
  }
};

// ==========================================
// GET /api/website/sitemap/posts
//
// Published posts only. Every row carries what <loc> and <lastmod> need.
//
// D5 FIX: this used to drop any post whose category could not be resolved
// (`if (!category) return null`). posts.category_id is nullable, so a
// published post with no category - or one whose category had been
// deactivated - vanished from the sitemap silently and was never indexed.
// The row is now always emitted, with category_slug null, and the caller
// decides which URL shape to build. Losing a published page from search
// results is a worse failure than emitting a row the generator skips.
// ==========================================
exports.getPostSitemap = async (req, res, next) => {
  try {
    const [rows, categories, subcategories] = await Promise.all([
      Post.findAll({
        where: { status: PUBLISHED },
        attributes: [
          "id",
          "slug",
          "category_id",
          "subcategory_id",
          "updated_at",
          "published_at",
        ],
        order: [["published_at", "DESC"]],
        raw: true,
      }),
      getCategoryMap(),
      getSubcategoryMap(),
    ]);

    const data = rows.map((row) => {
      const category = categories.get(Number(row.category_id)) || null;

      const subcategory =
        row.subcategory_id === null || row.subcategory_id === undefined
          ? null
          : subcategories.get(Number(row.subcategory_id)) || null;

      return {
        id: row.id,
        post_slug: row.slug,
        slug: row.slug,
        category_slug: category ? category.slug : null,
        subcategory_slug: subcategory ? subcategory.slug : null,

        // Everything in this response is published by construction; the field
        // is stated so a generator never has to infer it.
        status: PUBLISHED,

        // last_modified is the original field name and is kept. updated_at is
        // the column name, offered alongside it so the frontend can use
        // whichever it already reads.
        updated_at: row.updated_at,
        published_at: row.published_at,
        last_modified: row.updated_at || row.published_at,
      };
    });

    return res.json({ success: true, data });
  } catch (error) {
    return next(error);
  }
};

exports.PUBLIC_AUTHOR_ATTRIBUTES = PUBLIC_AUTHOR_ATTRIBUTES;
