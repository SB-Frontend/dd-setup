// controllers/website/subcategories.controller.js
//
// PUBLIC read endpoints for subcategories. No authentication, ever.
//
// Reads `subcategories` through the real association to `categories`. The
// fake category_subcategory_view is gone - it was a LEFT JOIN that produced a
// row per (category, subcategory) pair plus a NULL row for every empty
// category, which the old handlers then had to undo with GROUP BY and
// IS NOT NULL filters.

const Subcategory = require("../../models/subcategory.model");
const Category = require("../../models/category.model");
const { toId } = require("../../utils/queryParams");

const PUBLIC_ATTRIBUTES = ["id", "category_id", "name", "slug"];

const categoryInclude = () => ({
  model: Category,
  as: "category",
  attributes: ["id", "name", "slug"],
  required: true,
  where: { status: 1 },
});

function shape(row) {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    category_id: row.category_id,
    category_name: row.category ? row.category.name : null,
    category_slug: row.category ? row.category.slug : null,
  };
}

exports.listSubcategories = async (req, res, next) => {
  try {
    const rows = await Subcategory.findAll({
      where: { status: 1 },
      attributes: PUBLIC_ATTRIBUTES,
      include: [categoryInclude()],
      order: [["name", "ASC"]],
    });

    return res.json({ success: true, data: rows.map(shape) });
  } catch (error) {
    return next(error);
  }
};

exports.listByCategory = async (req, res, next) => {
  try {
    const categoryId = toId(req.params.category_id || req.params.cat_id);

    if (categoryId === null) {
      return res.status(400).json({
        success: false,
        error: "Bad Request",
        message: "category_id must be a positive integer.",
      });
    }

    const rows = await Subcategory.findAll({
      where: { category_id: categoryId, status: 1 },
      attributes: PUBLIC_ATTRIBUTES,
      include: [categoryInclude()],
      order: [["name", "ASC"]],
    });

    return res.json({ success: true, data: rows.map(shape) });
  } catch (error) {
    return next(error);
  }
};

exports.getSubcategoryMeta = async (req, res, next) => {
  try {
    const subcategory = await Subcategory.findOne({
      where: { slug: req.params.slug || req.params.subcat_slug, status: 1 },
      attributes: ["name", "slug", "meta_title", "meta_description", "meta_keywords"],
      raw: true,
    });

    if (!subcategory) {
      return res.status(404).json({
        success: false,
        error: "Not Found",
        message: "Subcategory not found.",
      });
    }

    return res.json({ success: true, data: subcategory });
  } catch (error) {
    return next(error);
  }
};

exports.getSubcategorySitemap = async (req, res, next) => {
  try {
    const rows = await Subcategory.findAll({
      where: { status: 1 },
      attributes: ["slug", "category_id"],
      include: [categoryInclude()],
    });

    const data = rows
      .filter((r) => r.category && r.category.slug && r.slug)
      .map((r) => ({ category_slug: r.category.slug, subcategory_slug: r.slug }));

    return res.json({ success: true, data });
  } catch (error) {
    return next(error);
  }
};
