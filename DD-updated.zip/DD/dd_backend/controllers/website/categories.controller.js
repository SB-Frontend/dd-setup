// controllers/website/categories.controller.js
//
// PUBLIC read endpoints for categories. No authentication, ever.

const Category = require("../../models/category.model");
const { getCategories } = require("../../services/category.service");

exports.listCategories = async (req, res, next) => {
  try {
    const data = await getCategories();

    return res.json({ success: true, data });
  } catch (error) {
    return next(error);
  }
};

// meta_desc is long gone: the column is meta_description everywhere now, so
// this endpoint no longer has to rename it on the way out.
exports.getCategoryMeta = async (req, res, next) => {
  try {
    const category = await Category.findOne({
      where: { slug: req.params.slug || req.params.cat_slug, status: 1 },
      attributes: ["name", "slug", "meta_title", "meta_description", "meta_keywords"],
      raw: true,
    });

    if (!category) {
      return res.status(404).json({
        success: false,
        error: "Not Found",
        message: "Category not found.",
      });
    }

    return res.json({ success: true, data: category });
  } catch (error) {
    return next(error);
  }
};

exports.getCategorySitemap = async (req, res, next) => {
  try {
    const rows = await getCategories();

    return res.json({
      success: true,
      data: rows.filter((r) => r.slug).map((r) => ({ category_slug: r.slug })),
    });
  } catch (error) {
    return next(error);
  }
};
