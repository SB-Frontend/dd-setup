// controllers/website/authors.controller.js
//
// PUBLIC author profiles. No authentication, ever.
//
// Reads the `authors` table directly. Previously this derived authors from
// `users WHERE is_author = 1`, which conflated CMS accounts with public
// bylines and exposed user_name - the CMS login name - to anonymous callers.
// Neither is possible now: authors are their own entity and this file never
// touches the users table.

const Author = require("../../models/author.model");

// Exactly what the public site may see. No created_by, no updated_by, no CMS
// account data of any kind.
const PUBLIC_ATTRIBUTES = ["id", "name", "display_name", "slug", "bio", "image"];

const ACTIVE = 1;

// ==========================================
// GET /api/website/authors
// ==========================================
exports.listAuthors = async (req, res, next) => {
  try {
    const rows = await Author.findAll({
      where: { status: ACTIVE },
      attributes: PUBLIC_ATTRIBUTES,
      order: [["display_name", "ASC"]],
    });

    return res.json({ success: true, data: rows });
  } catch (error) {
    return next(error);
  }
};

// ==========================================
// GET /api/website/authors/:slug
// ==========================================
exports.getAuthorBySlug = async (req, res, next) => {
  try {
    const author = await Author.findOne({
      where: { slug: req.params.slug, status: ACTIVE },
      attributes: PUBLIC_ATTRIBUTES,
    });

    if (!author) {
      return res.status(404).json({
        success: false,
        error: "Not Found",
        message: "Author not found.",
      });
    }

    return res.json({ success: true, data: author });
  } catch (error) {
    return next(error);
  }
};

// Exported so a test can assert the public field list without duplicating it.
exports.PUBLIC_ATTRIBUTES = PUBLIC_ATTRIBUTES;
