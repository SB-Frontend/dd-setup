const { Op } = require('sequelize');
const Subscription = require('../models/subscription.model');
const { parsePagination, parseSort } = require('../utils/queryParams');

const SUBSCRIPTION_SORT_FIELDS = ['id', 'email', 'name', 'created_at', 'updated_at'];

exports.subscribe = async (req, res) => {
  try {
    const { email, name } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
 if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }
 
    const [subscription, created] = await Subscription.findOrCreate({
      where: { email },
      defaults: {  name  }
    });

    res.status(200).json({ message: 'Subscribed successfully' });
  } catch (error) {
    console.error('Subscription error:', error);
    res.status(500).json({ error: 'Failed to subscribe' });
  }
};


exports.getAllSubscription = async (req, res) => {
  try {
    const { search = '' } = req.body;

    const { page, limit, offset } = parsePagination(req.body);

    const { field: sortField, order: sortOrder } = parseSort(req.body, {
      allowed: SUBSCRIPTION_SORT_FIELDS,
      defaultField: 'created_at',
      defaultOrder: 'DESC',
    });

    let where = {};
    if (search) {
  where = {
    [Op.or]: [
      {
        id: {
          [Op.like]: `%${search}%`,
        },
      },
      {
        name: {
          [Op.like]: `%${search}%`,
        },
      },
      {
        email: {
          [Op.like]: `%${search}%`,
        },
      },
    ],
  };
}

   const totalCount = await Subscription.count();

const filteredCount = await Subscription.count({
  where
});

const subscriptionList = await Subscription.findAll({
  where,
  order: [[sortField, sortOrder]],
  limit,
  offset
});
res.json({
  draw: page,
  iTotalRecords: totalCount,
  iTotalDisplayRecords: filteredCount,
  aaData: subscriptionList
});

  } catch (error) {
    console.error('Subscriptions error:', error);
    res.status(500).json({
      message: 'Failed to fetch subscription list'
    });
  }
};
