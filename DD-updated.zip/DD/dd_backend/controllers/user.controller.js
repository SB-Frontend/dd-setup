// controllers/user.controller.js
//
// CMS ACCOUNTS ONLY.
//
// Everything author-related moved to controllers/author.controller.js and the
// `authors` table. A CMS user is not a public author, so this file must never
// read or write is_author, author_photo, author_description or a public
// display name. Public author data comes from `authors`, never from here.
//
// Field renames from the legacy schema:
//   user_id -> id            user_name     -> username
//   user_email -> email      user_password -> password
//   user_status -> status    display_name  -> full_name (the operator's own
//                                             name, not a public byline)

const { Op } = require("sequelize");

const sequelize = require("../models");
const User = require("../models/user.model");
const { signAccessToken } = require("../utils/jwt");
const {
  resolveUserAccess,
  hasPermission,
  PERMISSIONS,
  BOOTSTRAP_ROLE_SLUG,
} = require("../config/permissions");
const rbac = require("../services/rbac.service");
const ApiError = require("../utils/ApiError");
const { parsePagination, toInt } = require("../utils/queryParams");

/**
 * Accept roles as a CSV string, a single value or an array, of ids or slugs.
 * Returns [] for anything absent, so "no roles supplied" and "roles supplied"
 * are never confused - the difference decides whether a permission is needed.
 */
function normaliseRoleList(value) {
  if (value === undefined || value === null || value === "") return [];

  const list = Array.isArray(value) ? value : String(value).split(",");

  return list.map((v) => String(v).trim()).filter(Boolean);
}

// What is safe to return about a CMS account. The password hash is excluded
// by the model default scope as well; this is belt and braces.
const PUBLIC_USER_ATTRIBUTES = [
  "id",
  "username",
  "full_name",
  "email",
  "status",
  "last_login_at",
  "created_at",
];

// =====================================
// CREATE USER
// =====================================
exports.createUser = async (req, res, next) => {
  try {
    const { username, full_name, email, password, status } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "username, email, and password required",
      });
    }

    // Roles are authorization, not profile data. Supplying them requires
    // role_management, so a holder of user_management alone can create an
    // account but cannot decide what it may do.
    const requestedRoles = normaliseRoleList(req.body.roles || req.body.role_ids);

    if (requestedRoles.length > 0 && !req.isBootstrap) {
      if (!hasPermission(req.user && req.user.permissions, PERMISSIONS.ROLES_UPDATE)) {
        return next(
          ApiError.forbidden("You do not have permission to assign roles.")
        );
      }
    }

    const existingUser = await User.findOne({
      where: { [Op.or]: [{ email }, { username }] },
    });

    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: "User already exists",
      });
    }

    // Account and its grants are created together: an account that exists with
    // the wrong authorization is worse than one that was never created.
    const { user, roles } = await sequelize.transaction(async (transaction) => {
      // Re-checked inside the transaction rather than trusting the middleware's
      // earlier count, so a second request cannot also be treated as the first.
      const isBootstrap =
        req.isBootstrap === true && (await User.count({ transaction })) === 0;

      // The model hashes `password` in a beforeCreate hook.
      const created = await User.create(
        {
          username,
          full_name: full_name || null,
          email,
          password,
          status: status === undefined ? 1 : Number(status) === 0 ? 0 : 1,
        },
        { transaction }
      );

      // The first account gets a real admin role row. It then authorises
      // through the normal chain - there is no permanent special case for it.
      const toAssign = isBootstrap ? [BOOTSTRAP_ROLE_SLUG] : requestedRoles;

      if (toAssign.length > 0) {
        await rbac.assignRolesToUser(created.id, toAssign, { transaction });
      }

      if (isBootstrap) {
        console.warn(
          `[auth] bootstrap account ${created.id} granted the ${BOOTSTRAP_ROLE_SLUG} role`
        );
      }

      return { user: created, roles: toAssign };
    });

    return res.status(201).json({
      success: true,
      message: "User created successfully",
      user: {
        id: user.id,
        username: user.username,
        full_name: user.full_name,
        email: user.email,
        status: user.status,
        roles,
      },
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Create user error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to create user",
    });
  }
};

// =====================================
// LOGIN
// =====================================
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }

    const user = await User.scope("withPassword").findOne({ where: { email } });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      });
    }

    if (Number(user.status) !== 1) {
      return res.status(401).json({
        success: false,
        message: "User account is inactive",
      });
    }

    if (!(await user.verifyPassword(password))) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      });
    }

    const access = await resolveUserAccess(user);

    // Recorded without blocking the response.
    user
      .update({ last_login_at: new Date() }, { silent: true })
      .catch((error) =>
        console.error("last_login_at update failed:", error.message)
      );

    // IDENTITY ONLY.
    // No roles and no permission list: authorization is resolved from the
    // database on every request, so a token that carried them would only be a
    // stale copy - and a tempting one to trust. Revoking a role takes effect
    // on the next request rather than when the token expires.
    const token = signAccessToken({ id: user.id });

    return res.json({
      success: true,
      message: "Login successful",
      user: {
        id: user.id,
        username: user.username,
        full_name: user.full_name,
        email: user.email,

        // Returned for the CMS to decide what to render. These are UI hints:
        // the backend re-resolves them per request and never trusts a copy
        // sent back by the client.
        roles: access.roles,
        modules: access.modules,
        permissions: access.permissions,
        token,
      },
    });
  } catch (error) {
    console.error("Login error:", error);

    return res.status(500).json({
      success: false,
      message: "Login failed",
    });
  }
};

// =====================================
// LIST USERS
// =====================================
exports.getUsers = async (req, res) => {
  try {
    const { search = "", status } = req.query;

    const { page, limit, offset } = parsePagination(req.query);

    const where = {};

    if (search) {
      where[Op.or] = [
        { username: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
        { full_name: { [Op.like]: `%${search}%` } },
      ];
    }

    if (status !== undefined && status !== "") {
      const statusValue = toInt(status);

      if (statusValue !== null) where.status = statusValue;
    }

    const { count, rows } = await User.findAndCountAll({
      where,
      attributes: PUBLIC_USER_ATTRIBUTES,
      order: [["created_at", "DESC"]],
      limit,
      offset,
    });

    return res.json({
      success: true,
      users: rows,
      pagination: {
        total: count,
        page,
        limit,
        totalPages: Math.ceil(count / limit),
      },
    });
  } catch (error) {
    console.error("Get users error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch users",
    });
  }
};

// =====================================
// UPDATE USER
// =====================================
exports.updateUser = async (req, res, next) => {
  try {
    const { username, full_name, email, password } = req.body;

    // "A user may edit their own record" must not become "a user may edit
    // their own authorization". Roles and status are refused here whatever
    // the caller holds; they have their own endpoints, with their own
    // permission and their own self-target protection.
    if (normaliseRoleList(req.body.roles || req.body.role_ids).length > 0) {
      return next(
        ApiError.forbidden(
          "Roles cannot be changed here. Use the user roles endpoint."
        )
      );
    }

    if (req.body.status !== undefined) {
      return next(
        ApiError.forbidden(
          "Status cannot be changed here. Use the user status endpoint."
        )
      );
    }

    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Only fields the caller actually sent. The list is a whitelist, so a
    // field that is not named here cannot be written however it is spelled.
    const updateData = {};

    if (username !== undefined) updateData.username = username;
    if (full_name !== undefined) updateData.full_name = full_name;
    if (email !== undefined) updateData.email = email;

    // The model re-hashes in a beforeUpdate hook when this changes.
    if (password) updateData.password = password;

    await user.update(updateData);

    const updatedUser = await User.findByPk(user.id, {
      attributes: PUBLIC_USER_ATTRIBUTES,
    });

    return res.json({
      success: true,
      message: "User updated successfully",
      user: updatedUser,
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Update user error:", error);

    return res.status(500).json({
      success: false,
      message: "Update failed",
    });
  }
};

// =====================================
// DELETE USER  (soft delete)
// =====================================
exports.deleteUser = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Refuse if this is the last account that could still administer the
    // system. Deleting it would be unrecoverable through the API.
    await rbac.assertRecoveryRemains(
      { excludeUserId: user.id },
      "This would leave no active account able to manage users and roles."
    );

    // Paranoid: sets deleted_at. The account disappears from every query but
    // the row survives, so created_by / updated_by audit trails stay readable.
    // Content is untouched: posts.created_by, authors.created_by and
    // media.uploaded_by are SET NULL relationships, never cascades.
    await user.destroy();

    return res.json({
      success: true,
      message: "User deleted successfully",
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Delete user error:", error);

    return res.status(500).json({
      success: false,
      message: "Delete failed",
    });
  }
};

// =====================================
// UPDATE USER STATUS  (suspend / reactivate)
// =====================================
exports.updateStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (status === undefined) {
      return res.status(400).json({
        success: false,
        message: "status is required",
      });
    }

    const newStatus = Number(status);

    if (![0, 1].includes(newStatus)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status value",
      });
    }

    const user = await User.findByPk(id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Suspending an account revokes its access on its next request, so it
    // counts as removing an administrator for lockout purposes.
    if (newStatus === 0) {
      await rbac.assertRecoveryRemains(
        { excludeUserId: user.id },
        "This would leave no active account able to manage users and roles."
      );
    }

    // Roles are untouched: suspending and reinstating an account must not
    // silently rewrite what it is allowed to do.
    await user.update({ status: newStatus });

    return res.json({
      success: true,
      message: "User status updated successfully",
      user: { id: user.id, status: newStatus },
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Update status error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update status",
    });
  }
};

// =====================================
// USER ROLES
//
// Separate from the user record on purpose. Editing a profile and deciding
// what an account may do are different privileges: these routes require
// role_management, and denySelfTarget stops an operator pointing them at
// their own account. Together that closes the self-escalation path - even a
// user holding both user_management and role_management cannot grant
// themselves anything.
// =====================================

// GET /api/admin/users/:id/roles
exports.getUserRoles = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.params.id, {
      attributes: PUBLIC_USER_ATTRIBUTES,
    });

    if (!user) return next(ApiError.notFound("User not found."));

    const access = await resolveUserAccess(user);

    return res.json({
      success: true,
      data: {
        user_id: user.id,
        roles: access.roles,
        modules: access.modules,
        permissions: access.permissions,
      },
    });
  } catch (error) {
    return next(error);
  }
};

// PUT /api/admin/users/:id/roles     replace the whole set
// POST /api/admin/users/:id/roles    add to the existing set
exports.setUserRoles = async (req, res, next) => {
  try {
    const roles = normaliseRoleList(req.body.roles || req.body.role_ids);

    if (roles.length === 0 && req.method === "POST") {
      return next(ApiError.badRequest("At least one role is required."));
    }

    const user = await User.findByPk(req.params.id);

    if (!user) return next(ApiError.notFound("User not found."));

    // Duplicate grants are absorbed rather than colliding with
    // UNIQUE(user_id, role_id); unknown roles are rejected as 400.
    const result =
      req.method === "PUT"
        ? { assigned: await rbac.replaceUserRoles(user.id, roles) }
        : await rbac.assignRolesToUser(user.id, roles);

    const current = await rbac.roleSlugsForUser(user.id);

    return res.json({
      success: true,
      message: "User roles updated successfully",
      data: { user_id: user.id, roles: current, ...result },
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Set user roles error:", error);

    return next(error);
  }
};

// DELETE /api/admin/users/:id/roles/:roleId
exports.revokeUserRole = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.params.id);

    if (!user) return next(ApiError.notFound("User not found."));

    const revoked = await rbac.revokeRoleFromUser(user.id, req.params.roleId);

    return res.json({
      success: true,
      message: "Role revoked successfully",
      data: { user_id: user.id, revoked, roles: await rbac.roleSlugsForUser(user.id) },
    });
  } catch (error) {
    if (error instanceof ApiError) return next(error);

    console.error("Revoke user role error:", error);

    return next(error);
  }
};
