// controllers/author.controller.js
//
// PUBLIC CONTENT AUTHORS - the person shown as the author of an article.
//
// An author is NOT a CMS user:
//   * creating an author never creates a login account
//   * an author may have no CMS account at all (guest, external, historical)
//   * posts.author_id -> authors.id, never users.id
//
// The only link to `users` is CMS audit metadata: created_by / updated_by
// record which operator maintained the record, not who the author is.
//
// Authorised by author_management, never user_management. Those are separate
// domains: granting Author Management must not let someone change a CMS
// account's email, password or roles.

const { Op } = require("sequelize");

const Author = require("../models/author.model");
const Post = require("../models/post.model");
const { parsePagination, parseSort, toId } = require("../utils/queryParams");

const AUTHOR_SORT_FIELDS = [
  "id",
  "name",
  "display_name",
  "slug",
  "created_at",
  "updated_at",
];

const ADMIN_ATTRIBUTES = [
  "id",
  "name",
  "display_name",
  "slug",
  "bio",
  "image",
  "status",
  "created_by",
  "updated_by",
  "created_at",
  "updated_at",
];

// Derived when the caller does not supply one, so author pages always have a
// usable URL.
function slugify(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 160);
}

// =====================================
// LIST
// =====================================
exports.listAuthors = async (req, res) => {
  try {
    const { search = "", status } = req.body && Object.keys(req.body).length
      ? req.body
      : req.query;

    const source = { ...req.query, ...(req.body || {}) };

    const { page, limit, offset } = parsePagination(source);

    const { field, order } = parseSort(source, {
      allowed: AUTHOR_SORT_FIELDS,
      defaultField: "display_name",
      defaultOrder: "ASC",
    });

    const where = {};

    if (search) {
      where[Op.or] = [
        { name: { [Op.like]: `%${search}%` } },
        { display_name: { [Op.like]: `%${search}%` } },
        { slug: { [Op.like]: `%${search}%` } },
      ];
    }

    if (status !== undefined && status !== "") {
      where.status = Number(status) === 0 ? 0 : 1;
    }

    const { count, rows } = await Author.findAndCountAll({
      where,
      attributes: ADMIN_ATTRIBUTES,
      order: [[field, order]],
      limit,
      offset,
    });

    return res.json({
      success: true,
      data: rows,
      pagination: {
        total: count,
        page,
        limit,
        totalPages: Math.ceil(count / limit),
      },
    });
  } catch (error) {
    console.error("List authors error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch authors",
    });
  }
};

// =====================================
// GET ONE
// =====================================
exports.getAuthor = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({
        success: false,
        message: "id must be a positive integer",
      });
    }

    const author = await Author.findByPk(id, { attributes: ADMIN_ATTRIBUTES });

    if (!author) {
      return res.status(404).json({
        success: false,
        message: "Author not found",
      });
    }

    return res.json({ success: true, data: author });
  } catch (error) {
    console.error("Get author error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch author",
    });
  }
};

// =====================================
// CREATE
// =====================================
exports.createAuthor = async (req, res) => {
  try {
    const { name, display_name, slug, bio, status } = req.body;

    if (!name || !display_name) {
      return res.status(400).json({
        success: false,
        message: "name and display_name are required",
      });
    }

    const finalSlug = slugify(slug || display_name);

    if (!finalSlug) {
      return res.status(400).json({
        success: false,
        message: "slug could not be derived; supply a valid slug",
      });
    }

    const existing = await Author.findOne({ where: { slug: finalSlug } });

    if (existing) {
      return res.status(409).json({
        success: false,
        message: "An author with this slug already exists",
      });
    }

    const author = await Author.create({
      name,
      display_name,
      slug: finalSlug,
      bio: bio || null,
      image: req.file ? req.file.filename : null,
      status: status === undefined ? 1 : Number(status) === 0 ? 0 : 1,

      // CMS audit. Taken from the session, never from the request body.
      created_by: req.user ? req.user.id : null,
      updated_by: req.user ? req.user.id : null,
    });

    return res.status(201).json({
      success: true,
      message: "Author created successfully",
      data: author,
    });
  } catch (error) {
    console.error("Create author error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to create author",
    });
  }
};

// =====================================
// UPDATE  (partial)
// =====================================
exports.updateAuthor = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({
        success: false,
        message: "id must be a positive integer",
      });
    }

    const author = await Author.findByPk(id);

    if (!author) {
      return res.status(404).json({
        success: false,
        message: "Author not found",
      });
    }

    const { name, display_name, slug, bio, status } = req.body;

    // Only fields the caller actually sent.
    const updateData = {};

    if (name !== undefined) updateData.name = name;
    if (display_name !== undefined) updateData.display_name = display_name;
    if (bio !== undefined) updateData.bio = bio;

    if (status !== undefined) {
      updateData.status = Number(status) === 0 ? 0 : 1;
    }

    if (slug !== undefined) {
      const finalSlug = slugify(slug);

      if (!finalSlug) {
        return res.status(400).json({
          success: false,
          message: "slug is not valid",
        });
      }

      if (finalSlug !== author.slug) {
        const clash = await Author.findOne({ where: { slug: finalSlug } });

        if (clash) {
          return res.status(409).json({
            success: false,
            message: "An author with this slug already exists",
          });
        }
      }

      updateData.slug = finalSlug;
    }

    // Only replace the image when a new file was uploaded.
    if (req.file) updateData.image = req.file.filename;

    updateData.updated_by = req.user ? req.user.id : null;

    await author.update(updateData);

    const updated = await Author.findByPk(id, { attributes: ADMIN_ATTRIBUTES });

    return res.json({
      success: true,
      message: "Author updated successfully",
      data: updated,
    });
  } catch (error) {
    console.error("Update author error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update author",
    });
  }
};

// =====================================
// DELETE  (soft delete - posts are never removed)
// =====================================
exports.deleteAuthor = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({
        success: false,
        message: "id must be a positive integer",
      });
    }

    const author = await Author.findByPk(id);

    if (!author) {
      return res.status(404).json({
        success: false,
        message: "Author not found",
      });
    }

    // Reported so an operator knows the byline will disappear from these
    // articles. The posts themselves are never touched: the model is paranoid
    // and posts.author_id is ON DELETE SET NULL.
    const attributedPosts = await Post.count({ where: { author_id: id } });

    await author.destroy();

    return res.json({
      success: true,
      message: "Author deleted successfully",
      affected_posts: attributedPosts,
    });
  } catch (error) {
    console.error("Delete author error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to delete author",
    });
  }
};

exports.AUTHOR_SORT_FIELDS = AUTHOR_SORT_FIELDS;
exports.slugify = slugify;
