// controllers/subcategory.controller.js
//
// ADMIN subcategory management.
//
// Field renames from the legacy p_sub_cat table:
//   subcat_id -> id   subcat_name -> name   subcat_slug -> slug
//   p_cat -> category_id   (a foreign key named after a table, fixed)
//   meta_desc -> meta_description
//
// The fake category_subcategory_view is gone; the parent category comes from
// the real association instead.

const Subcategory = require("../models/subcategory.model");
const Category = require("../models/category.model");
const Post = require("../models/post.model");
const { toId } = require("../utils/queryParams");
const taxonomyCache = require("../services/category.service");

const ATTRIBUTES = [
  "id",
  "category_id",
  "name",
  "slug",
  "status",
  "meta_title",
  "meta_description",
  "meta_keywords",
  "created_at",
  "updated_at",
];

const withCategory = () => [
  { model: Category, as: "category", attributes: ["id", "name", "slug"], required: false },
];

exports.getAllSubcategories = async (req, res) => {
  try {
    const data = await Subcategory.findAll({
      attributes: ATTRIBUTES,
      include: withCategory(),
      order: [["name", "ASC"]],
    });

    return res.json({ success: true, data });
  } catch (error) {
    console.error("subcategory error:", error);

    return res.status(500).json({ success: false, error: "Failed to fetch subcategory" });
  }
};

exports.getSubcategoriesByCategory = async (req, res) => {
  try {
    const categoryId = toId(req.params.cat_id || req.params.category_id);

    if (categoryId === null) {
      return res.status(400).json({
        success: false,
        message: "category_id must be a positive integer",
      });
    }

    const data = await Subcategory.findAll({
      where: { category_id: categoryId },
      attributes: ATTRIBUTES,
      order: [["name", "ASC"]],
    });

    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("Get subcategories by category error:", error);

    return res.status(500).json({ success: false, message: "Failed to fetch subcategories" });
  }
};

exports.createSubcategory = async (req, res) => {
  try {
    const { category_id, name, slug, status, meta_title, meta_description, meta_keywords } = req.body;

    if (!name || !slug) {
      return res.status(400).json({ success: false, message: "name and slug are required" });
    }

    const categoryId = toId(category_id);

    if (categoryId === null) {
      return res.status(400).json({ success: false, message: "category_id must be a positive integer" });
    }

    const parent = await Category.findByPk(categoryId, { attributes: ["id"] });

    if (!parent) {
      return res.status(404).json({ success: false, message: "Category not found" });
    }

    // slug is unique within a category, not globally.
    const existing = await Subcategory.findOne({ where: { category_id: categoryId, slug } });

    if (existing) {
      return res.status(409).json({
        success: false,
        message: "A subcategory with this slug already exists in this category",
      });
    }

    // The public site reads subcategories from a TTL cache; drop it so an
    // editorial change is visible immediately instead of up to a minute later.
    const subcategory = await Subcategory.create({
      category_id: categoryId,
      name,
      slug,
      status: status === undefined ? 1 : Number(status) === 0 ? 0 : 1,
      meta_title: meta_title || null,
      meta_description: meta_description || null,
      meta_keywords: meta_keywords || null,
    });

    taxonomyCache.invalidate();

    return res.status(201).json({ success: true, data: subcategory });
  } catch (error) {
    console.error("Create subcategory error:", error);

    return res.status(500).json({ success: false, error: "Failed to create subcategory" });
  }
};

exports.updateSubcategory = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const subcategory = await Subcategory.findByPk(id);

    if (!subcategory) {
      return res.status(404).json({ success: false, error: "Subcategory not found" });
    }

    const { category_id, name, slug, status, meta_title, meta_description, meta_keywords } = req.body;

    const updateData = {};

    for (const [key, value] of Object.entries({
      name,
      meta_title,
      meta_description,
      meta_keywords,
    })) {
      if (value !== undefined) updateData[key] = value;
    }

    if (status !== undefined) updateData.status = Number(status) === 0 ? 0 : 1;

    if (category_id !== undefined) {
      const categoryId = toId(category_id);

      if (categoryId === null) {
        return res.status(400).json({ success: false, message: "category_id must be a positive integer" });
      }

      const parent = await Category.findByPk(categoryId, { attributes: ["id"] });

      if (!parent) {
        return res.status(404).json({ success: false, message: "Category not found" });
      }

      updateData.category_id = categoryId;
    }

    if (slug !== undefined) updateData.slug = slug;

    const targetCategory = updateData.category_id || subcategory.category_id;
    const targetSlug = updateData.slug || subcategory.slug;

    if (targetCategory !== subcategory.category_id || targetSlug !== subcategory.slug) {
      const clash = await Subcategory.findOne({
        where: { category_id: targetCategory, slug: targetSlug },
      });

      if (clash && Number(clash.id) !== id) {
        return res.status(409).json({
          success: false,
          message: "A subcategory with this slug already exists in this category",
        });
      }
    }

    await subcategory.update(updateData);

    taxonomyCache.invalidate();

    const updated = await Subcategory.findByPk(id, {
      attributes: ATTRIBUTES,
      include: withCategory(),
    });

    return res.json({ success: true, data: updated });
  } catch (error) {
    console.error("Update subcategory error:", error);

    return res.status(500).json({ success: false, error: "Failed to update subcategory" });
  }
};

// Soft delete, with the same application-level guard as categories: a soft
// delete does not trip the database foreign key.
exports.deleteSubcategory = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const subcategory = await Subcategory.findByPk(id);

    if (!subcategory) {
      return res.status(404).json({ success: false, error: "Subcategory not found" });
    }

    const attached = await Post.count({ where: { subcategory_id: id } });

    if (attached > 0) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete: ${attached} post(s) still use this subcategory`,
      });
    }

    await subcategory.destroy();

    taxonomyCache.invalidate();

    return res.json({ success: true, message: "Subcategory deleted successfully" });
  } catch (error) {
    console.error("Delete subcategory error:", error);

    return res.status(500).json({ success: false, error: "Failed to delete subcategory" });
  }
};
