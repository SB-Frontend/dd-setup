// controllers/leads.controller.js
//
// Public contact-form submissions and the admin view of them.
//
// Changes from the legacy implementation:
//   * leads.comments (one appended TEXT blob) is replaced by the lead_notes
//     table, so every note has its own author and timestamp.
//   * lead_modified is gone. It was written by the old addComment and silently
//     discarded, because the column never existed. leads.updated_at and
//     lead_notes.created_at now carry that information for real.
//   * company and phone are optional, matching what the controller always
//     assumed.

const { Op } = require("sequelize");

const Lead = require("../models/lead.model");
const LeadNote = require("../models/lead_note.model");
const User = require("../models/user.model");
const { parsePagination, parseSort, toId } = require("../utils/queryParams");

const LEAD_SORT_FIELDS = [
  "id",
  "first_name",
  "last_name",
  "email",
  "company",
  "status",
  "created_at",
];

const LEAD_STATUSES = ["new", "contacted", "qualified", "closed"];

// PUBLIC. Anonymous website submission.
exports.createLead = async (req, res) => {
  try {
    const { firstName, lastName, email, company, phone, message } = req.body;

    if (!email || !firstName || !lastName || !message) {
      return res.status(400).json({ error: "Required fields are missing" });
    }

    await Lead.create({
      first_name: firstName,
      last_name: lastName,
      email,
      company: company || null,
      phone: phone || null,
      message,
    });

    return res.status(201).json({ message: "Lead submitted successfully" });
  } catch (error) {
    console.error("Lead submission error:", error);

    return res.status(500).json({ error: "Failed to submit form" });
  }
};

// ADMIN list.
exports.getAllLeads = async (req, res) => {
  try {
    const source = { ...req.query, ...(req.body || {}) };

    const { search = "", status } = source;

    const { page, limit, offset } = parsePagination(source);

    const { field, order } = parseSort(source, {
      allowed: LEAD_SORT_FIELDS,
      defaultField: "created_at",
      defaultOrder: "DESC",
    });

    const where = {};

    if (status && LEAD_STATUSES.includes(status)) where.status = status;

    if (search) {
      where[Op.or] = [
        { first_name: { [Op.like]: `%${search}%` } },
        { last_name: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
        { company: { [Op.like]: `%${search}%` } },
      ];
    }

    const totalCount = await Lead.count();

    const { count, rows } = await Lead.findAndCountAll({
      where,
      order: [[field, order]],
      limit,
      offset,
      distinct: true,
    });

    return res.json({
      draw: page,
      iTotalRecords: totalCount,
      iTotalDisplayRecords: count,
      aaData: rows,
    });
  } catch (error) {
    console.error("Leads error:", error);

    return res.status(500).json({ message: "Failed to fetch leads list" });
  }
};

// ADMIN: add a note. One row per note instead of appending to a TEXT column.
exports.addComment = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const { comment } = req.body;

    if (!comment || !comment.trim()) {
      return res.status(400).json({ success: false, message: "Comment is required" });
    }

    const lead = await Lead.findByPk(id);

    if (!lead) {
      return res.status(404).json({ success: false, message: "Lead not found" });
    }

    const note = await LeadNote.create({
      lead_id: lead.id,
      // The CMS operator who wrote it, from the session.
      user_id: req.user ? req.user.id : null,
      note: comment.trim(),
    });

    return res.status(200).json({
      success: true,
      message: "Comment added successfully",
      data: { id: note.id, created_at: note.created_at },
    });
  } catch (error) {
    console.error("Add comment error:", error);

    return res.status(500).json({ success: false, message: "Failed to add comment" });
  }
};

// ADMIN: the notes on one lead, newest first.
exports.getLeadNotes = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const lead = await Lead.findByPk(id, { attributes: ["id"] });

    if (!lead) {
      return res.status(404).json({ success: false, message: "Lead not found" });
    }

    const notes = await LeadNote.findAll({
      where: { lead_id: id },
      include: [
        { model: User, as: "author", attributes: ["id", "username", "full_name"], required: false },
      ],
      order: [["created_at", "DESC"]],
    });

    return res.json({ success: true, data: notes });
  } catch (error) {
    console.error("Get lead notes error:", error);

    return res.status(500).json({ success: false, message: "Failed to fetch notes" });
  }
};

exports.LEAD_SORT_FIELDS = LEAD_SORT_FIELDS;
exports.LEAD_STATUSES = LEAD_STATUSES;
