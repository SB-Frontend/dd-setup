// controllers/category.controller.js
//
// ADMIN category management.
//
// Field renames from the legacy p_cat table:
//   cat_id -> id   cat_name -> name   cat_slug -> slug
//   meta_desc -> meta_description   (now consistent with posts)

const Category = require("../models/category.model");
const Post = require("../models/post.model");
const { toId } = require("../utils/queryParams");
const categoryService = require("../services/category.service");

const ATTRIBUTES = [
  "id",
  "name",
  "slug",
  "status",
  "meta_title",
  "meta_description",
  "meta_keywords",
  "created_at",
  "updated_at",
];

exports.getAllCategories = async (req, res) => {
  try {
    const data = await Category.findAll({
      attributes: ATTRIBUTES,
      order: [["name", "ASC"]],
    });

    return res.json({ success: true, data });
  } catch (error) {
    console.error("category error:", error);

    return res.status(500).json({ success: false, error: "Failed to fetch category" });
  }
};

exports.createCategory = async (req, res) => {
  try {
    const { name, slug, status, meta_title, meta_description, meta_keywords } = req.body;

    if (!name || !slug) {
      return res.status(400).json({ success: false, message: "name and slug are required" });
    }

    const existing = await Category.findOne({ where: { slug } });

    if (existing) {
      return res.status(409).json({ success: false, message: "A category with this slug already exists" });
    }

    const category = await Category.create({
      name,
      slug,
      status: status === undefined ? 1 : Number(status) === 0 ? 0 : 1,
      meta_title: meta_title || null,
      meta_description: meta_description || null,
      meta_keywords: meta_keywords || null,
    });

    // The website caches the category list; make an edit visible immediately.
    categoryService.invalidate();

    return res.status(201).json({ success: true, data: category });
  } catch (error) {
    console.error("Create category error:", error);

    return res.status(500).json({ success: false, error: "Failed to create category" });
  }
};

exports.updateCategory = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const category = await Category.findByPk(id);

    if (!category) {
      return res.status(404).json({ success: false, error: "Category not found" });
    }

    const { name, slug, status, meta_title, meta_description, meta_keywords } = req.body;

    // Only fields the caller actually sent.
    const updateData = {};

    for (const [key, value] of Object.entries({
      name,
      meta_title,
      meta_description,
      meta_keywords,
    })) {
      if (value !== undefined) updateData[key] = value;
    }

    if (status !== undefined) updateData.status = Number(status) === 0 ? 0 : 1;

    if (slug !== undefined && slug !== category.slug) {
      const clash = await Category.findOne({ where: { slug } });

      if (clash) {
        return res.status(409).json({ success: false, message: "A category with this slug already exists" });
      }

      updateData.slug = slug;
    }

    await category.update(updateData);

    categoryService.invalidate();

    const updated = await Category.findByPk(id, { attributes: ATTRIBUTES });

    return res.json({ success: true, data: updated });
  } catch (error) {
    console.error("Update category error:", error);

    return res.status(500).json({ success: false, error: "Failed to update category" });
  }
};

// Soft delete. A soft delete is an UPDATE, so it does NOT trip the RESTRICT
// foreign key from posts.category_id - the check has to happen here.
exports.deleteCategory = async (req, res) => {
  try {
    const id = toId(req.params.id);

    if (id === null) {
      return res.status(400).json({ success: false, message: "id must be a positive integer" });
    }

    const category = await Category.findByPk(id);

    if (!category) {
      return res.status(404).json({ success: false, error: "Category not found" });
    }

    const attached = await Post.count({ where: { category_id: id } });

    if (attached > 0) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete: ${attached} post(s) still use this category`,
      });
    }

    await category.destroy();

    categoryService.invalidate();

    return res.json({ success: true, message: "Category deleted successfully" });
  } catch (error) {
    console.error("Delete category error:", error);

    return res.status(500).json({ success: false, error: "Failed to delete category" });
  }
};
