// utils/jwt.js
//
// One place that signs and verifies access tokens.
//
// Before this, login called jwt.sign() and the auth middleware called
// jwt.verify() with no shared configuration, which meant:
//   * verification accepted whatever algorithm the token header declared
//   * there was no issuer or audience, so a token minted by any other system
//     sharing the secret would have been accepted
//   * the lifetime was hardcoded in the controller
//
// This is configuration, not a redesign: the authentication flow is unchanged
// and authenticate() still re-reads the user from the database on every
// request, so a deactivated account loses access immediately.

const jwt = require("jsonwebtoken");

// Pinned. Passing an explicit algorithms list to verify() is what prevents a
// token from choosing its own verification algorithm.
const ALGORITHM = "HS256";

const ISSUER = process.env.JWT_ISSUER || "datademand-api";
const AUDIENCE = process.env.JWT_AUDIENCE || "datademand-admin";
const EXPIRES_IN = process.env.JWT_EXPIRES_IN || "24h";

// 32 bytes of entropy is the minimum sensible length for an HS256 secret.
const MIN_SECRET_LENGTH = 32;

function getSecret() {
  const secret = process.env.JWT_SECRET_KEY;

  if (!secret) {
    throw new Error("JWT_SECRET_KEY is not set");
  }

  return secret;
}

/**
 * Boot-time check. Never logs or returns the secret itself - only its length
 * and whether it is usable.
 *
 * Throws in production so a misconfigured deployment fails fast instead of
 * signing tokens with a weak or missing key. Warns elsewhere so local work is
 * not blocked.
 */
function assertSecretUsable({ strict = process.env.NODE_ENV === "production" } = {}) {
  const secret = process.env.JWT_SECRET_KEY;

  const problems = [];

  if (!secret) {
    problems.push("JWT_SECRET_KEY is not set");
  } else if (secret.length < MIN_SECRET_LENGTH) {
    problems.push(
      `JWT_SECRET_KEY is ${secret.length} characters; at least ${MIN_SECRET_LENGTH} is required`
    );
  }

  if (problems.length === 0) return { ok: true, length: secret.length };

  const message = `[jwt] ${problems.join("; ")}`;

  if (strict) throw new Error(message);

  console.warn(`${message} (allowed outside production)`);

  return { ok: false, length: secret ? secret.length : 0, problems };
}

function signAccessToken(payload) {
  return jwt.sign(payload, getSecret(), {
    algorithm: ALGORITHM,
    expiresIn: EXPIRES_IN,
    issuer: ISSUER,
    audience: AUDIENCE,
  });
}

function verifyAccessToken(token) {
  return jwt.verify(token, getSecret(), {
    algorithms: [ALGORITHM],
    issuer: ISSUER,
    audience: AUDIENCE,
  });
}

module.exports = {
  signAccessToken,
  verifyAccessToken,
  assertSecretUsable,
  ALGORITHM,
  ISSUER,
  AUDIENCE,
  EXPIRES_IN,
  MIN_SECRET_LENGTH,
};
