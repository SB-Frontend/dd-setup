// utils/queryParams.js
//
// Shared parsing for list-endpoint query parameters.
//
// Five controllers duplicated the same pagination and sort handling, and each
// copy had the same two defects: Number("abc") produced NaN which reached SQL,
// and the sort field went into ORDER BY unchecked, so an unknown column became
// a 500 that echoed the MySQL error back to the caller.
//
// POLICY
//   pagination  sanitised and clamped. Garbage falls back to defaults rather
//               than erroring, which is what callers of a list endpoint
//               expect and avoids breaking the public website.
//   sort/order  allowlisted. An unrecognised field or direction falls back to
//               the endpoint default instead of reaching SQL.
//
// Mutation inputs (post_status, path ids) are NOT handled here. Those are
// rejected with 400 at their call sites, because silently substituting a
// default for a write would hide a caller's mistake.

const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 100;

// Number() but only for genuine finite integers. Number("") is 0 and
// Number("1abc") is NaN, both of which reached SQL before.
function toInt(value) {
  if (value === null || value === undefined || value === "") return null;

  const n = Number(value);

  return Number.isFinite(n) ? Math.trunc(n) : null;
}

/**
 * Parse page/limit into a safe { page, limit, offset }.
 * offset is always a non-negative integer, so it can never be NaN in SQL.
 */
function parsePagination(source = {}, options = {}) {
  const defaultLimit = options.defaultLimit || DEFAULT_LIMIT;
  const maxLimit = options.maxLimit || MAX_LIMIT;

  let page = toInt(source.page);
  let limit = toInt(source.limit);

  if (page === null || page < 1) page = 1;

  if (limit === null || limit < 1) limit = defaultLimit;
  if (limit > maxLimit) limit = maxLimit;

  return { page, limit, offset: (page - 1) * limit };
}

/**
 * Parse sort/order against an allowlist.
 *
 * @param {object} source           req.body or req.query
 * @param {object} options
 * @param {string[]} options.allowed      column names that may be sorted on
 * @param {string} options.defaultField   used when sort is absent or unknown
 * @param {string} [options.defaultOrder] "ASC" or "DESC", default "DESC"
 */
function parseSort(source = {}, options = {}) {
  const allowed = options.allowed || [];
  const defaultField = options.defaultField;
  const defaultOrder = options.defaultOrder === "ASC" ? "ASC" : "DESC";

  const requested = source.sort;

  const field =
    typeof requested === "string" && allowed.includes(requested)
      ? requested
      : defaultField;

  const requestedOrder =
    typeof source.order === "string" ? source.order.toUpperCase() : null;

  const order =
    requestedOrder === "ASC" || requestedOrder === "DESC"
      ? requestedOrder
      : defaultOrder;

  return { field, order };
}

/**
 * Strict positive-integer id for path parameters.
 * Returns null when the value is not usable, so the caller can send a 400
 * instead of letting NaN reach the query builder.
 */
function toId(value) {
  const n = toInt(value);

  return n !== null && n > 0 ? n : null;
}

module.exports = {
  parsePagination,
  parseSort,
  toId,
  toInt,
  DEFAULT_LIMIT,
  MAX_LIMIT,
};
