// utils/cache.js
//
// Minimal in-process TTL cache for small, slow-changing reference data.
//
// The public site reads the category list on effectively every page render.
// p_cat holds fewer than ten rows and changes a few times a year, so serving
// it from a short-lived cache removes a database round trip from the hot path
// without any meaningful staleness.
//
// Deliberately not Redis: a single process, a handful of rows, and a 60
// second TTL do not justify another moving part. If the API is ever scaled to
// multiple instances, each keeps its own copy and they converge within one
// TTL, which is acceptable for taxonomy data.

function createTTLCache(ttlMs) {
  let value;
  let expiresAt = 0;
  let inflight = null;

  return {
    // loader is only called when the entry is missing or stale. Concurrent
    // callers during a refresh share one query rather than stampeding the
    // database.
    async get(loader) {
      if (value !== undefined && Date.now() < expiresAt) return value;

      if (inflight) return inflight;

      inflight = Promise.resolve()
        .then(loader)
        .then(
          (loaded) => {
            value = loaded;
            expiresAt = Date.now() + ttlMs;
            inflight = null;

            return loaded;
          },
          (error) => {
            inflight = null;

            throw error;
          }
        );

      return inflight;
    },

    clear() {
      value = undefined;
      expiresAt = 0;
    },
  };
}

module.exports = { createTTLCache };
