// utils/ApiError.js
//
// An error carrying an HTTP status and a client-safe message.
//
// Anything thrown or passed to next() that is NOT an ApiError is treated as
// unexpected by the error middleware and reported generically, so an
// accidental throw can never leak internals.

class ApiError extends Error {
  /**
   * @param {number} statusCode  HTTP status to send.
   * @param {string} message     Client-safe message. Never interpolate raw
   *                             driver, filesystem or SQL text into this.
   * @param {object} [options]
   * @param {string} [options.error]   Short label, e.g. "Not Found".
   * @param {object} [options.details] Safe structured detail, e.g. field errors.
   * @param {Error}  [options.cause]   Original error, logged but never sent.
   */
  constructor(statusCode, message, options = {}) {
    super(message);

    this.name = "ApiError";
    this.statusCode = statusCode;
    this.expected = true;

    if (options.error) this.error = options.error;
    if (options.details) this.details = options.details;
    if (options.cause) this.cause = options.cause;

    Error.captureStackTrace(this, ApiError);
  }

  static badRequest(message, details) {
    return new ApiError(400, message, { error: "Bad Request", details });
  }

  static unauthorized(message) {
    return new ApiError(401, message, { error: "Authentication Failed" });
  }

  static forbidden(message) {
    return new ApiError(403, message, { error: "Access Denied" });
  }

  static notFound(message) {
    return new ApiError(404, message, { error: "Not Found" });
  }

  static conflict(message, details) {
    return new ApiError(409, message, { error: "Conflict", details });
  }

  static payloadTooLarge(message) {
    return new ApiError(413, message, { error: "Payload Too Large" });
  }
}

module.exports = ApiError;
