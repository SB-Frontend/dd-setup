// services/rbac.service.js
//
// The one place that writes user_roles and role_permissions.
//
// Controllers never insert into those tables directly. Everything that changes
// who may do what goes through here, so the lockout guard and the duplicate
// handling cannot be forgotten at a call site.
//
// LOCKOUT GUARD
//   Since D4 removed the implicit-admin fallback, authorization is exactly
//   what the database says. That makes it possible to remove the last account
//   able to administer the system, which is unrecoverable through the API:
//   nobody would be left who could grant the permission back.
//
//   An account is "recovery capable" when its roles grant BOTH users.update
//   and roles.update (config/permissions.js RECOVERY_PERMISSIONS) - it can
//   repair an account and it can hand out roles. Any operation that would
//   leave zero active, non-deleted, recovery-capable accounts is refused with
//   409. The guard never fires while another such account remains.

const { Op } = require("sequelize");

const sequelize = require("../models");
const {
  User,
  Role,
  Permission,
  UserRole,
  RolePermission,
} = require("../models/associations");

const ApiError = require("../utils/ApiError");
const {
  RECOVERY_PERMISSIONS,
  expandSlugs,
} = require("../config/permissions");

// ==========================================
// LOOKUPS BY STABLE IDENTIFIER
//
// Slugs, never ids: auto-increment values differ between environments, so an
// id baked into application logic is a bug waiting for the next deployment.
// ==========================================

async function findRole(idOrSlug, options = {}) {
  const asNumber = Number(idOrSlug);

  const where = Number.isInteger(asNumber) && String(asNumber) === String(idOrSlug)
    ? { id: asNumber }
    : { role_slug: String(idOrSlug) };

  return Role.findOne({ where, ...options });
}

/**
 * Resolve a mixed list of permission ids or slugs to Permission rows.
 * Throws 400 naming the entries that do not exist, so a caller cannot half
 * apply a grant set (section 16: every supplied permission must exist).
 */
async function resolvePermissions(entries, options = {}) {
  const list = Array.isArray(entries) ? entries : [];

  if (list.length === 0) return [];

  const ids = [];
  const slugs = [];

  for (const entry of list) {
    const asNumber = Number(entry);

    if (Number.isInteger(asNumber) && String(asNumber) === String(entry).trim()) {
      ids.push(asNumber);
    } else {
      slugs.push(String(entry).trim());
    }
  }

  const rows = await Permission.findAll({
    where: { [Op.or]: [{ id: { [Op.in]: ids } }, { permission_slug: { [Op.in]: slugs } }] },
    ...options,
  });

  const found = new Set([
    ...rows.map((r) => String(r.id)),
    ...rows.map((r) => r.permission_slug),
  ]);

  const unknown = list
    .map((e) => String(e).trim())
    .filter((e) => !found.has(e));

  if (unknown.length > 0) {
    throw ApiError.badRequest(
      `Unknown permission: ${[...new Set(unknown)].slice(0, 5).join(", ")}`
    );
  }

  return rows;
}

async function resolveRoles(entries, options = {}) {
  const list = Array.isArray(entries) ? entries : [];

  if (list.length === 0) return [];

  const ids = [];
  const slugs = [];

  for (const entry of list) {
    const asNumber = Number(entry);

    if (Number.isInteger(asNumber) && String(asNumber) === String(entry).trim()) {
      ids.push(asNumber);
    } else {
      slugs.push(String(entry).trim());
    }
  }

  const rows = await Role.findAll({
    where: { [Op.or]: [{ id: { [Op.in]: ids } }, { role_slug: { [Op.in]: slugs } }] },
    ...options,
  });

  const found = new Set([
    ...rows.map((r) => String(r.id)),
    ...rows.map((r) => r.role_slug),
  ]);

  const unknown = list
    .map((e) => String(e).trim())
    .filter((e) => !found.has(e));

  if (unknown.length > 0) {
    throw ApiError.badRequest(
      `Unknown role: ${[...new Set(unknown)].slice(0, 5).join(", ")}`
    );
  }

  return rows;
}

// ==========================================
// READ
// ==========================================

/** Module slugs a role currently grants. */
async function permissionSlugsForRole(roleId, options = {}) {
  const rows = await RolePermission.findAll({
    where: { role_id: roleId },
    include: [
      { model: Permission, as: "permission", attributes: ["permission_slug"] },
    ],
    ...options,
  });

  return rows.map((r) => r.permission && r.permission.permission_slug).filter(Boolean);
}

/** Role slugs a user currently holds. */
async function roleSlugsForUser(userId, options = {}) {
  const rows = await UserRole.findAll({
    where: { user_id: userId },
    include: [{ model: Role, as: "role", attributes: ["role_slug"] }],
    ...options,
  });

  return rows.map((r) => r.role && r.role.role_slug).filter(Boolean);
}

// ==========================================
// LOCKOUT GUARD
// ==========================================

/**
 * Ids of active accounts that can still administer authorization, computed
 * from the live tables rather than from any cached view.
 *
 * `simulate` lets a caller ask "who would be left if I did this?" without
 * writing anything:
 *   excludeUserId    - this account is being deleted or deactivated
 *   revoke           - { userId, roleIds } this grant is being removed
 *   roleModules      - { roleId, modules } this role's grants are being replaced
 */
async function recoveryCapableUserIds(simulate = {}, options = {}) {
  const { excludeUserId = null, revoke = null, roleModules = null } = simulate;

  const grants = await UserRole.findAll({
    attributes: ["user_id", "role_id"],
    include: [
      {
        model: User,
        as: "user",
        attributes: ["id", "status"],
        required: true,
      },
      {
        model: Role,
        as: "role",
        attributes: ["id"],
        required: true,
        include: [
          {
            model: Permission,
            as: "permissions",
            attributes: ["permission_slug"],
            through: { attributes: [] },
          },
        ],
      },
    ],
    ...options,
  });

  const perUser = new Map();

  for (const grant of grants) {
    const user = grant.user;
    const role = grant.role;

    if (!user || !role) continue;

    // A suspended or soft-deleted account cannot log in, so it cannot recover
    // anything. (Paranoid User excludes soft-deleted rows from `include`.)
    if (Number(user.status) !== 1) continue;

    if (excludeUserId !== null && Number(user.id) === Number(excludeUserId)) continue;

    if (
      revoke &&
      Number(revoke.userId) === Number(user.id) &&
      (revoke.roleIds || []).map(Number).includes(Number(role.id))
    ) {
      continue;
    }

    // Either the role's real grants, or the replacement set being proposed.
    const modules =
      roleModules && Number(roleModules.roleId) === Number(role.id)
        ? roleModules.modules
        : role.permissions.map((p) => p.permission_slug);

    const existing = perUser.get(user.id) || new Set();

    expandSlugs(modules).forEach((action) => existing.add(action));

    perUser.set(user.id, existing);
  }

  const capable = [];

  for (const [userId, actions] of perUser) {
    if (RECOVERY_PERMISSIONS.every((permission) => actions.has(permission))) {
      capable.push(userId);
    }
  }

  return capable;
}

/**
 * Refuse an operation that would leave nobody able to administer the system.
 *
 * Deliberately a 409 rather than a 403: the caller is allowed to do this, the
 * system state is what forbids it.
 */
async function assertRecoveryRemains(simulate, message, options = {}) {
  const remaining = await recoveryCapableUserIds(simulate, options);

  if (remaining.length === 0) {
    throw ApiError.conflict(message);
  }
}

// ==========================================
// WRITE - user roles
// ==========================================

/**
 * Grant roles to a user. Idempotent: a grant that already exists is reported
 * as unchanged rather than violating UNIQUE(user_id, role_id).
 */
async function assignRolesToUser(userId, roles, { transaction } = {}) {
  const rows = await resolveRoles(roles, { transaction });

  const existing = await UserRole.findAll({
    attributes: ["role_id"],
    where: { user_id: userId },
    transaction,
  });

  const held = new Set(existing.map((r) => Number(r.role_id)));
  const toAdd = rows.filter((r) => !held.has(Number(r.id)));

  if (toAdd.length > 0) {
    await UserRole.bulkCreate(
      toAdd.map((r) => ({ user_id: userId, role_id: r.id })),
      { transaction, ignoreDuplicates: true }
    );
  }

  return {
    assigned: toAdd.map((r) => r.role_slug),
    unchanged: rows.filter((r) => held.has(Number(r.id))).map((r) => r.role_slug),
  };
}

/**
 * Revoke one role from a user, refusing if that would remove the last
 * administrator.
 */
async function revokeRoleFromUser(userId, roleIdOrSlug, { transaction } = {}) {
  const role = await findRole(roleIdOrSlug, { transaction });

  if (!role) throw ApiError.notFound("Role not found.");

  const grant = await UserRole.findOne({
    where: { user_id: userId, role_id: role.id },
    transaction,
  });

  if (!grant) throw ApiError.notFound("That user does not hold this role.");

  await assertRecoveryRemains(
    { revoke: { userId, roleIds: [role.id] } },
    "This would leave no active account able to manage users and roles.",
    { transaction }
  );

  await grant.destroy({ transaction });

  return role.role_slug;
}

/**
 * Replace a user's whole role set in one transaction, so a failure part way
 * through cannot leave the account holding neither the old nor the new roles.
 */
async function replaceUserRoles(userId, roles, { transaction } = {}) {
  const run = async (t) => {
    const rows = await resolveRoles(roles, { transaction: t });
    const keep = rows.map((r) => Number(r.id));

    const removing = await UserRole.findAll({
      attributes: ["role_id"],
      where: { user_id: userId, role_id: { [Op.notIn]: keep.length ? keep : [0] } },
      transaction: t,
    });

    if (removing.length > 0) {
      await assertRecoveryRemains(
        { revoke: { userId, roleIds: removing.map((r) => r.role_id) } },
        "This would leave no active account able to manage users and roles.",
        { transaction: t }
      );

      await UserRole.destroy({
        where: { user_id: userId, role_id: { [Op.in]: removing.map((r) => r.role_id) } },
        transaction: t,
      });
    }

    await assignRolesToUser(userId, roles, { transaction: t });

    return rows.map((r) => r.role_slug);
  };

  return transaction ? run(transaction) : sequelize.transaction(run);
}

// ==========================================
// WRITE - role permissions
// ==========================================

/**
 * Replace a role's permission set atomically (section 46). A partially applied
 * grant set is exactly the inconsistent authorization state to avoid, so the
 * delete and the insert share one transaction.
 */
async function replaceRolePermissions(roleId, permissions, { transaction } = {}) {
  const run = async (t) => {
    const rows = await resolvePermissions(permissions, { transaction: t });
    const keep = rows.map((r) => Number(r.id));

    await assertRecoveryRemains(
      { roleModules: { roleId, modules: rows.map((r) => r.permission_slug) } },
      "This would leave no active account able to manage users and roles.",
      { transaction: t }
    );

    await RolePermission.destroy({
      where: {
        role_id: roleId,
        ...(keep.length > 0 ? { permission_id: { [Op.notIn]: keep } } : {}),
      },
      transaction: t,
    });

    const existing = await RolePermission.findAll({
      attributes: ["permission_id"],
      where: { role_id: roleId },
      transaction: t,
    });

    const held = new Set(existing.map((r) => Number(r.permission_id)));
    const toAdd = rows.filter((r) => !held.has(Number(r.id)));

    if (toAdd.length > 0) {
      await RolePermission.bulkCreate(
        toAdd.map((r) => ({ role_id: roleId, permission_id: r.id })),
        { transaction: t, ignoreDuplicates: true }
      );
    }

    return rows.map((r) => r.permission_slug);
  };

  return transaction ? run(transaction) : sequelize.transaction(run);
}

module.exports = {
  findRole,
  resolveRoles,
  resolvePermissions,
  permissionSlugsForRole,
  roleSlugsForUser,
  recoveryCapableUserIds,
  assertRecoveryRemains,
  assignRolesToUser,
  revokeRoleFromUser,
  replaceUserRoles,
  replaceRolePermissions,
};
