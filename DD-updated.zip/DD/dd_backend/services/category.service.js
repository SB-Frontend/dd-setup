// services/category.service.js
//
// Cached read access to the public taxonomy - `categories` and
// `subcategories` - for the website.
//
// Both tables hold a handful of rows and change a few times a year, but the
// site needs their names on every post listing. Caching them lets the listing
// read `posts` alone and attach names in memory instead of joining, which is
// what keeps the public listing at two queries however many posts it returns.
//
// D5 added subcategories here for the same reason categories were already
// cached: the public post response now carries the subcategory, and doing that
// with a join would have added a query per listing.
//
// Admin controllers deliberately do NOT use this - the CMS must always see its
// own writes - and they call invalidate() after a change so the site picks it
// up immediately rather than waiting out the TTL.

const Category = require("../models/category.model");
const Subcategory = require("../models/subcategory.model");
const { createTTLCache } = require("../utils/cache");

const TTL_MS = Number(process.env.CATEGORY_CACHE_TTL_MS) || 60000;

const cache = createTTLCache(TTL_MS);
const subcategoryCache = createTTLCache(TTL_MS);

// Only what the public site can use. Meta fields stay out unless a meta
// endpoint asks for them explicitly.
const PUBLIC_ATTRIBUTES = ["id", "name", "slug"];

async function getCategories() {
  return cache.get(() =>
    Category.findAll({
      where: { status: 1 },
      attributes: PUBLIC_ATTRIBUTES,
      order: [["name", "ASC"]],
      raw: true,
    })
  );
}

// id -> { id, name, slug }
async function getCategoryMap() {
  const rows = await getCategories();

  return new Map(rows.map((row) => [Number(row.id), row]));
}

// category_id is carried so a caller can check that a post's subcategory
// really belongs to the category it claims.
const PUBLIC_SUBCATEGORY_ATTRIBUTES = ["id", "category_id", "name", "slug"];

async function getSubcategories() {
  return subcategoryCache.get(() =>
    Subcategory.findAll({
      where: { status: 1 },
      attributes: PUBLIC_SUBCATEGORY_ATTRIBUTES,
      order: [["name", "ASC"]],
      raw: true,
    })
  );
}

// id -> { id, category_id, name, slug }
async function getSubcategoryMap() {
  const rows = await getSubcategories();

  return new Map(rows.map((row) => [Number(row.id), row]));
}

// Clears both: a category change can hide the subcategories under it, so the
// two must never be refreshed independently.
function invalidate() {
  cache.clear();
  subcategoryCache.clear();
}

module.exports = {
  getCategories,
  getCategoryMap,
  getSubcategories,
  getSubcategoryMap,
  invalidate,
  PUBLIC_ATTRIBUTES,
  PUBLIC_SUBCATEGORY_ATTRIBUTES,
  TTL_MS,
};
