"use strict";

/**
 * D1-006 - media
 *
 * Replaces media_list. Supports the existing secure upload implementation
 * without changing it:
 *
 *   filename          the generated stored name (timestamp + 8 random bytes +
 *                     sanitised base + one canonical extension). UNIQUE, which
 *                     mirrors the guarantee the upload code already gets from
 *                     writing with the "wx" flag.
 *   original_filename what the uploader called it, so the CMS library is
 *                     recognisable.
 *   mime_type         already validated at upload against the byte signature;
 *                     storing it avoids re-sniffing to render a library.
 *   file_size         for display and quota.
 *   storage_path      currently IMPLICIT - two directories exist
 *                     (uploads/posts, uploads/author) and only convention
 *                     distinguishes them. Making it a column removes the
 *                     guesswork.
 *
 * uploaded_by -> users.id, NOT authors.id. Uploading is a CMS action performed
 * by a logged-in operator; it says nothing about who wrote the article.
 * SET NULL because the file outlives the account.
 *
 * The legacy media_path column stored a bare FILENAME despite its name, which
 * is why it is renamed rather than kept.
 */

const TABLE_OPTIONS =
  "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

module.exports = {
  async up(queryInterface) {
    await queryInterface.sequelize.query(`
      CREATE TABLE \`media\` (
        \`id\`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`filename\`          VARCHAR(255) NOT NULL,
        \`original_filename\` VARCHAR(255) NULL,
        \`title\`             VARCHAR(255) NULL,
        \`mime_type\`         VARCHAR(100) NULL,
        \`file_size\`         INT UNSIGNED NULL,
        -- which upload directory the file lives in: 'posts' or 'author'
        \`storage_path\`      VARCHAR(50)  NOT NULL DEFAULT 'posts',
        \`uploaded_by\`       INT UNSIGNED NULL,
        \`created_at\`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                           ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_media_filename\` (\`filename\`),
        KEY \`ix_media_uploaded_by\` (\`uploaded_by\`),
        KEY \`ix_media_created_at\` (\`created_at\`),
        CONSTRAINT \`fk_media_uploaded_by\` FOREIGN KEY (\`uploaded_by\`)
          REFERENCES \`users\` (\`id\`) ON DELETE SET NULL ON UPDATE RESTRICT
      ) ${TABLE_OPTIONS}
    `);
  },

  async down(queryInterface) {
    await queryInterface.sequelize.query("DROP TABLE IF EXISTS `media`");
  },
};
