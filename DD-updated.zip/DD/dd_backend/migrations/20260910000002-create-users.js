"use strict";

/**
 * D1-002 - users  (CMS accounts only)
 *
 * A row in this table is someone who can log into the CMS. It is NOT a public
 * content author. Public author profiles live in `authors` (D1-004) and are
 * deliberately independent: an author needs no CMS account, and a CMS account
 * does not make someone an author.
 *
 * REMOVED from the legacy users table, on purpose:
 *   is_author, display_name, author_photo, author_description
 * Those are public author profile fields and now belong to `authors`.
 *
 * Naming follows the Phase D1 specification (`password`, not `password_hash`).
 * The column stores a bcrypt hash and must never hold plaintext.
 */

const TABLE_OPTIONS =
  "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

module.exports = {
  async up(queryInterface) {
    await queryInterface.sequelize.query(`
      CREATE TABLE \`users\` (
        \`id\`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`username\`      VARCHAR(100) NOT NULL,
        \`full_name\`     VARCHAR(150) NULL,
        \`email\`         VARCHAR(254) NOT NULL,
        -- bcrypt hash. Never plaintext.
        \`password\`      VARCHAR(255) NOT NULL,
        -- 1 = active, 0 = disabled. Checked on every authenticated request.
        \`status\`        TINYINT(1)   NOT NULL DEFAULT 1,
        \`last_login_at\` DATETIME     NULL,
        \`created_at\`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                       ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_users_username\` (\`username\`),
        UNIQUE KEY \`uq_users_email\` (\`email\`),
        KEY \`ix_users_status\` (\`status\`)
      ) ${TABLE_OPTIONS}
    `);
  },

  async down(queryInterface) {
    await queryInterface.sequelize.query("DROP TABLE IF EXISTS `users`");
  },
};
