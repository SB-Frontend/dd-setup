"use strict";

/**
 * 001 - BASELINE SCHEMA  (SUPERSEDED - intentionally a no-op)
 *
 * This migration originally applied db/schema-baseline.sql, a PROVISIONAL
 * capture of the legacy schema (post_data, p_cat, p_sub_cat, media_list, and
 * the two fake views).
 *
 * Phase D1 replaces that schema entirely with a clean design, so this
 * migration is now a tombstone:
 *
 *   * On databases where it is already recorded (the local development
 *     database), it stays recorded and does nothing.
 *   * On a fresh database it does nothing, so the clean Phase D1 migrations
 *     build the schema instead of the legacy one.
 *
 * It is neutralised rather than deleted so that sequelize_meta does not have
 * to be edited by hand and migration history stays consistent.
 *
 * The original DDL is kept for reference at:
 *   db/legacy/schema-baseline-legacy.sql
 */

module.exports = {
  async up() {
    console.log(
      "[001-baseline] superseded by the Phase D1 clean schema - no action taken."
    );
  },

  async down() {
    // Nothing was created, so nothing is reversed.
  },
};
