"use strict";

/**
 * D1-010 - seed RBAC reference data
 *
 * Seeds the approved permissions, roles and role->permission grants from the
 * Phase C audit. This is static system reference data, not business data.
 *
 * NO USER AND NO PASSWORD IS SEEDED.
 * First-user creation stays the responsibility of the existing application
 * bootstrap (allowFirstUserOr in middleware/permission.middleware.js), which
 * permits exactly one unauthenticated registration while `users` is empty and
 * then closes on its own. A password must never appear in a migration file.
 *
 * Grants are inserted by joining on slug rather than hardcoded ids, so the
 * mapping stays correct regardless of insertion order or auto-increment state.
 *
 * Re-runnable: every insert is guarded by the unique constraints on
 * permission_slug, role_slug and (role_id, permission_id).
 */

// Phase C approved list. post_publishing is the tenth: the role list contains
// both Content Writer and Publisher, and that distinction is meaningless
// unless publishing is separately grantable. The backend already guards
// PATCH /api/admin/posts/:id/status with its own posts.publish constant.
const PERMISSIONS = [
  ["Dashboard Management", "dashboard_management", "Access the CMS dashboard"],
  ["Post Management", "post_management", "Create and edit posts"],
  ["Post Publishing", "post_publishing", "Change a post status to published"],
  ["User Management", "user_management", "Manage CMS user accounts and roles"],
  ["Lead Management", "lead_management", "View and annotate leads and subscribers"],
  ["Category Management", "category_management", "Manage categories and subcategories"],
  ["Role Management", "role_management", "Manage roles and their permissions"],
  ["Advertisement Management", "advertisement_management", "Manage advertisements"],
  ["Author Management", "author_management", "Manage public author profiles"],
  ["Media Management", "media_management", "Upload and manage media"],
];

// Business terminology preserved exactly as supplied.
const ROLES = [
  ["Admin", "admin", "Full access to every module"],
  ["Content Management", "content_management", "Owns the editorial pipeline"],
  ["SEO Manager", "seo_manager", "Post metadata and taxonomy"],
  ["Content Head", "content_head", "Editorial approval and publishing"],
  ["Marketing Head", "marketing_head", "Leads, subscribers and advertisements"],
  ["Graphics Team", "graphics_team", "Media assets"],
  ["Content Writer", "content_writer", "Drafts posts, cannot publish"],
  ["SEO Team", "seo_team", "Post metadata and taxonomy"],
  ["Publisher", "publisher", "Reviews and publishes posts"],
];

const GRANTS = {
  admin: PERMISSIONS.map((p) => p[1]),

  content_management: [
    "dashboard_management", "post_management", "post_publishing",
    "category_management", "author_management", "media_management",
  ],

  content_head: [
    "dashboard_management", "post_management", "post_publishing",
    "category_management", "author_management", "media_management",
  ],

  seo_manager: [
    "dashboard_management", "post_management",
    "category_management", "media_management",
  ],

  marketing_head: [
    "dashboard_management", "lead_management",
    "advertisement_management", "media_management",
  ],

  publisher: ["dashboard_management", "post_management", "post_publishing"],

  seo_team: ["dashboard_management", "post_management", "category_management"],

  // Media granted so a writer can embed images without a Graphics handoff.
  content_writer: ["dashboard_management", "post_management", "media_management"],

  graphics_team: ["dashboard_management", "media_management"],
};

module.exports = {
  async up(queryInterface) {
    const sql = queryInterface.sequelize;
    const { QueryTypes } = queryInterface.sequelize.constructor;

    for (const [name, slug, description] of PERMISSIONS) {
      await sql.query(
        "INSERT INTO `permissions` (`permission_name`, `permission_slug`, `description`) " +
          "VALUES (?, ?, ?) " +
          "ON DUPLICATE KEY UPDATE `permission_name` = VALUES(`permission_name`)",
        { replacements: [name, slug, description] }
      );
    }

    for (const [name, slug, description] of ROLES) {
      await sql.query(
        "INSERT INTO `roles` (`role_name`, `role_slug`, `description`, `is_system`) " +
          "VALUES (?, ?, ?, 1) " +
          "ON DUPLICATE KEY UPDATE `role_name` = VALUES(`role_name`)",
        { replacements: [name, slug, description] }
      );
    }

    let granted = 0;

    for (const [roleSlug, permissionSlugs] of Object.entries(GRANTS)) {
      for (const permissionSlug of permissionSlugs) {
        await sql.query(
          "INSERT INTO `role_permissions` (`role_id`, `permission_id`) " +
            "SELECT r.`id`, p.`id` FROM `roles` r, `permissions` p " +
            "WHERE r.`role_slug` = ? AND p.`permission_slug` = ? " +
            "ON DUPLICATE KEY UPDATE `role_id` = `role_id`",
          { replacements: [roleSlug, permissionSlug] }
        );

        granted += 1;
      }
    }

    const [[counts]] = await sql.query(
      "SELECT (SELECT COUNT(*) FROM `permissions`) AS permissions," +
        " (SELECT COUNT(*) FROM `roles`) AS roles," +
        " (SELECT COUNT(*) FROM `role_permissions`) AS grants"
    );

    console.log(
      `[D1-010] seeded ${counts.permissions} permissions, ${counts.roles} roles, ` +
        `${counts.grants} role-permission grants (${granted} attempted)`
    );

    void QueryTypes;
  },

  async down(queryInterface) {
    const sql = queryInterface.sequelize;

    // Grants first: role_permissions.permission_id is RESTRICT.
    await sql.query("DELETE FROM `role_permissions`");
    await sql.query("DELETE FROM `roles`");
    await sql.query("DELETE FROM `permissions`");
  },
};
