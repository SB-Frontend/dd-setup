"use strict";

/**
 * D1-007 - posts
 *
 * Replaces post_data.
 *
 * ============================================================================
 * REMOVED LEGACY POST WORKFLOW FIELDS
 * ============================================================================
 * The following legacy fields were intentionally removed from the posts
 * schema during the clean database redesign:
 *
 *   - session_user            - handover_to
 *   - session_user_name       - handover_to_name
 *   - comments                - handover_time
 *   - comment_by
 *   - comment_by_name
 *
 * Reason:
 * These fields belonged to the previous handover/session/comment workflow and
 * are not part of the clean post ownership/content model.
 *
 * CMS user activity is now represented through created_by / updated_by, while
 * public post authors are represented through authors.id.
 *
 * session_user_name, comment_by_name and handover_to_name were denormalized
 * display copies of a user's name and are replaced by joins.
 *
 * handover_to / handover_to_name / handover_time only ever existed in the
 * post_view projection; post_data never had backing columns for them and no
 * application code read them.
 *
 * If a dedicated notes/activity workflow is required in the future, it must be
 * modeled as a separate normalized table (for example post_notes) rather than
 * reintroducing these fields into posts. post_notes is deliberately NOT
 * created in D1.
 * ============================================================================
 *
 * THREE DISTINCT PEOPLE, THREE DISTINCT COLUMNS
 *   author_id  -> authors.id   who is displayed as the author (public)
 *   created_by -> users.id     which CMS operator created the record
 *   updated_by -> users.id     which CMS operator last edited the record
 * The legacy `session_user` collapsed all of this into one column that
 * defaulted to user 1.
 *
 * author_id uses ON DELETE SET NULL: removing an author must never delete
 * their articles.
 *
 * WHY BOTH category_id AND subcategory_id
 * subcategory_id is nullable, so category cannot be reliably derived through
 * it - a post with no subcategory would have no category at all. The website
 * also filters posts by category directly, and deriving would force a join on
 * every category-filtered listing. Both columns are therefore kept, with
 * category_id as the authoritative classification.
 *
 * STATUS
 * The CHECK constraint lists exactly the values the application accepts today
 * (controllers/post.controller.js: POST_STATUSES = ["draft", "published"]).
 * No additional statuses are invented here. Adding one later is a one-line
 * constraint change.
 */

const TABLE_OPTIONS =
  "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

module.exports = {
  async up(queryInterface) {
    await queryInterface.sequelize.query(`
      CREATE TABLE \`posts\` (
        \`id\`               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`title\`            VARCHAR(255)    NOT NULL,
        \`slug\`             VARCHAR(200)    NOT NULL,
        \`content\`          LONGTEXT        NOT NULL,
        -- short listing summary, so meta_description is not overloaded
        \`excerpt\`          VARCHAR(500)    NULL,
        \`status\`           VARCHAR(20)     NOT NULL DEFAULT 'draft',

        -- public author. NOT a CMS user.
        \`author_id\`        INT UNSIGNED    NULL,
        \`category_id\`      INT UNSIGNED    NULL,
        \`subcategory_id\`   INT UNSIGNED    NULL,

        \`banner_image\`     VARCHAR(255)    NULL,
        \`show_banner\`      TINYINT(1)      NOT NULL DEFAULT 1,
        \`reading_time\`     SMALLINT UNSIGNED NULL,
        \`priority\`         SMALLINT        NOT NULL DEFAULT 0,
        \`auto_publish\`     TINYINT(1)      NOT NULL DEFAULT 0,
        -- editorial publication date. NULL until the post is published.
        \`published_at\`     DATETIME        NULL,

        \`meta_title\`       VARCHAR(255)    NULL,
        \`meta_description\` VARCHAR(500)    NULL,
        \`meta_keywords\`    VARCHAR(255)    NULL,

        -- CMS audit. NOT the public author.
        \`created_by\`       INT UNSIGNED    NULL,
        \`updated_by\`       INT UNSIGNED    NULL,

        \`created_at\`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                             ON UPDATE CURRENT_TIMESTAMP,

        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_posts_slug\` (\`slug\`),
        KEY \`ix_posts_status_published_at\` (\`status\`, \`published_at\`),
        KEY \`ix_posts_category_status_published\`
          (\`category_id\`, \`status\`, \`published_at\`),
        KEY \`ix_posts_subcategory\` (\`subcategory_id\`),
        KEY \`ix_posts_author\` (\`author_id\`),
        KEY \`ix_posts_created_at\` (\`created_at\`),
        KEY \`ix_posts_created_by\` (\`created_by\`),
        KEY \`ix_posts_updated_by\` (\`updated_by\`),

        CONSTRAINT \`chk_posts_status\`
          CHECK (\`status\` IN ('draft', 'published')),

        CONSTRAINT \`fk_posts_author\` FOREIGN KEY (\`author_id\`)
          REFERENCES \`authors\` (\`id\`) ON DELETE SET NULL ON UPDATE RESTRICT,
        CONSTRAINT \`fk_posts_category\` FOREIGN KEY (\`category_id\`)
          REFERENCES \`categories\` (\`id\`) ON DELETE RESTRICT ON UPDATE RESTRICT,
        CONSTRAINT \`fk_posts_subcategory\` FOREIGN KEY (\`subcategory_id\`)
          REFERENCES \`subcategories\` (\`id\`) ON DELETE SET NULL ON UPDATE RESTRICT,
        CONSTRAINT \`fk_posts_created_by\` FOREIGN KEY (\`created_by\`)
          REFERENCES \`users\` (\`id\`) ON DELETE SET NULL ON UPDATE RESTRICT,
        CONSTRAINT \`fk_posts_updated_by\` FOREIGN KEY (\`updated_by\`)
          REFERENCES \`users\` (\`id\`) ON DELETE SET NULL ON UPDATE RESTRICT
      ) ${TABLE_OPTIONS}
    `);
  },

  async down(queryInterface) {
    await queryInterface.sequelize.query("DROP TABLE IF EXISTS `posts`");
  },
};
