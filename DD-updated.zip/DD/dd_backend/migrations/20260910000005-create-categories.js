"use strict";

/**
 * D1-005 - categories and subcategories
 *
 * Replaces p_cat / p_sub_cat and the fake category_subcategory_view with two
 * real tables and a real foreign key:
 *
 *   categories (1) --< (N) subcategories
 *
 * The legacy `p_sub_cat.p_cat` column was a foreign key named after a table.
 * It becomes `subcategories.category_id`.
 *
 * ON DELETE RESTRICT: a subcategory without a parent category is meaningless,
 * so deleting a category that still has subcategories must fail rather than
 * silently orphan them (which is what happens today, with no FK at all).
 *
 * `slug` is unique GLOBALLY on categories but PER CATEGORY on subcategories:
 * two categories may each legitimately have a "tools" subcategory, and public
 * URLs are /{category}/{subcategory}.
 *
 * SEO columns are nullable here. In the legacy schema meta_title and meta_desc
 * were NOT NULL with no default, forcing every insert to supply SEO text.
 * `meta_desc` is normalised to `meta_description` to match posts.
 */

const TABLE_OPTIONS =
  "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

module.exports = {
  async up(queryInterface) {
    const sql = queryInterface.sequelize;

    await sql.query(`
      CREATE TABLE \`categories\` (
        \`id\`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`name\`             VARCHAR(100) NOT NULL,
        \`slug\`             VARCHAR(120) NOT NULL,
        \`status\`           TINYINT(1)   NOT NULL DEFAULT 1,
        \`meta_title\`       VARCHAR(255) NULL,
        \`meta_description\` VARCHAR(500) NULL,
        \`meta_keywords\`    VARCHAR(255) NULL,
        \`created_at\`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_categories_slug\` (\`slug\`),
        KEY \`ix_categories_status\` (\`status\`)
      ) ${TABLE_OPTIONS}
    `);

    await sql.query(`
      CREATE TABLE \`subcategories\` (
        \`id\`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`category_id\`      INT UNSIGNED NOT NULL,
        \`name\`             VARCHAR(100) NOT NULL,
        \`slug\`             VARCHAR(120) NOT NULL,
        \`status\`           TINYINT(1)   NOT NULL DEFAULT 1,
        \`meta_title\`       VARCHAR(255) NULL,
        \`meta_description\` VARCHAR(500) NULL,
        \`meta_keywords\`    VARCHAR(255) NULL,
        \`created_at\`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        -- slug is unique within a category, not globally
        UNIQUE KEY \`uq_subcategories_category_slug\` (\`category_id\`, \`slug\`),
        KEY \`ix_subcategories_status\` (\`status\`),
        CONSTRAINT \`fk_subcategories_category\` FOREIGN KEY (\`category_id\`)
          REFERENCES \`categories\` (\`id\`) ON DELETE RESTRICT ON UPDATE RESTRICT
      ) ${TABLE_OPTIONS}
    `);
  },

  async down(queryInterface) {
    const sql = queryInterface.sequelize;

    await sql.query("DROP TABLE IF EXISTS `subcategories`");
    await sql.query("DROP TABLE IF EXISTS `categories`");
  },
};
