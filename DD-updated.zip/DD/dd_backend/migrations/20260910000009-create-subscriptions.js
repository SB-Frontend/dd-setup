"use strict";

/**
 * D1-009 - subscriptions
 *
 * Newsletter signups from the public website. A separate domain table with no
 * relationship to users, authors or leads - a subscriber is an anonymous email
 * address, not a CMS identity and not a sales enquiry.
 *
 * This was the healthiest table in the legacy schema: it already had a correct
 * unique constraint on email and sensible types. Two additions only:
 *
 *   status           subscribed / unsubscribed
 *   unsubscribed_at  when they opted out
 *
 * Reason: hard-deleting a subscriber destroys the record that they opted out,
 * which is exactly the record you may later need to prove. Keeping the row and
 * flipping status preserves it.
 *
 * The unique index on email is what makes the existing findOrCreate in
 * subscribeController race-safe.
 */

const TABLE_OPTIONS =
  "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

module.exports = {
  async up(queryInterface) {
    await queryInterface.sequelize.query(`
      CREATE TABLE \`subscriptions\` (
        \`id\`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`email\`           VARCHAR(254) NOT NULL,
        \`name\`            VARCHAR(150) NULL,
        \`status\`          VARCHAR(20)  NOT NULL DEFAULT 'subscribed',
        \`unsubscribed_at\` DATETIME     NULL,
        \`created_at\`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_subscriptions_email\` (\`email\`),
        KEY \`ix_subscriptions_status\` (\`status\`),
        CONSTRAINT \`chk_subscriptions_status\`
          CHECK (\`status\` IN ('subscribed', 'unsubscribed'))
      ) ${TABLE_OPTIONS}
    `);
  },

  async down(queryInterface) {
    await queryInterface.sequelize.query(
      "DROP TABLE IF EXISTS `subscriptions`"
    );
  },
};
