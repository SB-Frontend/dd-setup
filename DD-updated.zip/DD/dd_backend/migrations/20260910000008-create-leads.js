"use strict";

/**
 * D1-008 - leads and lead_notes
 *
 * leads: anonymous contact-form submissions from the public website. No
 * foreign key to users or authors - these are not CMS identities.
 *
 * CORRECTIONS TO THE LEGACY TABLE
 *   company / phone   were NOT NULL, while the controller wrote
 *                     `phone: phone || null`, showing they were meant to be
 *                     optional. Now nullable.
 *   status            added. The CMS lists leads and annotates them but had no
 *                     workflow state at all.
 *   updated_at        added. The legacy model set `updatedAt: false`, which is
 *                     precisely why a `lead_modified` column was invented in
 *                     application code - and silently discarded, because the
 *                     column never existed in the database.
 *   lead_modified     deliberately NOT created. It was a dead write.
 *   comments          replaced by lead_notes (below).
 *
 * ----------------------------------------------------------------------------
 * WHY lead_notes IS CREATED BUT post_notes IS NOT
 * ----------------------------------------------------------------------------
 * Lead notes are an endpoint-backed feature that exists today:
 *   PUT /api/admin/leads/:id/comment  ->  leadsController.addComment
 * It appends to leads.comments with a literal "<br>" separator. Dropping the
 * column without a replacement would remove a live CMS capability.
 *
 * A table fixes three defects in the old approach: notes grow without bound in
 * a single TEXT column, individual notes have no timestamp, and only the most
 * recent author was recorded (in leads there was not even that).
 *
 * Post notes had no dedicated endpoint, so per the Phase D1 default decision
 * post_notes is NOT created.
 *
 * Nothing reads lead_notes yet - models are unchanged in D1 - so this table is
 * inert until the application is aligned in a later phase. Flagged for review.
 * ----------------------------------------------------------------------------
 */

const TABLE_OPTIONS =
  "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

module.exports = {
  async up(queryInterface) {
    const sql = queryInterface.sequelize;

    await sql.query(`
      CREATE TABLE \`leads\` (
        \`id\`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`first_name\` VARCHAR(100) NOT NULL,
        \`last_name\`  VARCHAR(100) NOT NULL,
        \`email\`      VARCHAR(254) NOT NULL,
        \`company\`    VARCHAR(255) NULL,
        \`phone\`      VARCHAR(50)  NULL,
        \`message\`    TEXT         NOT NULL,
        \`status\`     VARCHAR(20)  NOT NULL DEFAULT 'new',
        \`created_at\` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        -- email is intentionally NOT unique: the same person may enquire twice
        KEY \`ix_leads_email\` (\`email\`),
        KEY \`ix_leads_status\` (\`status\`),
        KEY \`ix_leads_created_at\` (\`created_at\`),
        CONSTRAINT \`chk_leads_status\`
          CHECK (\`status\` IN ('new', 'contacted', 'qualified', 'closed'))
      ) ${TABLE_OPTIONS}
    `);

    await sql.query(`
      CREATE TABLE \`lead_notes\` (
        \`id\`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`lead_id\`    INT UNSIGNED NOT NULL,
        -- CMS operator who wrote the note
        \`user_id\`    INT UNSIGNED NULL,
        \`note\`       TEXT         NOT NULL,
        \`created_at\` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        KEY \`ix_lead_notes_lead_created\` (\`lead_id\`, \`created_at\`),
        KEY \`ix_lead_notes_user\` (\`user_id\`),
        CONSTRAINT \`fk_lead_notes_lead\` FOREIGN KEY (\`lead_id\`)
          REFERENCES \`leads\` (\`id\`) ON DELETE CASCADE ON UPDATE RESTRICT,
        CONSTRAINT \`fk_lead_notes_user\` FOREIGN KEY (\`user_id\`)
          REFERENCES \`users\` (\`id\`) ON DELETE SET NULL ON UPDATE RESTRICT
      ) ${TABLE_OPTIONS}
    `);
  },

  async down(queryInterface) {
    const sql = queryInterface.sequelize;

    await sql.query("DROP TABLE IF EXISTS `lead_notes`");
    await sql.query("DROP TABLE IF EXISTS `leads`");
  },
};
