"use strict";

/**
 * D2-011 - soft delete support
 *
 * Adds `deleted_at` so Sequelize paranoid mode can retire rows instead of
 * removing them. Content must never be destroyed by a click in the CMS.
 *
 * WHICH TABLES GET IT, AND WHY
 *
 *   posts          Articles are the product. A hard DELETE is unrecoverable.
 *   authors        Referenced by posts. Removing one must be reversible.
 *   categories     Referenced by posts.
 *   subcategories  Referenced by posts.
 *   media          Rows point at files on disk; losing the row orphans the file.
 *   users          An account can be retired without erasing who did what.
 *
 * WHICH TABLES DELIBERATELY DO NOT GET IT
 *
 *   leads,           A person may ask for their data to be erased. Soft delete
 *   subscriptions,   would keep it, which defeats the request. These must stay
 *   lead_notes       hard-deletable.
 *
 *   roles,           System reference data and grant rows. Revoking a grant
 *   permissions,     should remove it outright - a "soft revoked" permission
 *   user_roles,      is a confusing and risky concept in an access-control
 *   role_permissions table.
 *
 * NO INDEX ON deleted_at
 * Paranoid adds `deleted_at IS NULL` to every query, but the column is NULL
 * for virtually every row, so an index on it has almost no selectivity and
 * would not be chosen. The existing composite indexes still drive the queries
 * and MySQL filters deleted_at afterwards.
 *
 * IMPORTANT INTERACTION - documented, not a defect:
 * A soft delete is an UPDATE, so it does NOT trigger the RESTRICT foreign keys
 * (for example posts.category_id -> categories.id). The database still blocks
 * a hard DELETE of a category that owns posts, but a soft delete will succeed
 * and leave posts pointing at a hidden category. Guarding that is an
 * application-level check and belongs to the controller phase.
 */

const SOFT_DELETE_TABLES = [
  "users",
  "authors",
  "categories",
  "subcategories",
  "posts",
  "media",
];

module.exports = {
  async up(queryInterface) {
    const sql = queryInterface.sequelize;

    for (const table of SOFT_DELETE_TABLES) {
      await sql.query(
        `ALTER TABLE \`${table}\` ADD COLUMN \`deleted_at\` DATETIME NULL DEFAULT NULL`
      );

      console.log(`[D2-011] added deleted_at to ${table}`);
    }
  },

  async down(queryInterface) {
    const sql = queryInterface.sequelize;

    for (const table of [...SOFT_DELETE_TABLES].reverse()) {
      await sql.query(`ALTER TABLE \`${table}\` DROP COLUMN \`deleted_at\``);
    }
  },
};
