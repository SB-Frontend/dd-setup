"use strict";

/**
 * D1-001 - REMOVE LEGACY SCHEMA
 *
 * Drops the legacy tables and the two fake views so the clean Phase D1 schema
 * can be built in their place.
 *
 * SAFETY
 * ------
 * This migration refuses to run if any of these tables contains a row. The
 * database was verified empty (0 application rows) before Phase D1, and this
 * check makes the migration safe to re-run and safe to fail on any database
 * that is NOT the intended empty development one.
 *
 * WHAT IS REMOVED AND WHY
 *
 *   post_view                  Never a real view here - sequelize.sync()
 *   category_subcategory_view  created both as BASE TABLES from the models on
 *                              an empty database. Phase 8 already moved the
 *                              website off them; they are replaced by real
 *                              foreign keys and joins.
 *
 *   post_data                  Replaced by `posts` with clean naming, real
 *                              relationships, and the legacy handover/session
 *                              workflow columns removed.
 *   p_cat                      Replaced by `categories`.
 *   p_sub_cat                  Replaced by `subcategories`.
 *   media_list                 Replaced by `media`.
 *   users                      Replaced by a CMS-only `users` table; the
 *                              public author fields move to `authors`.
 *   leads                      Replaced with nullable optional fields, a
 *                              status column and a real updated_at.
 *   subscriptions              Replaced with status handling.
 *
 * sequelize_meta is deliberately left alone.
 */

// Order matters only if foreign keys exist; there are none, but child-first
// ordering is kept so this stays correct if it is ever re-run elsewhere.
const LEGACY_TABLES = [
  "post_view",
  "category_subcategory_view",
  "post_data",
  "p_sub_cat",
  "p_cat",
  "media_list",
  "leads",
  "subscriptions",
  "users",
];

module.exports = {
  async up(queryInterface) {
    const sql = queryInterface.sequelize;

    const [existing] = await sql.query(
      "SELECT TABLE_NAME AS name, TABLE_TYPE AS type FROM information_schema.TABLES " +
        "WHERE TABLE_SCHEMA = DATABASE()"
    );

    const present = new Map(existing.map((row) => [row.name, row.type]));

    // Refuse to drop anything that holds data.
    const occupied = [];

    for (const table of LEGACY_TABLES) {
      if (!present.has(table)) continue;
      if (present.get(table) !== "BASE TABLE") continue;

      const [[{ count }]] = await sql.query(
        `SELECT COUNT(*) AS count FROM \`${table}\``
      );

      if (Number(count) > 0) occupied.push(`${table}=${count}`);
    }

    if (occupied.length > 0) {
      throw new Error(
        "Refusing to drop legacy tables that contain data: " +
          occupied.join(", ") +
          ". Phase D1 assumes an empty development database. " +
          "Inspect and clear the data deliberately before re-running."
      );
    }

    for (const table of LEGACY_TABLES) {
      const type = present.get(table);

      if (!type) continue;

      if (type === "VIEW") {
        await sql.query(`DROP VIEW IF EXISTS \`${table}\``);
        console.log(`[D1-001] dropped view ${table}`);
      } else {
        await sql.query(`DROP TABLE IF EXISTS \`${table}\``);
        console.log(`[D1-001] dropped table ${table}`);
      }
    }
  },

  async down() {
    // The legacy schema is intentionally not restorable. Its definition is
    // kept for reference at db/legacy/schema-baseline-legacy.sql, but
    // recreating it would undo the clean redesign.
    throw new Error(
      "D1-001 is intentionally irreversible. The legacy schema is superseded; " +
        "see db/legacy/schema-baseline-legacy.sql for its original definition."
    );
  },
};
