"use strict";

/**
 * D1-004 - authors  (public content authors)
 *
 * A row here is the person displayed as the author of an article. An author
 * does NOT need a CMS login and does NOT need to exist in `users`: external,
 * guest, contributor and historical authors are all first-class.
 *
 *   users   = CMS authentication / administration identity
 *   authors = public content author identity
 *
 * THERE IS DELIBERATELY NO `authors.user_id`.
 * The only link to `users` is CMS audit metadata:
 *
 *   authors.created_by -> users.id   which operator created this record
 *   authors.updated_by -> users.id   which operator last edited it
 *
 * Both are nullable with ON DELETE SET NULL, because an author profile must
 * outlive the CMS account that happened to create it. Neither field says
 * anything about who the author is.
 *
 * `display_name` and `name` are NOT unique - two people may legitimately share
 * a byline. `slug` is unique because it addresses a public URL.
 */

const TABLE_OPTIONS =
  "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

module.exports = {
  async up(queryInterface) {
    await queryInterface.sequelize.query(`
      CREATE TABLE \`authors\` (
        \`id\`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
        -- actual / internal name
        \`name\`         VARCHAR(150) NOT NULL,
        -- public byline shown on articles
        \`display_name\` VARCHAR(150) NOT NULL,
        -- public URL identifier for author pages
        \`slug\`         VARCHAR(160) NOT NULL,
        \`bio\`          TEXT         NULL,
        -- stored filename, consistent with the upload implementation
        \`image\`        VARCHAR(255) NULL,
        -- 1 = visible on the website, 0 = hidden
        \`status\`       TINYINT(1)   NOT NULL DEFAULT 1,
        -- CMS audit only. NOT author identity.
        \`created_by\`   INT UNSIGNED NULL,
        \`updated_by\`   INT UNSIGNED NULL,
        \`created_at\`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                      ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_authors_slug\` (\`slug\`),
        KEY \`ix_authors_status_display_name\` (\`status\`, \`display_name\`),
        KEY \`ix_authors_created_by\` (\`created_by\`),
        KEY \`ix_authors_updated_by\` (\`updated_by\`),
        CONSTRAINT \`fk_authors_created_by\` FOREIGN KEY (\`created_by\`)
          REFERENCES \`users\` (\`id\`) ON DELETE SET NULL ON UPDATE RESTRICT,
        CONSTRAINT \`fk_authors_updated_by\` FOREIGN KEY (\`updated_by\`)
          REFERENCES \`users\` (\`id\`) ON DELETE SET NULL ON UPDATE RESTRICT
      ) ${TABLE_OPTIONS}
    `);
  },

  async down(queryInterface) {
    await queryInterface.sequelize.query("DROP TABLE IF EXISTS `authors`");
  },
};
