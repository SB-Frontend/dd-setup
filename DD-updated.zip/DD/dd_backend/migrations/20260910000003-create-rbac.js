"use strict";

/**
 * D1-003 - RBAC:  roles, permissions, user_roles, role_permissions
 *
 *   users --< user_roles >-- roles --< role_permissions >-- permissions
 *
 * SLUG COLUMNS
 * role_slug and permission_slug are the stable identifiers the application
 * authorises against (config/permissions.js already keys on constants such as
 * "posts.publish"). role_name / permission_name are display labels an operator
 * can edit through Role Management. Keeping them separate means renaming a
 * label in the CMS cannot silently break an authorisation check.
 *
 * is_system marks the nine seeded roles so Role Management cannot delete them
 * and lock everyone out.
 *
 * DELETE BEHAVIOUR
 *   user_roles.user_id       CASCADE  - grants are meaningless once the user is gone
 *   user_roles.role_id       RESTRICT - deleting a role still assigned must fail loudly
 *   role_permissions.role_id CASCADE  - removing a role removes its grants
 *   role_permissions.permission_id RESTRICT - permissions are code-coupled
 */

const TABLE_OPTIONS =
  "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

module.exports = {
  async up(queryInterface) {
    const sql = queryInterface.sequelize;

    await sql.query(`
      CREATE TABLE \`roles\` (
        \`id\`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`role_name\`   VARCHAR(100) NOT NULL,
        \`role_slug\`   VARCHAR(100) NOT NULL,
        \`description\` VARCHAR(255) NULL,
        \`is_system\`   TINYINT(1)   NOT NULL DEFAULT 0,
        \`created_at\`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                     ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_roles_role_name\` (\`role_name\`),
        UNIQUE KEY \`uq_roles_role_slug\` (\`role_slug\`)
      ) ${TABLE_OPTIONS}
    `);

    await sql.query(`
      CREATE TABLE \`permissions\` (
        \`id\`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`permission_name\` VARCHAR(100) NOT NULL,
        \`permission_slug\` VARCHAR(100) NOT NULL,
        \`description\`     VARCHAR(255) NULL,
        \`created_at\`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_permissions_permission_name\` (\`permission_name\`),
        UNIQUE KEY \`uq_permissions_permission_slug\` (\`permission_slug\`)
      ) ${TABLE_OPTIONS}
    `);

    // The reverse-order index on each join table matters: the composite UNIQUE
    // cannot answer "which users hold this role", which Role Management needs.
    await sql.query(`
      CREATE TABLE \`user_roles\` (
        \`id\`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`user_id\`    INT UNSIGNED NOT NULL,
        \`role_id\`    INT UNSIGNED NOT NULL,
        \`created_at\` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_user_roles_user_role\` (\`user_id\`, \`role_id\`),
        KEY \`ix_user_roles_role\` (\`role_id\`),
        CONSTRAINT \`fk_user_roles_user\` FOREIGN KEY (\`user_id\`)
          REFERENCES \`users\` (\`id\`) ON DELETE CASCADE ON UPDATE RESTRICT,
        CONSTRAINT \`fk_user_roles_role\` FOREIGN KEY (\`role_id\`)
          REFERENCES \`roles\` (\`id\`) ON DELETE RESTRICT ON UPDATE RESTRICT
      ) ${TABLE_OPTIONS}
    `);

    await sql.query(`
      CREATE TABLE \`role_permissions\` (
        \`id\`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
        \`role_id\`       INT UNSIGNED NOT NULL,
        \`permission_id\` INT UNSIGNED NOT NULL,
        \`created_at\`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                       ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (\`id\`),
        UNIQUE KEY \`uq_role_permissions_role_permission\`
          (\`role_id\`, \`permission_id\`),
        KEY \`ix_role_permissions_permission\` (\`permission_id\`),
        CONSTRAINT \`fk_role_permissions_role\` FOREIGN KEY (\`role_id\`)
          REFERENCES \`roles\` (\`id\`) ON DELETE CASCADE ON UPDATE RESTRICT,
        CONSTRAINT \`fk_role_permissions_permission\` FOREIGN KEY (\`permission_id\`)
          REFERENCES \`permissions\` (\`id\`) ON DELETE RESTRICT ON UPDATE RESTRICT
      ) ${TABLE_OPTIONS}
    `);
  },

  async down(queryInterface) {
    const sql = queryInterface.sequelize;

    await sql.query("DROP TABLE IF EXISTS `role_permissions`");
    await sql.query("DROP TABLE IF EXISTS `user_roles`");
    await sql.query("DROP TABLE IF EXISTS `permissions`");
    await sql.query("DROP TABLE IF EXISTS `roles`");
  },
};
