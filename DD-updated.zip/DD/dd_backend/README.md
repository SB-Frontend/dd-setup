# DD_SETUP — DataDemand backend

Headless CMS backend for the DataDemand website. Node + Express + Sequelize on
MySQL 8.4, serving two separate surfaces:

```
/api/website/*    public, unauthenticated, read-only   ← the Next.js site
/api/admin/*      authenticated + permission-checked   ← the CMS
```

## Requirements

| | |
|---|---|
| Node | v22.x (developed on v22.13.1) |
| Database | **MySQL 8.4** — see the warning below |
| Host / port | `127.0.0.1:3306` |
| Database name | `datademand` |

> ### ⚠ MySQL, not MariaDB
>
> A WAMP install commonly runs **both** database servers at once:
>
> ```
> 127.0.0.1:3306   MySQL 8.4.7      ← DD_SETUP uses this
> 127.0.0.1:3307   MariaDB 11.4.9   ← not used, leave alone
> ```
>
> `DB_HOST` and `DB_PORT` are therefore both set **explicitly** in `.env`.
> Do not rely on `localhost` (on Windows it may resolve to `::1` or
> `127.0.0.1` depending on the resolver) and do not omit the port.
>
> An older XAMPP/MariaDB installation may still exist on a developer machine.
> It is not used by this project and its data directory must not be touched.
>
> `npm run db:health` prints which server you actually reached.

## First-time setup

```bash
npm install
cp .env.example .env          # then edit it - see "Environment" below
```

Create the database (once), then let migrations build the schema:

```bash
mysql -h 127.0.0.1 -P 3306 -u root -p -e "CREATE DATABASE datademand CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
```

```bash
npm run db:migrate
```

```bash
npm run db:health
```

A healthy install reports MySQL 8.4.x, 12 applied migrations, 0 pending,
14 tables, 15 foreign keys.

### Creating the first CMS account

No user and no password is ever seeded. While `users` is empty — and only then
— one unauthenticated registration is permitted, and that account is granted
the `admin` **role** in the database:

```bash
curl -X POST http://localhost:5010/api/admin/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"you","email":"you@example.com","password":"choose-a-strong-one"}'
```

The moment that account exists the bootstrap path closes permanently, and all
further account creation requires `user_management`. See
[docs/AUTH-AND-RBAC.md](docs/AUTH-AND-RBAC.md).

## Commands

```bash
npm run dev              # nodemon, http://localhost:5010
```

```bash
npm start                # plain node
```

```bash
npm test                 # full suite: 15 suites, 801 assertions
```

```bash
npm run db:health        # connection, version, migration state, schema shape
```

| Command | Purpose |
|---|---|
| `npm run db:seed` | Populate development data (idempotent) |
| `npm run db:migrate` | Apply pending migrations |
| `npm run db:migrate:status` | List applied/pending migrations |
| `npm run db:migrate:undo` | Roll back the last migration |
| `npm run test:security` | Security suites only |
| `npm run test:website` | Public website suite only |
| `npm run test:auth` | Authentication + RBAC suites only |

### Development seed data

```bash
npm run db:seed
```

Populates an empty local database with 3 CMS users, 6 categories, 12
subcategories, 5 public authors and 20 posts (16 published, 4 draft) so the CMS
and the website have something realistic to render. It is **idempotent** —
every record is matched on its natural key, so running it twice creates
nothing — **transactional**, and it refuses to run when `NODE_ENV=production`
or against a non-local `DB_HOST`.

The three accounts share one password, printed when the seed finishes. Override
it with `SEED_PASSWORD`. It is development-only and hashed with bcrypt like any
other account.

| Account | Role | Can |
|---|---|---|
| `admin@datademand.local` | `admin` | everything |
| `editor.one@datademand.local` | `content_management` | write **and publish** posts, manage authors |
| `editor.two@datademand.local` | `content_writer` | draft posts, **not** publish |

Seeded authors are public bylines with no CMS account — that separation is the
point, so do not give them logins.

### Running tests once you have seeded

> **Seed the development database and the tests need their own database.**
>
> Several suites assert absolute counts (`total === 10`) that assume the only
> rows present are the fixtures they created. That is true of an empty
> database; it stops being true once `npm run db:seed` has run, and those
> suites will fail on arithmetic rather than on a defect. The bootstrap suite
> also needs an empty `users` table and will skip.
>
> Use a dedicated test database — the harness already supports it:
>
> ```bash
> mysql -h 127.0.0.1 -P 3306 -u root -p -e "CREATE DATABASE datademand_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
> ```
>
> ```bash
> DB_NAME=datademand_test npx sequelize-cli db:migrate
> ```
>
> Then set `TEST_DB_NAME=datademand_test` in `.env`, or prefix the run:
>
> ```bash
> TEST_DB_NAME=datademand_test npm test
> ```

On an unseeded database the suite runs against `datademand` directly, creating
rows prefixed `ZZTEST` / `ZZSCHEMA` and removing them in each suite's `finally`
block.

## Environment

Copy `.env.example`. Nothing in it is a real credential. The values that matter:

| Variable | Notes |
|---|---|
| `DB_HOST` | `127.0.0.1` — explicit, never `localhost` |
| `DB_PORT` | `3306` — explicit, MySQL not MariaDB |
| `DB_NAME` | `datademand` |
| `DB_USER` / `DB_PASSWORD` | Local MySQL account |
| `JWT_SECRET_KEY` | **≥ 32 characters.** Startup fails in production if weaker |
| `CORS_ORIGINS` | Comma-separated, scheme included, no trailing slash. Empty blocks all cross-origin browser requests |
| `NODE_ENV` | Only `development` enables debug detail in error responses |
| `TRUST_PROXY` | `false` unless genuinely behind a proxy — trusting an absent proxy lets a client spoof its IP and defeat rate limiting |

`.env`, `.env.test` and `.env.backup-*` are gitignored. Migrations may run
under a separate higher-privilege account via `MIGRATION_DB_USER` /
`MIGRATION_DB_PASSWORD`; the application runtime needs no DDL rights.

## Schema

The database is owned entirely by **migrations**. `sequelize.sync()` is not
used anywhere and must not be reintroduced — on an empty database it once
created two fake tables that shadowed real views. A test asserts no source file
calls it.

```
migrations/  →  MySQL schema  →  Sequelize models  →  controllers
```

## Layout

```
config/       permissions catalogue, security, sanitize, uploads, db config
controllers/  admin controllers; controllers/website/ is the public surface
middleware/   auth, permissions, sanitize, uploads, rate limit, errors, cache
migrations/   the source of truth for the schema
models/       Sequelize models; associations.js wires every relationship
routes/       routes/admin/*, routes/website/*, plus legacy top-level aliases
services/     rbac.service.js (all user_roles / role_permissions writes)
scripts/      db-health.js, seed-dev.js
tests/        custom harness, no framework - see tests/README.md
```

## Documentation

| Document | Covers |
|---|---|
| [docs/PROJECT-SUMMARY.md](docs/PROJECT-SUMMARY.md) | What was rebuilt, what it found, and the final state |
| [docs/API-REFERENCE.md](docs/API-REFERENCE.md) | **All 105 endpoints** — website, CMS and legacy, in one list |
| [docs/PUBLIC-API-CONTRACT.md](docs/PUBLIC-API-CONTRACT.md) | Every `/api/website/*` endpoint — written for the Next.js developer |
| [docs/ADMIN-API.md](docs/ADMIN-API.md) | Every `/api/admin/*` endpoint and the permission each requires |
| [docs/AUTH-AND-RBAC.md](docs/AUTH-AND-RBAC.md) | Login, JWT, roles, permissions, escalation protections |
| [docs/ARCHITECTURE-DECISIONS.md](docs/ARCHITECTURE-DECISIONS.md) | Why things are the way they are, and known intentional oddities |

## Two rules worth knowing before you change anything

**CMS users are not public authors.** `users` holds login accounts; `authors`
holds bylines. A post's `author_id` points at `authors`, while `created_by` and
`updated_by` point at `users`. There is no `authors.user_id` and there must
never be one — an author does not need a login.

**The public API is public.** Nothing under `/api/website/*` may require a
token. Publication filtering happens server-side, so the website never has to
decide what is safe to show.
