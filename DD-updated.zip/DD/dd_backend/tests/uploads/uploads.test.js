// tests/uploads/uploads.test.js
//
// Upload hardening (Phase 7).
//
// These go through the real endpoints, so they insert media_list rows and
// write real files. Both are tracked by primary key / absolute path and
// removed in the finally block, including when an assertion throws.

require("../helpers/env");

const fs = require("fs");
const path = require("path");
const { Op } = require("sequelize");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const { createStubber, tokens } = require("../helpers/stubs");
const db = require("../helpers/db");

const Media = require("../../models/media.model");
const { UPLOAD_ROOT, LIMITS } = require("../../config/uploads");

const POST_DIR = path.join(UPLOAD_ROOT, "posts");
const AUTHOR_DIR = path.join(UPLOAD_ROOT, "author");

// Valid signatures, padded so the files are a realistic size.
const pad = (n) => Buffer.alloc(n, 0x41);
const JPEG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), pad(200), Buffer.from([0xff, 0xd9])]);
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), pad(200)]);
const WEBP = Buffer.concat([Buffer.from("RIFF"), Buffer.alloc(4), Buffer.from("WEBP"), pad(200)]);
const PHP = Buffer.from(`<?php system($_GET["c"]); ?>${"A".repeat(200)}`);
const SVG = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');

const listDir = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir) : []);

(async () => {
  const t = createHarness("uploads");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const stubber = createStubber();

  // This suite writes real media rows, and media.uploaded_by is a foreign key
  // into users, so the session has to be a CMS account that genuinely exists.
  const operator = await db.createOperator({ roles: ["admin"] });

  const srv = await startServer();
  const token = tokens.valid(operator.id);

  const createdFiles = [];
  const createdMediaIds = [];
  const createdUserEmails = [];

  const upload = async (url, field, filename, type, bytes, extra = {}) => {
    const form = new FormData();

    for (const [k, v] of Object.entries(extra)) form.append(k, v);

    form.append(field, new Blob([bytes], { type }), filename);

    const r = await srv.request("POST", url, { token, body: form });

    const stored = r.json && r.json.data && r.json.data.filename;

    if (stored) {
      createdFiles.push(path.join(POST_DIR, stored));

      if (r.json.data.id) createdMediaIds.push(r.json.data.id);
    }

    return { ...r, stored };
  };

  try {
    const filesBefore = listDir(POST_DIR).length;

    t.section("valid images are still accepted");

    for (const [name, type, bytes] of [
      ["photo.jpg", "image/jpeg", JPEG],
      ["photo.jpeg", "image/jpeg", JPEG],
      ["photo.PNG", "image/png", PNG],
      ["photo.webp", "image/webp", WEBP],
    ]) {
      const r = await upload("/api/admin/media", "file", name, type, bytes, {
        title: "ZZTEST",
      });

      t.ok(r.status === 201, `${name} (${type}) accepted`, `-> ${r.status} ${r.stored || r.message}`);
    }

    t.section("executable and script uploads are refused");

    for (const [name, type, bytes] of [
      ["shell.php", "application/x-httpd-php", PHP],
      ["shell.exe", "application/octet-stream", PHP],
      ["x.svg", "image/svg+xml", SVG],
      ["x.html", "text/html", Buffer.from("<script>1</script>")],
    ]) {
      const r = await upload("/api/admin/media", "file", name, type, bytes, {
        title: "ZZTEST",
      });

      t.ok(r.status === 400, `${name} refused`, `-> ${r.status} ${r.message.slice(0, 44)}`);
    }

    t.section("forged content type and double extensions");

    const forgedMime = await upload(
      "/api/admin/media",
      "file",
      "shell.jpg",
      "application/x-httpd-php",
      PHP,
      { title: "ZZTEST" }
    );

    t.ok(forgedMime.status === 400, "a .jpg declared as PHP is refused", `-> ${forgedMime.status}`);

    const forgedBytes = await upload(
      "/api/admin/media",
      "file",
      "shell.jpg",
      "image/jpeg",
      PHP,
      { title: "ZZTEST" }
    );

    t.ok(
      forgedBytes.status === 400,
      "a .jpg with image/jpeg but PHP bytes is refused by the magic-byte check",
      `-> ${forgedBytes.status}`
    );

    const doubleExt = await upload(
      "/api/admin/media",
      "file",
      "shell.php.jpg",
      "image/jpeg",
      JPEG,
      { title: "ZZTEST" }
    );

    t.ok(
      doubleExt.status === 201 &&
        doubleExt.stored &&
        !doubleExt.stored.includes(".php") &&
        (doubleExt.stored.match(/\./g) || []).length === 1,
      "shell.php.jpg is stored with exactly one extension",
      `-> ${doubleExt.stored}`
    );

    t.section("size limits");

    const oversize = Buffer.concat([
      Buffer.from([0xff, 0xd8, 0xff, 0xe0]),
      Buffer.alloc(LIMITS.fileSize + 4096, 0x41),
    ]);

    const tooBig = await upload("/api/admin/media", "file", "big.jpg", "image/jpeg", oversize, {
      title: "ZZTEST",
    });

    t.ok(
      tooBig.status === 413,
      `a file over ${(LIMITS.fileSize / 1048576).toFixed(0)}MB -> 413`,
      `-> ${tooBig.status}`
    );

    const bigField = await upload("/api/admin/media", "file", "ok.jpg", "image/jpeg", JPEG, {
      title: "x".repeat(LIMITS.fieldSize + 1024),
    });

    t.ok(bigField.status === 413, "a text field over the limit -> 413", `-> ${bigField.status}`);

    t.ok(
      LIMITS.fieldSize > 1048576,
      "fieldSize is above the 1MB busboy default so post_content is not truncated",
      `${(LIMITS.fieldSize / 1048576).toFixed(0)}MB`
    );

    t.section("collision-safe filenames");

    const names = new Set();

    for (let i = 0; i < 5; i += 1) {
      const r = await upload("/api/admin/media", "file", "same.jpg", "image/jpeg", JPEG, {
        title: "ZZTEST",
      });

      if (r.stored) names.add(r.stored);
    }

    t.ok(names.size === 5, "five uploads of same.jpg produce five distinct names", `${names.size}/5`);

    t.section("cleanup when the request fails");

    const beforeFail = listDir(POST_DIR).length;

    const failed = await upload("/api/admin/posts", "banner_img", "orphan.jpg", "image/jpeg", JPEG, {});

    await new Promise((resolve) => setTimeout(resolve, 350));

    const afterFail = listDir(POST_DIR).length;

    t.ok(
      failed.status >= 400 && afterFail === beforeFail,
      `a failed create (${failed.status}) leaves no file behind`,
      `files ${beforeFail} -> ${afterFail}`
    );

    t.section("the author directory exists");

    const email = `zztest-upload-${Date.now()}@example.test`;

    createdUserEmails.push(email);

    const authorUpload = await srv.request("POST", "/api/admin/auth/register", {
      token,
      body: (() => {
        const form = new FormData();

        form.append("username", `zztest${Date.now()}`);
        form.append("email", email);
        form.append("password", "irrelevant-test-value");
        

        return form;
      })(),
    });

    t.ok(
      !/storage location/.test(authorUpload.message),
      "author photo upload no longer fails with ENOENT",
      `-> ${authorUpload.status} ${authorUpload.message.slice(0, 40)}`
    );

    listDir(AUTHOR_DIR).forEach((f) => createdFiles.push(path.join(AUTHOR_DIR, f)));

    t.section("static serving");

    const existing = listDir(POST_DIR).find((f) => f.includes("nasa"));

    if (existing) {
      const served = await srv.get(`/uploads/posts/${encodeURIComponent(existing)}`);

      t.ok(served.status === 200, "a pre-existing upload is still served", `-> ${served.status}`);
      t.ok(
        served.headers.get("x-content-type-options") === "nosniff",
        "nosniff header is present"
      );
      t.ok(
        /max-age=2592000/.test(served.headers.get("cache-control") || ""),
        "cache headers are set",
        served.headers.get("cache-control")
      );
    } else {
      t.skip("pre-existing upload is served", "no seed file present in uploads/posts");
      t.skip("nosniff header", "no seed file present");
      t.skip("cache headers", "no seed file present");
    }

    for (const [label, url] of [
      ["directory listing is refused", "/uploads/posts/"],
      ["upload root listing is refused", "/uploads/"],
      ["path traversal is blocked", "/uploads/../server.js"],
      ["dotfiles are refused", "/uploads/posts/.htaccess"],
      ["a missing file returns JSON 404", "/uploads/posts/missing.jpg"],
    ]) {
      const r = await srv.get(url);

      t.ok(r.status === 404, label, `-> ${r.status}`);
    }
  } finally {
    // Remove every file and row this suite created.
    let removedFiles = 0;

    for (const file of createdFiles) {
      try {
        fs.unlinkSync(file);
        removedFiles += 1;
      } catch {
        /* already gone */
      }
    }

    try {
      if (createdMediaIds.length) {
        await Media.destroy({ where: { id: { [Op.in]: createdMediaIds } }, force: true });
      }

      if (createdUserEmails.length) {
        const User = require("../../models/user.model");

        // findByPk is stubbed, destroy is not.
        await User.destroy({ where: { email: { [Op.in]: createdUserEmails } }, force: true });
      }

      await db.destroyOperator(operator);
    } catch (error) {
      console.error("[uploads] row cleanup failed:", error.message);
    }

    console.log(
      `\n[cleanup] removed ${removedFiles} files, ${createdMediaIds.length} media rows`
    );

    stubber.restore();
    await srv.close();
    await db.close();
  }

  t.finish();
})();
