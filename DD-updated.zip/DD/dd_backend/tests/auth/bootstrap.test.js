// tests/auth/bootstrap.test.js
//
// D6 §7: the FIRST-USER BOOTSTRAP, from both sides.
//
// The rest of the suite only ever proves the door is shut - that an anonymous
// registration is refused once accounts exist. That is the easy half. The half
// that actually matters is that the door opens exactly once, on a genuinely
// empty users table, and that the account it creates is a real RBAC principal
// rather than a hardcoded superuser.
//
// This needs an empty `users` table, so it must run BEFORE any suite that
// creates accounts - see the ordering in tests/run-all.js. If accounts already
// exist the suite SKIPS and says so rather than deleting anybody's data.

process.env.RATE_LIMIT_DISABLED = "true";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const db = require("../helpers/db");

const { Op } = require("sequelize");
const sequelize = require("../../models");
const User = require("../../models/user.model");
const rbac = require("../../services/rbac.service");

const MARK = "zzboot";
const PASSWORD = "ZzBootstrap-Password-1";

(async () => {
  const t = createHarness("auth-bootstrap");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const existing = await User.count();

  if (existing > 0) {
    // Never destructive: an occupied users table means this suite cannot run,
    // not that the table should be emptied.
    t.skip(
      "first-user bootstrap",
      `${existing} account(s) already exist - this suite needs an empty users table and will not delete anything`
    );

    await db.close();
    t.finish();
    return;
  }

  let srv = null;

  try {
    srv = await startServer();

    const call = (path, json) => srv.request("POST", path, { json });

    t.section("the door opens exactly once, on an empty users table");

    const email = `${MARK}-first@example.test`;

    const first = await call("/api/admin/auth/register", {
      username: `${MARK}_first`,
      email,
      password: PASSWORD,
    });

    t.ok(
      first.status === 201,
      "an anonymous registration succeeds while no account exists",
      `-> ${first.status} ${first.message}`
    );

    const created = await User.findOne({ where: { email } });

    t.ok(Boolean(created), "the account really exists in the database");

    t.section("it is a real RBAC principal, not a hardcoded superuser");

    const granted = await rbac.roleSlugsForUser(created.id);

    t.ok(
      granted.includes("admin"),
      "the bootstrap account holds the admin ROLE, granted through user_roles",
      granted.join(",") || "(none)"
    );

    const [rows] = await sequelize.query(
      "SELECT COUNT(*) n FROM user_roles WHERE user_id = ?",
      { replacements: [created.id] }
    );

    t.ok(
      Number(rows[0].n) === 1,
      "there is a genuine row in user_roles - nothing is implied in code",
      String(rows[0].n)
    );

    t.section("no password was seeded, invented or defaulted");

    const withHash = await User.scope("withPassword").findByPk(created.id);

    t.ok(
      typeof withHash.password === "string" && withHash.password.startsWith("$2"),
      "the password the caller chose is stored bcrypt-hashed",
      withHash.password.slice(0, 7) + "…"
    );

    t.ok(
      await withHash.verifyPassword(PASSWORD),
      "and it is the caller's password, not a default"
    );

    for (const guess of ["admin", "password", "changeme", "admin123", "datademand"]) {
      // A seeded default credential would verify against one of these.
      t.ok(
        !(await withHash.verifyPassword(guess)),
        `the account does not accept the common default "${guess}"`
      );
    }

    t.section("the account authenticates through the normal flow");

    const login = await call("/api/admin/auth/login", { email, password: PASSWORD });

    t.ok(login.status === 200, "it can log in", `-> ${login.status}`);

    const token = login.json && login.json.user && login.json.user.token;

    t.ok(Boolean(token), "a JWT is issued");

    const protectedRead = await srv.request("GET", "/api/admin/roles", { token });

    t.ok(
      protectedRead.status === 200,
      "and it reaches a role_management endpoint through ordinary RBAC",
      `-> ${protectedRead.status}`
    );

    t.section("the door then closes, permanently");

    const second = await call("/api/admin/auth/register", {
      username: `${MARK}_second`,
      email: `${MARK}-second@example.test`,
      password: PASSWORD,
    });

    t.ok(
      second.status === 401,
      "a second anonymous registration is refused",
      `-> ${second.status} ${second.message}`
    );

    const claimed = await call("/api/admin/auth/register", {
      username: `${MARK}_claim`,
      email: `${MARK}-claim@example.test`,
      password: PASSWORD,
      isBootstrap: true,
      roles: ["admin"],
    });

    t.ok(
      claimed.status === 401,
      "a request cannot re-open it by claiming to be the bootstrap",
      `-> ${claimed.status}`
    );

    const [[count]] = await sequelize.query(
      "SELECT COUNT(*) n FROM users WHERE username LIKE ?",
      { replacements: [`${MARK}%`] }
    );

    t.ok(
      Number(count.n) === 1,
      "exactly one account came out of all of that",
      String(count.n)
    );

    t.section("public routes were never involved");

    const site = await srv.request("GET", "/api/website/posts?limit=1", {});

    t.ok(site.status === 200, "the public website is unaffected", `-> ${site.status}`);
  } catch (error) {
    t.ok(false, "the suite ran without an unexpected error", error.message);
    console.error(error);
  } finally {
    try {
      // Everything this suite made, gone - the users table goes back to empty
      // so the state is the same as it found it.
      await User.destroy({
        where: { username: { [Op.like]: `${MARK}%` } },
        force: true,
      });

      const remaining = await User.count();

      console.log(`\n[cleanup] users remaining: ${remaining}`);
    } catch (error) {
      console.error("[bootstrap] cleanup failed:", error.message);
    }

    if (srv) await srv.close();
    await db.close();
  }

  t.finish();
})();
