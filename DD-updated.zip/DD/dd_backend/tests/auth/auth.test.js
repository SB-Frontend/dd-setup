// tests/auth/auth.test.js
//
// Authentication and authorization.
//
// D4 REWRITE
//   This suite used to fix a role for the life of the process through
//   AUTH_DEFAULT_ROLE, because config/permissions.js granted an implicit role
//   to any account with no rows in user_roles. That fallback is gone: a
//   session is now exactly what the database says it is.
//
//   So the suite creates real CMS accounts with real grants and runs every
//   role matrix in one process. Each request walks the full chain -
//   users -> user_roles -> roles -> role_permissions -> permissions - which is
//   the thing that actually needs proving.
//
//   Role slugs come from the D1-010 seed. No role or permission id is
//   hardcoded anywhere in this file.

process.env.RATE_LIMIT_DISABLED = "true";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const { tokens } = require("../helpers/stubs");
const db = require("../helpers/db");

// What each role is expected to be allowed to reach. 403 means the permission
// middleware denied it; anything else means it got through to the controller
// (which may then fail for unrelated reasons such as empty test data, and that
// is fine - this suite is about the gate, not the handler).
const PERMISSION_EXPECTATIONS = {
  // Every module.
  admin: {
    "GET /api/admin/posts": "allow",
    "POST /api/admin/posts": "allow",
    "PATCH /api/admin/posts/1/status": "allow",
    "GET /api/admin/users": "allow",
    "GET /api/admin/roles": "allow",
    "GET /api/admin/authors": "allow",
    "DELETE /api/admin/categories/1": "allow",
    "GET /api/admin/leads": "allow",
    "GET /api/admin/subscriptions": "allow",
    "POST /api/admin/media": "allow",
  },

  // Drafts posts, cannot publish, cannot touch users, roles or taxonomy.
  content_writer: {
    "GET /api/admin/posts": "allow",
    "POST /api/admin/posts": "allow",
    "PATCH /api/admin/posts/1/status": "deny",
    "GET /api/admin/users": "deny",
    "GET /api/admin/roles": "deny",
    "GET /api/admin/authors": "deny",
    "DELETE /api/admin/categories/1": "deny",
    "GET /api/admin/leads": "deny",
    "GET /api/admin/subscriptions": "deny",
    "POST /api/admin/media": "allow",
  },

  // Publishes, and holds post_management too, but has no editorial taxonomy,
  // no author management and no user or role management.
  publisher: {
    "GET /api/admin/posts": "allow",
    "POST /api/admin/posts": "allow",
    "PATCH /api/admin/posts/1/status": "allow",
    "GET /api/admin/users": "deny",
    "GET /api/admin/roles": "deny",
    "GET /api/admin/authors": "deny",
    "DELETE /api/admin/categories/1": "deny",
    "GET /api/admin/leads": "deny",
    "GET /api/admin/subscriptions": "deny",
    "POST /api/admin/media": "deny",
  },
};

const OWNERSHIP_EXPECTATIONS = {
  admin: { putOther: "allow", putOtherLegacy: "allow" },
  content_writer: { putOther: 403, putOtherLegacy: 403 },
  publisher: { putOther: 403, putOtherLegacy: 403 },
};

(async () => {
  const t = createHarness("auth");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const operators = [];
  let srv = null;

  const call = (method, path, token) =>
    srv.request(method, path, {
      token,
      json: ["POST", "PUT", "PATCH"].includes(method) ? {} : undefined,
    });

  try {
    srv = await startServer();

    t.section("public website: must work with no token");

    for (const p of [
      "/api/website/posts?limit=1",
      "/api/website/categories",
      "/api/website/subcategories",
      "/api/website/authors",
      "/api/website/sitemap/posts",
      "/api/website/sitemap/categories",
    ]) {
      const r = await call("GET", p);

      t.ok(r.status === 200, `GET ${p}`, `-> ${r.status}`);
    }

    const garbage = await call("GET", "/api/website/categories", "garbage.token.here");

    t.ok(garbage.status === 200, "website ignores a garbage token", `-> ${garbage.status}`);

    for (const p of ["/api/posts/sitemap", "/api/category/get_all_categories"]) {
      const r = await call("GET", p);

      t.ok(r.status === 200, `legacy public ${p}`, `-> ${r.status}`);
    }

    t.section("token handling on admin");

    const noToken = await call("GET", "/api/admin/posts");

    t.ok(noToken.status === 401, "no token -> 401", `-> ${noToken.status}`);

    for (const [label, token] of [
      ["malformed token", tokens.malformed()],
      ["wrong signature", tokens.wrongSignature()],
      ["expired token", tokens.expired()],
      ["token for a user that no longer exists", tokens.unknownUser()],
    ]) {
      const r = await call("GET", "/api/admin/posts", token);

      t.ok(r.status === 401, `${label} -> 401`, `-> ${r.status} ${r.message}`);
    }

    // ----------------------------------------------------------------
    // One real account per role, granted through user_roles.
    // ----------------------------------------------------------------
    const sessions = {};

    for (const role of Object.keys(PERMISSION_EXPECTATIONS)) {
      const user = await db.createOperator({ roles: [role] });

      operators.push(user);

      sessions[role] = { user, token: tokens.valid(user.id) };
    }

    for (const [role, expectations] of Object.entries(PERMISSION_EXPECTATIONS)) {
      t.section(`permissions resolved from the database (role=${role})`);

      const { token } = sessions[role];

      for (const [key, expected] of Object.entries(expectations)) {
        const [method, path] = key.split(" ");
        const r = await call(method, path, token);

        const denied = r.status === 403;
        const matches = expected === "deny" ? denied : !denied;

        t.ok(matches, `${key} -> ${expected}`, `-> ${r.status}${denied ? " DENIED" : ""}`);
      }
    }

    t.section("an account with no roles has no permissions");

    const stranger = await db.createOperator({ roles: [] });

    operators.push(stranger);

    const strangerToken = tokens.valid(stranger.id);

    const strangerAuth = await call("GET", "/api/admin/posts", strangerToken);

    t.ok(
      strangerAuth.status === 403,
      "authenticates but is authorized for nothing",
      `-> ${strangerAuth.status}`
    );

    // The regression this guards: config/permissions.js used to grant a
    // fallback role to any account with no grants, and the fallback defaulted
    // to admin. Every account created since D1 was silently a full
    // administrator.
    const strangerUsers = await call("GET", "/api/admin/users", strangerToken);

    t.ok(
      strangerUsers.status === 403,
      "no implicit admin fallback for an account with no grants",
      `-> ${strangerUsers.status}`
    );

    t.section("ownership / IDOR protection");

    for (const [role, own] of Object.entries(OWNERSHIP_EXPECTATIONS)) {
      const { user, token } = sessions[role];

      const selfPut = await call("PUT", `/api/admin/users/${user.id}`, token);

      t.ok(
        selfPut.status !== 403,
        `${role}: a user may edit their own record`,
        `-> ${selfPut.status}`
      );

      const otherPut = await call("PUT", `/api/admin/users/${stranger.id}`, token);

      t.ok(
        own.putOther === 403 ? otherPut.status === 403 : otherPut.status !== 403,
        `${role}: editing another user -> ${own.putOther}`,
        `-> ${otherPut.status} ${otherPut.message}`
      );

      const legacyOther = await call("PUT", `/api/auth/users/${stranger.id}`, token);

      t.ok(
        own.putOtherLegacy === 403
          ? legacyOther.status === 403
          : legacyOther.status !== 403,
        `${role}: the legacy path enforces the same ownership rule`,
        `-> ${legacyOther.status}`
      );
    }

    const selfDelete = await call(
      "DELETE",
      `/api/admin/users/${sessions.admin.user.id}`,
      sessions.admin.token
    );

    t.ok(selfDelete.status === 403, "deleting your own account is refused", `-> ${selfDelete.status}`);

    const selfStatus = await srv.request(
      "PATCH",
      `/api/admin/users/${sessions.admin.user.id}/status`,
      { token: sessions.admin.token, json: { status: 0 } }
    );

    t.ok(
      selfStatus.status === 403,
      "suspending your own account is refused",
      `-> ${selfStatus.status}`
    );

    t.section("legacy admin paths must not bypass authentication");

    const legacyAdmin = [
      ["POST", "/api/posts/create"],
      ["POST", "/api/posts/get_all_posts"],
      ["PATCH", "/api/posts/status/1"],
      ["POST", "/api/leads/all_leads"],
      ["POST", "/api/subscribe/all_subscribe"],
      ["GET", "/api/auth/users"],
      ["POST", "/api/media/getlist"],
      ["DELETE", "/api/category/1"],
    ];

    for (const [method, path] of legacyAdmin) {
      const r = await call(method, path);

      t.ok(r.status === 401, `${method} ${path} -> 401`, `-> ${r.status}`);
    }

    t.section("legacy admin paths enforce the same permissions, not just login");

    const writer = sessions.content_writer.token;

    for (const [method, path] of [
      ["GET", "/api/auth/users"],
      ["PATCH", "/api/posts/status/1"],
      ["POST", "/api/leads/all_leads"],
      ["DELETE", "/api/category/1"],
    ]) {
      const r = await call(method, path, writer);

      t.ok(
        r.status === 403,
        `content_writer: ${method} ${path} -> 403`,
        `-> ${r.status}`
      );
    }
  } finally {
    await db.destroyOperator(operators);

    if (srv) await srv.close();
    await db.close();
  }

  t.finish();
})();
