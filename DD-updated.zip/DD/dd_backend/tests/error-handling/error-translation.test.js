// tests/error-handling/error-translation.test.js
//
// Unit tests for middleware/error.middleware.js translate() (Phase 3).
//
// Each fixture carries something that must never reach a client - a full SQL
// statement, a connection string with a username and database name, an
// absolute filesystem path - and every translated result is scanned against a
// forbidden-pattern list.
//
// No database and no HTTP server: this is the fastest suite and the only one
// that runs without MySQL.

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { translate } = require("../../middleware/error.middleware");
const ApiError = require("../../utils/ApiError");

const mk = (props) => Object.assign(new Error(props.message || "raw"), props);

// A synthetic path, not a real one from any machine. It only has to be
// distinctive enough that the leak scan below can prove it was not echoed.
const FAKE_PATH = "/var/app-private/uploads/author";

const CASES = [
  ["ApiError 404", ApiError.notFound("Nope"), 404],
  ["ApiError 409", ApiError.conflict("Slug taken"), 409],
  [
    "multer LIMIT_FILE_SIZE",
    mk({ name: "MulterError", code: "LIMIT_FILE_SIZE", field: "banner_img" }),
    413,
  ],
  [
    "multer LIMIT_FIELD_VALUE",
    mk({ name: "MulterError", code: "LIMIT_FIELD_VALUE", field: "post_content" }),
    413,
  ],
  [
    "fileFilter rejection",
    new Error("Only jpeg, jpg, png and webp images are allowed"),
    400,
  ],
  [
    "malformed JSON body",
    mk({ type: "entity.parse.failed", status: 400, message: "Unexpected token }" }),
    400,
  ],
  ["body too large", mk({ type: "entity.too.large", status: 413 }), 413],
  [
    "Sequelize validation",
    mk({
      name: "SequelizeValidationError",
      errors: [{ path: "post_title", message: "Post.post_title cannot be null" }],
    }),
    400,
  ],
  [
    "Sequelize unique constraint",
    mk({
      name: "SequelizeUniqueConstraintError",
      errors: [{ path: "user_email", message: "user_email must be unique" }],
    }),
    409,
  ],
  ["Sequelize foreign key", mk({ name: "SequelizeForeignKeyConstraintError" }), 409],
  [
    "Sequelize database error carrying SQL",
    mk({
      name: "SequelizeDatabaseError",
      message: "Unknown column 'x' in 'order clause'",
      sql: "SELECT * FROM `post_data` WHERE `post_slug`='secret' ORDER BY `x`",
      parameters: ["secret"],
    }),
    500,
  ],
  [
    "Sequelize connection refused (carries host, user, database)",
    mk({
      name: "SequelizeConnectionRefusedError",
      message: "connect ECONNREFUSED 127.0.0.1:3306 user=root database=datademand",
    }),
    503,
  ],
  ["Sequelize acquire timeout", mk({ name: "SequelizeConnectionAcquireTimeoutError" }), 503],
  [
    "ENOENT carrying an absolute path",
    mk({ code: "ENOENT", message: "ENOENT: no such file or directory", path: FAKE_PATH }),
    500,
  ],
  ["unrecognised Error", new Error("kaboom internal detail"), 500],
];

// Anything matching these in a translated payload is a disclosure bug.
const FORBIDDEN = [
  /SELECT/i,
  /FROM `/,
  /ECONNREFUSED/,
  /app-private/, // the synthetic filesystem path above
  /[A-Za-z]:\\/, // a Windows absolute path
  /dd_backend/,
  /\broot\b/,
  /datademand/,
  /kaboom/,
  /Unknown column/,
];

const t = createHarness("error-translation");

t.section("status codes");

for (const [label, error, expectedStatus] of CASES) {
  const out = translate(error);

  t.ok(
    out.statusCode === expectedStatus,
    `${label} -> ${expectedStatus}`,
    `-> ${out.statusCode}`
  );
}

t.section("no internal detail is disclosed");

for (const [label, error] of CASES) {
  const payload = JSON.stringify(translate(error));
  const leaks = FORBIDDEN.filter((re) => re.test(payload));

  t.ok(
    leaks.length === 0,
    `${label} discloses nothing`,
    leaks.length ? `LEAKED: ${leaks.join(" ")}` : ""
  );
}

t.section("useful detail is still returned where it is safe");

const validation = translate(
  mk({
    name: "SequelizeValidationError",
    errors: [{ path: "post_title", message: "Post.post_title cannot be null" }],
  })
);

t.ok(
  Array.isArray(validation.details) && validation.details[0].field === "post_title",
  "validation errors keep the field name"
);

t.ok(
  validation.details[0].message === "post_title cannot be null",
  "the model name prefix is stripped from validation messages",
  validation.details[0].message
);

t.finish();
