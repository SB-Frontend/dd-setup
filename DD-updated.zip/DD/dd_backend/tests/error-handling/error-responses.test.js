// tests/error-handling/error-responses.test.js
//
// End-to-end error responses (Phase 3).
//
// Run once per NODE_ENV: production must disclose nothing, development must
// add a debug block. tests/run-all.js runs this file twice.
//
//   NODE_ENV=production  node tests/error-handling/error-responses.test.js
//   NODE_ENV=development node tests/error-handling/error-responses.test.js

process.env.NODE_ENV = process.env.NODE_ENV || "production";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const { createStubber, tokens } = require("../helpers/stubs");
const db = require("../helpers/db");

const ENV = process.env.NODE_ENV;
const IS_DEV = ENV === "development";

(async () => {
  const t = createHarness(`error-responses (NODE_ENV=${ENV})`);

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const stubber = createStubber();

  const operator = await db.createOperator({ roles: ["admin"] });

  const srv = await startServer();
  const token = tokens.valid(operator.id);

  try {
    t.section("everything returns JSON, never an HTML stack trace");

    const notFound = await srv.get("/api/does/not/exist");

    t.ok(notFound.status === 404, "unknown API route -> 404", `-> ${notFound.status}`);
    t.ok(
      notFound.contentType === "application/json",
      "unknown API route returns JSON",
      notFound.contentType
    );

    const nonApi = await srv.get("/totally/unknown");

    t.ok(
      nonApi.status === 404 && nonApi.contentType === "application/json",
      "unknown non-API route -> JSON 404",
      `-> ${nonApi.status} ${nonApi.contentType}`
    );

    const badJson = await srv.request("POST", "/api/admin/auth/login", {
      headers: { "Content-Type": "application/json" },
      body: "{ this is not json",
    });

    t.ok(badJson.status === 400, "malformed JSON body -> 400", `-> ${badJson.status}`);
    t.ok(
      badJson.json && badJson.json.message === "Request body is not valid JSON.",
      "malformed JSON message is generic",
      badJson.message
    );

    t.section("consistent envelope");

    for (const r of [notFound, nonApi, badJson]) {
      t.ok(
        r.json && r.json.success === false && r.json.error && r.json.message,
        "error body is {success,error,message}",
        JSON.stringify(r.json).slice(0, 60)
      );
    }

    t.section("authentication failures");

    const noToken = await srv.get("/api/admin/posts");

    t.ok(noToken.status === 401, "missing token -> 401", `-> ${noToken.status}`);
    t.ok(
      noToken.json.message === "No authentication token provided.",
      "missing token message",
      noToken.message
    );

    const expired = await srv.get("/api/admin/posts", { token: tokens.expired() });

    t.ok(expired.status === 401, "expired token -> 401", `-> ${expired.status}`);
    t.ok(
      /expired/i.test(expired.message),
      "expired token is distinguishable from invalid",
      expired.message
    );

    t.section("no SQL reaches the client on a database error");

    const badSort = await srv.get("/api/admin/posts?sort=definitely_not_a_column", {
      token,
    });

    t.ok(
      !/SELECT|FROM `|Unknown column|order clause/i.test(badSort.text),
      "bad sort column discloses no SQL",
      `-> ${badSort.status}`
    );

    t.section("no filesystem path reaches the client on an upload failure");

    const form = new FormData();

    form.append("title", "not a real image");
    form.append(
      "file",
      new Blob([Buffer.from("not-an-image")], { type: "image/png" }),
      "a.png"
    );

    // Media upload is the surface that still takes a file; CMS accounts no
    // longer carry an image, so registration no longer accepts one.
    const upload = await srv.request("POST", "/api/admin/media", {
      token,
      body: form,
    });

    t.ok(
      upload.status >= 400,
      "an invalid upload is rejected",
      `-> ${upload.status} ${upload.message.slice(0, 50)}`
    );

    // In development the debug block deliberately carries the raw message and
    // stack, so only the client-facing fields are checked there.
    const disclosureTarget = IS_DEV
      ? JSON.stringify({
          success: upload.json && upload.json.success,
          error: upload.json && upload.json.error,
          message: upload.json && upload.json.message,
        })
      : upload.text;

    t.ok(
      !/uploads[\\/]|dd_backend|[A-Za-z]:\\/.test(disclosureTarget),
      "no filesystem path in the client-facing fields",
      disclosureTarget.slice(0, 70)
    );

    t.section(`environment disclosure policy (NODE_ENV=${ENV})`);

    if (IS_DEV) {
      t.ok(
        badJson.json && badJson.json.debug && badJson.json.debug.stack,
        "development adds a debug block with a stack"
      );
    } else {
      t.ok(
        badJson.json && badJson.json.debug === undefined,
        "production omits the debug block entirely"
      );
      t.ok(
        !/stack|at Object|node_modules/.test(badJson.text),
        "production discloses no stack frames"
      );
    }

    t.section("public website is unaffected by error handling");

    const site = await srv.get("/api/website/categories");

    t.ok(
      site.status === 200 && site.json && site.json.success === true,
      "GET /api/website/categories still 200",
      `-> ${site.status}`
    );
  } finally {
    stubber.restore();
    await db.destroyOperator(operator);
    await srv.close();
    await db.close();
  }

  t.finish();
})();
