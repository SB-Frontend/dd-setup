// tests/bug-fixes/query-and-update.test.js
//
// The functional defects fixed in Phase 4, re-expressed against the clean
// D1/D2 schema. The defects are the same; only the column names moved.
//
// Several assertions inspect the payload a controller hands to Sequelize
// rather than the HTTP response, because "an omitted field must not appear in
// the UPDATE" is invisible from outside. Those use stubs, so no rows are
// written.

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const { createStubber, tokens } = require("../helpers/stubs");
const db = require("../helpers/db");

const Post = require("../../models/post.model");
const Author = require("../../models/author.model");
const Category = require("../../models/category.model");
const Subcategory = require("../../models/subcategory.model");

(async () => {
  const t = createHarness("bug-fixes");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const stubber = createStubber();

  // A real CMS account with a real admin grant: since D4 there is no implicit
  // role, so the session has to exist in the database like any other.
  const operator = await db.createOperator({ roles: ["admin"] });

  const captured = { update: null, create: null };

  const fakePost = {
    id: 1,
    slug: "existing-slug",
    status: "draft",
    published_at: null,
    banner_image: "existing.jpg",
    created_by: 42,
    update: async (values) => {
      captured.update = values;

      return fakePost;
    },
  };

  stubber.replace(Post, "findByPk", async () => fakePost);
  stubber.replace(Post, "findOne", async () => null);
  stubber.replace(Post, "count", async () => 0);
  stubber.replace(Post, "findAndCountAll", async () => ({ count: 0, rows: [] }));

  // Reference checks in the controller resolve against these.
  stubber.replace(Author, "findByPk", async (id) =>
    Number(id) === 7 ? { id: 7, status: 1 } : Number(id) === 8 ? { id: 8, status: 0 } : null
  );
  stubber.replace(Category, "findByPk", async (id) => (Number(id) === 3 ? { id: 3 } : null));
  stubber.replace(Subcategory, "findByPk", async (id) => (Number(id) === 5 ? { id: 5 } : null));

  const srv = await startServer();
  const token = tokens.valid(operator.id);

  const call = (method, path, json) => srv.request(method, path, { token, json });

  try {
    t.section("fix 1: missing Op import broke search");

    for (const path of ["/api/admin/leads/list", "/api/admin/subscriptions/list"]) {
      const r = await call("POST", path, { search: "acme" });

      t.ok(r.status === 200, `POST ${path} search=acme`, `-> ${r.status}`);
    }

    t.section("fix 3: NaN pagination reached SQL");

    for (const q of [
      "page=abc&limit=abc",
      "page=0",
      "page=-5",
      "limit=99999999",
      "page=2&limit=25",
    ]) {
      const r = await call("GET", `/api/admin/users?${q}`);
      const p = r.json && r.json.pagination;

      t.ok(
        r.status === 200 && p && Number.isInteger(p.page) && Number.isInteger(p.limit),
        `GET /api/admin/users?${q}`,
        `-> ${r.status} ${JSON.stringify(p)}`
      );
    }

    const legacyList = await srv.request("POST", "/api/posts/website/posts", {
      json: { page: "abc", limit: "abc" },
    });

    t.ok(
      legacyList.status === 200,
      "legacy website list survives garbage pagination",
      `-> ${legacyList.status}`
    );

    t.section("fix 4: NaN path parameter");

    const badParam = await call("GET", "/api/website/subcategories/by-category/abc");

    t.ok(badParam.status === 400, "non-numeric category_id -> 400", `-> ${badParam.status}`);

    const goodParam = await call("GET", "/api/website/subcategories/by-category/3");

    t.ok(goodParam.status === 200, "numeric category_id -> 200", `-> ${goodParam.status}`);

    t.section("fix 5 and 6: sort and order allowlists");

    for (const q of [
      "sort=password",
      "sort=(SELECT 1)",
      "order=DROP TABLE",
      "sort=created_at&order=asc",
    ]) {
      const r = await call("GET", `/api/admin/posts?${q}`);

      t.ok(r.status === 200, `GET /api/admin/posts?${q}`, `-> ${r.status}`);
    }

    const badLeadSort = await call("POST", "/api/admin/leads/list", { sort: "nope_column" });

    t.ok(badLeadSort.status === 200, "unknown lead sort falls back", `-> ${badLeadSort.status}`);

    t.section("fix 7: post status allowlist matches the database CHECK");

    const statusCases = [
      ["bogus", 400],
      ["", 400],
      [null, 400],
      ["x".repeat(50), 400],
      // The application accepts exactly draft and published; the CHECK
      // constraint lists the same two, so archived must be rejected here too.
      ["archived", 400],
      ["published", 200],
      ["draft", 200],
    ];

    for (const [value, expected] of statusCases) {
      const r = await call("PATCH", "/api/admin/posts/1/status", { status: value });

      t.ok(
        r.status === expected,
        `status=${JSON.stringify(value).slice(0, 20)} -> ${expected}`,
        `-> ${r.status}`
      );
    }

    const badId = await call("PATCH", "/api/admin/posts/abc/status", { status: "draft" });

    t.ok(badId.status === 400, "non-numeric post id -> 400", `-> ${badId.status}`);

    t.section("fix 2: partial update must not send omitted fields");

    captured.update = null;

    await call("PUT", "/api/admin/posts/1", { title: "Only the title" });

    const keys = Object.keys(captured.update || {});

    t.ok(
      !keys.includes("meta_title") &&
        !keys.includes("category_id") &&
        !keys.includes("excerpt") &&
        !keys.includes("author_id"),
      "omitted fields are absent from the UPDATE",
      `keys=[${keys.join(",")}]`
    );

    t.ok(
      captured.update && captured.update.banner_image === undefined,
      "banner_image is untouched when no file was uploaded"
    );

    t.ok(
      captured.update && captured.update.created_by === undefined,
      "created_by is never rewritten on update"
    );

    t.ok(
      captured.update && Number(captured.update.updated_by) === Number(operator.id),
      "updated_by is set from the session",
      String(captured.update && captured.update.updated_by)
    );

    t.section("reference validation on write");

    const badAuthor = await call("POST", "/api/admin/posts", {
      title: "t", slug: "s1", content: "c", author_id: 99999,
    });

    t.ok(badAuthor.status === 404, "unknown author_id -> 404", `-> ${badAuthor.status}`);

    const inactiveAuthor = await call("POST", "/api/admin/posts", {
      title: "t", slug: "s2", content: "c", author_id: 8,
    });

    t.ok(inactiveAuthor.status === 400, "inactive author_id -> 400", `-> ${inactiveAuthor.status}`);

    const badAuthorType = await call("POST", "/api/admin/posts", {
      title: "t", slug: "s3", content: "c", author_id: "abc",
    });

    t.ok(badAuthorType.status === 400, "non-numeric author_id -> 400", `-> ${badAuthorType.status}`);

    const badSubcategory = await call("POST", "/api/admin/posts", {
      title: "t", slug: "s4", content: "c", subcategory_id: 99999,
    });

    t.ok(badSubcategory.status === 404, "unknown subcategory_id -> 404", `-> ${badSubcategory.status}`);

    t.section("create sets the CMS audit columns, never the byline");

    stubber.replace(Post, "create", async (values) => {
      captured.create = values;

      return { id: 1 };
    });

    await call("POST", "/api/admin/posts", {
      title: "t", slug: "audit-slug", content: "c", author_id: 7,
    });

    t.ok(captured.create !== undefined, "the create payload was captured");

    if (captured.create) {
      t.ok(
        Number(captured.create.created_by) === Number(operator.id) &&
          Number(captured.create.updated_by) === Number(operator.id),
        "created_by and updated_by come from the session",
        `created_by=${captured.create.created_by}`
      );

      t.ok(
        Number(captured.create.author_id) === 7,
        "author_id is the supplied AUTHOR, not the logged-in user",
        `author_id=${captured.create.author_id}`
      );

      t.ok(
        Number(captured.create.author_id) !== Number(operator.id),
        "author_id is never derived from the CMS user id"
      );

      t.ok(
        captured.create.status === "draft",
        "a new post is always created as a draft; publishing is a separate right"
      );

      t.ok(
        !("session_user" in captured.create) &&
          !("comment_by" in captured.create) &&
          !("comments" in captured.create) &&
          !("handover_to" in captured.create),
        "no legacy handover/session/comment fields are written",
        `keys=${Object.keys(captured.create).length}`
      );
    }
  } finally {
    stubber.restore();
    await db.destroyOperator(operator);
    await srv.close();
    await db.close();
  }

  t.finish();
})();
