// tests/api/hardening.test.js
//
// D6 §19 slugs, §21 pagination, §22 sorting, §23 filtering and search.
//
// The website suite already covers the happy paths on the public listing.
// This one is adversarial and covers BOTH surfaces: it feeds every collection
// endpoint - public and admin - the inputs a client should never send, and
// requires that none of them reach SQL, none of them error, and none of them
// widen what the caller can see.
//
// The admin half matters as much as the public half: an authenticated user
// with a legitimate token is still an untrusted source of query parameters.

process.env.RATE_LIMIT_DISABLED = "true";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const { tokens } = require("../helpers/stubs");
const db = require("../helpers/db");

// Values that must never reach ORDER BY, LIMIT or a WHERE clause intact.
const INJECTION = [
  "1; DROP TABLE posts",
  "1' OR '1'='1",
  "' UNION SELECT password FROM users -- ",
  "(SELECT password FROM users LIMIT 1)",
  "id, (SELECT 1)",
  "../../etc/passwd",
  "%00",
  "<script>alert(1)</script>",
  "\\x00",
  "1 OR SLEEP(5)",
];

// Every pagination input a client can get wrong, and some it can get hostile.
const PAGINATION = [
  "page=1&limit=10",
  "page=2&limit=4",
  "limit=50",
  "limit=51",
  "limit=9999999",
  "limit=0",
  "limit=-1",
  "page=0",
  "page=-1",
  "page=abc&limit=abc",
  "page=1e10&limit=1e10",
  "page=NaN&limit=NaN",
  "page=null&limit=undefined",
  "page=1.9&limit=7.9",
  "page=%20&limit=%20",
  "limit[]=5",
  "page[]=1",
];

(async () => {
  const t = createHarness("api-hardening");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  let seeded = null;
  let srv = null;
  let operator = null;

  try {
    seeded = await db.seed();
    operator = await db.createOperator({ roles: ["admin"] });

    srv = await startServer();

    const token = tokens.valid(operator.id);

    const get = (p) => srv.get(p);
    const admin = (p) => srv.request("GET", p, { token });

    // ================================================================
    t.section("§21 pagination - public listing");
    // ================================================================

    for (const q of PAGINATION) {
      const r = await get(`/api/website/posts?${q}`);
      const m = r.json && r.json.meta;

      const sane =
        r.status === 200 &&
        m &&
        Number.isInteger(m.page) && m.page >= 1 &&
        Number.isInteger(m.limit) && m.limit >= 1 && m.limit <= 50 &&
        Number.isInteger(m.total) && m.total >= 0 &&
        Array.isArray(r.json.data) &&
        r.json.data.length <= m.limit;

      t.ok(sane, `public ?${q}`, m ? `page=${m.page} limit=${m.limit} rows=${r.json.data.length}` : `-> ${r.status}`);
    }

    let r = await get("/api/website/posts?limit=9999999");

    t.ok(r.json.meta.limit === 50, "an enormous limit is capped, not honoured", `limit=${r.json.meta.limit}`);

    t.ok(
      r.json.data.length <= 50,
      "and the response really is capped, not just the metadata",
      String(r.json.data.length)
    );

    // A page far past the end must be an empty list, never an error and never
    // a wrapped-around first page.
    r = await get("/api/website/posts?page=99999&limit=10");

    t.ok(
      r.status === 200 && r.json.data.length === 0 && r.json.meta.has_more === false,
      "a page past the end returns an empty list",
      `rows=${r.json.data.length}`
    );

    // ================================================================
    t.section("§21 pagination - admin collections");
    // ================================================================

    const BAD_PAGES = ["page=abc&limit=abc", "page=-5", "limit=9999999", "limit=-1", "page[]=1"];

    // /api/admin/users returns { pagination: { page, limit, ... } }.
    for (const q of BAD_PAGES) {
      const rr = await admin(`/api/admin/users?${q}`);
      const p = rr.json && rr.json.pagination;

      t.ok(
        rr.status === 200 && p && Number.isInteger(p.page) && p.page >= 1 &&
          Number.isInteger(p.limit) && p.limit > 0 && p.limit <= 100,
        `admin users ?${q}`,
        p ? `page=${p.page} limit=${p.limit}` : `-> ${rr.status}`
      );
    }

    // /api/admin/posts answers in the legacy jQuery DataTables envelope the
    // existing CMS consumes - { draw, iTotalRecords, iTotalDisplayRecords,
    // aaData } - not { page, limit }. `draw` echoes the SANITISED page, so it
    // is the observable proof that parsePagination normalised the input: a NaN
    // reaching LIMIT/OFFSET would have produced a 500, not a 200.
    for (const q of BAD_PAGES) {
      const rr = await admin(`/api/admin/posts?${q}`);
      const j = rr.json || {};

      t.ok(
        rr.status === 200 &&
          Number.isInteger(j.draw) && j.draw >= 1 &&
          Array.isArray(j.aaData) &&
          Number.isInteger(j.iTotalRecords) && j.iTotalRecords >= 0 &&
          Number.isInteger(j.iTotalDisplayRecords) &&
          j.aaData.length <= 100,
        `admin posts ?${q}`,
        `-> ${rr.status} draw=${j.draw} rows=${Array.isArray(j.aaData) ? j.aaData.length : "?"}`
      );
    }

    // Garbage and negative pages must all normalise to page 1.
    for (const q of ["page=abc", "page=-5", "page=0", "page=NaN", "page[]=1"]) {
      const rr = await admin(`/api/admin/posts?${q}`);

      t.ok(
        rr.json && rr.json.draw === 1,
        `admin posts ?${q} normalises to page 1`,
        `draw=${rr.json && rr.json.draw}`
      );
    }

    // The admin hard cap is real, not just advertised.
    const capped = await admin("/api/admin/posts?limit=9999999");

    t.ok(
      capped.json.aaData.length <= 100,
      "an enormous admin limit cannot pull an unbounded result set",
      `rows=${capped.json.aaData.length}`
    );

    // ================================================================
    t.section("§21 the count always describes the same set as the rows");
    // ================================================================

    for (const q of [
      "limit=50",
      `category_id=${seeded.cats[0]}&limit=50`,
      `subcategory_id=${seeded.subcategoryId}&limit=50`,
      "reading_time=under-5&limit=50",
      "search=Marketing&limit=50",
    ]) {
      const rr = await get(`/api/website/posts?${q}`);

      t.ok(
        rr.json.meta.total === rr.json.data.length,
        `count agrees with rows for ?${q}`,
        `total=${rr.json.meta.total} rows=${rr.json.data.length}`
      );
    }

    // ================================================================
    t.section("§22 sorting - only allowlisted fields reach ORDER BY");
    // ================================================================

    const SAFE = ["published_at", "created_at", "updated_at", "reading_time", "title"];

    for (const payload of INJECTION) {
      const rr = await get(`/api/website/posts?sort=${encodeURIComponent(payload)}&limit=5`);

      t.ok(
        rr.status === 200 && SAFE.includes(rr.json.meta.sort),
        `public sort=${payload.slice(0, 28)} falls back`,
        `-> ${rr.status} sort=${rr.json && rr.json.meta && rr.json.meta.sort}`
      );
    }

    for (const payload of INJECTION) {
      const rr = await get(`/api/website/posts?order=${encodeURIComponent(payload)}&limit=5`);

      t.ok(
        rr.status === 200 && ["ASC", "DESC"].includes(rr.json.meta.order),
        `public order=${payload.slice(0, 28)} falls back`,
        `order=${rr.json && rr.json.meta && rr.json.meta.order}`
      );
    }

    // Sorting on a column that exists but is not public must not be possible.
    for (const hidden of ["content", "created_by", "updated_by", "id"]) {
      const rr = await get(`/api/website/posts?sort=${hidden}&limit=5`);

      t.ok(
        rr.status === 200 && rr.json.meta.sort !== hidden,
        `public sort=${hidden} is refused even though the column exists`,
        `sort=${rr.json.meta.sort}`
      );
    }

    for (const payload of INJECTION.slice(0, 6)) {
      for (const [label, path] of [["posts", "/api/admin/posts"], ["users", "/api/admin/users"]]) {
        const rr = await admin(`${path}?sort=${encodeURIComponent(payload)}&order=${encodeURIComponent(payload)}`);

        t.ok(rr.status === 200, `admin ${label} survives sort/order=${payload.slice(0, 22)}`, `-> ${rr.status}`);
      }
    }

    // The proof that sorting is real and not silently ignored.
    const asc = await get("/api/website/posts?sort=reading_time&order=ASC&limit=50");
    const desc = await get("/api/website/posts?sort=reading_time&order=DESC&limit=50");

    const ascTimes = asc.json.data.map((p) => p.reading_time);
    const descTimes = desc.json.data.map((p) => p.reading_time);

    t.ok(
      JSON.stringify(ascTimes) === JSON.stringify([...ascTimes].sort((a, b) => a - b)),
      "ASC really is ascending",
      ascTimes.join(",")
    );

    t.ok(
      JSON.stringify(descTimes) === JSON.stringify([...ascTimes].sort((a, b) => b - a)),
      "DESC really is descending",
      descTimes.join(",")
    );

    // ================================================================
    t.section("§23 filtering and search cannot be turned into a leak");
    // ================================================================

    for (const payload of INJECTION) {
      const rr = await get(`/api/website/posts?search=${encodeURIComponent(payload)}&limit=50`);

      t.ok(
        rr.status === 200 && Array.isArray(rr.json.data),
        `search=${payload.slice(0, 28)} is handled safely`,
        `-> ${rr.status} total=${rr.json && rr.json.meta && rr.json.meta.total}`
      );

      t.ok(
        rr.status === 200 && !/password|\$2[aby]\$|username/i.test(JSON.stringify(rr.json)),
        `search=${payload.slice(0, 28)} leaks no account data`
      );
    }

    for (const param of ["category_id", "subcategory_id", "exclude_id"]) {
      for (const payload of ["abc", "-1", "0", "1;DROP TABLE posts", "1,2,abc", "", "null"]) {
        const rr = await get(`/api/website/posts?${param}=${encodeURIComponent(payload)}&limit=50`);

        t.ok(
          rr.status === 200 && rr.json.meta.total <= 10,
          `${param}=${payload || "(empty)"} never widens the published set`,
          `total=${rr.json && rr.json.meta && rr.json.meta.total}`
        );
      }
    }

    // An unknown filter must be ignored, not treated as a column.
    for (const q of ["status=draft", "deleted_at=null", "created_by=1", "nonsense=1", "author_id=1"]) {
      const rr = await get(`/api/website/posts?${q}&limit=50`);

      t.ok(
        rr.status === 200 && rr.json.meta.total === 10,
        `?${q} is ignored and cannot reach unpublished rows`,
        `total=${rr.json.meta.total}`
      );
    }

    // ================================================================
    t.section("§19 slug lookups");
    // ================================================================

    const good = await get(`/api/website/posts/${seeded.subcategoryPostSlug}`);

    t.ok(good.status === 200, "a valid published slug resolves", `-> ${good.status}`);

    const SLUGS = [
      ["unknown", "no-such-post-anywhere"],
      ["draft", "zztest-post-12"],
      ["empty-ish", "%20"],
      ["dot segment", "..%2F..%2Fetc%2Fpasswd"],
      ["sql", encodeURIComponent("' OR '1'='1")],
      ["sql comment", encodeURIComponent("x'--")],
      ["union", encodeURIComponent("' UNION SELECT password FROM users -- ")],
      ["script", encodeURIComponent("<script>alert(1)</script>")],
      ["null byte", encodeURIComponent("post%00.jpg")],
      ["very long", "a".repeat(300)],
      ["unicode", encodeURIComponent("артикул-тест")],
      ["emoji", encodeURIComponent("post-🙂")],
      ["percent", "100%25-guide"],
      ["plus", "a+b+c"],
    ];

    for (const [label, slug] of SLUGS) {
      const rr = await get(`/api/website/posts/${slug}`);

      t.ok(
        rr.status === 404,
        `slug ${label} -> 404`,
        `-> ${rr.status}`
      );

      t.ok(
        !/SQL|sequelize|SELECT |mysql|ER_|\.js:\d+|at Query/i.test(rr.text || ""),
        `slug ${label} exposes no database detail`,
        (rr.text || "").slice(0, 70)
      );
    }

    // The same rules on the meta endpoint and the legacy alias.
    for (const path of [
      "/api/website/posts/meta/zztest-post-12",
      `/api/website/posts/meta/${encodeURIComponent("' OR '1'='1")}`,
      "/api/posts/get_post/zztest-post-11",
      "/api/posts/meta/no-such-post",
    ]) {
      const rr = await get(path);

      t.ok(rr.status === 404, `${path} -> 404`, `-> ${rr.status}`);
    }

    t.section("§19 an author slug behaves the same way");

    for (const slug of [
      "no-such-author",
      encodeURIComponent("' OR '1'='1"),
      encodeURIComponent("<script>x</script>"),
      "z".repeat(300),
    ]) {
      const rr = await get(`/api/website/authors/${slug}`);

      t.ok(rr.status === 404, `author slug ${slug.slice(0, 24)} -> 404`, `-> ${rr.status}`);

      t.ok(
        !/password|username|email/i.test(rr.text || ""),
        `author slug ${slug.slice(0, 24)} leaks no CMS field`
      );
    }

    t.section("§20 taxonomy path parameters");

    for (const bad of ["abc", "-1", "0", "1;DROP", "%20", "null"]) {
      const rr = await get(`/api/website/subcategories/by-category/${encodeURIComponent(bad)}`);

      t.ok(
        rr.status === 400,
        `by-category/${bad} -> 400`,
        `-> ${rr.status}`
      );
    }

    const validCat = await get(`/api/website/subcategories/by-category/${seeded.cats[0]}`);

    t.ok(validCat.status === 200, "a valid category id resolves", `-> ${validCat.status}`);

    t.ok(
      validCat.json.data.every((s) => s.category_slug && s.category_id),
      "every subcategory carries its parent through the real association"
    );
  } catch (error) {
    t.ok(false, "the suite ran without an unexpected error", error.message);
    console.error(error);
  } finally {
    try {
      await db.cleanup(seeded);
      await db.destroyOperator(operator);

      const left = await db.countLeftovers();

      console.log(`\n[cleanup] ZZTEST rows remaining: ${JSON.stringify(left)}`);
    } catch (error) {
      console.error("[hardening] cleanup failed:", error.message);
    }

    if (srv) await srv.close();
    await db.close();
  }

  t.finish();
})();
