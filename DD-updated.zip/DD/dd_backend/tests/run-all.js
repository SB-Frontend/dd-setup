// tests/run-all.js
//
// Runs every suite in a child process and aggregates the results.
//
// Child processes rather than requires, because one suite has to run more than
// once under different environments and the setting is read at module load
// time:
//   * NODE_ENV fixes what the error middleware discloses
//
// The auth suite used to run twice, once per AUTH_DEFAULT_ROLE. D4 removed
// that environment variable along with the implicit-role fallback it drove, so
// the suite now creates real accounts with real grants and covers every role
// matrix in a single process.
//
//   node tests/run-all.js
//   node tests/run-all.js --filter website

const path = require("path");
const { spawn } = require("child_process");

const { RESULT_PREFIX } = require("./helpers/harness");

const ROOT = path.resolve(__dirname, "..");

const SUITES = [
  {
    name: "error-translation",
    file: "tests/error-handling/error-translation.test.js",
    env: {},
    needsDb: false,
  },
  // MUST stay first: it needs an empty users table and skips (never deletes)
  // if one is not available.
  {
    name: "auth-bootstrap",
    file: "tests/auth/bootstrap.test.js",
    env: {},
    needsDb: true,
  },
  {
    name: "database-schema",
    file: "tests/database/schema.test.js",
    env: {},
    needsDb: true,
  },
  {
    name: "api-hardening",
    file: "tests/api/hardening.test.js",
    env: {},
    needsDb: true,
  },
  {
    name: "auth",
    file: "tests/auth/auth.test.js",
    env: {},
    needsDb: true,
  },
  {
    name: "security-rbac",
    file: "tests/security/rbac.test.js",
    env: {},
    needsDb: true,
  },
  {
    name: "error-responses (production)",
    file: "tests/error-handling/error-responses.test.js",
    env: { NODE_ENV: "production" },
    needsDb: true,
  },
  {
    name: "error-responses (development)",
    file: "tests/error-handling/error-responses.test.js",
    env: { NODE_ENV: "development" },
    needsDb: true,
  },
  {
    name: "bug-fixes",
    file: "tests/bug-fixes/query-and-update.test.js",
    env: {},
    needsDb: true,
  },
  { name: "uploads", file: "tests/uploads/uploads.test.js", env: {}, needsDb: true },
  {
    name: "security-headers-cors",
    file: "tests/security/headers-and-cors.test.js",
    env: {},
    needsDb: true,
  },
  {
    name: "security-rate-limit",
    file: "tests/security/rate-limit.test.js",
    env: {},
    needsDb: true,
  },
  {
    name: "security-sanitization",
    file: "tests/security/sanitization.test.js",
    env: {},
    needsDb: true,
  },
  { name: "security-jwt", file: "tests/security/jwt.test.js", env: {}, needsDb: true },
  {
    name: "website-api",
    file: "tests/website/website-api.test.js",
    env: {},
    needsDb: true,
  },
];

const args = process.argv.slice(2);
const filterIndex = args.indexOf("--filter");
const filter = filterIndex >= 0 ? args[filterIndex + 1] : null;
const verbose = args.includes("--verbose");

function runSuite(suite) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [suite.file], {
      cwd: ROOT,
      env: { ...process.env, ...suite.env },
      stdio: ["ignore", "pipe", "pipe"],
    });

    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      stdout += chunk;

      if (verbose) process.stdout.write(chunk);
    });

    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });

    child.on("close", (code) => {
      const line = stdout
        .split("\n")
        .reverse()
        .find((l) => l.startsWith(RESULT_PREFIX));

      let result = null;

      if (line) {
        try {
          result = JSON.parse(line.slice(RESULT_PREFIX.length));
        } catch {
          result = null;
        }
      }

      resolve({ suite, code, result, stdout, stderr });
    });
  });
}

(async () => {
  const selected = filter
    ? SUITES.filter((s) => s.name.includes(filter) || s.file.includes(filter))
    : SUITES;

  if (selected.length === 0) {
    console.error(`No suite matches --filter ${filter}`);
    process.exit(1);
  }

  console.log("DataDemand backend - local test run");
  console.log(`Node ${process.version}   suites: ${selected.length}\n`);

  const startedAt = Date.now();
  const results = [];

  for (const suite of selected) {
    process.stdout.write(`running ${suite.name} ... `);

    const outcome = await runSuite(suite);

    results.push(outcome);

    if (outcome.result) {
      const { passed, failed, skipped, durationMs } = outcome.result;

      console.log(
        `${failed > 0 ? "FAILED" : "ok"}  ${passed} passed, ${failed} failed, ` +
          `${skipped} skipped (${(durationMs / 1000).toFixed(1)}s)`
      );
    } else {
      console.log(`ERROR (exit ${outcome.code}, no result line)`);
    }
  }

  const totals = results.reduce(
    (acc, r) => {
      if (r.result) {
        acc.passed += r.result.passed;
        acc.failed += r.result.failed;
        acc.skipped += r.result.skipped;
      } else {
        acc.crashed += 1;
      }

      return acc;
    },
    { passed: 0, failed: 0, skipped: 0, crashed: 0 }
  );

  const runtime = ((Date.now() - startedAt) / 1000).toFixed(1);

  console.log("\n" + "=".repeat(58));
  console.log("SUMMARY");
  console.log("=".repeat(58));
  console.log(`  assertions : ${totals.passed + totals.failed + totals.skipped}`);
  console.log(`  passed     : ${totals.passed}`);
  console.log(`  failed     : ${totals.failed}`);
  console.log(`  skipped    : ${totals.skipped}`);
  console.log(`  suites     : ${results.length} (${totals.crashed} crashed)`);
  console.log(`  runtime    : ${runtime}s`);

  // Show output from anything that failed or crashed, so a failure is
  // actionable without a second run.
  for (const r of results) {
    if (!r.result || r.result.failed > 0) {
      console.log("\n" + "-".repeat(58));
      console.log(`OUTPUT: ${r.suite.name}`);
      console.log("-".repeat(58));
      console.log(r.stdout.trim().split("\n").slice(-40).join("\n"));

      if (r.stderr.trim()) console.log("stderr:\n" + r.stderr.trim().slice(-1500));
    }
  }

  process.exit(totals.failed > 0 || totals.crashed > 0 ? 1 : 0);
})();
