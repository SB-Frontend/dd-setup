// tests/helpers/stubs.js
//
// Model stubbing and token minting.
//
// D4 NOTE - THERE IS NO LONGER A FAKE SESSION USER.
//   This file used to export TEST_USER and stubAuthUser(), which made
//   authenticate() resolve an in-memory account that existed nowhere. That
//   worked only because config/permissions.js granted a fallback role to any
//   account with no rows in user_roles. D4 removed that fallback, so a session
//   is now exactly what the database says it is.
//
//   Suites create a real account with real grants instead:
//       const admin = await db.createOperator({ roles: ["admin"] });
//       const token = tokens.valid(admin.id);
//
//   This is strictly better as a test: the request walks the real
//   user_roles -> roles -> role_permissions -> permissions chain rather than a
//   shortcut around it.
//
// Stubbing is still used for write-payload assertions (what a controller hands
// to Sequelize), which cannot be observed from outside. Every stub is recorded
// and restore() puts the original methods back.

const jwt = require("jsonwebtoken");

function createStubber() {
  const restores = [];

  return {
    // replace(Model, "findByPk", fn)
    replace(target, method, implementation) {
      const original = target[method];

      restores.push(() => {
        target[method] = original;
      });

      target[method] = implementation;

      return original;
    },

    restore() {
      while (restores.length > 0) restores.pop()();
    },
  };
}

// Valid tokens are minted through the application's own signer, so they carry
// the same algorithm, issuer and audience the middleware verifies. Building
// them by hand here would mean the tests stopped exercising that config.
const { signAccessToken, ISSUER, AUDIENCE, ALGORITHM } = require("../../utils/jwt");

// An id that no account will ever have, for the "token for a user that no
// longer exists" case.
const GHOST_USER_ID = 424242;

function signToken(payload = {}) {
  return signAccessToken(payload);
}

// Each of these is invalid for a different reason, so a single check cannot
// accidentally satisfy all of them. All take the real user id the token should
// identify, because authentication now resolves a real row.
const tokens = {
  valid: (userId) => signToken({ id: userId }),

  expired: (userId = GHOST_USER_ID) =>
    jwt.sign({ id: userId }, process.env.JWT_SECRET_KEY, {
      algorithm: ALGORITHM,
      issuer: ISSUER,
      audience: AUDIENCE,
      expiresIn: "-10s",
    }),

  wrongSignature: (userId = GHOST_USER_ID) =>
    jwt.sign({ id: userId }, "not-the-real-secret", {
      algorithm: ALGORITHM,
      issuer: ISSUER,
      audience: AUDIENCE,
      expiresIn: "1h",
    }),

  // Correctly signed, but for a user the database does not have.
  unknownUser: () => signToken({ id: GHOST_USER_ID }),

  // Right secret, but issued for a different audience.
  wrongAudience: (userId = GHOST_USER_ID) =>
    jwt.sign({ id: userId }, process.env.JWT_SECRET_KEY, {
      algorithm: ALGORITHM,
      issuer: ISSUER,
      audience: "some-other-service",
      expiresIn: "1h",
    }),

  // Right secret and audience, but the "none" algorithm.
  noneAlgorithm: (userId = GHOST_USER_ID) => {
    const header = Buffer.from(JSON.stringify({ alg: "none", typ: "JWT" })).toString("base64url");
    const body = Buffer.from(
      JSON.stringify({ id: userId, iss: ISSUER, aud: AUDIENCE })
    ).toString("base64url");

    return `${header}.${body}.`;
  },

  malformed: () => "abc.def.ghi",

  // A correctly signed token that also carries role and permission claims.
  // Used to prove the backend ignores them: authorization comes from the
  // database, never from what the client presents.
  withForgedClaims: (userId, claims) => signToken({ id: userId, ...claims }),
};

module.exports = { createStubber, signToken, tokens, GHOST_USER_ID };
