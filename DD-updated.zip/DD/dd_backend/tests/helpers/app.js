// tests/helpers/app.js
//
// Builds the Express app the suites exercise.
//
// IMPORTANT: this mirrors the middleware chain in server.js. server.js was
// deliberately not refactored to export its app, because changing it was out
// of scope for this stage. If the chain in server.js changes, change it here
// too. Extracting an app factory that both share is the better long-term fix
// and is recorded as a follow-up.

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

const routesHandler = require("../../routes/routesHandler.routes.js");
const {
  notFoundHandler,
  errorHandler,
} = require("../../middleware/error.middleware");
const { cleanupFailedUploads } = require("../../middleware/upload.middleware");
const { UPLOAD_ROOT } = require("../../config/uploads");
const {
  corsOptions,
  helmetOptions,
  trustProxySetting,
} = require("../../config/security");

function buildApp(options = {}) {
  const app = express();

  app.set("trust proxy", trustProxySetting());
  app.disable("x-powered-by");

  app.use(helmet(helmetOptions()));
  app.use(cors(corsOptions));

  app.use(express.json());
  app.use(cleanupFailedUploads);

  if (options.serveUploads !== false) {
    app.use(
      "/uploads",
      express.static(UPLOAD_ROOT, {
        index: false,
        dotfiles: "deny",
        etag: true,
        maxAge: "30d",
        setHeaders(res) {
          res.setHeader("X-Content-Type-Options", "nosniff");
          res.setHeader("Content-Security-Policy", "default-src 'none'; sandbox");
          res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
        },
      })
    );
  }

  app.use("/api", routesHandler);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

// Starts the app on an ephemeral port and returns helpers bound to it, so no
// suite has to hardcode a port or risk colliding with a running dev server.
async function startServer(options) {
  const app = buildApp(options);

  const server = await new Promise((resolve) => {
    const s = app.listen(0, () => resolve(s));
  });

  const base = `http://127.0.0.1:${server.address().port}`;

  const request = async (method, urlPath, opts = {}) => {
    const headers = { ...(opts.headers || {}) };

    if (opts.token) headers.Authorization = `Bearer ${opts.token}`;

    let body = opts.body;

    if (opts.json !== undefined) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(opts.json);
    }

    const response = await fetch(base + urlPath, { method, headers, body });
    const text = await response.text();

    let json = null;

    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }

    return {
      status: response.status,
      headers: response.headers,
      contentType: (response.headers.get("content-type") || "").split(";")[0],
      text,
      json,
      message: (json && json.message) || "",
    };
  };

  return {
    app,
    server,
    base,
    request,
    get: (p, opts) => request("GET", p, opts),
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

module.exports = { buildApp, startServer };
