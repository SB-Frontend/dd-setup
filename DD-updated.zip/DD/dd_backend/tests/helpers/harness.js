// tests/helpers/harness.js
//
// A deliberately tiny assertion harness.
//
// The suites were written as plain Node scripts and there is no test
// framework in this project. Rather than introduce one and rewrite ~140
// working assertions, this keeps the existing PASS/FAIL style and adds the
// two things a runner needs: an exit code, and one machine-readable summary
// line that tests/run-all.js parses.
//
// If a framework is adopted later, only this file and the summary line have
// to change; the assertions themselves are plain booleans.

const RESULT_PREFIX = "##RESULT ";

function createHarness(name) {
  let passed = 0;
  let failed = 0;
  let skipped = 0;

  const failures = [];
  const startedAt = Date.now();

  return {
    name,

    section(title) {
      console.log(`\n--- ${title} ---`);
    },

    ok(condition, label, extra = "") {
      const suffix = extra ? `   ${extra}` : "";

      if (condition) {
        passed += 1;
        console.log(`PASS  ${label}${suffix}`);
      } else {
        failed += 1;
        failures.push(label);
        console.log(`FAIL  ${label}${suffix}`);
      }

      return Boolean(condition);
    },

    skip(label, reason) {
      skipped += 1;
      console.log(`SKIP  ${label}   ${reason}`);
    },

    // Called once at the end of a suite. Prints a human summary plus the
    // machine-readable line, and sets the process exit code.
    //
    // It then exits explicitly. Sequelize keeps pool handles alive for a few
    // seconds after close(), which left every database-backed suite idling
    // for ~5s after its last assertion - about 30s across a full run. The
    // exit is deferred until stdout has flushed so no output is truncated.
    finish() {
      const durationMs = Date.now() - startedAt;

      console.log(
        `\n${name}: ${passed} passed, ${failed} failed, ${skipped} skipped ` +
          `(${(durationMs / 1000).toFixed(1)}s)`
      );

      if (failures.length > 0) {
        console.log("Failed assertions:");
        failures.forEach((f) => console.log(`  - ${f}`));
      }

      console.log(
        RESULT_PREFIX +
          JSON.stringify({ name, passed, failed, skipped, durationMs })
      );

      const code = failed > 0 ? 1 : 0;

      process.exitCode = code;

      process.stdout.write("", () => process.exit(code));

      return { passed, failed, skipped, durationMs };
    },
  };
}

module.exports = { createHarness, RESULT_PREFIX };
