// tests/helpers/env.js
//
// MUST be required first by every test file, before any model or route is
// loaded, because models/index.js reads DB_* at require time.
//
// Responsibilities:
//   * make the process cwd the project root, so dotenv and any relative path
//     resolve the same way regardless of where the runner was invoked from
//   * load .env.test when present, otherwise fall back to .env for local
//     database credentials only
//   * force a test-only JWT secret so no real signing key is ever exercised
//   * allow pointing the whole suite at a dedicated database

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..", "..");

process.chdir(ROOT);

const testEnvPath = path.join(ROOT, ".env.test");
const defaultEnvPath = path.join(ROOT, ".env");

const envPath = fs.existsSync(testEnvPath) ? testEnvPath : defaultEnvPath;

require("dotenv").config({ path: envPath, quiet: true });

// Tests never sign with a real key. This overrides whatever the env file
// carries, so a production or developer secret cannot leak into a token that
// gets written to a log or a snapshot.
process.env.JWT_SECRET_KEY =
  process.env.TEST_JWT_SECRET_KEY || "test-only-secret-not-for-production";

// Point the suite at a dedicated database when one is configured. Without it
// the tests use the local development database, seeding rows prefixed ZZTEST
// and removing them again.
if (process.env.TEST_DB_NAME) {
  process.env.DB_NAME = process.env.TEST_DB_NAME;
}

// Individual suites override this (the error suite runs in both development
// and production to check what each discloses).
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = "test";
}

// Upload limits are read from the environment by config/uploads.js. Keep the
// test values small so oversize fixtures stay cheap to build.
process.env.UPLOAD_MAX_FILE_MB = process.env.UPLOAD_MAX_FILE_MB || "5";
process.env.UPLOAD_MAX_FIELD_MB = process.env.UPLOAD_MAX_FIELD_MB || "8";

module.exports = {
  ROOT,
  envPath,
  usingDedicatedTestDb: Boolean(process.env.TEST_DB_NAME),
  database: process.env.DB_NAME,
};
