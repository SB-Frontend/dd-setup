// tests/helpers/db.js
//
// Database availability plus seed/cleanup for the suites that need real rows.
//
// THE FIXTURES DELIBERATELY KEEP CMS USERS AND PUBLIC AUTHORS SEPARATE.
// A CMS user is created, an Author is created independently, and the post
// points at both in different columns:
//
//   post.author_id  -> author.id   the public byline
//   post.created_by -> user.id     the CMS operator
//   post.updated_by -> user.id
//
// One of the authors is created with no corresponding CMS account at all,
// which is the case the old single-table design could not express.
//
// Everything created is prefixed ZZTEST and removed by cleanup(), which tracks
// the exact primary keys it inserted rather than deleting by pattern.

const { Op } = require("sequelize");

const sequelize = require("../../models");
const {
  Post,
  Author,
  Category,
  Subcategory,
  User,
  Lead,
} = require("../../models/associations");
const rbac = require("../../services/rbac.service");

const PREFIX = "ZZTEST";

// Fixture accounts need a real password because login is exercised over HTTP.
// It is a literal in a test helper, never a seeded production credential, and
// every account using it is deleted in the suite's finally block.
const OPERATOR_PASSWORD = "zztest-Operator-Password-1";

async function isAvailable() {
  try {
    await sequelize.authenticate();

    return true;
  } catch {
    return false;
  }
}

async function close() {
  try {
    await sequelize.close();
  } catch {
    /* already closed */
  }
}

/**
 * 1 CMS user, 2 public authors (one with no CMS account), 3 categories,
 * 1 subcategory, 12 posts (10 published + 2 draft) across three reading-time
 * bands with ascending publication dates.
 */
async function seed() {
  const created = {
    users: [],
    authors: [],
    cats: [],
    subs: [],
    posts: [],
    leads: [],
  };

  // --- CMS operator. Not an author. ---
  const operator = await createOperator({ roles: ["admin"] });

  created.users.push(operator.id);

  // --- Public authors. Neither has a CMS login. ---
  const staffAuthor = await Author.create({
    name: `${PREFIX} Staff Writer`,
    display_name: `${PREFIX} Staff`,
    slug: "zztest-staff",
    bio: "Staff biography",
    image: "staff.jpg",
    status: 1,
    created_by: operator.id,
    updated_by: operator.id,
  });

  // A guest contributor with no CMS account and nobody recorded as creator -
  // exactly the case that motivated splitting authors out of users.
  const guestAuthor = await Author.create({
    name: `${PREFIX} Guest Contributor`,
    display_name: `${PREFIX} Guest`,
    slug: "zztest-guest",
    bio: "Guest biography",
    status: 1,
  });

  created.authors.push(staffAuthor.id, guestAuthor.id);

  for (const [name, slug] of [
    [`${PREFIX} Marketing`, "zztest-marketing"],
    [`${PREFIX} Data`, "zztest-data"],
    [`${PREFIX} Cloud`, "zztest-cloud"],
  ]) {
    const row = await Category.create({
      name,
      slug,
      status: 1,
      meta_title: PREFIX,
      meta_description: `${PREFIX} desc`,
      meta_keywords: PREFIX,
    });

    created.cats.push(row.id);
  }

  const sub = await Subcategory.create({
    category_id: created.cats[0],
    name: `${PREFIX} Sub`,
    slug: "zztest-sub",
    status: 1,
    meta_title: PREFIX,
    meta_description: `${PREFIX} d`,
  });

  created.subs.push(sub.id);

  for (let i = 1; i <= 12; i += 1) {
    const published = i <= 10;

    const post = await Post.create({
      title: `${PREFIX} ${published ? "Marketing" : "Draft"} Post ${String(i).padStart(2, "0")}`,
      slug: `zztest-post-${i}`,
      content: "<p>body</p>",
      excerpt: `${PREFIX} excerpt ${i}`,
      status: published ? "published" : "draft",
      published_at: published ? new Date(Date.UTC(2026, 0, i)) : null,
      reading_time: i <= 3 ? 3 : i <= 7 ? 7 : 15,
      // Post 6 is deliberately left with no category. posts.category_id is
      // nullable, and a published post without one must still appear in the
      // public listing and the sitemap - it used to be dropped silently.
      category_id: i === 6 ? null : created.cats[i % 3],

      // Only post 1 has a subcategory, so the "no subcategory" path is the
      // common case in these fixtures, as it is in real data.
      subcategory_id: i === 1 ? sub.id : null,

      // The public byline, alternating between the two authors.
      author_id: i % 2 === 0 ? staffAuthor.id : guestAuthor.id,

      // The CMS operator. A different concept, a different column.
      created_by: operator.id,
      updated_by: operator.id,

      meta_description: `${PREFIX} meta ${i}`,
      show_banner: 1,
      auto_publish: 0,
    });

    created.posts.push(post.id);
  }

  const lead = await Lead.create({
    first_name: PREFIX,
    last_name: "Enquirer",
    email: "zztest-lead@example.test",
    company: "ZZ Co",
    phone: "123",
    message: "Interested",
  });

  created.leads.push(lead.id);

  created.operatorId = operator.id;
  created.staffAuthorId = staffAuthor.id;
  created.guestAuthorId = guestAuthor.id;
  created.subcategoryId = sub.id;
  created.uncategorisedPostSlug = "zztest-post-6";
  created.subcategoryPostSlug = "zztest-post-1";

  require("../../services/category.service").invalidate();

  return created;
}

// ---------------------------------------------------------------------------
// A real CMS user, with real roles.
//
// D4 removed the implicit-admin fallback, so authorization is exactly what
// `user_roles` says. A suite therefore cannot fake a session any more: it
// creates a genuine account and genuine grants, and the request walks the same
// user_roles -> roles -> role_permissions -> permissions chain production
// walks. That is also what makes the FK columns (created_by, updated_by,
// uploaded_by) satisfiable.
//
//   createOperator({ roles: ["admin"] })
//   createOperator({ roles: ["content_writer"] })
//   createOperator({ roles: [] })            no permissions at all
//
// Roles are referenced by slug. The slugs are seeded by migration D1-010, so
// no test hardcodes a role id.
// ---------------------------------------------------------------------------
let operatorSequence = 0;

async function createOperator({
  roles = ["admin"],
  status = 1,
  suffix = `${Date.now()}_${(operatorSequence += 1)}`,
} = {}) {
  const user = await User.create({
    username: `zztest_op_${suffix}`,
    full_name: `${PREFIX} Operator`,
    email: `zztest-op-${suffix}@example.test`,
    password: OPERATOR_PASSWORD,
    status,
  });

  if (roles.length > 0) {
    await rbac.assignRolesToUser(user.id, roles);
  }

  return user;
}

// user_roles.user_id is ON DELETE CASCADE, so the grants go with the account.
async function destroyOperator(operator) {
  if (!operator) return;

  const list = Array.isArray(operator) ? operator : [operator];

  for (const one of list) {
    if (!one) continue;

    await User.destroy({ where: { id: one.id }, force: true });
  }
}

async function cleanup(created) {
  if (!created) return;

  const force = { force: true };

  // Child rows first. Posts are paranoid, so force is needed to actually
  // remove the fixture rather than soft-delete it.
  if (created.posts.length) {
    await Post.destroy({ where: { id: { [Op.in]: created.posts } }, ...force });
  }

  if (created.leads.length) {
    await Lead.destroy({ where: { id: { [Op.in]: created.leads } } });
  }

  if (created.subs.length) {
    await Subcategory.destroy({ where: { id: { [Op.in]: created.subs } }, ...force });
  }

  if (created.cats.length) {
    await Category.destroy({ where: { id: { [Op.in]: created.cats } }, ...force });
  }

  if (created.authors.length) {
    await Author.destroy({ where: { id: { [Op.in]: created.authors } }, ...force });
  }

  if (created.users.length) {
    await User.destroy({ where: { id: { [Op.in]: created.users } }, ...force });
  }

  require("../../services/category.service").invalidate();
}

/** Does this account still exist (ignoring soft delete)? */
async function userExists(id) {
  const row = await User.findByPk(id, { paranoid: false });

  return Boolean(row) && row.deleted_at === null;
}

/**
 * Fixtures created by the RBAC suite. Roles last, because user_roles.role_id
 * is RESTRICT: the users holding them have to go first.
 */
async function cleanupRbacFixtures({ posts = [], authors = [], roles = [] } = {}) {
  const { Op: Operators } = require("sequelize");
  const Role = require("../../models/role.model");

  if (posts.length) {
    await Post.destroy({ where: { id: { [Operators.in]: posts } }, force: true });
  }

  if (authors.length) {
    await Author.destroy({ where: { id: { [Operators.in]: authors } }, force: true });
  }

  if (roles.length) {
    const UserRole = require("../../models/user_role.model");

    await UserRole.destroy({ where: { role_id: { [Operators.in]: roles } } });
    await Role.destroy({ where: { id: { [Operators.in]: roles } } });
  }
}

// Rows left behind by an interrupted run.
async function countLeftovers() {
  const [rows] = await sequelize.query(
    "SELECT (SELECT COUNT(*) FROM posts WHERE slug LIKE 'zztest-%') posts," +
      " (SELECT COUNT(*) FROM authors WHERE slug LIKE 'zztest-%') authors," +
      " (SELECT COUNT(*) FROM categories WHERE slug LIKE 'zztest-%') cats," +
      " (SELECT COUNT(*) FROM subcategories WHERE slug LIKE 'zztest-%') subs," +
      " (SELECT COUNT(*) FROM users WHERE email LIKE 'zztest%') users," +
      " (SELECT COUNT(*) FROM leads WHERE email LIKE 'zztest%') leads"
  );

  return rows[0];
}

module.exports = {
  isAvailable,
  close,
  seed,
  cleanup,
  createOperator,
  destroyOperator,
  cleanupRbacFixtures,
  userExists,
  OPERATOR_PASSWORD,
  countLeftovers,
  PREFIX,
  sequelize,
};
