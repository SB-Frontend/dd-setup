// tests/database/schema.test.js
//
// D6: the database itself is a security control, so it gets tested like one.
//
// Everything here reads the LIVE schema out of information_schema and then
// proves the constraints actually fire. Application-level validation is not
// evidence: a CHECK constraint that was silently dropped, or a table that came
// back as MyISAM (which discards foreign keys without an error), would leave
// every application test still passing while referential integrity was gone.
//
// Sections: D6 §3 migrations, §4 schema integrity, §36 strict sql_mode,
// §37 concurrency and uniqueness.

require("../helpers/env");

const fs = require("fs");
const path = require("path");

const { createHarness } = require("../helpers/harness");
const db = require("../helpers/db");

const sequelize = require("../../models");
const { Op } = require("sequelize");
const { User, Author, Category, Post } = require("../../models/associations");

const ROOT = path.resolve(__dirname, "..", "..");

// The application tables D1 defines. sequelize_meta is the migration
// bookkeeping table and is checked separately - sequelize-cli creates it with
// its own hardcoded charset.
const APP_TABLES = [
  "authors", "categories", "lead_notes", "leads", "media", "permissions",
  "posts", "role_permissions", "roles", "subcategories", "subscriptions",
  "user_roles", "users",
];

// Every foreign key D1 defines, with the delete rule that makes it safe.
// SET NULL on an audit column is what stops deleting a CMS user from taking
// their content with them.
const EXPECTED_FKS = {
  fk_authors_created_by: ["authors", "created_by", "users", "SET NULL"],
  fk_authors_updated_by: ["authors", "updated_by", "users", "SET NULL"],
  fk_lead_notes_lead: ["lead_notes", "lead_id", "leads", "CASCADE"],
  fk_lead_notes_user: ["lead_notes", "user_id", "users", "SET NULL"],
  fk_media_uploaded_by: ["media", "uploaded_by", "users", "SET NULL"],
  fk_posts_author: ["posts", "author_id", "authors", "SET NULL"],
  fk_posts_category: ["posts", "category_id", "categories", "RESTRICT"],
  fk_posts_created_by: ["posts", "created_by", "users", "SET NULL"],
  fk_posts_subcategory: ["posts", "subcategory_id", "subcategories", "SET NULL"],
  fk_posts_updated_by: ["posts", "updated_by", "users", "SET NULL"],
  fk_role_permissions_permission: ["role_permissions", "permission_id", "permissions", "RESTRICT"],
  fk_role_permissions_role: ["role_permissions", "role_id", "roles", "CASCADE"],
  fk_subcategories_category: ["subcategories", "category_id", "categories", "RESTRICT"],
  fk_user_roles_role: ["user_roles", "role_id", "roles", "RESTRICT"],
  fk_user_roles_user: ["user_roles", "user_id", "users", "CASCADE"],
};

const MYSQL_STRICT =
  "ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE," +
  "ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION";

const P = "ZZSCHEMA";

const one = async (sql, replacements) => {
  const [rows] = await sequelize.query(sql, { replacements });

  return rows[0];
};

(async () => {
  const t = createHarness("database-schema");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const made = { users: [], authors: [], cats: [], posts: [] };

  try {
    // ================================================================
    t.section("§35 the suite is pointed at the intended server");
    // ================================================================

    const server = await one(
      "SELECT VERSION() v, @@version_comment c, @@port p, DATABASE() db, @@datadir d"
    );

    t.ok(/^8\./.test(server.v), "MySQL 8.x, not MariaDB", `${server.v} (${server.c})`);
    t.ok(!/MariaDB/i.test(server.c), "the server is not MariaDB", server.c);
    t.ok(Number(server.p) === 3306, "on port 3306", String(server.p));
    t.ok(
      ["127.0.0.1", "::1", "localhost"].includes(process.env.DB_HOST),
      "against a local host only, never a remote database",
      process.env.DB_HOST
    );
    t.ok(
      !/xampp/i.test(String(server.d)),
      "not the old XAMPP data directory",
      server.d
    );

    // ================================================================
    t.section("§3 migrations own the schema");
    // ================================================================

    const onDisk = fs
      .readdirSync(path.join(ROOT, "migrations"))
      .filter((f) => f.endsWith(".js"))
      .sort();

    const [appliedRows] = await sequelize.query(
      "SELECT name FROM sequelize_meta ORDER BY name"
    );

    const applied = appliedRows.map((r) => r.name);

    t.ok(applied.length === onDisk.length, "every migration file is applied", `${applied.length}/${onDisk.length}`);

    const pending = onDisk.filter((f) => !applied.includes(f));
    const orphaned = applied.filter((f) => !onDisk.includes(f));

    t.ok(pending.length === 0, "no pending migrations", pending.join(",") || "none");
    t.ok(orphaned.length === 0, "no applied migration without a file", orphaned.join(",") || "none");

    t.ok(
      JSON.stringify(applied) === JSON.stringify([...applied].sort()),
      "migration order is deterministic (timestamp-ordered filenames)"
    );

    // The schema must come from migrations, never from sync(). A stray
    // sync({alter:true}) would rewrite tables at boot and silently undo D1.
    const sources = [];

    const walk = (dir) => {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;

        const full = path.join(dir, entry.name);

        if (entry.isDirectory()) walk(full);
        else if (entry.name.endsWith(".js")) sources.push(full);
      }
    };

    for (const dir of ["controllers", "models", "routes", "services", "middleware", "config", "utils"]) {
      const full = path.join(ROOT, dir);

      if (fs.existsSync(full)) walk(full);
    }

    sources.push(path.join(ROOT, "server.js"));

    const syncCallers = sources.filter((f) => {
      const text = fs.readFileSync(f, "utf8");

      // Ignore the explanatory comments that record why sync() was removed.
      return text
        .split("\n")
        .some((l) => /\.sync\s*\(/.test(l) && !/^\s*(\/\/|\*)/.test(l));
    });

    t.ok(
      syncCallers.length === 0,
      "no application file calls sequelize.sync()",
      syncCallers.map((f) => path.relative(ROOT, f)).join(",") || "none"
    );

    // ================================================================
    t.section("§4 storage engine and charset");
    // ================================================================

    const [tables] = await sequelize.query(
      "SELECT TABLE_NAME n, ENGINE e, TABLE_COLLATION c, TABLE_TYPE ty " +
        "FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()"
    );

    const byName = new Map(tables.map((x) => [x.n, x]));

    for (const name of APP_TABLES) {
      t.ok(byName.has(name), `table ${name} exists`);
    }

    const appRows = APP_TABLES.map((n) => byName.get(n)).filter(Boolean);

    const notInnodb = appRows.filter((x) => x.e !== "InnoDB");

    // MyISAM accepts FOREIGN KEY syntax and silently ignores it, so this
    // check is what stands between the schema and invisible data corruption.
    t.ok(
      notInnodb.length === 0,
      "every application table is InnoDB",
      notInnodb.map((x) => `${x.n}=${x.e}`).join(",") || "all InnoDB"
    );

    const notUtf8mb4 = appRows.filter((x) => !String(x.c).startsWith("utf8mb4"));

    t.ok(
      notUtf8mb4.length === 0,
      "every application table is utf8mb4",
      notUtf8mb4.map((x) => `${x.n}=${x.c}`).join(",") || "all utf8mb4"
    );

    const views = tables.filter((x) => x.ty !== "BASE TABLE");

    t.ok(
      views.length === 0,
      "there are no views - the fake legacy views are gone and stay gone",
      views.map((x) => x.n).join(",") || "none"
    );

    // ================================================================
    t.section("§4 foreign keys, with the delete rule that makes them safe");
    // ================================================================

    const [fkRows] = await sequelize.query(
      `SELECT rc.CONSTRAINT_NAME cn, rc.TABLE_NAME tn, k.COLUMN_NAME col,
              rc.REFERENCED_TABLE_NAME rt, rc.DELETE_RULE dr
         FROM information_schema.REFERENTIAL_CONSTRAINTS rc
         JOIN information_schema.KEY_COLUMN_USAGE k
           ON k.CONSTRAINT_NAME = rc.CONSTRAINT_NAME
          AND k.CONSTRAINT_SCHEMA = rc.CONSTRAINT_SCHEMA
        WHERE rc.CONSTRAINT_SCHEMA = DATABASE()`
    );

    const fkByName = new Map(fkRows.map((r) => [r.cn, r]));

    t.ok(
      fkRows.length === Object.keys(EXPECTED_FKS).length,
      `all ${Object.keys(EXPECTED_FKS).length} foreign keys are present`,
      `found ${fkRows.length}`
    );

    for (const [name, [tn, col, rt, dr]] of Object.entries(EXPECTED_FKS)) {
      const actual = fkByName.get(name);

      t.ok(
        actual &&
          actual.tn === tn &&
          actual.col === col &&
          actual.rt === rt &&
          actual.dr === dr,
        `${name}: ${tn}.${col} -> ${rt} ON DELETE ${dr}`,
        actual ? `${actual.tn}.${actual.col} -> ${actual.rt} ${actual.dr}` : "MISSING"
      );
    }

    // Nothing may cascade into posts: deleting a person must never delete
    // published content.
    const cascadesIntoPosts = fkRows.filter(
      (r) => r.tn === "posts" && r.dr === "CASCADE"
    );

    t.ok(
      cascadesIntoPosts.length === 0,
      "no foreign key cascades a delete into posts",
      cascadesIntoPosts.map((r) => r.cn).join(",") || "none"
    );

    // ================================================================
    t.section("§4 CHECK constraints exist AND fire");
    // ================================================================

    const [checks] = await sequelize.query(
      "SELECT CONSTRAINT_NAME n FROM information_schema.TABLE_CONSTRAINTS " +
        "WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_TYPE = 'CHECK'"
    );

    const checkNames = checks.map((c) => c.n);

    for (const name of ["chk_posts_status", "chk_leads_status", "chk_subscriptions_status"]) {
      t.ok(checkNames.includes(name), `${name} is defined`, checkNames.join(","));
    }

    // ---- fixtures for the behavioural checks ----
    const operator = await User.create({
      username: `${P.toLowerCase()}_op`,
      full_name: `${P} Operator`,
      email: `${P.toLowerCase()}-op@example.test`,
      password: "ZzSchema-Password-1",
      status: 1,
    });

    made.users.push(operator.id);

    const author = await Author.create({
      name: `${P} Author`,
      display_name: `${P} A`,
      slug: `${P.toLowerCase()}-author`,
      status: 1,
    });

    made.authors.push(author.id);

    const category = await Category.create({
      name: `${P} Category`,
      slug: `${P.toLowerCase()}-category`,
      status: 1,
    });

    made.cats.push(category.id);

    const post = await Post.create({
      title: `${P} Post`,
      slug: `${P.toLowerCase()}-post`,
      content: "<p>body</p>",
      status: "draft",
      author_id: author.id,
      category_id: category.id,
      created_by: operator.id,
      updated_by: operator.id,
    });

    made.posts.push(post.id);

    let rejected = null;

    try {
      await sequelize.query(
        "INSERT INTO posts (title, slug, content, status) VALUES (?, ?, ?, ?)",
        { replacements: [`${P} Bad`, `${P.toLowerCase()}-bad-status`, "x", "archived"] }
      );
    } catch (error) {
      rejected = error;
    }

    t.ok(
      rejected !== null && /3819|CHECK/i.test(String(rejected.parent ? rejected.parent.errno : rejected.message)),
      "the database rejects a post status outside draft/published",
      rejected ? String(rejected.parent && rejected.parent.errno) : "NOT REJECTED"
    );

    rejected = null;

    try {
      await Post.create({
        title: `${P} Orphan`,
        slug: `${P.toLowerCase()}-orphan`,
        content: "x",
        status: "draft",
        author_id: 987654321,
      });
    } catch (error) {
      rejected = error;
    }

    t.ok(
      rejected !== null && /ER_NO_REFERENCED_ROW/.test(String(rejected.parent && rejected.parent.code)),
      "the database rejects a post pointing at a nonexistent author",
      rejected ? String(rejected.parent && rejected.parent.code) : "NOT REJECTED"
    );

    // ================================================================
    t.section("§4 delete behaviour is what D1 promised");
    // ================================================================

    await Author.destroy({ where: { id: author.id }, force: true });
    made.authors = made.authors.filter((id) => id !== author.id);

    const afterAuthor = await Post.findByPk(post.id);

    t.ok(Boolean(afterAuthor), "deleting an author leaves the post standing");
    t.ok(
      afterAuthor.author_id === null,
      "and sets posts.author_id to NULL",
      String(afterAuthor.author_id)
    );

    await User.destroy({ where: { id: operator.id }, force: true });
    made.users = made.users.filter((id) => id !== operator.id);

    const afterUser = await Post.findByPk(post.id);

    t.ok(Boolean(afterUser), "deleting the CMS creator leaves the post standing");
    t.ok(
      afterUser.created_by === null && afterUser.updated_by === null,
      "and sets created_by / updated_by to NULL",
      `${afterUser.created_by}/${afterUser.updated_by}`
    );

    // A category still holding posts must not be removable.
    rejected = null;

    try {
      await Category.destroy({ where: { id: category.id }, force: true });
    } catch (error) {
      rejected = error;
    }

    t.ok(
      rejected !== null,
      "a category with posts cannot be deleted (RESTRICT)",
      rejected ? String(rejected.parent && rejected.parent.code) : "NOT REJECTED"
    );

    // ================================================================
    t.section("§37 uniqueness is enforced by the database, not just the app");
    // ================================================================

    const dupUser = await User.create({
      username: `${P.toLowerCase()}_dup`,
      full_name: `${P} Dup`,
      email: `${P.toLowerCase()}-dup@example.test`,
      password: "ZzSchema-Password-1",
      status: 1,
    });

    made.users.push(dupUser.id);

    for (const [label, values] of [
      ["username", { username: `${P.toLowerCase()}_dup`, email: `${P.toLowerCase()}-other@example.test` }],
      ["email", { username: `${P.toLowerCase()}_other`, email: `${P.toLowerCase()}-dup@example.test` }],
    ]) {
      rejected = null;

      try {
        const extra = await User.create({
          full_name: `${P} Clash`,
          password: "ZzSchema-Password-1",
          status: 1,
          ...values,
        });

        made.users.push(extra.id);
      } catch (error) {
        rejected = error;
      }

      t.ok(
        rejected !== null && /Unique|ER_DUP_ENTRY/i.test(
          String((rejected.parent && rejected.parent.code) || rejected.name)
        ),
        `a duplicate ${label} is refused by a unique index`,
        rejected ? String((rejected.parent && rejected.parent.code) || rejected.name) : "NOT REJECTED"
      );
    }

    rejected = null;

    try {
      await Post.create({
        title: `${P} Slug Clash`,
        slug: `${P.toLowerCase()}-post`,
        content: "x",
        status: "draft",
      });
    } catch (error) {
      rejected = error;
    }

    t.ok(
      rejected !== null,
      "a duplicate post slug is refused by a unique index",
      rejected ? String((rejected.parent && rejected.parent.code) || rejected.name) : "NOT REJECTED"
    );

    // Concurrency: the application checks for an existing row before writing,
    // but two simultaneous requests can both pass that check. Only the index
    // makes it safe, so fire the writes together and require exactly one to
    // survive.
    const racers = await Promise.allSettled(
      [1, 2, 3, 4, 5].map(() =>
        User.create({
          username: `${P.toLowerCase()}_race`,
          full_name: `${P} Race`,
          email: `${P.toLowerCase()}-race@example.test`,
          password: "ZzSchema-Password-1",
          status: 1,
        })
      )
    );

    racers
      .filter((r) => r.status === "fulfilled")
      .forEach((r) => made.users.push(r.value.id));

    const winners = racers.filter((r) => r.status === "fulfilled").length;

    t.ok(
      winners === 1,
      "five concurrent inserts of the same username produce exactly one row",
      `${winners} succeeded, ${racers.length - winners} rejected`
    );

    const [[raceCount]] = await sequelize.query(
      "SELECT COUNT(*) n FROM users WHERE username = ?",
      { replacements: [`${P.toLowerCase()}_race`] }
    );

    t.ok(Number(raceCount.n) === 1, "and the table holds exactly one", String(raceCount.n));

    // The RBAC join tables carry composite unique keys for the same reason.
    const [uniques] = await sequelize.query(
      `SELECT TABLE_NAME t, INDEX_NAME i, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) cols
         FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND NON_UNIQUE = 0
          AND TABLE_NAME IN ('user_roles','role_permissions')
        GROUP BY TABLE_NAME, INDEX_NAME`
    );

    t.ok(
      uniques.some((u) => u.t === "user_roles" && u.cols === "user_id,role_id"),
      "user_roles has UNIQUE(user_id, role_id)",
      JSON.stringify(uniques.filter((u) => u.t === "user_roles").map((u) => u.cols))
    );

    t.ok(
      uniques.some((u) => u.t === "role_permissions" && u.cols === "role_id,permission_id"),
      "role_permissions has UNIQUE(role_id, permission_id)",
      JSON.stringify(uniques.filter((u) => u.t === "role_permissions").map((u) => u.cols))
    );

    // ================================================================
    t.section("§36 the application is strict-sql_mode safe");
    // ================================================================

    const globalMode = (await one("SELECT @@GLOBAL.sql_mode m")).m;

    t.ok(true, "server sql_mode recorded", globalMode || "(empty)");

    await sequelize.query(`SET SESSION sql_mode = '${MYSQL_STRICT}'`);

    const strictAuthor = await Author.create({
      name: `${P} Strict`,
      display_name: `${P} S`,
      slug: `${P.toLowerCase()}-strict`,
      status: 1,
    });

    made.authors.push(strictAuthor.id);

    t.ok(Boolean(strictAuthor.id), "an author inserts under MySQL's own strict mode");

    const strictPost = await Post.create({
      title: `${P} Strict Post`,
      slug: `${P.toLowerCase()}-strict-post`,
      content: "<p>x</p>",
      status: "published",
      published_at: new Date(),
      author_id: strictAuthor.id,
      category_id: category.id,
    });

    made.posts.push(strictPost.id);

    t.ok(Boolean(strictPost.id), "a post inserts under strict mode");

    const [strictJoin] = await sequelize.query(
      "SELECT p.id, p.title, a.display_name FROM posts p " +
        "LEFT JOIN authors a ON a.id = p.author_id WHERE p.id = ?",
      { replacements: [strictPost.id] }
    );

    t.ok(strictJoin.length === 1, "a join reads under strict mode");

    // ONLY_FULL_GROUP_BY is the mode that most often breaks legacy queries.
    const [grouped] = await sequelize.query(
      "SELECT category_id, COUNT(*) n FROM posts WHERE status = 'published' GROUP BY category_id"
    );

    t.ok(Array.isArray(grouped), "a GROUP BY survives ONLY_FULL_GROUP_BY", `${grouped.length} groups`);

    await sequelize.query("SET SESSION sql_mode = @@GLOBAL.sql_mode");
  } catch (error) {
    t.ok(false, "the suite ran without an unexpected error", error.message);
    console.error(error);
  } finally {
    try {
      await sequelize.query("SET SESSION sql_mode = @@GLOBAL.sql_mode");

      if (made.posts.length) {
        await Post.destroy({ where: { id: { [Op.in]: made.posts } }, force: true });
      }

      await Post.destroy({ where: { slug: { [Op.like]: `${P.toLowerCase()}%` } }, force: true });

      if (made.cats.length) {
        await Category.destroy({ where: { id: { [Op.in]: made.cats } }, force: true });
      }

      if (made.authors.length) {
        await Author.destroy({ where: { id: { [Op.in]: made.authors } }, force: true });
      }

      if (made.users.length) {
        await User.destroy({ where: { id: { [Op.in]: made.users } }, force: true });
      }

      await User.destroy({ where: { username: { [Op.like]: `${P.toLowerCase()}%` } }, force: true });

      const [[left]] = await sequelize.query(
        "SELECT (SELECT COUNT(*) FROM posts WHERE slug LIKE ?) p," +
          " (SELECT COUNT(*) FROM authors WHERE slug LIKE ?) a," +
          " (SELECT COUNT(*) FROM users WHERE username LIKE ?) u," +
          " (SELECT COUNT(*) FROM categories WHERE slug LIKE ?) c",
        { replacements: Array(4).fill(`${P.toLowerCase()}%`) }
      );

      console.log(`\n[cleanup] ${P} rows remaining: ${JSON.stringify(left)}`);
    } catch (error) {
      console.error("[schema] cleanup failed:", error.message);
    }

    await db.close();
  }

  t.finish();
})();
