# Tests

Local integration and unit tests for the DataDemand backend.

```bash
npm test                 # everything
npm run test:verbose     # everything, streaming each suite's output
npm run test:auth        # one group
npm run test:website
npm run test:uploads
npm run test:errors
```

A single suite can also be run directly:

```bash
node tests/website/website-api.test.js
AUTH_DEFAULT_ROLE=author node tests/auth/auth.test.js
```

## Layout

```
tests/
  run-all.js                 spawns every suite, aggregates results
  helpers/
    env.js                   MUST be required first by every suite
    harness.js               PASS/FAIL assertions, summary, exit code
    app.js                   builds the Express app (mirrors server.js)
    stubs.js                 model stubbing + test tokens
    db.js                    availability check, seed, cleanup
  auth/auth.test.js
  error-handling/error-translation.test.js    (no database needed)
  error-handling/error-responses.test.js
  bug-fixes/query-and-update.test.js
  uploads/uploads.test.js
  website/website-api.test.js
```

## Why there is no test framework

The suites began as plain Node scripts and the project has no framework. Rather
than introduce one and rewrite ~200 working assertions, `helpers/harness.js`
provides `ok()`, a summary, an exit code, and one machine-readable `##RESULT`
line that `run-all.js` parses. Assertions are plain booleans, so moving to a
framework later means changing only the harness.

## Why some suites run twice

Two settings are read once at module load and fix behaviour for the life of the
process, so `run-all.js` runs those files in separate child processes:

- `AUTH_DEFAULT_ROLE` — `config/permissions.js` reads it at load, so the role a
  request resolves to cannot change mid-process. Run as `admin` and `author`.
- `NODE_ENV` — decides what the error middleware discloses. Run as `production`
  (must reveal nothing) and `development` (must add a debug block).

## Database

Every suite except `error-translation` needs a reachable MySQL/MariaDB. If the
database is unreachable, those suites report **skipped** rather than failing.

Tests use the database named by `DB_NAME`, or by `TEST_DB_NAME` when set.
Everything created is prefixed `ZZTEST` (or tracked by primary key) and removed
in a `finally` block, so an assertion failure still cleans up. `website-api`
prints the leftover count at the end; it should always be zero.

`uploads` writes real files under `uploads/`, tracks their absolute paths, and
deletes them. The three pre-existing files in `uploads/posts` are never touched.

## Environment

Copy `.env.test.example` to `.env.test` to point the suite at a dedicated
database. Without it, tests fall back to `.env` and use the local development
database.

| Variable | Purpose |
|---|---|
| `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` | Local database connection |
| `TEST_DB_NAME` | Optional. Overrides `DB_NAME` for tests only |
| `TEST_JWT_SECRET_KEY` | Optional. Changes the test-only signing key |
| `UPLOAD_MAX_FILE_MB`, `UPLOAD_MAX_FIELD_MB` | Upload limits used by fixtures |

`helpers/env.js` **always** overrides `JWT_SECRET_KEY` with a test-only value,
so no real signing key is ever exercised. Do not put production credentials in
`.env.test`; it is listed in `.gitignore`.

## Known limitation

`helpers/app.js` duplicates the middleware chain from `server.js` rather than
importing it, because `server.js` does not export its app and refactoring it was
out of scope. **If the chain in `server.js` changes, change it here too.**
Extracting a shared app factory is the better fix and is recorded as follow-up
work.
