// tests/security/sanitization.test.js
//
// B4 stored HTML / XSS.
//
// Two layers. First the profiles are unit tested directly, then the payload a
// controller would actually persist is captured through a real request, so a
// route missing its sanitizer would be caught.

process.env.RATE_LIMIT_DISABLED = "true";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const { createStubber, tokens } = require("../helpers/stubs");
const db = require("../helpers/db");
const { sanitizeValue } = require("../../middleware/sanitize.middleware");

const Post = require("../../models/post.model");
const Lead = require("../../models/lead.model");
const LeadNote = require("../../models/lead_note.model");

// Payloads that must never survive in any profile.
const ATTACKS = [
  ["script tag", "<script>alert(1)</script>", /<script/i],
  ["img onerror", '<img src=x onerror="alert(1)">', /onerror/i],
  ["svg onload", '<svg onload="alert(1)"></svg>', /onload|<svg/i],
  ["body onload", '<body onload=alert(1)>', /onload/i],
  ["javascript: href", '<a href="javascript:alert(1)">x</a>', /javascript:/i],
  ["javascript: src", '<iframe src="javascript:alert(1)"></iframe>', /javascript:/i],
  ["onclick attribute", '<div onclick="alert(1)">x</div>', /onclick/i],
  ["onmouseover", '<p onmouseover="alert(1)">x</p>', /onmouseover/i],
  ["object tag", '<object data="evil.swf"></object>', /<object/i],
  ["embed tag", '<embed src="evil.swf">', /<embed/i],
  ["form + input", '<form action="/x"><input name="p"></form>', /<form|<input/i],
  ["meta refresh", '<meta http-equiv="refresh" content="0;url=//evil">', /<meta/i],
  ["base tag", '<base href="//evil.example/">', /<base/i],
  ["link stylesheet", '<link rel=stylesheet href="//evil">', /<link/i],
  ["style url payload", '<p style="background:url(javascript:alert(1))">x</p>', /javascript:|style=/i],
  ["data: svg image", '<img src="data:image/svg+xml;base64,PHN2Zz4=">', /data:/i],
  ["nested obfuscation", '<scr<script>ipt>alert(1)</script>', /<script/i],
];

(async () => {
  const t = createHarness("security-sanitization");

  t.section("every attack payload is neutralised in every profile");

  for (const profile of ["rich", "basic", "plain"]) {
    for (const [label, payload, forbidden] of ATTACKS) {
      const cleaned = sanitizeValue(payload, profile);

      t.ok(!forbidden.test(cleaned), `${profile}: ${label}`, JSON.stringify(cleaned).slice(0, 46));
    }
  }

  t.section("legitimate rich content survives (the site publishes HTML)");

  const article =
    "<h2>Heading</h2><p>Body with <strong>bold</strong>, <em>italic</em> and " +
    '<a href="https://example.com">a link</a>.</p>' +
    "<ul><li>one</li><li>two</li></ul>" +
    '<img src="/uploads/posts/x.jpg" alt="pic">' +
    "<blockquote>quote</blockquote><pre><code>code()</code></pre>" +
    "<table><tr><td>cell</td></tr></table>";

  const cleanedArticle = sanitizeValue(article, "rich");

  for (const tag of ["<h2>", "<strong>", "<em>", "<a href", "<ul>", "<img", "<blockquote>", "<code>", "<td>"]) {
    t.ok(cleanedArticle.includes(tag), `rich keeps ${tag}`);
  }

  t.section("embeds: allowlisted hosts only");

  const yt = sanitizeValue('<iframe src="https://www.youtube.com/embed/abc"></iframe>', "rich");

  t.ok(yt.includes("youtube.com/embed/abc"), "a YouTube embed is preserved", yt.slice(0, 50));

  const evilFrame = sanitizeValue('<iframe src="https://evil.example/x"></iframe>', "rich");

  t.ok(!evilFrame.includes("evil.example"), "an embed from an unlisted host loses its src", evilFrame);

  t.section("target=_blank gets rel=noopener");

  const blank = sanitizeValue('<a href="https://x.example" target="_blank">x</a>', "rich");

  t.ok(blank.includes("noopener"), "rel=noopener noreferrer is added", blank);

  t.section("profile boundaries differ as intended");

  t.ok(
    !sanitizeValue('<img src="/a.jpg">', "basic").includes("<img"),
    "basic strips images"
  );
  t.ok(
    sanitizeValue("<strong>x</strong>", "basic").includes("<strong>"),
    "basic keeps inline formatting"
  );
  t.ok(
    sanitizeValue("<strong>x</strong>", "plain") === "x",
    "plain removes all markup",
    JSON.stringify(sanitizeValue("<strong>x</strong>", "plain"))
  );

  // ---- end to end ----
  if (!(await db.isAvailable())) {
    t.skip("end-to-end route sanitisation", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const stubber = createStubber();

  const operator = await db.createOperator({ roles: ["admin"] });

  const captured = {};

  stubber.replace(Post, "findOne", async () => null);
  stubber.replace(Post, "create", async (values) => {
    captured.post = values;

    return { post_date: null };
  });

  // Lead notes are their own rows now, not an appended TEXT column.
  stubber.replace(Lead, "findByPk", async () => ({ id: 1 }));
  stubber.replace(LeadNote, "create", async (values) => {
    captured.leadNote = values;

    return { id: 1, created_at: new Date() };
  });
  stubber.replace(Lead, "create", async (values) => {
    captured.publicLead = values;

    return { id: 1 };
  });

  const srv = await startServer();
  const token = tokens.valid(operator.id);

  try {
    t.section("end to end: what actually reaches the database");

    await srv.request("POST", "/api/admin/posts", {
      token,
      json: {
        title: "<script>alert(1)</script>Real Title",
        slug: "safe-slug",
        content: '<p>ok</p><script>alert(1)</script><img src=x onerror=alert(1)>',
        excerpt: "<b>summary</b>",
        meta_description: "<b>meta</b>",
      },
    });

    t.ok(captured.post !== undefined, "the create payload was captured");

    if (captured.post) {
      t.ok(
        !/<script|onerror/i.test(String(captured.post.content)),
        "content persisted without script or handlers",
        String(captured.post.content).slice(0, 50)
      );
      t.ok(
        String(captured.post.content).includes("<p>ok</p>"),
        "content kept its legitimate markup"
      );
      t.ok(
        captured.post.title === "Real Title",
        "title is stored as plain text",
        JSON.stringify(captured.post.title)
      );
      t.ok(
        !/<b>/i.test(String(captured.post.meta_description)),
        "meta_description is plain text",
        JSON.stringify(captured.post.meta_description)
      );
      t.ok(
        !/<b>/i.test(String(captured.post.excerpt)),
        "excerpt is stored as plain text",
        JSON.stringify(captured.post.excerpt)
      );
    }

    await srv.request("PUT", "/api/admin/leads/1/comment", {
      token,
      json: { comment: '<script>alert(1)</script><b>followed up</b>' },
    });

    t.ok(
      captured.leadNote && !/<script/i.test(String(captured.leadNote.note)),
      "a lead note is sanitised",
      captured.leadNote ? JSON.stringify(captured.leadNote.note).slice(0, 50) : "(not captured)"
    );

    t.ok(
      captured.leadNote && String(captured.leadNote.note).includes("<b>"),
      "a lead note keeps its allowed inline formatting"
    );

    t.section("end to end: the anonymous public contact form");

    await srv.request("POST", "/api/website/leads", {
      json: {
        firstName: "<script>alert(1)</script>Jane",
        lastName: "Doe",
        email: "jane@example.test",
        company: "<img src=x onerror=alert(1)>Acme",
        phone: "123",
        message: "<script>alert(document.cookie)</script>Hello there",
      },
    });

    t.ok(captured.publicLead !== undefined, "the public lead payload was captured");

    if (captured.publicLead) {
      const joined = JSON.stringify(captured.publicLead);

      t.ok(!/<script|onerror|<img/i.test(joined), "no markup survives from the public form", joined.slice(0, 70));
      t.ok(captured.publicLead.first_name === "Jane", "the plain text is preserved");
      t.ok(
        captured.publicLead.message === "Hello there",
        "the message keeps its text",
        JSON.stringify(captured.publicLead.message)
      );
    }
  } finally {
    stubber.restore();
    await db.destroyOperator(operator);
    await srv.close();
    await db.close();
  }

  t.finish();
})();
