// tests/security/jwt.test.js
//
// B5 JWT configuration, plus the authentication matrix Stage B asked to be
// re-verified: valid, invalid, expired, deactivated user.

process.env.RATE_LIMIT_DISABLED = "true";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const { tokens } = require("../helpers/stubs");
const db = require("../helpers/db");

const jwtUtil = require("../../utils/jwt");

(async () => {
  const t = createHarness("security-jwt");

  t.section("configuration");

  t.ok(jwtUtil.ALGORITHM === "HS256", "the algorithm is pinned", jwtUtil.ALGORITHM);
  t.ok(Boolean(jwtUtil.ISSUER), "an issuer is configured", jwtUtil.ISSUER);
  t.ok(Boolean(jwtUtil.AUDIENCE), "an audience is configured", jwtUtil.AUDIENCE);
  t.ok(jwtUtil.MIN_SECRET_LENGTH >= 32, "a minimum secret length is enforced", String(jwtUtil.MIN_SECRET_LENGTH));

  t.section("the secret comes from the environment and is never echoed");

  const check = jwtUtil.assertSecretUsable({ strict: false });

  t.ok(check.ok === true, "the configured secret passes the length check", `length=${check.length}`);

  t.ok(
    !JSON.stringify(check).includes(process.env.JWT_SECRET_KEY),
    "the check result does not contain the secret itself"
  );

  const source = require("fs").readFileSync(require.resolve("../../utils/jwt"), "utf8");

  t.ok(
    !/JWT_SECRET_KEY\s*\|\|\s*["']/.test(source),
    "there is no hardcoded fallback secret in utils/jwt"
  );

  t.section("a missing or weak secret is rejected in production");

  const original = process.env.JWT_SECRET_KEY;

  process.env.JWT_SECRET_KEY = "";

  let threw = false;

  try {
    jwtUtil.assertSecretUsable({ strict: true });
  } catch {
    threw = true;
  }

  t.ok(threw, "an empty secret throws when strict");

  process.env.JWT_SECRET_KEY = "too-short";
  threw = false;

  try {
    jwtUtil.assertSecretUsable({ strict: true });
  } catch {
    threw = true;
  }

  t.ok(threw, "a short secret throws when strict");

  process.env.JWT_SECRET_KEY = original;

  t.ok(
    jwtUtil.assertSecretUsable({ strict: true }).ok === true,
    "the real secret passes strict mode"
  );

  t.section("round trip");

  const token = jwtUtil.signAccessToken({ id: 1, email: "a@b.test" });
  const decoded = jwtUtil.verifyAccessToken(token);

  t.ok(decoded.id === 1, "a signed token verifies");
  t.ok(decoded.iss === jwtUtil.ISSUER, "the issuer claim is present", decoded.iss);
  t.ok(decoded.aud === jwtUtil.AUDIENCE, "the audience claim is present", decoded.aud);
  t.ok(typeof decoded.exp === "number", "an expiry claim is present");

  // ---- over HTTP ----
  if (!(await db.isAvailable())) {
    t.skip("authentication matrix over HTTP", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  // A real CMS account with a real admin grant. D4 removed the implicit role,
  // so the account and its grants have to exist for a token to be worth
  // anything - which is what makes the deactivation case below a real test
  // rather than a stubbed one.
  const operator = await db.createOperator({ roles: ["admin"] });

  const srv = await startServer();

  try {
    t.section("authentication matrix");

    const cases = [
      ["valid token", tokens.valid(operator.id), 200],
      ["no token", undefined, 401],
      ["malformed token", tokens.malformed(), 401],
      ["wrong signature", tokens.wrongSignature(), 401],
      ["expired token", tokens.expired(), 401],
      ["token for a deleted user", tokens.unknownUser(), 401],
      ["wrong audience", tokens.wrongAudience(), 401],
      ["alg=none", tokens.noneAlgorithm(), 401],
    ];

    for (const [label, token, expected] of cases) {
      const r = await srv.get("/api/admin/posts", { token });

      t.ok(r.status === expected, `${label} -> ${expected}`, `-> ${r.status} ${r.message}`);
    }

    t.section("a deactivated user loses access immediately");

    const valid = tokens.valid(operator.id);

    const before = await srv.get("/api/admin/posts", { token: valid });

    t.ok(before.status === 200, "the token works while the account is active", `-> ${before.status}`);

    // Same token, but the account is genuinely disabled in the database - not
    // stubbed. authenticate() re-reads the row on every request, so the change
    // takes effect on the next call rather than when the token expires.
    await operator.update({ status: 0 });

    const after = await srv.get("/api/admin/posts", { token: valid });

    t.ok(
      after.status === 401,
      "the SAME token is rejected once the account is deactivated",
      `-> ${after.status} ${after.message}`
    );

    t.ok(
      /no longer active/i.test(after.message),
      "the reason is specific",
      after.message
    );

    t.section("public website is unaffected by any of this");

    const site = await srv.get("/api/website/posts?limit=1");

    t.ok(site.status === 200, "no token, still 200", `-> ${site.status}`);

    const siteBadToken = await srv.get("/api/website/posts?limit=1", {
      token: tokens.expired(),
    });

    t.ok(
      siteBadToken.status === 200,
      "an expired token does not break a public read",
      `-> ${siteBadToken.status}`
    );
  } finally {
    await db.destroyOperator(operator);
    await srv.close();
    await db.close();
  }

  t.finish();
})();
