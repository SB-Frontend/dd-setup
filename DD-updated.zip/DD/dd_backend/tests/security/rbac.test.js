// tests/security/rbac.test.js
//
// Phase D4: authentication, the RBAC chain, and privilege escalation.
//
// Everything here runs against real rows. Roles are granted through the API or
// through services/rbac.service.js, never faked, so each assertion exercises
//   users -> user_roles -> roles -> role_permissions -> permissions
// exactly as a production request would.
//
// Role and permission SLUGS are used throughout. No test refers to a role id
// or a permission id, because those differ between environments.

process.env.RATE_LIMIT_DISABLED = "true";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const { tokens } = require("../helpers/stubs");
const db = require("../helpers/db");

const rbac = require("../../services/rbac.service");
const Role = require("../../models/role.model");
const Author = require("../../models/author.model");
const Post = require("../../models/post.model");

const PREFIX = db.PREFIX;

(async () => {
  const t = createHarness("security-rbac");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const operators = [];
  const createdRoles = [];
  const createdAuthors = [];
  const createdPosts = [];

  let srv = null;

  const newOperator = async (options) => {
    const user = await db.createOperator(options);

    operators.push(user);

    return user;
  };

  try {
    srv = await startServer();

    // GET and DELETE never carry a body: fetch rejects that outright, and
    // attaching one would misrepresent what these requests look like.
    const call = (method, path, token, json) =>
      srv.request(method, path, {
        token,
        json: ["POST", "PUT", "PATCH"].includes(method) ? json : undefined,
      });

    // ================================================================
    t.section("authentication: login");
    // ================================================================

    const admin = await newOperator({ roles: ["admin"] });
    const adminToken = tokens.valid(admin.id);

    const login = await call("POST", "/api/admin/auth/login", undefined, {
      email: admin.email,
      password: db.OPERATOR_PASSWORD,
    });

    t.ok(login.status === 200, "valid credentials -> 200", `-> ${login.status}`);

    const body = login.json && login.json.user;

    t.ok(Boolean(body && body.token), "a JWT is issued");

    t.ok(
      Boolean(body) && !("password" in body) && !("password_hash" in body),
      "the login response carries no password field",
      body ? Object.keys(body).join(",") : "(no body)"
    );

    t.ok(
      Boolean(body) && Array.isArray(body.roles) && body.roles.includes("admin"),
      "the login response reports the roles held",
      body && JSON.stringify(body.roles)
    );

    t.ok(
      !/password|\$2[aby]\$/i.test(JSON.stringify(login.json || {})),
      "no bcrypt hash appears anywhere in the response"
    );

    // The issued token must be usable, and must identify the account without
    // carrying its authorization.
    const issued = await call("GET", "/api/admin/posts", body && body.token);

    t.ok(issued.status === 200, "the issued token opens a protected endpoint", `-> ${issued.status}`);

    const claims = JSON.parse(
      Buffer.from(String(body.token).split(".")[1], "base64url").toString("utf8")
    );

    t.ok(
      !("roles" in claims) && !("permissions" in claims) && !("role" in claims),
      "the token carries identity only, not an authorization snapshot",
      Object.keys(claims).join(",")
    );

    const badPassword = await call("POST", "/api/admin/auth/login", undefined, {
      email: admin.email,
      password: "definitely-not-the-password",
    });

    t.ok(badPassword.status === 401, "wrong password -> 401", `-> ${badPassword.status}`);

    const badEmail = await call("POST", "/api/admin/auth/login", undefined, {
      email: "nobody-here@example.test",
      password: db.OPERATOR_PASSWORD,
    });

    t.ok(badEmail.status === 401, "unknown email -> 401", `-> ${badEmail.status}`);

    t.ok(
      badPassword.message === badEmail.message,
      "the two failures are indistinguishable, so the response does not confirm an account exists",
      `${badPassword.message} / ${badEmail.message}`
    );

    const suspended = await newOperator({ roles: ["admin"], status: 0 });

    const suspendedLogin = await call("POST", "/api/admin/auth/login", undefined, {
      email: suspended.email,
      password: db.OPERATOR_PASSWORD,
    });

    t.ok(suspendedLogin.status === 401, "an inactive account cannot log in", `-> ${suspendedLogin.status}`);

    // ================================================================
    t.section("the backend never trusts authorization sent by the client");
    // ================================================================

    const writer = await newOperator({ roles: ["content_writer"] });

    const forged = tokens.withForgedClaims(writer.id, {
      roles: ["admin"],
      role: "admin",
      permissions: ["users.read", "posts.publish", "roles.update"],
      is_admin: true,
    });

    const forgedUsers = await call("GET", "/api/admin/users", forged);

    t.ok(
      forgedUsers.status === 403,
      "role and permission claims inside a validly signed token are ignored",
      `-> ${forgedUsers.status}`
    );

    const forgedBody = await call("POST", "/api/admin/auth/register", tokens.valid(writer.id), {
      username: `zztest_forged_${Date.now()}`,
      email: `zztest-forged-${Date.now()}@example.test`,
      password: db.OPERATOR_PASSWORD,
      permissions: ["users.create"],
      role: "admin",
      is_admin: true,
    });

    t.ok(
      forgedBody.status === 403,
      "permissions supplied in the request body are ignored",
      `-> ${forgedBody.status}`
    );

    // ================================================================
    t.section("RBAC: a change in the database takes effect on the next request");
    // ================================================================

    // A role built through the API, so role creation itself is exercised.
    const created = await call("POST", "/api/admin/roles", adminToken, {
      role_name: `${PREFIX} Temp Editor`,
      description: "created by the RBAC suite",
      permissions: ["post_management", "media_management"],
    });

    t.ok(created.status === 201, "a role can be created", `-> ${created.status} ${created.message}`);

    const tempRole = created.json && created.json.data;

    if (tempRole) createdRoles.push(tempRole.id);

    t.ok(
      Boolean(tempRole) && tempRole.modules.sort().join(",") === "media_management,post_management",
      "a new role holds exactly the permissions requested, not everything",
      tempRole && tempRole.modules.join(",")
    );

    t.ok(
      Boolean(tempRole) && tempRole.is_system === false,
      "a role created through the API is not a system role"
    );

    const holder = await newOperator({ roles: [] });
    const holderToken = tokens.valid(holder.id);

    const before = await call("GET", "/api/admin/posts", holderToken);

    t.ok(before.status === 403, "no roles -> no access", `-> ${before.status}`);

    const assign = await call("POST", `/api/admin/users/${holder.id}/roles`, adminToken, {
      roles: [tempRole.role_slug],
    });

    t.ok(assign.status === 200, "an admin can assign a role", `-> ${assign.status} ${assign.message}`);

    const after = await call("GET", "/api/admin/posts", holderToken);

    t.ok(
      after.status === 200,
      "the SAME token now works, without re-issuing it",
      `-> ${after.status}`
    );

    // Duplicate grant: UNIQUE(user_id, role_id) must not be violated.
    const again = await call("POST", `/api/admin/users/${holder.id}/roles`, adminToken, {
      roles: [tempRole.role_slug],
    });

    t.ok(
      again.status === 200 &&
        again.json.data.unchanged.includes(tempRole.role_slug),
      "a duplicate role assignment is absorbed, not duplicated",
      `-> ${again.status}`
    );

    const roleCheck = await call("GET", `/api/admin/users/${holder.id}/roles`, adminToken);

    t.ok(
      roleCheck.status === 200 &&
        roleCheck.json.data.roles.filter((r) => r === tempRole.role_slug).length === 1,
      "the user holds the role exactly once",
      roleCheck.json && JSON.stringify(roleCheck.json.data.roles)
    );

    // Removing the permission from the role must revoke access immediately.
    const stripped = await call(
      "PUT",
      `/api/admin/roles/${tempRole.id}/permissions`,
      adminToken,
      { permissions: ["media_management"] }
    );

    t.ok(stripped.status === 200, "a role's permissions can be replaced", `-> ${stripped.status}`);

    const afterStrip = await call("GET", "/api/admin/posts", holderToken);

    t.ok(
      afterStrip.status === 403,
      "removing a permission from the role revokes access on the next request",
      `-> ${afterStrip.status}`
    );

    // Removing the role entirely.
    const revoke = await call(
      "DELETE",
      `/api/admin/users/${holder.id}/roles/${tempRole.id}`,
      adminToken
    );

    t.ok(revoke.status === 200, "a role can be revoked", `-> ${revoke.status} ${revoke.message}`);

    const afterRevoke = await call("GET", "/api/admin/media", holderToken);

    t.ok(afterRevoke.status === 403, "revoking the role revokes the access", `-> ${afterRevoke.status}`);

    // Deactivation, with a live grant in place.
    await call("POST", `/api/admin/users/${holder.id}/roles`, adminToken, {
      roles: [tempRole.role_slug],
    });

    const deactivate = await call(
      "PATCH",
      `/api/admin/users/${holder.id}/status`,
      adminToken,
      { status: 0 }
    );

    t.ok(deactivate.status === 200, "an account can be suspended", `-> ${deactivate.status}`);

    const afterDeactivate = await call("GET", "/api/admin/media", holderToken);

    t.ok(
      afterDeactivate.status === 401,
      "a suspended account is refused at authentication, not authorization",
      `-> ${afterDeactivate.status}`
    );

    await call("PATCH", `/api/admin/users/${holder.id}/status`, adminToken, { status: 1 });

    const reinstated = await call("GET", `/api/admin/users/${holder.id}/roles`, adminToken);

    t.ok(
      reinstated.status === 200 && reinstated.json.data.roles.includes(tempRole.role_slug),
      "suspending and reinstating an account does not rewrite its roles",
      reinstated.json && JSON.stringify(reinstated.json.data.roles)
    );

    t.section("multiple roles union their permissions");

    const multi = await newOperator({ roles: ["content_writer", "publisher"] });
    const multiToken = tokens.valid(multi.id);

    const multiEdit = await call("GET", "/api/admin/posts", multiToken);
    const multiPublish = await call("PATCH", "/api/admin/posts/1/status", multiToken, {
      status: "draft",
    });

    t.ok(multiEdit.status !== 403, "a second role does not remove the first one's access");
    t.ok(
      multiPublish.status !== 403,
      "publishing is allowed through the second role",
      `-> ${multiPublish.status}`
    );

    const multiRoles = await call("GET", `/api/admin/users/${multi.id}/roles`, adminToken);

    t.ok(
      multiRoles.json.data.roles.length === 2,
      "both roles are reported",
      JSON.stringify(multiRoles.json.data.roles)
    );

    // ================================================================
    t.section("SELF-ESCALATION");
    // ================================================================

    // A role that manages accounts but not authorization - the exact split
    // section 15 asks about.
    const accountManagerRole = await Role.create({
      role_name: `${PREFIX} Account Manager`,
      role_slug: `zztest_account_manager_${Date.now()}`,
      description: "user_management only",
      is_system: 0,
    });

    createdRoles.push(accountManagerRole.id);

    await rbac.replaceRolePermissions(accountManagerRole.id, ["user_management"]);

    const accountManager = await newOperator({ roles: [accountManagerRole.role_slug] });
    const managerToken = tokens.valid(accountManager.id);

    const selfAdmin = await call(
      "POST",
      `/api/admin/users/${accountManager.id}/roles`,
      managerToken,
      { roles: ["admin"] }
    );

    t.ok(
      selfAdmin.status === 403,
      "user_management holder cannot grant themselves the admin role",
      `-> ${selfAdmin.status} ${selfAdmin.message}`
    );

    const selfPublish = await call(
      "POST",
      `/api/admin/users/${accountManager.id}/roles`,
      managerToken,
      { roles: ["publisher"] }
    );

    t.ok(
      selfPublish.status === 403,
      "user_management holder cannot grant themselves post publishing",
      `-> ${selfPublish.status}`
    );

    const otherRole = await call(
      "POST",
      `/api/admin/users/${writer.id}/roles`,
      managerToken,
      { roles: ["admin"] }
    );

    t.ok(
      otherRole.status === 403,
      "user_management holder cannot grant a role to anyone else either",
      `-> ${otherRole.status}`
    );

    // Even a role_management holder cannot point the role routes at itself.
    const selfByAdmin = await call(
      "POST",
      `/api/admin/users/${admin.id}/roles`,
      adminToken,
      { roles: ["publisher"] }
    );

    t.ok(
      selfByAdmin.status === 403,
      "even an admin cannot change their own roles",
      `-> ${selfByAdmin.status} ${selfByAdmin.message}`
    );

    const selfRevokeByAdmin = await call(
      "DELETE",
      `/api/admin/users/${admin.id}/roles/admin`,
      adminToken
    );

    t.ok(
      selfRevokeByAdmin.status === 403,
      "and cannot revoke their own roles",
      `-> ${selfRevokeByAdmin.status}`
    );

    // The profile route must refuse authorization fields outright rather than
    // silently dropping them - a silent drop reads like success to the caller.
    const selfProfileRole = await call(
      "PUT",
      `/api/admin/users/${accountManager.id}`,
      managerToken,
      { full_name: "Renamed", roles: ["admin"] }
    );

    t.ok(
      selfProfileRole.status === 403,
      "roles cannot be smuggled through the profile update route",
      `-> ${selfProfileRole.status} ${selfProfileRole.message}`
    );

    const selfProfileStatus = await call(
      "PUT",
      `/api/admin/users/${accountManager.id}`,
      managerToken,
      { status: 1 }
    );

    t.ok(
      selfProfileStatus.status === 403,
      "status cannot be smuggled through the profile update route",
      `-> ${selfProfileStatus.status}`
    );

    const managerRoles = await call(
      "GET",
      `/api/admin/users/${accountManager.id}/roles`,
      adminToken
    );

    t.ok(
      managerRoles.json.data.roles.length === 1 &&
        managerRoles.json.data.roles[0] === accountManagerRole.role_slug,
      "after every attempt the account still holds only its original role",
      JSON.stringify(managerRoles.json.data.roles)
    );

    const createAdminAccount = await call("POST", "/api/admin/auth/register", managerToken, {
      username: `zztest_escalate_${Date.now()}`,
      email: `zztest-escalate-${Date.now()}@example.test`,
      password: db.OPERATOR_PASSWORD,
      roles: ["admin"],
    });

    t.ok(
      createAdminAccount.status === 403,
      "user_management holder cannot create a new account carrying the admin role",
      `-> ${createAdminAccount.status}`
    );

    // ================================================================
    t.section("permission catalogue is read only");
    // ================================================================

    const catalogue = await call("GET", "/api/admin/roles/permissions", adminToken);

    t.ok(
      catalogue.status === 200 && catalogue.json.data.length === 10,
      "the seeded permission catalogue is listable",
      catalogue.json && `n=${catalogue.json.data.length}`
    );

    for (const method of ["POST", "PUT", "DELETE"]) {
      const r = await call(method, "/api/admin/roles/permissions", adminToken, {
        permission_name: "Invented",
        permission_slug: "invented_permission",
      });

      t.ok(
        r.status === 404 || r.status === 405,
        `${method} /roles/permissions is not a route`,
        `-> ${r.status}`
      );
    }

    const unknownGrant = await call(
      "PUT",
      `/api/admin/roles/${tempRole.id}/permissions`,
      adminToken,
      { permissions: ["media_management", "invented_permission"] }
    );

    t.ok(
      unknownGrant.status === 400,
      "granting a permission that does not exist is rejected",
      `-> ${unknownGrant.status} ${unknownGrant.message}`
    );

    const stillThere = await call("GET", `/api/admin/roles/${tempRole.id}`, adminToken);

    t.ok(
      stillThere.json.data.modules.includes("media_management") &&
        !stillThere.json.data.modules.includes("invented_permission"),
      "the rejected grant set was not partially applied",
      stillThere.json.data.modules.join(",")
    );

    t.section("role deletion");

    const systemRole = await call("DELETE", "/api/admin/roles/admin", adminToken);

    t.ok(
      systemRole.status === 403,
      "a seeded system role cannot be deleted",
      `-> ${systemRole.status} ${systemRole.message}`
    );

    const heldRole = await call("DELETE", `/api/admin/roles/${tempRole.id}`, adminToken);

    t.ok(
      heldRole.status === 409,
      "a role still assigned to a user cannot be deleted",
      `-> ${heldRole.status} ${heldRole.message}`
    );

    const holderStillThere = await db.userExists(holder.id);

    t.ok(holderStillThere, "the refused role deletion did not touch the user holding it");

    const slugChange = await call("PUT", `/api/admin/roles/${tempRole.id}`, adminToken, {
      role_slug: "something_else",
    });

    t.ok(
      slugChange.status === 400,
      "role_slug cannot be rewritten, so grants cannot be silently detached",
      `-> ${slugChange.status}`
    );

    // ================================================================
    t.section("lockout protection");
    // ================================================================

    const capable = await rbac.recoveryCapableUserIds();

    if (capable.length === 1 && Number(capable[0]) === Number(admin.id)) {
      const deleter = await newOperator({ roles: [accountManagerRole.role_slug] });

      const lastAdmin = await call(
        "DELETE",
        `/api/admin/users/${admin.id}`,
        tokens.valid(deleter.id)
      );

      t.ok(
        lastAdmin.status === 409,
        "deleting the last account able to manage users and roles is refused",
        `-> ${lastAdmin.status} ${lastAdmin.message}`
      );

      const suspendLast = await call(
        "PATCH",
        `/api/admin/users/${admin.id}/status`,
        tokens.valid(deleter.id),
        { status: 0 }
      );

      t.ok(
        suspendLast.status === 409,
        "suspending that account is refused for the same reason",
        `-> ${suspendLast.status}`
      );

      const survives = await call("GET", "/api/admin/roles", adminToken);

      t.ok(survives.status === 200, "the last administrator still works afterwards");
    } else {
      t.skip("last-administrator protection", `${capable.length} recovery-capable accounts present`);
      t.skip("suspending the last administrator", "same");
      t.skip("the last administrator survives", "same");
    }

    // ================================================================
    t.section("bootstrap is closed once an account exists");
    // ================================================================

    const anonymousRegister = await call("POST", "/api/admin/auth/register", undefined, {
      username: `zztest_anon_${Date.now()}`,
      email: `zztest-anon-${Date.now()}@example.test`,
      password: db.OPERATOR_PASSWORD,
    });

    t.ok(
      anonymousRegister.status === 401,
      "unauthenticated registration is refused while accounts exist",
      `-> ${anonymousRegister.status}`
    );

    const anonymousAdmin = await call("POST", "/api/admin/auth/register", undefined, {
      username: `zztest_anon2_${Date.now()}`,
      email: `zztest-anon2-${Date.now()}@example.test`,
      password: db.OPERATOR_PASSWORD,
      roles: ["admin"],
      isBootstrap: true,
    });

    t.ok(
      anonymousAdmin.status === 401,
      "a request cannot claim to be the bootstrap request",
      `-> ${anonymousAdmin.status}`
    );

    // ================================================================
    t.section("author management is not user management");
    // ================================================================

    const authorManagerRole = await Role.create({
      role_name: `${PREFIX} Author Manager`,
      role_slug: `zztest_author_manager_${Date.now()}`,
      description: "author_management only",
      is_system: 0,
    });

    createdRoles.push(authorManagerRole.id);

    await rbac.replaceRolePermissions(authorManagerRole.id, ["author_management"]);

    const authorManager = await newOperator({ roles: [authorManagerRole.role_slug] });
    const authorToken = tokens.valid(authorManager.id);

    const slug = `zztest-rbac-author-${Date.now()}`;

    const authorCreate = await call("POST", "/api/admin/authors", authorToken, {
      name: `${PREFIX} RBAC Author`,
      display_name: `${PREFIX} RBAC`,
      slug,
      bio: "created under author_management",
    });

    t.ok(
      authorCreate.status === 201,
      "author_management can create an author",
      `-> ${authorCreate.status} ${authorCreate.message}`
    );

    const authorId = authorCreate.json && authorCreate.json.data && authorCreate.json.data.id;

    if (authorId) createdAuthors.push(authorId);

    t.ok(
      authorId && !("user_id" in authorCreate.json.data),
      "the created author has no user_id: it is not linked to a CMS account",
      authorCreate.json && Object.keys(authorCreate.json.data).join(",")
    );

    const createdAuthorRow = await Author.findByPk(authorId);

    t.ok(
      createdAuthorRow && Number(createdAuthorRow.created_by) === Number(authorManager.id),
      "the CMS operator is recorded as created_by",
      createdAuthorRow && String(createdAuthorRow.created_by)
    );

    for (const [method, path] of [
      ["GET", "/api/admin/users"],
      ["POST", "/api/admin/auth/register"],
      ["DELETE", `/api/admin/users/${writer.id}`],
      ["POST", `/api/admin/users/${writer.id}/roles`],
    ]) {
      const r = await call(method, path, authorToken, {});

      t.ok(
        r.status === 403,
        `author_management does not confer ${method} ${path}`,
        `-> ${r.status}`
      );
    }

    const writerAuthorCreate = await call("POST", "/api/admin/authors", tokens.valid(writer.id), {
      name: "Should not exist",
      slug: `zztest-denied-${Date.now()}`,
    });

    t.ok(
      writerAuthorCreate.status === 403,
      "a role without author_management cannot create an author",
      `-> ${writerAuthorCreate.status}`
    );

    // ================================================================
    t.section("posts: editing, publishing and the byline");
    // ================================================================

    const postCreate = await call("POST", "/api/admin/posts", tokens.valid(writer.id), {
      title: `${PREFIX} RBAC Post`,
      slug: `zztest-rbac-post-${Date.now()}`,
      content: "<p>body</p>",
      author_id: authorId,
    });

    t.ok(
      postCreate.status === 201,
      "post_management can create a post",
      `-> ${postCreate.status} ${postCreate.message}`
    );

    const postId = postCreate.json && postCreate.json.data && postCreate.json.data.id;

    if (postId) createdPosts.push(postId);

    const postRow = postId ? await Post.findByPk(postId) : null;

    t.ok(
      postRow && Number(postRow.created_by) === Number(writer.id),
      "created_by is the CMS operator",
      postRow && String(postRow.created_by)
    );

    t.ok(
      postRow && Number(postRow.author_id) === Number(authorId),
      "author_id is the chosen public author, not the operator",
      postRow && `author_id=${postRow.author_id} operator=${writer.id}`
    );

    t.ok(
      postRow && Number(postRow.author_id) !== Number(writer.id),
      "the byline is never the CMS user id"
    );

    t.ok(postRow && postRow.status === "draft", "a new post starts as a draft", postRow && postRow.status);

    const writerPublish = await call(
      "PATCH",
      `/api/admin/posts/${postId}/status`,
      tokens.valid(writer.id),
      { status: "published" }
    );

    t.ok(
      writerPublish.status === 403,
      "post_management alone cannot publish",
      `-> ${writerPublish.status}`
    );

    const stillDraft = await Post.findByPk(postId);

    t.ok(stillDraft.status === "draft", "the refused publish did not change the post");

    const publisher = await newOperator({ roles: ["publisher"] });

    const publisherPublish = await call(
      "PATCH",
      `/api/admin/posts/${postId}/status`,
      tokens.valid(publisher.id),
      { status: "published" }
    );

    t.ok(
      publisherPublish.status === 200,
      "post_publishing can publish",
      `-> ${publisherPublish.status} ${publisherPublish.message}`
    );

    const published = await Post.findByPk(postId);

    t.ok(published.status === "published", "the post is published");
    t.ok(Boolean(published.published_at), "published_at was stamped");
    t.ok(
      Number(published.updated_by) === Number(publisher.id),
      "updated_by records who published it",
      String(published.updated_by)
    );
    t.ok(
      Number(published.created_by) === Number(writer.id),
      "created_by still records who wrote it"
    );

    // ================================================================
    t.section("deleting a CMS user does not delete their content");
    // ================================================================

    const disposable = await newOperator({ roles: ["content_writer"] });

    const ownedPost = await call("POST", "/api/admin/posts", tokens.valid(disposable.id), {
      title: `${PREFIX} Orphan Post`,
      slug: `zztest-orphan-${Date.now()}`,
      content: "<p>body</p>",
      author_id: authorId,
    });

    const ownedId = ownedPost.json && ownedPost.json.data && ownedPost.json.data.id;

    if (ownedId) createdPosts.push(ownedId);

    const removeUser = await call("DELETE", `/api/admin/users/${disposable.id}`, adminToken);

    t.ok(removeUser.status === 200, "the account can be deleted", `-> ${removeUser.status} ${removeUser.message}`);

    const orphan = await Post.findByPk(ownedId);

    t.ok(Boolean(orphan), "the post they created still exists");
    t.ok(
      orphan && orphan.status === "draft",
      "and is untouched",
      orphan && orphan.status
    );

    // ================================================================
    t.section("deleting an author does not delete the post or any user");
    // ================================================================

    const authorDelete = await call(
      "DELETE",
      `/api/admin/authors/${authorId}`,
      authorToken
    );

    t.ok(
      authorDelete.status === 200,
      "author_management can delete an author",
      `-> ${authorDelete.status} ${authorDelete.message}`
    );

    const survivingPost = await Post.findByPk(postId);

    t.ok(Boolean(survivingPost), "the published post survives the author deletion");

    const managerStillExists = await db.userExists(authorManager.id);

    t.ok(managerStillExists, "the CMS account that managed the author is untouched");

    // ================================================================
    t.section("public website is unaffected by all of this");
    // ================================================================

    const publicList = await call("GET", "/api/website/posts?limit=5");

    t.ok(publicList.status === 200, "no CMS token required", `-> ${publicList.status}`);

    const serialised = JSON.stringify(publicList.json || {});

    for (const leak of ["password", "permissions", "user_roles", "role_slug", "created_by"]) {
      t.ok(!serialised.includes(leak), `the public payload does not contain ${leak}`);
    }

    const publicAuthors = await call("GET", "/api/website/authors");

    t.ok(
      publicAuthors.status === 200 &&
        !JSON.stringify(publicAuthors.json).includes("username"),
      "the public author list exposes no CMS account data",
      `-> ${publicAuthors.status}`
    );
  } finally {
    try {
      await db.cleanupRbacFixtures({
        posts: createdPosts,
        authors: createdAuthors,
        roles: createdRoles,
      });

      await db.destroyOperator(operators);
    } catch (error) {
      console.error("[rbac] cleanup failed:", error.message);
    }

    if (srv) await srv.close();
    await db.close();
  }

  t.finish();
})();
