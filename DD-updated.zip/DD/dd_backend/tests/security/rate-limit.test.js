// tests/security/rate-limit.test.js
//
// B2 rate limiting.
//
// The limiters are built at module load from these variables, so they are set
// before anything is required. Using small limits here exercises the real
// middleware rather than a stand-in.
//
// Public write requests are sent with an INVALID body on purpose: they are
// rejected at validation, so nothing is inserted, while the limiter still
// counts the attempt.

process.env.RATE_LIMIT_AUTH_MAX = "3";
process.env.RATE_LIMIT_PUBLIC_WRITE_MAX = "3";
process.env.RATE_LIMIT_WEBSITE_MAX = "8";
process.env.RATE_LIMIT_ADMIN_MAX = "5";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const db = require("../helpers/db");

// Fires `count` requests and reports how many were rejected with 429.
async function burst(srv, method, path, count, options = {}) {
  const statuses = [];

  for (let i = 0; i < count; i += 1) {
    const r = await srv.request(method, path, options);

    statuses.push(r.status);
  }

  return {
    statuses,
    limited: statuses.filter((s) => s === 429).length,
    firstLimitedAt: statuses.indexOf(429),
  };
}

(async () => {
  const t = createHarness("security-rate-limit");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const srv = await startServer();

  try {
    t.section("login is tightly limited (brute-force surface)");

    const login = await burst(srv, "POST", "/api/admin/auth/login", 5, {
      json: { user_email: "nobody@example.test", user_password: "wrong" },
    });

    t.ok(login.limited > 0, "repeated logins are eventually rejected", `statuses=${login.statuses}`);
    t.ok(
      login.firstLimitedAt === 3,
      "the 4th attempt is the first rejected (limit 3)",
      `first429@index=${login.firstLimitedAt}`
    );

    const limitedBody = await srv.request("POST", "/api/admin/auth/login", {
      json: { user_email: "nobody@example.test", user_password: "wrong" },
    });

    t.ok(limitedBody.status === 429, "still limited", `-> ${limitedBody.status}`);
    t.ok(
      limitedBody.json &&
        limitedBody.json.success === false &&
        limitedBody.json.error === "Too Many Requests",
      "a 429 uses the standard error envelope",
      JSON.stringify(limitedBody.json)
    );
    t.ok(
      limitedBody.headers.get("retry-after") !== null,
      "Retry-After is sent",
      limitedBody.headers.get("retry-after") || "(absent)"
    );

    t.section("public writes are limited separately from login");

    const leads = await burst(srv, "POST", "/api/website/leads", 5, { json: {} });

    t.ok(leads.limited > 0, "the contact form is limited", `statuses=${leads.statuses}`);
    t.ok(
      leads.statuses[0] === 400,
      "the first attempts still reach validation (nothing inserted)",
      `first=${leads.statuses[0]}`
    );

    const subs = await burst(srv, "POST", "/api/website/subscribe", 5, { json: {} });

    t.ok(subs.limited > 0, "the newsletter form is limited", `statuses=${subs.statuses}`);

    t.ok(
      leads.limited > 0 && login.limited > 0,
      "public writes and login consume separate budgets"
    );

    t.section("website reads have their own, much larger budget");

    // The write limiters above are already exhausted; reads must be unaffected.
    const firstRead = await srv.get("/api/website/categories");

    t.ok(firstRead.status === 200, "reads still work after writes were limited", `-> ${firstRead.status}`);

    const reads = await burst(srv, "GET", "/api/website/posts?limit=1", 12);

    t.ok(reads.limited > 0, "reads are limited eventually", `statuses=${reads.statuses}`);
    t.ok(
      reads.firstLimitedAt > 3,
      "the read budget is larger than the write budget",
      `first429@index=${reads.firstLimitedAt}`
    );

    t.section("rate limit headers");

    const policy = firstRead.headers.get("ratelimit-policy") || "";

    t.ok(policy.includes("website-read"), "the limiter identifies itself in the policy header", policy);

    t.ok(
      firstRead.headers.get("ratelimit") !== null,
      "the RateLimit header is present",
      firstRead.headers.get("ratelimit") || "(absent)"
    );

    t.section("admin traffic is limited independently");

    const admin = await burst(srv, "GET", "/api/admin/posts", 8);

    t.ok(admin.limited > 0, "admin endpoints are limited", `statuses=${admin.statuses}`);
    t.ok(
      admin.statuses[0] === 401,
      "unauthenticated admin requests are still rejected as 401 before the limit is hit",
      `first=${admin.statuses[0]}`
    );

    t.section("preflight is never rate limited");

    const pre = await burst(srv, "OPTIONS", "/api/website/posts", 5, {
      headers: { Origin: "http://localhost:3000", "Access-Control-Request-Method": "GET" },
    });

    t.ok(pre.limited === 0, "OPTIONS requests are skipped by every limiter", `statuses=${pre.statuses}`);
  } finally {
    await srv.close();
    await db.close();
  }

  t.finish();
})();
