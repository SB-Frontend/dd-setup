// tests/security/headers-and-cors.test.js
//
// B1 security headers and B3 CORS.

process.env.CORS_ORIGINS =
  process.env.CORS_ORIGINS || "http://localhost:3000,https://site.example";

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const db = require("../helpers/db");

const ALLOWED = "http://localhost:3000";
const DISALLOWED = "https://evil.example";

(async () => {
  const t = createHarness("security-headers-cors");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  const srv = await startServer();

  try {
    t.section("B1: security headers");

    const r = await srv.get("/api/website/categories");

    t.ok(r.status === 200, "public read still works with helmet enabled", `-> ${r.status}`);

    t.ok(
      r.headers.get("x-powered-by") === null,
      "X-Powered-By is removed",
      r.headers.get("x-powered-by") || "(absent)"
    );

    const expected = [
      ["content-security-policy", /default-src 'none'/],
      ["x-content-type-options", /nosniff/],
      ["x-frame-options", /SAMEORIGIN|DENY/],
      ["referrer-policy", /no-referrer/],
      ["x-dns-prefetch-control", /off/],
      ["cross-origin-resource-policy", /same-origin/],
    ];

    for (const [header, pattern] of expected) {
      const value = r.headers.get(header);

      t.ok(value !== null && pattern.test(value), `${header} is set`, value || "(absent)");
    }

    t.ok(
      r.headers.get("strict-transport-security") === null,
      "HSTS is off outside production (it would pin http://localhost)",
      r.headers.get("strict-transport-security") || "(absent)"
    );

    t.section("B1: headers are present on error responses too");

    const err = await srv.get("/api/does/not/exist");

    t.ok(err.status === 404, "unknown route -> 404");
    t.ok(
      err.headers.get("x-content-type-options") === "nosniff",
      "error responses also carry security headers"
    );

    t.section("B1: uploads override CORP so the website can load images");

    const img = await srv.get("/uploads/posts/missing.jpg");

    t.ok(img.status === 404, "missing upload -> 404 (route reachable)");

    t.section("B3: CORS allowed origin");

    const allowed = await srv.get("/api/website/posts?limit=1", {
      headers: { Origin: ALLOWED },
    });

    t.ok(
      allowed.headers.get("access-control-allow-origin") === ALLOWED,
      "an allowed origin is echoed back",
      allowed.headers.get("access-control-allow-origin") || "(absent)"
    );

    t.ok(
      allowed.headers.get("access-control-allow-credentials") === "true",
      "credentials are permitted for an allowlisted origin"
    );

    t.ok(
      allowed.headers.get("access-control-allow-origin") !== "*",
      "the wildcard is never used alongside credentials"
    );

    t.section("B3: CORS disallowed origin");

    const denied = await srv.get("/api/website/posts?limit=1", {
      headers: { Origin: DISALLOWED },
    });

    t.ok(
      denied.headers.get("access-control-allow-origin") === null,
      "a disallowed origin gets no CORS headers, so the browser blocks it",
      denied.headers.get("access-control-allow-origin") || "(absent)"
    );

    t.ok(
      denied.status === 200,
      "the request itself is not turned into a server error",
      `-> ${denied.status}`
    );

    t.section("B3: no Origin header (server-to-server, SSR, curl)");

    const noOrigin = await srv.get("/api/website/posts?limit=1");

    t.ok(noOrigin.status === 200, "a request without Origin is unaffected", `-> ${noOrigin.status}`);

    t.section("B3: preflight for every method, including PATCH");

    for (const method of ["GET", "POST", "PUT", "PATCH", "DELETE"]) {
      const pre = await srv.request("OPTIONS", "/api/admin/posts/1/status", {
        headers: {
          Origin: ALLOWED,
          "Access-Control-Request-Method": method,
          "Access-Control-Request-Headers": "authorization,content-type",
        },
      });

      const allow = pre.headers.get("access-control-allow-methods") || "";

      t.ok(
        (pre.status === 204 || pre.status === 200) && allow.includes(method),
        `${method} preflight is allowed`,
        `-> ${pre.status} allow=${allow}`
      );
    }

    const patchPre = await srv.request("OPTIONS", "/api/admin/posts/1/status", {
      headers: {
        Origin: ALLOWED,
        "Access-Control-Request-Method": "PATCH",
      },
    });

    t.ok(
      (patchPre.headers.get("access-control-allow-headers") || "")
        .toLowerCase()
        .includes("authorization"),
      "preflight permits the Authorization header",
      patchPre.headers.get("access-control-allow-headers") || "(absent)"
    );

    t.section("B3: preflight from a disallowed origin");

    const badPre = await srv.request("OPTIONS", "/api/admin/posts/1/status", {
      headers: { Origin: DISALLOWED, "Access-Control-Request-Method": "PATCH" },
    });

    t.ok(
      badPre.headers.get("access-control-allow-origin") === null,
      "a disallowed origin gets no preflight approval"
    );
  } finally {
    await srv.close();
    await db.close();
  }

  t.finish();
})();
