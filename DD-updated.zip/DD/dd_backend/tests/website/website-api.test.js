// tests/website/website-api.test.js
//
// Public website API contract against the clean D1/D2 schema.
//
// The headline assertions here are the user/author separation ones: the public
// author must come from `authors`, and no CMS account data may appear on this
// surface at all.
//
// This is the only suite that needs real rows; totals, page boundaries and
// filter/count agreement cannot be stubbed meaningfully.

require("../helpers/env");

const { createHarness } = require("../helpers/harness");
const { startServer } = require("../helpers/app");
const db = require("../helpers/db");

const sequelize = require("../../models");

// The public sort allowlist. A rejected value must fall back to one of
// these, never reach ORDER BY.
const SAFE_SORTS = ["published_at", "created_at", "updated_at", "reading_time", "title"];
const { Author, Post } = require("../../models/associations");

(async () => {
  const t = createHarness("website-api");

  if (!(await db.isAvailable())) {
    t.skip("entire suite", "database unreachable");
    await db.close();
    t.finish();
    return;
  }

  let seeded = null;
  let srv = null;

  try {
    seeded = await db.seed();
    srv = await startServer();

    const get = (p) => srv.get(p);

    t.section("envelope and published-only filtering");

    let r = await get("/api/website/posts?limit=50");

    t.ok(
      r.status === 200 && r.json.success === true && Array.isArray(r.json.data) && r.json.meta,
      "consistent envelope {success,data,meta}"
    );

    t.ok(r.json.meta.total === 10, "drafts excluded: 10 of 12 seeded", `total=${r.json.meta.total}`);

    t.section("only required fields are returned");

    const keys = Object.keys(r.json.data[0]).sort();

    t.ok(!keys.includes("content"), "the article body is not in the listing", keys.join(","));
    t.ok(
      !keys.includes("created_by") && !keys.includes("updated_by"),
      "CMS audit columns are not exposed publicly"
    );
    t.ok(keys.includes("category_name") && keys.includes("category_slug"), "category attached");

    t.section("PUBLIC AUTHOR COMES FROM authors, NOT users");

    const detail = await get("/api/website/posts/zztest-post-2");

    t.ok(detail.status === 200, "GET /posts/:slug", `-> ${detail.status}`);

    const author = detail.json.data.post.author;

    t.ok(author && author.display_name, "the post carries an author object", author && author.display_name);

    t.ok(
      Number(author.id) === Number(seeded.staffAuthorId),
      "author.id is the AUTHOR id, not a user id",
      `author.id=${author.id} staffAuthorId=${seeded.staffAuthorId} operatorId=${seeded.operatorId}`
    );

    t.ok(
      Number(author.id) !== Number(seeded.operatorId),
      "author.id is not the CMS operator id"
    );

    const authorKeys = Object.keys(author).sort();

    t.ok(
      JSON.stringify(authorKeys) ===
        JSON.stringify(["bio", "display_name", "id", "image", "name", "slug"]),
      "only safe public author fields are exposed",
      authorKeys.join(",")
    );

    for (const forbidden of [
      "password",
      "username",
      "email",
      "roles",
      "permissions",
      "created_by",
      "updated_by",
      "user_id",
      "is_author",
    ]) {
      t.ok(!(forbidden in author), `author does not expose ${forbidden}`);
    }

    t.section("an author with NO CMS account still works");

    const guestPost = await get("/api/website/posts/zztest-post-1");

    t.ok(
      guestPost.status === 200 &&
        Number(guestPost.json.data.post.author.id) === Number(seeded.guestAuthorId),
      "a guest author with no login is a valid byline",
      `author.id=${guestPost.json.data.post.author && guestPost.json.data.post.author.id}`
    );

    t.section("pagination and count correctness");

    const seen = new Set();

    for (let page = 1; page <= 3; page += 1) {
      const rr = await get(`/api/website/posts?page=${page}&limit=4`);

      rr.json.data.forEach((x) => seen.add(x.id));

      if (page === 1) {
        t.ok(
          rr.json.data.length === 4 &&
            rr.json.meta.total_pages === 3 &&
            rr.json.meta.has_more === true,
          "page 1 limit 4 -> 4 rows, 3 pages, has_more",
          JSON.stringify(rr.json.meta)
        );
      }

      if (page === 3) {
        t.ok(
          rr.json.data.length === 2 && rr.json.meta.has_more === false,
          "page 3 -> 2 rows, has_more false"
        );
      }
    }

    t.ok(seen.size === 10, "paging covers all 10 with no duplicates or skips", `${seen.size}/10`);

    t.section("maximum page size and invalid pagination");

    r = await get("/api/website/posts?limit=9999");
    t.ok(r.json.meta.limit === 50, "limit is capped at 50", `limit=${r.json.meta.limit}`);

    r = await get("/api/website/posts?page=abc&limit=xyz");
    t.ok(r.json.meta.page === 1 && r.json.meta.limit === 10, "garbage pagination falls back");

    r = await get("/api/website/posts?page=-4");
    t.ok(r.json.meta.page === 1, "a negative page is clamped");

    t.section("filtering");

    r = await get("/api/website/posts?search=Marketing&limit=50");
    t.ok(r.json.meta.total === 10, "search=Marketing", `total=${r.json.meta.total}`);

    r = await get("/api/website/posts?search=Draft&limit=50");
    t.ok(r.json.meta.total === 0, "search cannot reach drafts", `total=${r.json.meta.total}`);

    r = await get(`/api/website/posts?category_id=${seeded.cats[0]},${seeded.cats[1]}&limit=50`);
    t.ok(
      r.json.data.every((p) => [seeded.cats[0], seeded.cats[1]].includes(p.category_id)) &&
        r.json.meta.total === r.json.data.length,
      "category_id CSV filter and its count agree",
      `total=${r.json.meta.total}`
    );

    r = await get(`/api/website/posts?subcategory_id=${seeded.subcategoryId}&limit=50`);
    t.ok(
      r.json.meta.total === 1,
      "subcategory_id filter works (posts now link to subcategories)",
      `total=${r.json.meta.total}`
    );

    for (const [band, check] of [
      ["under-5", (v) => v < 5],
      ["5-10", (v) => v >= 5 && v <= 10],
      ["10-plus", (v) => v > 10],
    ]) {
      r = await get(`/api/website/posts?reading_time=${band}&limit=50`);

      t.ok(
        r.json.data.length > 0 && r.json.data.every((p) => check(p.reading_time)),
        `reading_time=${band}`,
        `n=${r.json.data.length}`
      );
    }

    t.section("exclude_id");

    const all = (await get("/api/website/posts?limit=50")).json.data;
    const [first, second] = [all[0].id, all[1].id];

    r = await get(`/api/website/posts?exclude_id=${first}&limit=50`);
    t.ok(
      r.json.meta.total === 9 && !r.json.data.some((p) => p.id === first),
      "exclude_id removes the post and the count",
      `total=${r.json.meta.total}`
    );

    r = await get(`/api/website/posts?exclude_id=${first},${second}&limit=50`);
    t.ok(r.json.meta.total === 8, "exclude_id accepts a CSV list");

    t.section("safe sorting");

    r = await get("/api/website/posts?sort=reading_time&order=ASC&limit=50");
    const times = r.json.data.map((p) => p.reading_time);
    t.ok(
      JSON.stringify(times) === JSON.stringify([...times].sort((a, b) => a - b)),
      "sort=reading_time order=ASC is honoured",
      times.join(",")
    );

    r = await get("/api/website/posts?sort=password&order=DROP&limit=5");
    t.ok(
      r.status === 200 && r.json.meta.sort === "published_at" && r.json.meta.order === "DESC",
      "an unsafe sort or order falls back",
      `${r.json.meta.sort}/${r.json.meta.order}`
    );

    t.section("drafts are never reachable");

    r = await get("/api/website/posts/zztest-post-12");
    t.ok(r.status === 404, "a draft is not reachable by slug", `-> ${r.status}`);

    r = await get("/api/website/posts/meta/zztest-post-12");
    t.ok(r.status === 404, "a draft has no public meta", `-> ${r.status}`);

    t.section("meta endpoint");

    r = await get("/api/website/posts/meta/zztest-post-2");
    t.ok(
      r.status === 200 && r.json.data.author_display_name === `${db.PREFIX} Staff`,
      "meta carries the author display name from authors",
      r.json.data && r.json.data.author_display_name
    );

    t.section("taxonomy and authors");

    r = await get("/api/website/categories");
    t.ok(
      r.status === 200 && r.json.data.some((c) => c.slug === "zztest-marketing"),
      "categories list"
    );

    r = await get("/api/website/categories/meta/zztest-marketing");
    t.ok(
      r.status === 200 && r.json.data.meta_description === `${db.PREFIX} desc`,
      "category meta uses meta_description"
    );

    r = await get(`/api/website/subcategories/by-category/${seeded.cats[0]}`);
    t.ok(
      r.status === 200 && r.json.data.length === 1 && r.json.data[0].category_slug === "zztest-marketing",
      "subcategories by-category resolves the parent through the association"
    );

    r = await get("/api/website/subcategories/by-category/abc");
    t.ok(r.status === 400, "a non-numeric category_id -> 400");

    r = await get("/api/website/authors");
    const listed = r.json.data.find((x) => x.slug === "zztest-guest");
    t.ok(r.status === 200 && listed, "authors list comes from the authors table");
    t.ok(
      listed && !("username" in listed) && !("email" in listed) && !("created_by" in listed),
      "the authors list exposes no CMS account data",
      Object.keys(listed || {}).join(",")
    );

    r = await get("/api/website/authors/zztest-staff");
    t.ok(r.status === 200 && r.json.data.slug === "zztest-staff", "public author page by slug");

    r = await get("/api/website/sitemap/posts");
    t.ok(
      r.status === 200 && r.json.data.length === 10 && r.json.data[0].category_slug,
      "the post sitemap carries category_slug"
    );

    t.section("deleting an author must not remove the article");

    const targetAuthor = await Author.findByPk(seeded.staffAuthorId);

    await targetAuthor.destroy();

    const survivor = await get("/api/website/posts/zztest-post-2");

    t.ok(survivor.status === 200, "the post is still published after the author is deleted");
    t.ok(
      survivor.json.data.post.author === null,
      "the byline is simply absent",
      JSON.stringify(survivor.json.data.post.author)
    );

    await Author.findByPk(seeded.staffAuthorId, { paranoid: false }).then((a) => a.restore());

    // ================================================================
    // D5 additions
    // ================================================================

    t.section("D5: subcategory relationship");

    const withSub = await get(`/api/website/posts/${seeded.subcategoryPostSlug}`);
    const subPost = withSub.json.data.post;

    t.ok(
      withSub.status === 200 && Number(subPost.subcategory_id) === Number(seeded.subcategoryId),
      "a post carries its subcategory_id",
      `subcategory_id=${subPost.subcategory_id}`
    );

    t.ok(
      subPost.subcategory &&
        Number(subPost.subcategory.id) === Number(seeded.subcategoryId) &&
        subPost.subcategory.slug === "zztest-sub" &&
        Boolean(subPost.subcategory.name),
      "the nested subcategory object carries id, name and slug",
      JSON.stringify(subPost.subcategory)
    );

    t.ok(
      subPost.subcategory_slug === "zztest-sub" && Boolean(subPost.subcategory_name),
      "the flat subcategory_name / subcategory_slug pair is present too",
      `${subPost.subcategory_name}/${subPost.subcategory_slug}`
    );

    t.ok(
      subPost.category &&
        subPost.category.slug === subPost.category_slug &&
        subPost.category.name === subPost.category_name,
      "the nested category object agrees with the flat pair",
      JSON.stringify(subPost.category)
    );

    const noSub = await get("/api/website/posts/zztest-post-2");

    t.ok(
      noSub.json.data.post.subcategory === null &&
        noSub.json.data.post.subcategory_slug === null,
      "a post with no subcategory reports null rather than a manufactured one",
      JSON.stringify(noSub.json.data.post.subcategory)
    );

    r = await get("/api/website/posts?limit=50");

    t.ok(
      r.json.data.every((p) => "subcategory" in p && "category" in p),
      "every listing row carries both taxonomy objects"
    );

    t.ok(
      r.json.data.filter((p) => p.subcategory !== null).length === 1,
      "exactly the one seeded post has a subcategory",
      String(r.json.data.filter((p) => p.subcategory !== null).length)
    );

    t.section("D5: a published post with no category is still public");

    const uncategorised = r.json.data.find(
      (p) => p.slug === seeded.uncategorisedPostSlug
    );

    t.ok(Boolean(uncategorised), "it appears in the listing");

    t.ok(
      uncategorised && uncategorised.category === null && uncategorised.category_slug === null,
      "with a null category rather than being hidden",
      uncategorised && JSON.stringify(uncategorised.category)
    );

    t.section("D5: timestamps the website needs");

    t.ok(
      r.json.data.every((p) => Boolean(p.updated_at)),
      "every listing row carries updated_at"
    );

    t.ok(
      Boolean(subPost.updated_at) && Boolean(subPost.created_at),
      "the detail response carries created_at and updated_at",
      `${subPost.created_at} / ${subPost.updated_at}`
    );

    const metaTimestamps = await get("/api/website/posts/meta/zztest-post-2");

    t.ok(
      Boolean(metaTimestamps.json.data.updated_at),
      "the meta response carries updated_at for <lastmod>",
      metaTimestamps.json.data.updated_at
    );

    t.ok(
      metaTimestamps.json.data.subcategory !== undefined,
      "the meta response carries the subcategory field"
    );

    t.section("D5: sitemap contract");

    const sitemap = await get("/api/website/sitemap/posts");

    t.ok(
      sitemap.status === 200 && sitemap.json.data.length === 10,
      "the sitemap lists all 10 published posts, drafts excluded",
      `n=${sitemap.json.data.length}`
    );

    t.ok(
      sitemap.json.data.some((x) => x.post_slug === seeded.uncategorisedPostSlug),
      "including the one with no category, which used to be dropped silently"
    );

    const sitemapRow = sitemap.json.data.find((x) => x.post_slug === "zztest-post-1");

    t.ok(
      sitemapRow &&
        Boolean(sitemapRow.id) &&
        sitemapRow.slug === "zztest-post-1" &&
        Boolean(sitemapRow.category_slug) &&
        sitemapRow.subcategory_slug === "zztest-sub" &&
        sitemapRow.status === "published" &&
        Boolean(sitemapRow.updated_at) &&
        Boolean(sitemapRow.last_modified),
      "a sitemap row carries id, slug, category, subcategory, status and both date fields",
      JSON.stringify(sitemapRow)
    );

    t.ok(
      !sitemap.json.data.some((x) => /zztest-post-1[12]/.test(x.post_slug)),
      "no draft reaches the sitemap"
    );

    t.ok(
      !JSON.stringify(sitemap.json).includes("created_by") &&
        !JSON.stringify(sitemap.json).includes("content"),
      "the sitemap carries no CMS or body data"
    );

    t.section("D5: extended sort allowlist");

    for (const field of SAFE_SORTS) {
      r = await get(`/api/website/posts?sort=${field}&order=ASC&limit=50`);

      t.ok(
        r.status === 200 && r.json.meta.sort === field && r.json.meta.order === "ASC",
        `sort=${field} is honoured`,
        `${r.json.meta.sort}/${r.json.meta.order}`
      );
    }

    for (const bad of [
      "sort=content",
      "sort=created_by",
      "sort=id;DROP TABLE posts",
      "sort=(SELECT 1)",
      "sort[]=title",
      "order=;DROP TABLE posts",
    ]) {
      r = await get(`/api/website/posts?${bad}&limit=5`);

      t.ok(
        r.status === 200 &&
          SAFE_SORTS.includes(r.json.meta.sort) &&
          ["ASC", "DESC"].includes(r.json.meta.order),
        `unsafe ${bad} falls back safely`,
        `${r.json.meta.sort}/${r.json.meta.order}`
      );
    }

    t.section("D5: unpublished content is never reachable");

    for (const path of [
      "/api/website/posts/zztest-post-11",
      "/api/website/posts/zztest-post-12",
      "/api/website/posts/meta/zztest-post-11",
      "/api/posts/get_post/zztest-post-12",
      "/api/posts/meta/zztest-post-12",
    ]) {
      const draft = await get(path);

      t.ok(draft.status === 404, `${path} -> 404`, `-> ${draft.status}`);

      t.ok(
        !/Draft|excerpt/.test(draft.text || ""),
        `${path} leaks nothing about the draft`,
        (draft.text || "").slice(0, 60)
      );
    }

    r = await get("/api/website/posts?search=zztest-post-12&limit=50");

    t.ok(r.json.meta.total === 0, "a draft cannot be reached through search");

    r = await get("/api/website/posts?exclude_id=0&limit=50");

    t.ok(r.json.meta.total === 10, "no filter combination widens the published set");

    t.section("D5: public response safety");

    const surfaces = [
      "/api/website/posts?limit=50",
      `/api/website/posts/${seeded.subcategoryPostSlug}`,
      "/api/website/posts/meta/zztest-post-2",
      "/api/website/sitemap/posts",
      "/api/website/authors",
      "/api/website/authors/zztest-staff",
      "/api/website/categories",
      "/api/website/subcategories",
    ];

    const FORBIDDEN = [
      "password",
      "password_hash",
      "username",
      "roles",
      "permissions",
      "created_by",
      "updated_by",
      "deleted_at",
      "user_id",
      "is_author",
      "last_login_at",
    ];

    for (const path of surfaces) {
      const res = await get(path);
      const text = JSON.stringify(res.json || {});

      const leaked = FORBIDDEN.filter((f) => text.includes(f));

      t.ok(
        res.status === 200 && leaked.length === 0,
        `${path} exposes no CMS field`,
        leaked.length ? `LEAKED: ${leaked.join(",")}` : "clean"
      );
    }

    t.section("D5: the whole public surface works with no token at all");

    for (const path of surfaces) {
      const res = await get(path);

      t.ok(res.status === 200, `anonymous GET ${path}`, `-> ${res.status}`);
    }

    const adminBoundary = await get("/api/admin/posts");

    t.ok(
      adminBoundary.status === 401,
      "the admin boundary is untouched: no token -> 401",
      `-> ${adminBoundary.status}`
    );

    t.section("caching headers");

    r = await get("/api/website/posts?limit=1");
    t.ok(/max-age=60/.test(r.headers.get("cache-control") || ""), "post list cache header");

    r = await get("/api/admin/posts");
    t.ok(
      !/max-age/.test(r.headers.get("cache-control") || ""),
      "admin responses carry no caching headers"
    );

    t.section("query efficiency");

    let queries = 0;
    const original = sequelize.query.bind(sequelize);

    sequelize.query = (...args) => {
      queries += 1;

      return original(...args);
    };

    await get("/api/website/posts?limit=5");
    const cold = queries;

    queries = 0;
    await get("/api/website/posts?limit=5");
    const warm = queries;

    sequelize.query = original;

    t.ok(
      warm <= 2,
      "the listing uses at most 2 queries once the category cache is warm",
      `cold=${cold} warm=${warm}`
    );

    void Post;
  } finally {
    try {
      await db.cleanup(seeded);

      const left = await db.countLeftovers();

      console.log(`\n[cleanup] ZZTEST rows remaining: ${JSON.stringify(left)}`);
    } catch (error) {
      console.error("[website] cleanup failed:", error.message);
    }

    if (srv) await srv.close();
    await db.close();
  }

  t.finish();
})();
