// scripts/seed-dev.js
//
// LOCAL DEVELOPMENT SEED DATA.  npm run db:seed
//
// Populates an empty local database with enough realistic content to exercise
// the CMS and the public website: 3 CMS users, 6 categories, 12 subcategories,
// 5 public authors and 20 posts.
//
// ---------------------------------------------------------------------------
// THIS IS DEVELOPMENT DATA. IT MUST NEVER RUN ANYWHERE ELSE.
//
// The script refuses to run when NODE_ENV is "production", and refuses to run
// against a non-local database host. Both checks are belt and braces - the
// real safeguard is that you only ever invoke it by hand.
// ---------------------------------------------------------------------------
//
// PASSWORDS
//   The three accounts need a password to be usable, and a seed cannot ask for
//   one interactively. It is read from SEED_PASSWORD, falling back to a
//   deliberately obvious local-only value that is printed on completion so
//   nobody has to guess it. It is bcrypt-hashed by the model hook exactly like
//   any other account - the plaintext exists only in this file's default and in
//   your shell. Change it, or set SEED_PASSWORD, before the machine is shared.
//
// IDEMPOTENT
//   Every record is matched on its natural key - username, email, category
//   slug, subcategory slug within its category, author slug, post slug - and
//   skipped if it already exists. Running twice creates nothing the second
//   time. Nothing is ever truncated or deleted.
//
// TRANSACTIONAL
//   The whole seed is one transaction in dependency order (users, categories,
//   subcategories, authors, posts). A failure anywhere rolls the lot back
//   rather than leaving half a dataset behind.
//
// SEPARATION
//   CMS users and public authors are different things and this seed keeps them
//   that way. posts.author_id points at `authors`; posts.created_by and
//   posts.updated_by point at `users`. No author is given a login, and no user
//   is used as a byline.

require("dotenv").config();

const sequelize = require("../models");
const {
  User,
  Author,
  Category,
  Subcategory,
  Post,
} = require("../models/associations");
const rbac = require("../services/rbac.service");

// Only what the schema actually permits. There is no "archived" status: the
// CHECK constraint on posts and Post.STATUSES both list exactly draft and
// published, and a seed is not a reason to widen a constraint.
const { STATUSES } = Post;

const PASSWORD =
  process.env.SEED_PASSWORD || "DevSeed-Local-Only-2026";

// ---------------------------------------------------------------------------
// DATA
// ---------------------------------------------------------------------------

// Roles are referenced by the slugs seeded in migration D1-010. No new role or
// permission is created here.
const USERS = [
  {
    username: "admin",
    full_name: "System Admin",
    email: "admin@datademand.local",
    roles: ["admin"],
    note: "full access to every module",
  },
  {
    username: "editor.one",
    full_name: "Content Editor One",
    email: "editor.one@datademand.local",
    roles: ["content_management"],
    note: "owns the editorial pipeline - can publish",
  },
  {
    username: "editor.two",
    full_name: "Content Editor Two",
    email: "editor.two@datademand.local",
    roles: ["content_writer"],
    note: "drafts posts - deliberately cannot publish",
  },
];

const CATEGORIES = [
  ["Digital Marketing", "digital-marketing", "Campaigns, channels and strategy across digital marketing."],
  ["Artificial Intelligence", "artificial-intelligence", "Applied AI for marketing and commercial teams."],
  ["Advertising Technology", "advertising-technology", "The platforms and pipes behind modern advertising."],
  ["Social Media", "social-media", "Social platforms, community and social commerce."],
  ["Data & Analytics", "data-analytics", "Measurement, attribution and customer data."],
  ["Martech", "martech", "The marketing technology stack and how teams run it."],
];

const SUBCATEGORIES = [
  ["digital-marketing", "SEO", "seo"],
  ["digital-marketing", "Content Marketing", "content-marketing"],
  ["artificial-intelligence", "Generative AI", "generative-ai"],
  ["artificial-intelligence", "AI Automation", "ai-automation"],
  ["advertising-technology", "Programmatic Advertising", "programmatic-advertising"],
  ["advertising-technology", "Ad Platforms", "ad-platforms"],
  ["social-media", "Social Media Marketing", "social-media-marketing"],
  ["social-media", "Social Commerce", "social-commerce"],
  ["data-analytics", "Marketing Analytics", "marketing-analytics"],
  ["data-analytics", "Customer Data", "customer-data"],
  ["martech", "Marketing Automation", "marketing-automation"],
  ["martech", "CRM", "crm"],
];

// Fictional public authors. None of them has - or needs - a CMS account.
const AUTHORS = [
  ["Alex Morgan", "Alex Morgan", "alex-morgan", "Writes about the intersection of media buying and machine learning."],
  ["Sarah Mitchell", "Sarah Mitchell", "sarah-mitchell", "Covers search, content strategy and how audiences actually find things."],
  ["Daniel Carter", "Daniel Carter", "daniel-carter", "Follows the advertising technology stack and the money moving through it."],
  ["Emily Wilson", "Emily Wilson", "emily-wilson", "Reports on social platforms, community and the commerce built on top of them."],
  ["Michael Anderson", "Michael Anderson", "michael-anderson", "Writes about measurement, customer data and the systems that hold them."],
];

// 20 posts. Original development copy - nothing is reproduced from anywhere.
//
// Columns: title, slug, category slug, subcategory slug (null = category only),
//          author slug, status, days ago, reading time.
const POSTS = [
  ["How AI Is Changing Digital Marketing Strategies", "ai-changing-digital-marketing-strategies", "digital-marketing", "content-marketing", "alex-morgan", "published", 92, 8],
  ["The Future of Generative AI in Marketing", "future-of-generative-ai-in-marketing", "artificial-intelligence", "generative-ai", "alex-morgan", "published", 87, 11],
  ["Programmatic Advertising Trends for Modern Brands", "programmatic-advertising-trends-modern-brands", "advertising-technology", "programmatic-advertising", "daniel-carter", "published", 81, 7],
  ["Building a Better SEO Content Strategy", "building-a-better-seo-content-strategy", "digital-marketing", "seo", "sarah-mitchell", "published", 76, 9],
  ["Marketing Automation: From Leads to Revenue", "marketing-automation-from-leads-to-revenue", "martech", "marketing-automation", "michael-anderson", "published", 70, 12],
  ["How Social Commerce Is Changing Online Retail", "how-social-commerce-is-changing-online-retail", "social-media", "social-commerce", "emily-wilson", "published", 64, 6],
  ["Using Marketing Analytics to Improve Campaign Performance", "using-marketing-analytics-to-improve-campaign-performance", "data-analytics", "marketing-analytics", "michael-anderson", "published", 58, 10],
  ["The Role of Customer Data Platforms in Martech", "role-of-customer-data-platforms-in-martech", "martech", "crm", "michael-anderson", "published", 52, 13],
  ["AI-Powered Personalization in Digital Marketing", "ai-powered-personalization-in-digital-marketing", "artificial-intelligence", "ai-automation", "alex-morgan", "published", 47, 8],
  ["How Brands Can Improve Their Content Distribution", "how-brands-can-improve-content-distribution", "digital-marketing", null, "sarah-mitchell", "published", 41, 5],
  ["Programmatic Buying and the Evolution of Digital Advertising", "programmatic-buying-evolution-of-digital-advertising", "advertising-technology", "ad-platforms", "daniel-carter", "published", 36, 14],
  ["Social Media Listening for Better Customer Insights", "social-media-listening-for-better-customer-insights", "social-media", "social-media-marketing", "emily-wilson", "published", 30, 7],
  ["Generative AI Tools for Marketing Teams", "generative-ai-tools-for-marketing-teams", "artificial-intelligence", null, "alex-morgan", "published", 25, 4],
  ["Measuring ROI Across Digital Marketing Channels", "measuring-roi-across-digital-marketing-channels", "data-analytics", "marketing-analytics", "michael-anderson", "published", 21, 11],
  ["Marketing Automation Workflows Every Team Should Consider", "marketing-automation-workflows-every-team-should-consider", "martech", "marketing-automation", "sarah-mitchell", "published", 16, 9],
  ["The Growing Importance of First-Party Data", "growing-importance-of-first-party-data", "data-analytics", "customer-data", "michael-anderson", "published", 11, 6],
  ["SEO Strategies for Content-Heavy Websites", "seo-strategies-for-content-heavy-websites", "digital-marketing", "seo", "sarah-mitchell", "draft", 8, 10],
  ["How Martech Platforms Improve Customer Engagement", "how-martech-platforms-improve-customer-engagement", "martech", null, "michael-anderson", "draft", 6, 8],
  ["Data-Driven Decision Making for Marketing Teams", "data-driven-decision-making-for-marketing-teams", "social-media", null, "emily-wilson", "draft", 4, 7],
  ["Emerging Trends in Advertising Technology", "emerging-trends-in-advertising-technology", "advertising-technology", null, "daniel-carter", "draft", 2, 15],
];

// ---------------------------------------------------------------------------
// CONTENT GENERATION
// ---------------------------------------------------------------------------

/**
 * Build an article body. Deliberately generated rather than copied: the point
 * is realistic *shape* - headings, paragraphs, a list, a quote - so the website
 * has something true-to-life to render and sanitise.
 */
function buildContent(title, categoryName, subcategoryName) {
  const topic = subcategoryName || categoryName;

  return [
    `<p>${title} is a question a lot of teams are working through right now. `,
    `The pressure is rarely the technology itself - it is deciding which parts `,
    `of ${topic.toLowerCase()} are worth the operational cost of adopting.</p>`,
    `<h2>Where teams usually start</h2>`,
    `<p>Most teams begin with the measurement problem rather than the tooling `,
    `problem. Until it is clear what a campaign is supposed to move, adding `,
    `another platform to the ${categoryName.toLowerCase()} stack tends to add `,
    `reporting overhead rather than clarity.</p>`,
    `<ul>`,
    `<li>Agree what the campaign is accountable for before choosing tooling.</li>`,
    `<li>Instrument the handful of events that actually change a decision.</li>`,
    `<li>Give the work somewhere to live once the pilot finishes.</li>`,
    `</ul>`,
    `<h2>What changes in practice</h2>`,
    `<p>The teams that get value out of ${topic.toLowerCase()} usually treat it `,
    `as a workflow change rather than a purchase. That means someone owns the `,
    `output, someone reviews it, and there is an agreed way to tell whether it `,
    `worked.</p>`,
    `<blockquote>The constraint is almost never the model or the platform. It is `,
    `whether anyone downstream is set up to act on what comes out.</blockquote>`,
    `<h2>Where it tends to go wrong</h2>`,
    `<p>Two failure modes come up repeatedly: buying capability nobody has time `,
    `to operate, and running a pilot with no route into the day job. Both are `,
    `avoidable, and both are cheaper to avoid than to unwind.</p>`,
    `<p>None of this makes ${topic.toLowerCase()} simple. It does make it `,
    `tractable, which is usually the more useful outcome.</p>`,
  ].join("");
}

function buildExcerpt(title, categoryName) {
  return (
    `A practical look at ${title.toLowerCase().replace(/^(how|the|using|building|measuring) /, "")}` +
    `, and what it actually changes for ${categoryName.toLowerCase()} teams.`
  ).slice(0, 480);
}

const daysAgo = (n) => new Date(Date.now() - n * 24 * 60 * 60 * 1000);

// ---------------------------------------------------------------------------
// SAFETY
// ---------------------------------------------------------------------------

function assertLocalDevelopment() {
  if (process.env.NODE_ENV === "production") {
    throw new Error("refusing to seed: NODE_ENV is production");
  }

  const host = process.env.DB_HOST;

  if (!["127.0.0.1", "::1", "localhost"].includes(host)) {
    throw new Error(`refusing to seed: DB_HOST is "${host}", which is not local`);
  }
}

// ---------------------------------------------------------------------------
// SEED
// ---------------------------------------------------------------------------

async function seed() {
  assertLocalDevelopment();

  const summary = {
    users: { created: 0, existing: 0 },
    categories: { created: 0, existing: 0 },
    subcategories: { created: 0, existing: 0 },
    authors: { created: 0, existing: 0 },
    posts: { created: 0, existing: 0 },
  };

  await sequelize.transaction(async (transaction) => {
    // ---- 1. CMS users -----------------------------------------------------
    const users = {};

    for (const spec of USERS) {
      let user = await User.findOne({
        where: { username: spec.username },
        transaction,
      });

      if (user) {
        summary.users.existing += 1;
      } else {
        // The model's beforeCreate hook hashes this with bcrypt.
        user = await User.create(
          {
            username: spec.username,
            full_name: spec.full_name,
            email: spec.email,
            password: PASSWORD,
            status: 1,
          },
          { transaction }
        );

        summary.users.created += 1;
      }

      // Idempotent: an existing grant is reported as unchanged, never
      // duplicated - user_roles carries UNIQUE(user_id, role_id).
      await rbac.assignRolesToUser(user.id, spec.roles, { transaction });

      users[spec.username] = user;
    }

    // ---- 2. Categories ----------------------------------------------------
    const categories = {};

    for (const [name, slug, description] of CATEGORIES) {
      let row = await Category.findOne({ where: { slug }, transaction });

      if (row) {
        summary.categories.existing += 1;
      } else {
        row = await Category.create(
          {
            name,
            slug,
            status: 1,
            meta_title: name,
            meta_description: description,
            meta_keywords: name.toLowerCase(),
          },
          { transaction }
        );

        summary.categories.created += 1;
      }

      categories[slug] = row;
    }

    // ---- 3. Subcategories -------------------------------------------------
    const subcategories = {};

    for (const [categorySlug, name, slug] of SUBCATEGORIES) {
      const parent = categories[categorySlug];

      if (!parent) throw new Error(`unknown parent category ${categorySlug}`);

      let row = await Subcategory.findOne({ where: { slug }, transaction });

      if (row) {
        summary.subcategories.existing += 1;
      } else {
        row = await Subcategory.create(
          {
            category_id: parent.id,
            name,
            slug,
            status: 1,
            meta_title: name,
            meta_description: `${name} coverage within ${parent.name}.`,
            meta_keywords: name.toLowerCase(),
          },
          { transaction }
        );

        summary.subcategories.created += 1;
      }

      subcategories[slug] = row;
    }

    // ---- 4. Public authors ------------------------------------------------
    //
    // No user_id, no login, no role. An author is a byline and nothing more.
    // created_by records which CMS operator maintains the profile, which does
    // NOT make that operator the author.
    const authors = {};
    const maintainer = users["admin"];

    for (const [name, displayName, slug, bio] of AUTHORS) {
      let row = await Author.findOne({ where: { slug }, transaction });

      if (row) {
        summary.authors.existing += 1;
      } else {
        row = await Author.create(
          {
            name,
            display_name: displayName,
            slug,
            bio: `<p>${bio}</p>`,
            status: 1,
            created_by: maintainer ? maintainer.id : null,
            updated_by: maintainer ? maintainer.id : null,
          },
          { transaction }
        );

        summary.authors.created += 1;
      }

      authors[slug] = row;
    }

    // ---- 5. Posts ---------------------------------------------------------
    const operators = [users["admin"], users["editor.one"], users["editor.two"]];

    for (const [index, spec] of POSTS.entries()) {
      const [
        title, slug, categorySlug, subcategorySlug, authorSlug, status, ago, readingTime,
      ] = spec;

      const existing = await Post.findOne({ where: { slug }, transaction });

      if (existing) {
        summary.posts.existing += 1;
        continue;
      }

      if (!STATUSES.includes(status)) {
        throw new Error(`post "${slug}" uses unsupported status "${status}"`);
      }

      const category = categories[categorySlug];
      const subcategory = subcategorySlug ? subcategories[subcategorySlug] : null;
      const author = authors[authorSlug];

      if (!category) throw new Error(`unknown category ${categorySlug}`);
      if (subcategorySlug && !subcategory) throw new Error(`unknown subcategory ${subcategorySlug}`);
      if (!author) throw new Error(`unknown author ${authorSlug}`);

      // Spread the audit columns across all three operators, and make the
      // updater differ from the creator often enough to be worth testing.
      const creator = operators[index % operators.length];
      const updater = operators[(index + 1) % operators.length];

      const createdAt = daysAgo(ago);
      const updatedAt = daysAgo(Math.max(0, ago - 2));

      await Post.create(
        {
          title,
          slug,
          content: buildContent(title, category.name, subcategory ? subcategory.name : null),
          excerpt: buildExcerpt(title, category.name),
          status,

          // The public byline lives in authors; the CMS operators live in
          // users. Different columns, different tables, on purpose.
          author_id: author.id,
          category_id: category.id,
          subcategory_id: subcategory ? subcategory.id : null,
          created_by: creator.id,
          updated_by: updater.id,

          reading_time: readingTime,
          show_banner: 1,
          auto_publish: 0,
          published_at: status === "published" ? createdAt : null,

          meta_title: title,
          meta_description: buildExcerpt(title, category.name).slice(0, 250),
          meta_keywords: [category.name, subcategory ? subcategory.name : null]
            .filter(Boolean)
            .join(", ")
            .toLowerCase(),

          created_at: createdAt,
          updated_at: updatedAt,
        },
        { transaction, silent: true }
      );

      summary.posts.created += 1;
    }
  });

  // The public site reads the taxonomy through a TTL cache; drop it so the
  // seeded categories appear immediately rather than up to a minute later.
  require("../services/category.service").invalidate();

  return summary;
}

// ---------------------------------------------------------------------------

seed()
  .then(async (summary) => {
    const line = (label, s) =>
      console.log(`  ${label.padEnd(15)} ${String(s.created).padStart(3)} created, ${String(s.existing).padStart(3)} already present`);

    console.log("\nDevelopment seed complete\n");
    line("users", summary.users);
    line("categories", summary.categories);
    line("subcategories", summary.subcategories);
    line("authors", summary.authors);
    line("posts", summary.posts);

    console.log("\n  Sign in at POST /api/admin/auth/login with any of:");
    USERS.forEach((u) => console.log(`    ${u.email.padEnd(32)} ${u.roles.join(",").padEnd(20)} ${u.note}`));
    console.log(`\n  Password for all three: ${PASSWORD}`);
    console.log("  (development only - set SEED_PASSWORD to override)\n");

    await sequelize.close();
  })
  .catch(async (error) => {
    console.error("\nSeed failed - the transaction was rolled back, nothing was written.");
    console.error(`  ${error.message}\n`);

    try {
      await sequelize.close();
    } catch {
      /* already closed */
    }

    process.exitCode = 1;
  });
