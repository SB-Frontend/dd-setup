// scripts/db-health.js
//
// Local database health check.  node scripts/db-health.js
//
// Deliberately a CLI script and NOT an HTTP endpoint: the useful output here
// includes the server version, the data directory and the migration state,
// none of which should ever be reachable from the network. Nothing printed
// contains a password - the connection is made from the same .env the
// application uses, and only non-secret facts are echoed.
//
// Exits non-zero when the environment is not usable, so it can gate a task.

require("dotenv").config();

const path = require("path");
const fs = require("fs");

const mysql = require("mysql2/promise");

const MIGRATIONS_DIR = path.resolve(__dirname, "..", "migrations");

async function main() {
  const config = {
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
  };

  const problems = [];

  console.log("target      %s:%s/%s", config.host, config.port, config.database);

  let conn;

  try {
    conn = await mysql.createConnection({ ...config, connectTimeout: 5000 });
  } catch (error) {
    console.error("connection  FAIL - %s", error.code || error.message);
    process.exitCode = 1;

    return;
  }

  console.log("connection  OK");

  // ---- server identity ----
  const [[server]] = await conn.query(
    "SELECT VERSION() version, @@version_comment comment, @@port port, " +
      "@@datadir datadir, @@character_set_database charset, " +
      "@@collation_database collation, @@sql_mode sql_mode"
  );

  console.log("server      %s (%s)", server.version, server.comment);
  console.log("datadir     %s", server.datadir);
  console.log("charset     %s / %s", server.charset, server.collation);
  console.log("sql_mode    %s", server.sql_mode || "(empty)");

  if (!/^8\./.test(server.version) && !/MariaDB/i.test(server.comment)) {
    problems.push(`unexpected server version ${server.version}`);
  }

  if (!String(server.charset).startsWith("utf8mb4")) {
    problems.push(`database charset is ${server.charset}, expected utf8mb4`);
  }

  // A local development database must never be a remote host.
  if (!["127.0.0.1", "::1", "localhost"].includes(config.host)) {
    problems.push(`DB_HOST is ${config.host}, which is not local`);
  }

  // ---- migration state ----
  const onDisk = fs
    .readdirSync(MIGRATIONS_DIR)
    .filter((f) => f.endsWith(".js"))
    .sort();

  let applied = [];

  try {
    const [rows] = await conn.query("SELECT name FROM sequelize_meta ORDER BY name");

    applied = rows.map((r) => r.name);
  } catch {
    problems.push("sequelize_meta is missing - migrations have never run");
  }

  const pending = onDisk.filter((f) => !applied.includes(f));
  const unknown = applied.filter((f) => !onDisk.includes(f));

  console.log("migrations  %d applied, %d pending", applied.length, pending.length);

  if (pending.length > 0) {
    pending.forEach((f) => console.log("  pending   %s", f));
    problems.push(`${pending.length} migration(s) pending`);
  }

  if (unknown.length > 0) {
    unknown.forEach((f) => console.log("  unknown   %s", f));
    problems.push(`${unknown.length} applied migration(s) have no file`);
  }

  // ---- schema shape ----
  const [tables] = await conn.query(
    "SELECT TABLE_NAME n, ENGINE e FROM information_schema.TABLES " +
      "WHERE TABLE_SCHEMA = ? AND TABLE_TYPE = 'BASE TABLE'",
    [config.database]
  );

  console.log("tables      %d", tables.length);

  const nonInnodb = tables.filter((t) => t.e !== "InnoDB");

  if (nonInnodb.length > 0) {
    // MyISAM silently ignores foreign keys, so this would quietly dismantle
    // referential integrity rather than fail loudly.
    problems.push(
      `non-InnoDB tables: ${nonInnodb.map((t) => `${t.n}=${t.e}`).join(", ")}`
    );
  }

  const [[fkCount]] = await conn.query(
    "SELECT COUNT(*) n FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = ?",
    [config.database]
  );

  console.log("foreign keys %d", fkCount.n);

  // The architectural invariant that matters most: authors are not users.
  const [[authorUserId]] = await conn.query(
    "SELECT COUNT(*) n FROM information_schema.COLUMNS " +
      "WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'authors' AND COLUMN_NAME = 'user_id'",
    [config.database]
  );

  if (authorUserId.n > 0) {
    problems.push("authors.user_id exists - CMS users and public authors must stay separate");
  }

  await conn.end();

  console.log("");

  if (problems.length === 0) {
    console.log("HEALTH: OK");
  } else {
    console.log("HEALTH: %d problem(s)", problems.length);
    problems.forEach((p) => console.log("  - %s", p));
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error("health check failed:", error.message);
  process.exitCode = 1;
});
