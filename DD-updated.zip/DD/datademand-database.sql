-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 03, 2026 at 09:54 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `datademand`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `category_subcategory_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `category_subcategory_view`;
CREATE TABLE IF NOT EXISTS `category_subcategory_view` (
`cat_id` bigint
,`cat_name` varchar(200)
,`cat_slug` varchar(200)
,`subcat_id` int
,`subcat_name` varchar(50)
,`subcat_slug` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
CREATE TABLE IF NOT EXISTS `leads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `comments` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `first_name`, `last_name`, `email`, `company`, `phone`, `message`, `comments`, `created_at`) VALUES
(1, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', 'Followed up with the client. They are interested and will confirm by tomorrow.<br>lead closed<br>lead closed', '2026-01-27 14:07:55'),
(2, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', '', '2026-01-27 14:08:01'),
(3, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', '', '2026-01-27 14:08:09'),
(4, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', '', '2026-01-27 14:30:23'),
(5, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', '', '2026-01-27 14:30:25'),
(6, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', '', '2026-01-27 15:26:53'),
(7, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', '', '2026-01-27 15:27:52'),
(8, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', '', '2026-01-27 16:15:54'),
(9, 'John', 'Doe', 'test@example4.com', 'Test Company', '1234567890', 'Hello, this is a test message. Please ignore. Thank you.', '', '2026-01-27 16:15:57'),
(10, 'Sujitsingh', 'Bhadoriya', 'sbhadoriya@kingsresearch.com', 'KR', '1234567890', 'fsdfds', '', '2026-01-27 17:39:00'),
(11, 'fdg', 'gdfg', 'sdfg@fgdfg', 'KR', '78451239695', 'bnn', '', '2026-01-28 10:38:04');

-- --------------------------------------------------------

--
-- Table structure for table `media_list`
--

DROP TABLE IF EXISTS `media_list`;
CREATE TABLE IF NOT EXISTS `media_list` (
  `media_id` int NOT NULL AUTO_INCREMENT,
  `media_title` varchar(255) NOT NULL,
  `media_path` text NOT NULL,
  `user_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`media_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `media_list`
--

INSERT INTO `media_list` (`media_id`, `media_title`, `media_path`, `user_id`, `created_at`) VALUES
(22, 'Company Banner', '1788337799917-media_path-1733833210410-protein-hydrolysate-market-1.webp', 149, '2026-09-02 08:29:59'),
(21, 'Company Banner', '1788337772536-media_path-1733833210410-protein-hydrolysate-market-1.webp', 149, '2026-09-02 08:29:32');

-- --------------------------------------------------------

--
-- Table structure for table `post_data`
--

DROP TABLE IF EXISTS `post_data`;
CREATE TABLE IF NOT EXISTS `post_data` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_slug` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_date` datetime NOT NULL,
  `reading_time` int DEFAULT NULL,
  `post_author` int UNSIGNED DEFAULT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_modified` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `banner_show` int DEFAULT '1',
  `auto_publish` int NOT NULL DEFAULT '0',
  `cat_id` int UNSIGNED DEFAULT NULL,
  `meta_keywords` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `banner_img` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `meta_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `meta_description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `post_Created` datetime DEFAULT CURRENT_TIMESTAMP,
  `session_user` int NOT NULL,
  `comments` text NOT NULL,
  `post_updated_date` datetime DEFAULT NULL,
  `post_priority` int DEFAULT NULL,
  `comment_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_name` (`post_slug`),
  KEY `post_author` (`post_author`,`post_date`),
  KEY `post_status` (`post_status`,`cat_id`),
  KEY `post_Created` (`post_Created`,`session_user`),
  KEY `post_modified` (`post_modified`)
) ENGINE=MyISAM AUTO_INCREMENT=83034 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `post_data`
--

INSERT INTO `post_data` (`id`, `post_title`, `post_content`, `post_slug`, `post_date`, `reading_time`, `post_author`, `post_status`, `post_modified`, `banner_show`, `auto_publish`, `cat_id`, `meta_keywords`, `banner_img`, `meta_title`, `meta_description`, `post_Created`, `session_user`, `comments`, `post_updated_date`, `post_priority`, `comment_by`) VALUES
(83031, 'MarTech360 Interview with Miruna Dragomir, Chief Marketing Officer at Planable test', '<h1>Complete guide to Node.js microservices</h1><p>Learn architecture, deployment, and scaling...</p>', 'crm-tools-with-automation:our-top-picks-for-2025', '2026-01-28 13:00:00', 5, 148, 'published', '2026-09-01 17:32:59', 1, 0, 1, 'nodejs,microservices,aws,backend,scalable', NULL, 'Node.js Microservices Complete Guide 2026', 'Learn Node.js microservices architecture AWS deployment and scaling patterns for production.', '2026-08-31 08:22:24', 148, '[]', '2026-08-31 10:17:43', 1, NULL),
(83032, 'CRM tools with automation: Our top picks for 2025', '<h1>Complete guide to Node.js microservices</h1><p>Learn architecture, deployment, and scaling...</p>', 'cMarTech360 Interview with Miruna Dragomir, Chief Marketing Officer at Planable test', '2026-01-28 13:00:00', 9, 148, 'published', '2026-09-01 17:33:07', 1, 0, 2, 'nodejs,microservices,aws,backend,scalable', NULL, 'Node.js Microservices Complete Guide 2026', 'Learn Node.js microservices architecture AWS deployment and scaling patterns for production.', '2026-09-01 10:59:37', 1, '[]', '2026-01-28 13:00:00', 1, NULL),
(83033, 'TEst', '', 'test', '2026-09-01 18:30:00', NULL, 148, 'draft', NULL, 0, 0, 1, 'Test', '1788364780674-nasa-q1p7bh3shj8-unsplash.jpg', ' Test Meta Title', ' Test Meta Title', '2026-09-02 15:59:40', 149, '\r\n    <b>By admin2 [2026-09-02 21:29:40]:</b>\r\n    TEst\r\n  ', '2026-09-01 18:30:00', NULL, 149);

-- --------------------------------------------------------

--
-- Stand-in structure for view `post_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `post_view`;
CREATE TABLE IF NOT EXISTS `post_view` (
`id` bigint unsigned
,`post_title` text
,`post_content` longtext
,`reading_time` int
,`post_slug` varchar(250)
,`post_author` int unsigned
,`author_id` int
,`author_name` varchar(255)
,`author_display_name` varchar(255)
,`author_photo` text
,`author_description` text
,`post_status` varchar(20)
,`banner_img` longtext
,`banner_show` int
,`post_date` datetime
,`auto_publish` int
,`cat_id` int unsigned
,`cat_name` varchar(200)
,`cat_slug` varchar(200)
,`meta_title` text
,`meta_description` mediumtext
,`meta_keywords` text
,`post_created` datetime
,`post_modified` datetime
,`session_user` int
,`session_user_name` varchar(255)
,`comments` text
,`comment_by` int
,`comment_by_name` varchar(255)
,`post_updated_date` datetime
,`post_priority` int
);

-- --------------------------------------------------------

--
-- Table structure for table `p_cat`
--

DROP TABLE IF EXISTS `p_cat`;
CREATE TABLE IF NOT EXISTS `p_cat` (
  `cat_id` bigint NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cat_slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `meta_title` varchar(250) NOT NULL,
  `meta_desc` varchar(250) NOT NULL,
  `meta_keywords` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `cat_id` (`cat_id`,`cat_slug`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `p_cat`
--

INSERT INTO `p_cat` (`cat_id`, `cat_name`, `cat_slug`, `created_at`, `updated_at`, `meta_title`, `meta_desc`, `meta_keywords`) VALUES
(1, 'Account-Based Marketing', 'account-based-marketing', '2026-09-01 17:27:54', '0000-00-00 00:00:00', 'Account-Based Marketing', 'Account-Based Marketing', 'account based marketing, ABM'),
(2, 'Content Syndication', 'content-syndication', '2026-09-01 17:27:54', '0000-00-00 00:00:00', 'Content Syndication', 'Content Syndication', 'content syndication'),
(3, 'Demand Generation', 'demand-generation', '2026-09-01 17:27:54', '0000-00-00 00:00:00', 'Demand Generation', 'Demand Generation', 'demand generation'),
(4, 'Intent & Signals', 'intent-signals', '2026-09-01 17:27:54', '0000-00-00 00:00:00', 'Intent & Signals', 'Intent & Signals', 'intent signals'),
(5, 'Market Intelligence', 'market-intelligence', '2026-09-01 17:27:54', '0000-00-00 00:00:00', 'Market Intelligence', 'Market Intelligence', 'market intelligence'),
(6, 'Performance Measurement', 'performance-measurement', '2026-09-01 17:27:54', '0000-00-00 00:00:00', 'Performance Measurement', 'Performance Measurement', 'performance measurement'),
(7, 'Sales & Marketing Alignment', 'sales-marketing-alignment', '2026-09-01 17:27:54', '0000-00-00 00:00:00', 'Sales & Marketing Alignment', 'Sales & Marketing Alignment', 'sales marketing alignment'),
(8, 'Signal Validation', 'signal-validation', '2026-09-01 17:27:54', '0000-00-00 00:00:00', 'Signal Validation', 'Signal Validation', 'signal validation'),
(9, 'Testing', 'testing', '2026-09-01 14:17:44', '2026-09-01 14:17:44', 'Global Intelligent Document Processing Market', 'Global Herbicides Market', 'Global Intelligent Document Processing Market');

-- --------------------------------------------------------

--
-- Table structure for table `p_sub_cat`
--

DROP TABLE IF EXISTS `p_sub_cat`;
CREATE TABLE IF NOT EXISTS `p_sub_cat` (
  `subcat_id` int NOT NULL AUTO_INCREMENT,
  `subcat_name` varchar(50) NOT NULL,
  `subcat_slug` varchar(50) NOT NULL,
  `p_cat` int NOT NULL,
  `meta_title` varchar(250) NOT NULL,
  `meta_desc` varchar(250) NOT NULL,
  `meta_keywords` varchar(250) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`subcat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  `rolename` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_role` (`role`),
  KEY `roles_rolename` (`rolename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `email`, `name`, `created_at`, `updated_at`) VALUES
(1, 'test@example1.com', 'Jane1', '2026-01-27 13:46:20', '2026-01-27 13:46:20'),
(2, 'test@example2.com', 'Jane1', '2026-01-27 13:47:07', '2026-01-27 13:47:07'),
(3, 'test@example3.com', 'Jane1', '2026-01-27 13:53:29', '2026-01-27 13:53:29'),
(4, 'test@example4.com', 'Jane1', '2026-01-27 15:19:32', '2026-01-27 15:19:32'),
(5, 'jogn@gmail.com', 'Jopgn', '2026-01-27 17:35:18', '2026-01-27 17:35:18'),
(6, 'asdf@we', 'sdfasd', '2026-01-27 17:35:47', '2026-01-27 17:35:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(110) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `author_photo` text,
  `author_description` text,
  `user_status` int NOT NULL DEFAULT '1',
  `is_author` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_email` (`user_email`),
  UNIQUE KEY `user_email_5` (`user_email`),
  UNIQUE KEY `user_email_6` (`user_email`),
  UNIQUE KEY `user_email_7` (`user_email`),
  UNIQUE KEY `user_email_8` (`user_email`),
  UNIQUE KEY `user_email_9` (`user_email`),
  UNIQUE KEY `user_email_10` (`user_email`),
  UNIQUE KEY `user_email_11` (`user_email`),
  UNIQUE KEY `user_email_12` (`user_email`),
  UNIQUE KEY `user_email_13` (`user_email`),
  UNIQUE KEY `user_email_14` (`user_email`),
  UNIQUE KEY `user_email_15` (`user_email`),
  UNIQUE KEY `user_email_16` (`user_email`),
  UNIQUE KEY `user_email_17` (`user_email`),
  UNIQUE KEY `user_email_18` (`user_email`),
  UNIQUE KEY `user_email_19` (`user_email`),
  UNIQUE KEY `user_email_20` (`user_email`),
  UNIQUE KEY `user_email_21` (`user_email`),
  UNIQUE KEY `user_email_22` (`user_email`),
  UNIQUE KEY `user_email_23` (`user_email`),
  UNIQUE KEY `user_email_24` (`user_email`),
  UNIQUE KEY `user_email_25` (`user_email`),
  UNIQUE KEY `user_email_26` (`user_email`),
  UNIQUE KEY `user_email_27` (`user_email`),
  UNIQUE KEY `user_email_28` (`user_email`),
  UNIQUE KEY `user_email_29` (`user_email`),
  UNIQUE KEY `user_email_30` (`user_email`),
  UNIQUE KEY `user_email_31` (`user_email`),
  UNIQUE KEY `user_email_32` (`user_email`),
  UNIQUE KEY `user_email_33` (`user_email`),
  UNIQUE KEY `user_email_34` (`user_email`),
  UNIQUE KEY `user_email_35` (`user_email`),
  UNIQUE KEY `user_email_36` (`user_email`),
  UNIQUE KEY `user_email_37` (`user_email`),
  UNIQUE KEY `user_email_38` (`user_email`),
  UNIQUE KEY `user_email_39` (`user_email`),
  UNIQUE KEY `user_email_40` (`user_email`),
  UNIQUE KEY `user_email_41` (`user_email`),
  UNIQUE KEY `user_email_42` (`user_email`),
  UNIQUE KEY `user_email_43` (`user_email`),
  UNIQUE KEY `user_email_44` (`user_email`),
  UNIQUE KEY `user_email_45` (`user_email`),
  UNIQUE KEY `user_email_46` (`user_email`),
  UNIQUE KEY `user_email_47` (`user_email`),
  UNIQUE KEY `user_email_48` (`user_email`),
  UNIQUE KEY `user_email_49` (`user_email`),
  UNIQUE KEY `user_email_50` (`user_email`),
  UNIQUE KEY `user_email_51` (`user_email`),
  UNIQUE KEY `user_email_52` (`user_email`),
  UNIQUE KEY `user_email_53` (`user_email`),
  UNIQUE KEY `user_email_54` (`user_email`),
  UNIQUE KEY `user_email_55` (`user_email`),
  UNIQUE KEY `user_email_56` (`user_email`),
  UNIQUE KEY `user_email_57` (`user_email`),
  UNIQUE KEY `user_email_58` (`user_email`),
  UNIQUE KEY `user_email_59` (`user_email`),
  UNIQUE KEY `user_email_60` (`user_email`),
  UNIQUE KEY `user_email_61` (`user_email`),
  UNIQUE KEY `user_email_62` (`user_email`),
  UNIQUE KEY `uq_user_email` (`user_email`),
  UNIQUE KEY `user_email_2` (`user_email`),
  UNIQUE KEY `user_email_3` (`user_email`),
  KEY `users_user_status_created_at_is_author` (`user_status`,`created_at`,`is_author`)
) ENGINE=MyISAM AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_password`, `display_name`, `author_photo`, `author_description`, `user_status`, `is_author`, `created_at`, `updated_at`) VALUES
(155, 'admin5', 'admin5@datademand.com', '$2b$10$nPhhveDO2YuP/Q97OXQC4uY/ULbqKOzM2D9LE23yxYYhM0jGZErVa', 'admin5', NULL, NULL, 1, 0, '2026-09-01 14:37:30', '2026-09-01 14:37:30'),
(154, 'admin4', 'admin4@datademand.com', '$2b$10$8Fn6nk7k74NFOSuap/Gba.m7aWWE6SKm2TRGpphzyRk6anOH05Bde', 'admin4', NULL, NULL, 1, 0, '2026-09-01 14:36:23', '2026-09-01 14:36:23'),
(153, 'admin3', 'admin3@datademand.com', '$2b$10$LIeBgJzomZK0ACfZ0dyvX.Vpv6EiSYe1sDhoDc5Sw1FDZq6N0ARhC', 'admin3', NULL, NULL, 1, 0, '2026-09-01 14:29:54', '2026-09-01 14:29:54'),
(152, 'sujitsingh-testing', 'itbplp@gmail.com', '$2b$10$quKNTXNarrss33.LM5X0wedSWI6HebjA9xUXPvSqw553rKpvQqahG', 'Sujitsingh Testing', NULL, NULL, 1, 0, '2026-09-01 14:15:53', '2026-09-01 14:15:53'),
(151, '123test', 'admin@martech.com', '$2b$10$2cz3wE8M0yTWsZwpCBnX.eKy6hy84I1JnUAmLthbHFtHBKC5KiXRS', 'Testing', NULL, NULL, 1, 0, '2026-09-01 14:15:03', '2026-09-01 14:15:03'),
(150, 'testing123', 'test1@top.com', '$2b$10$qV.Q6jsATKi.SWXBxSXj/OgA4ry0n7jyAPszn6LmSfS.XyK2pu8MW', 'Testing', NULL, 'null', 1, 1, '2026-09-01 13:47:22', '2026-09-01 14:10:26'),
(149, 'admin2', 'admin2@datademand.com', '$2b$10$h5i8JMd/N0TTbKt1bSCep.h.7Lii/BhiFZk8ZMkIMGkGqOFPpNAi6', 'admin2', NULL, 'This is author', 1, 1, '2026-08-28 11:33:40', '2026-08-28 11:33:40'),
(148, 'admin', 'admin@datademand.com', '$2a$08$CLLeXZR.2ulfteH0z60GEuny2S.0c/PQCM2jbKl85p2W.ANinKljq', 'Admin', NULL, 'This is author', 1, 1, '2026-08-28 11:26:29', '2026-08-28 11:26:29');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE IF NOT EXISTS `user_roles` (
  `role_id` int NOT NULL,
  `user_id` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure for view `category_subcategory_view`
--
DROP TABLE IF EXISTS `category_subcategory_view`;

DROP VIEW IF EXISTS `category_subcategory_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `category_subcategory_view`  AS SELECT `c`.`cat_id` AS `cat_id`, `c`.`cat_name` AS `cat_name`, `c`.`cat_slug` AS `cat_slug`, `s`.`subcat_id` AS `subcat_id`, `s`.`subcat_name` AS `subcat_name`, `s`.`subcat_slug` AS `subcat_slug` FROM (`p_cat` `c` left join `p_sub_cat` `s` on((`c`.`cat_id` = `s`.`p_cat`))) ;

-- --------------------------------------------------------

--
-- Structure for view `post_view`
--
DROP TABLE IF EXISTS `post_view`;

DROP VIEW IF EXISTS `post_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `post_view`  AS SELECT `p`.`id` AS `id`, `p`.`post_title` AS `post_title`, `p`.`post_content` AS `post_content`, `p`.`reading_time` AS `reading_time`, `p`.`post_slug` AS `post_slug`, `p`.`post_author` AS `post_author`, `au`.`user_id` AS `author_id`, `au`.`user_name` AS `author_name`, `au`.`display_name` AS `author_display_name`, `au`.`author_photo` AS `author_photo`, `au`.`author_description` AS `author_description`, `p`.`post_status` AS `post_status`, `p`.`banner_img` AS `banner_img`, `p`.`banner_show` AS `banner_show`, `p`.`post_date` AS `post_date`, `p`.`auto_publish` AS `auto_publish`, `p`.`cat_id` AS `cat_id`, `c`.`cat_name` AS `cat_name`, `c`.`cat_slug` AS `cat_slug`, `p`.`meta_title` AS `meta_title`, `p`.`meta_description` AS `meta_description`, `p`.`meta_keywords` AS `meta_keywords`, `p`.`post_Created` AS `post_created`, `p`.`post_modified` AS `post_modified`, `p`.`session_user` AS `session_user`, `su`.`user_name` AS `session_user_name`, `p`.`comments` AS `comments`, `p`.`comment_by` AS `comment_by`, `cu`.`user_name` AS `comment_by_name`, `p`.`post_updated_date` AS `post_updated_date`, `p`.`post_priority` AS `post_priority` FROM ((((`post_data` `p` left join `p_cat` `c` on((`p`.`cat_id` = `c`.`cat_id`))) left join `users` `au` on((`p`.`post_author` = `au`.`user_id`))) left join `users` `cu` on((`p`.`comment_by` = `cu`.`user_id`))) left join `users` `su` on((`p`.`session_user` = `su`.`user_id`))) ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
