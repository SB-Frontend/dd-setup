-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 12, 2026 at 04:54 AM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `datademand_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int UNSIGNED DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_authors_slug` (`slug`),
  KEY `ix_authors_status_display_name` (`status`,`display_name`),
  KEY `ix_authors_created_by` (`created_by`),
  KEY `ix_authors_updated_by` (`updated_by`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_categories_slug` (`slug`),
  KEY `ix_categories_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
CREATE TABLE IF NOT EXISTS `leads` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_leads_email` (`email`),
  KEY `ix_leads_status` (`status`),
  KEY `ix_leads_created_at` (`created_at`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `lead_notes`
--

DROP TABLE IF EXISTS `lead_notes`;
CREATE TABLE IF NOT EXISTS `lead_notes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_lead_notes_lead_created` (`lead_id`,`created_at`),
  KEY `ix_lead_notes_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int UNSIGNED DEFAULT NULL,
  `storage_path` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'posts',
  `uploaded_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_media_filename` (`filename`),
  KEY `ix_media_uploaded_by` (`uploaded_by`),
  KEY `ix_media_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_permissions_permission_name` (`permission_name`),
  UNIQUE KEY `uq_permissions_permission_slug` (`permission_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_name`, `permission_slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Dashboard Management', 'dashboard_management', 'Access the CMS dashboard', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(2, 'Post Management', 'post_management', 'Create and edit posts', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(3, 'Post Publishing', 'post_publishing', 'Change a post status to published', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(4, 'User Management', 'user_management', 'Manage CMS user accounts and roles', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(5, 'Lead Management', 'lead_management', 'View and annotate leads and subscribers', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(6, 'Category Management', 'category_management', 'Manage categories and subcategories', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(7, 'Role Management', 'role_management', 'Manage roles and their permissions', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(8, 'Advertisement Management', 'advertisement_management', 'Manage advertisements', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(9, 'Author Management', 'author_management', 'Manage public author profiles', '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(10, 'Media Management', 'media_management', 'Upload and manage media', '2026-09-09 22:53:13', '2026-09-09 22:53:13');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `author_id` int UNSIGNED DEFAULT NULL,
  `category_id` int UNSIGNED DEFAULT NULL,
  `subcategory_id` int UNSIGNED DEFAULT NULL,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_banner` tinyint(1) NOT NULL DEFAULT '1',
  `reading_time` smallint UNSIGNED DEFAULT NULL,
  `priority` smallint NOT NULL DEFAULT '0',
  `auto_publish` tinyint(1) NOT NULL DEFAULT '0',
  `published_at` datetime DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_posts_slug` (`slug`),
  KEY `ix_posts_status_published_at` (`status`,`published_at`),
  KEY `ix_posts_category_status_published` (`category_id`,`status`,`published_at`),
  KEY `ix_posts_subcategory` (`subcategory_id`),
  KEY `ix_posts_author` (`author_id`),
  KEY `ix_posts_created_at` (`created_at`),
  KEY `ix_posts_created_by` (`created_by`),
  KEY `ix_posts_updated_by` (`updated_by`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_role_name` (`role_name`),
  UNIQUE KEY `uq_roles_role_slug` (`role_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `role_slug`, `description`, `is_system`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin', 'Full access to every module', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(2, 'Content Management', 'content_management', 'Owns the editorial pipeline', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(3, 'SEO Manager', 'seo_manager', 'Post metadata and taxonomy', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(4, 'Content Head', 'content_head', 'Editorial approval and publishing', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(5, 'Marketing Head', 'marketing_head', 'Leads, subscribers and advertisements', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(6, 'Graphics Team', 'graphics_team', 'Media assets', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(7, 'Content Writer', 'content_writer', 'Drafts posts, cannot publish', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(8, 'SEO Team', 'seo_team', 'Post metadata and taxonomy', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(9, 'Publisher', 'publisher', 'Reviews and publishes posts', 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE IF NOT EXISTS `role_permissions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` int UNSIGNED NOT NULL,
  `permission_id` int UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_permissions_role_permission` (`role_id`,`permission_id`),
  KEY `ix_role_permissions_permission` (`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`id`, `role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(2, 1, 2, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(3, 1, 3, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(4, 1, 4, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(5, 1, 5, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(6, 1, 6, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(7, 1, 7, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(8, 1, 8, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(9, 1, 9, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(10, 1, 10, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(11, 2, 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(12, 2, 2, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(13, 2, 3, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(14, 2, 6, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(15, 2, 9, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(16, 2, 10, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(17, 4, 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(18, 4, 2, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(19, 4, 3, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(20, 4, 6, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(21, 4, 9, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(22, 4, 10, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(23, 3, 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(24, 3, 2, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(25, 3, 6, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(26, 3, 10, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(27, 5, 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(28, 5, 5, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(29, 5, 8, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(30, 5, 10, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(31, 9, 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(32, 9, 2, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(33, 9, 3, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(34, 8, 1, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(35, 8, 2, '2026-09-09 22:53:13', '2026-09-09 22:53:13'),
(36, 8, 6, '2026-09-09 22:53:14', '2026-09-09 22:53:14'),
(37, 7, 1, '2026-09-09 22:53:14', '2026-09-09 22:53:14'),
(38, 7, 2, '2026-09-09 22:53:14', '2026-09-09 22:53:14'),
(39, 7, 10, '2026-09-09 22:53:14', '2026-09-09 22:53:14'),
(40, 6, 1, '2026-09-09 22:53:14', '2026-09-09 22:53:14'),
(41, 6, 10, '2026-09-09 22:53:14', '2026-09-09 22:53:14');

-- --------------------------------------------------------

--
-- Table structure for table `sequelize_meta`
--

DROP TABLE IF EXISTS `sequelize_meta`;
CREATE TABLE IF NOT EXISTS `sequelize_meta` (
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `sequelize_meta`
--

INSERT INTO `sequelize_meta` (`name`) VALUES
('20260908000001-baseline-schema.js'),
('20260910000001-drop-legacy-schema.js'),
('20260910000002-create-users.js'),
('20260910000003-create-rbac.js'),
('20260910000004-create-authors.js'),
('20260910000005-create-categories.js'),
('20260910000006-create-media.js'),
('20260910000007-create-posts.js'),
('20260910000008-create-leads.js'),
('20260910000009-create-subscriptions.js'),
('20260910000010-seed-rbac.js'),
('20260910000011-add-soft-delete.js');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

DROP TABLE IF EXISTS `subcategories`;
CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` int UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subcategories_category_slug` (`category_id`,`slug`),
  KEY `ix_subcategories_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'subscribed',
  `unsubscribed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subscriptions_email` (`email`),
  KEY `ix_subscriptions_status` (`status`)
) ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `ix_users_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int UNSIGNED NOT NULL,
  `role_id` int UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_roles_user_role` (`user_id`,`role_id`),
  KEY `ix_user_roles_role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `authors`
--
ALTER TABLE `authors`
  ADD CONSTRAINT `fk_authors_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_authors_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT;

--
-- Constraints for table `lead_notes`
--
ALTER TABLE `lead_notes`
  ADD CONSTRAINT `fk_lead_notes_lead` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_lead_notes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT;

--
-- Constraints for table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `fk_media_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `fk_posts_author` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_posts_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_posts_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_posts_subcategory` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_posts_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `fk_subcategories_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `fk_user_roles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_user_roles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
